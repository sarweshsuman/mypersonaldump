import os
import numpy as np

class PreprocessImageClassification:
    __separator='|'
    def __init__(self,initContext,component):
        self.__component = component
        self.__initialContext = initContext

    def get_generator(self,generator_from_last_step):
        self.__generator_from_last_step=generator_from_last_step
        def preprocess_generator():
            while True:
                #will always expect it to be list of lines with x and y separated by |
                lines=next(self.__generator_from_last_step)
                x=[]
                y=[]
                for line in lines:
                    if line == '':
                        print("Line is empty")
                        continue
                    x1, y1 = line.split(self.__separator)
                    x1_array_of_pixels = x1.split(',')
                    y1_array_of_classes = y1.split(',')
                    x1_numpy_array = np.array(x1_array_of_pixels,dtype=np.float32)
                    y1_numpy_array = np.array(y1_array_of_classes,dtype=np.float32)
                    x.append(x1_numpy_array)
                    y.append(y1_numpy_array)
                yield [x,y]
        return preprocess_generator()
