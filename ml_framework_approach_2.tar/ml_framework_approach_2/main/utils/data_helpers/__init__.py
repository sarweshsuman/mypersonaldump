from .mnist_data import Mnist
