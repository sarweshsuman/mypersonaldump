from tensorflow.examples.tutorials.mnist import input_data
import os

class Mnist:
    def __init__(self,initContext,component):
        self.__initialContext=initContext
        self.__component = component
        self.__batch_size=int(self.__component['batch_size'])
        self.__mnist = input_data.read_data_sets('MNIST_data', one_hot=True)
    def get_generator(self):
        def mnist_batch():
            while True:
               yield self.__mnist.train.next_batch(self.__batch_size)
        return mnist_batch()
