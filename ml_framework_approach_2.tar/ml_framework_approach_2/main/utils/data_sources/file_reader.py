import os
import random

class LocalFileReader:
    def __init__(self,initContext,component):
        self.__component = component
        self.__initialContext = initContext
        self.__batch_size = int(self.__component['batch_size'])
        self.__file_name = self.__component['file_name']
        if os.path.isfile(self.__file_name) == False:
            print("File {} does not exists ".format(self.__file_name))
            raise Exception("File {} does not exists ".format(self.__file_name))
        self.__file = open(self.__file_name,'r')
    def get_generator(self):
        def batch():
            while True:
                #print("Here ")
                count=0
                lines=[]
                try:
                    while count<self.__batch_size:
                        #print(count,end=',')
                        line=self.__file.readline()
                        if line=='':
                            self.__file.seek(0,0)
                            continue
                        lines.append(self.__file.readline())
                        count += 1
                except:
                    print("End of file reached")
                    self.__file.close()
                    self.__file = open(self.__file_name,'r')
                    count=0
                    continue
                random.shuffle(lines)
                #print("\n")
                #print(lines)
                yield lines
        return batch()
