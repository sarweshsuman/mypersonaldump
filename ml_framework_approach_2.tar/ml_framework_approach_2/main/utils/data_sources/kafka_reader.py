from main.utils.kafka.kafka_consumer import SimpleKafkaConsumer
import os

class Kafka:
    def __init__(self,initContext,component):
        self.__component = component
        self.__initialContext = initContext
        #Adding params to initial context as SimpleKafkaConsumer reterives params from initContext only.
        for param in self.__component:
            self.__initialContext[os.path.join(self.__initialContext['job_runner/run/jobname'],self.__class__.__name__,param)]=self.__component[param]
        self.__consumer = SimpleKafkaConsumer(os.path.join(self.__initialContext['job_runner/run/jobname'],self.__class__.__name__),self.__initialContext)
        self.__batch_size = int(self.__component['batch_size'])
        print("Initialized Kafka data source")
        #self.__batch_size = self.__initialContext['']
    def get_generator(self):
        def kafka_batch():
            while True:
                yield self.__consumer.get_n_messages(self.__batch_size)
        return kafka_batch()
