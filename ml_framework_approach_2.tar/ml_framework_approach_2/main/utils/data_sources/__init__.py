from .kafka_reader import Kafka
from .data_sources import DataSource
from ..data_helpers import Mnist
from .file_reader import LocalFileReader
