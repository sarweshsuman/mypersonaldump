# ####################################################################################################################################
#
# ####################################################################################################################################

package ProcessGroupManager; 

use strict;
use Carp;
use PMTExecContext;

sub new {
  my $package = shift;
  my %args = @_;

  my $o = {};
  my $parent_ic = $args{'initialcontext'};
  my $xnode = $args{'xnode'};
  my $name = $args{'name'};

  $o->{'initialcontext'} = new PMTExecContext($parent_ic); #new PMTExecContext($parent_ic);
  my $ic = $o->{'initialcontext'}; 
  $ic->{'RUNTIME/EXEC/GROUP'} = $name;
  
  $o->{'xnode'} = $ic->xnode(data=>$xnode->xnodePath()); # I basically need a clone, cause this xnode needs to be tied to the new ic
  $o->{'name'} = $name;
  $o->{'jobmanager'} = $args{'jobmanager'};
  $o->{'_pool_'} = {};
  $o->{'_setup_'} = 0;
  $o->{'started_'} = 0;
  $o->{'_running_'} = 0;
  $o->{'_finished_'} = 0;
  $o->{'_waitnotified_'} = 0;

  use Time::HiRes qw(time);
  $ic->appendJLOG(directives=>{type=>'event',context=>{group=>$name},mtime=>time()},data=>{event_type=>'process_group_create'});
  $ic->log(message=>"Created a processjobmanager for group $name",domain=>"system",level=>"info");
  return bless $o;
}


sub setup {
  my $self = shift;
  my $name = $self->{'name'};
  my $xnode = $self->{'xnode'};
  my $ic = $self->{'initialcontext'};
  my $name = $self->{'name'};
 
  if ($self->{'_setup_'}) { return ; }

  # Actually I should check if there's wait condiition now
  if (not $self->{'_waitnotified'}) {
    $ic->log(message=>"Doing setup in processgroupmanager $name",domain=>"system",level=>"debug");
  }
  my $waitcondition = $xnode->evalPreReqs(condition_type=>'wait');
  if (not $waitcondition) {
    if (not $self->{'_waitnotified_'}) {
    	$ic->log(message=>"Group $name wait condition not fullfilled ... group $name setup will have to wait",domain=>"system",level=>"info");
      $self->{'_waitnotified_'} = 1;
    }
    return;
  }
  # the wait condition is ok but is the condition to use it also ok ?
  my $use_condition = $xnode->evalPreReqs(condition_type=>'condition');
  if (not $use_condition) {
    $self->{'_finished_'} = 1;
    $ic->log(message=>"Group $name does not have to run, condition 'condition' fail",domain=>"system",level=>"info");
    $ic->appendJLOG(directives=>{type=>'event',context=>{group=>$name},mtime=>time()},data=>{event_type=>'process_group_end',detail=>{status=>'condition_fail'}});
    return;
  }

  # I need the helper:

  # find the number of subprocesses:
  my $max_processes;
  if ($xnode->exists('config/param[@name="subprocesses"]')) {
    $max_processes = $xnode->xfind('config/param[@name="subprocesses"]');
  }
  else {
    # base ourselves on the Sys::CPU module
    use Sys::CPU;
    my $number_of_cpus = Sys::CPU::cpu_count();
    $max_processes = $number_of_cpus;
    $ic->log(message=>"I got $number_of_cpus cpus",domain=>"system",level=>"debug");
  }

  my $helper_node = $xnode->xfind('config/param[@name="helper"]');


  my $loopdriver;
  my $empty_policy ;

  use PMTIteratorBase;
  use UNIVERSAL;
  use PMTWorkList;
  if ($xnode->exists('loopdriver')) {
    $loopdriver = $xnode->xfind('loopdriver');
    $ic->log(message=>"Group $name has a loopdriver",domain=>"system",level=>"debug");
    use PMTIteratorBase;
    if (defined $loopdriver and ref $loopdriver) {
    #if ($loopdriver and ref $loopdriver) {
      my $rld = ref $loopdriver;
      $ic->log(message=>"I found a loopdriver: $rld",domain=>"system",level=>"debug");
      if (UNIVERSAL::isa($loopdriver,'PMTIteratorBase')) {
         $empty_policy = $xnode->xfind('loopdriver/@empty_policy',default=>'undef');
         $empty_policy = uc $empty_policy; my $rl = ref $loopdriver;
         $ic->log(message=>"Found a loopdriver in processgroupmanager $name ($rl) with empty policy $empty_policy",domain=>"system",level=>"debug");
      }
      elsif (ref $loopdriver eq 'ARRAY') {
        $ic->log(message=>"Loopdriver is an array, creating a simple worklist",domain=>"system",level=>"debug");
        $loopdriver = new PMTWorklist(list=>$loopdriver);
        $empty_policy = 'UNDEF';
      }
    }
    elsif ($loopdriver) {
      $ic->log(message=>"Loopdriver appears to be a single item,creating a simple worklist",domain=>"system","level"=>"info");
      $loopdriver = new PMTWorkList(list=>[$loopdriver]);
      $empty_policy = "UNDEF";
    }
  }
  else {
    $ic->log(message=>"Could not find a loopdriver in progressgroupmanager, creating a dummy one",domain=>"system",level=>"debug");
    # I should make a dummy one ...
    $loopdriver = new PMTWorkList(list=>[1]);
    $empty_policy = 'UNDEF';
  }

  
  # now, how we go about this ... kinda depends on the empty attribute on the loopdriver

  my $workercount = 0;
  if ($empty_policy eq 'UNDEF') {
    #my $item = <${loopdriver}>;
    use PMTWorkList;
    my $do_continue = 1;
    while ($workercount < $max_processes and $do_continue) {
     
      my $item = <${loopdriver}>;
      if (defined $item) {
        my $h = $helper_node->xfind('./factory()');
        $h->setWorkListPolicy(policy=>'UNDEF');
        my $process_model = undef;
        if ($xnode->exists('process_model')) { $process_model = $xnode->xfind('process_model/xnodePath()'); }
        $ic->log(message=>"Creating a helperhelper with process_model",data=>$process_model,level=>"info",domain=>"system");
        $h->setResources(process_model=>$process_model,worklist => new PMTWorkList(list=>[$item],parent=>$loopdriver));
        $h->setProcessModel(process_model=>$process_model);
        $h->setGroupManager($self);
      	$h->setHelperId($workercount);

        $self->{'_pool_'}->{$workercount} = $h;
        $workercount++;
      }
      else {
        $do_continue = 0;
      }
    }
  }
  else {
    # The empty policy is anything else but UNDEF, we basically spawn the exact number of processes
    while ($workercount < $max_processes) {
      my $h = $helper_node->xfind('./factory()');
      $h->setHelperId($workercount);
      $ic->log(message=>"In PMTJobManager setting helper id to $workercount",domain=>"system",level=>"debug");
      $ic->log(message=>"Setting worklist empty policy to $empty_policy",domain=>"system",level=>"debug"); 
      $h->setWorkListPolicy(policy=>$empty_policy);
      my $process_model = undef;
      if ($xnode->exists('process_model')) { $process_model = $xnode->xfind('process_model/xnodePath()'); }
      #print "Creating a helperhelper with process_model $process_model\n";
      $ic->log(message=>"Creating a helperhelper with process model",data=>$process_model,domain=>"system",level=>"info");
      $h->setResources(process_model=>$process_model,worklist=>$loopdriver);
      $h->setProcessModel(process_model=>$process_model);

      $self->{'_pool_'}->{$workercount} = $h;
      $workercount++;
    }
  }
  $ic->log(message=>"Using $workercount processes",domain=>"system",level=>"info");
  if ($workercount == 0) {
  	$ic->log(message=>"Looks like there's no work to be done in group $name, exiting right away",domain=>"system",level=>"info");
    # looks like there's nothing to process
    $ic->MDBStartGroup(group=>$name);
    $ic->MDBEndGroup(group=>$name,success=>1);
    $ic->appendJLOG(directives=>{type=>'event',context=>{group=>$name},mtime=>time()},data=>{event_type=>'process_group_end'});
    $self->{'_finished_'} = 1;
    $self->end();
    return;
  }

  # And now loop while there are items and or children are running ...
  $self->{'_setup_'} = 1;
}

sub start {
  my $self = shift;
  # this doesn't really do much ... 
  my $ic = $self->{'initialcontext'};
  my $xnode = $self->{'xnode'};
  my $name = $self->{'name'};
  if ($self->{'_started_'}) { 
    return 1; 
  }
  $ic->log(message=>"Doing start in processgroup $name",domain=>"system",level=>"debug");
 
  $self->setup();
  if ($self->{'_setup_'}) { 
    if ($xnode->evalPreReqs(condition_type=>'wait_start')) {
      $self->{'_started_'} = 1; 
      $ic->log(message=>"Effectively start group $name",domain=>"system",level=>"debug");
      $ic->MDBStartGroup(group=>$name);
      $ic->appendJLOG(directives=>{type=>'event',context=>{group=>$name},mtime=>time()},data=>{event_type=>'process_group_start'});
    }
    else { 
      $ic->log(message=>"wait_start condition for group $name not fullfilled, this step will have to wait",domain=>"system",level=>"info");
    }
  }
  return $self->{'_started_'};
}

sub execLocalCallStep {
  my $self = shift;
  my %args = @_;
  my $stepnode = $args{'stepnode'};
  my $object = $stepnode->xfind('object');
  my $method = $stepnode->xfind('method');
  my $params = {};
  if ($stepnode->exists('params')) {
    $params = $stepnode->xfind('params');
  }
  use PMTUtilities qw(h2a);
  my @cp = h2a(hash=>$params);
  eval {
    $object->$method(@cp);
  };
  if ($@) { print STDERR "Error occurred in local call step: $@\n"; }
}

sub execLocalIcUpdateStep {
  my $self = shift;
  my %args = @_;
  my $stepnode = $args{'stepnode'};
}

sub execLocalStep {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $stepnode = $args{'stepnode'};
  # what can I find here
  my $names = $stepnode->xfind('*[name() != "pre_reqs"]/name(.)',force_array=>1);
  for my $n (@$names) {
    $ic->log(message=>"Executing a local step of type $n",domain=>"system",level=>"debug");
  }
  my $stepelements = $stepnode->xnode(data=>'*[name() != "pre_reqs"]',force_array=>1);
  for my $sel (@$stepelements) {
    my $n = $sel->xfind('./name()');
    if ($n eq 'ic_update') {
      my $ic_update = $sel->xfind('./parseParamset()');
      use PMTUtilities qw(icdefined mergeRecursiveHash);
      if (icdefined $ic_update) {
        mergeRecursiveHash(src=>$ic_update,update=>$ic);
      }
    }
    elsif ($n eq 'call') {
      $self->execLocalCallStep(stepnode=>$sel);
    }
  }
}

sub end {
  my $self = shift;
  my $xnode = $self->{'xnode'};
  my $jobmanager = $self->{'jobmanager'};
  my $ic = $self->{'initialcontext'};
  my $name = $self->{'name'};
  $ic->log(message=>"Doing 'end' in processgroup $name",domain=>"system",level=>"debug");

  my $endsteps = $xnode->xnode(data=>'end/steps/step',force_array=>1);
  for my $step (@$endsteps) {
    if ($step->evalPreReqs(condition_type=>'condition')) {
      $self->execLocalStep(stepnode=>$step);
    }
  }
}

sub run {
  my $self = shift;
  my $xnode = $self->{'xnode'};
  my $name = $self->{'name'};
  my $ic = $self->{'initialcontext'};

  $self->start();
  if ($self->{'_started_'} == 0) { return; }
  if ($self->{'_running_'}) { return ; }
  $ic->log(message=>"Attempting to do run in processgroup $name",domain=>"system",level=>"debug");
  if ($xnode->evalPreReqs(condition_type=>'wait_run')) {
    use Data::Dumper;
    eval {
      for my $h (values %{$self->{'_pool_'}}) {
        $ic->log(message=>"Invoking run on helper $h in group $name",domain=>"system",level=>"debug");
        $h->();
        $ic->log(message=>"Invoked run on helper $h in group $name",domain=>"system",level=>"debug");
      }
    };
    if ($@) {
      my $e = $@;
      $ic->log(message=>"Error calling run in workerpool for group $name",domain=>"system",level=>"error",data=>$e);
      $self->{'_finished_'} = 1;
      $ic->appendJLOG(directives=>{type=>'event',context=>{group=>$name},mtime=>time()},data=>{event_type=>'process_group_end',detail=>{status=>'fail'}});
      return 0;
    }
    $self->{'_running_'} = 1;
  }
  else {
    $ic->log(message=>"Process group $name method run: wait condition not fullfilled. Waiting",domain=>"system",level=>"debug");
  }
}

sub isFinished {
  my $self = shift;
  my $run_count = 0;
  my $ic = $self->{'initialcontext'};
  my $name = $self->{'name'};
  $self->run();
  if ($self->{'_finished_'}) { return 1; }
  if (not $self->{'_running_'}) { return 0; }
  #
  # pool is the pool of helpers, it contains PMTHelperHelper-instances
  for my $h (keys %{$self->{'_pool_'}}) {
    my $f = $self->{'_pool_'}->{$h}->isFinished();
    if ($f) {
      # I don't think we should do anything here
      $ic->log(message=>"HelperHelper $h in group $name is finished",domain=>"system",level=>"debug");
      delete $self->{'_pool_'}->{$h};
    }
    else {
      $run_count++;
    }
  }

  if ($run_count > 0) { return 0; } 
  else { 
    my $name = $self->{'name'};
    $ic->appendJLOG(directives=>{type=>'event',context=>{group=>$name},mtime=>time()},data=>{event_type=>'process_group_end',detail=>{status=>'success'}});
    $ic->log(message=>"Group $name is finished, I should now call it quits",domain=>"system",level=>"info");
    $self->{'_finished_'} = 1;
    $self->end();
    $ic->MDBEndGroup(group=>$name,success=>1);
    return 1; 
  }
}

DESTROY {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $name = $self->{'name'};
  my $pool = $self->{'_pool_'};
  while (scalar @{$self->{'_pool_'}}) { 
    # This should invoke their destructors to 
    shift @{$self->{'_pool_'}};
  }
  $ic->log(message=>"End of destructor in ProcessgroupManager for group $name",domain=>"system",level=>"debug");
}

1;


# ####################################################################################################################################
#
# ####################################################################################################################################

package PMTJobManager;

use strict;
use Carp;

use Data::Dumper;
use File::Spec;
use PMTUtilities qw(serializeTo deserializeFrom getPMTSysConfig);
use JSON;

sub new {
  my $class = shift;
  my %args = @_;

  my $o = {};
  $o->{'initialcontext'} = $args{'initialcontext'};
  $o->{'xnode'} = $args{'xnode'};
  $o->{'initparams'} = $args{'initparams'};

  return bless $o;
}

sub execLocalCallStep {
  my $self = shift;
  my %args = @_;
  my $stepnode = $args{'stepnode'};
}

sub execLocalIcUpdateStep {
  my $self = shift;
  my %args = @_;
  my $stepnode = $args{'stepnode'};
}

sub execLocalStep {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $stepnode = $args{'stepnode'};
  # what can I find here
  $ic->log(message=>"Executing a local step",data=>"$stepnode",domain=>"system",level=>"debug");

  my $names = $stepnode->xfind('*[name() != "pre_reqs"]/name(.)',force_array=>1);
  for my $n (@$names) {
    $ic->log(message=>"Executing a local step of type $n",domain=>"system",level=>"info");
  }
  my $stepelements = $stepnode->xnode(data=>'*[name() != "pre_reqs"]',force_array=>1);
  for my $sel (@$stepelements) {
    my $n = $sel->xfind('./name()');
    if ($n eq 'ic_update') {
      my $ic_update = $sel->xfind('./parseParamset()');
      use PMTUtilities qw(icdefined mergeRecursiveHash);
      if (icdefined $ic_update) {
        mergeRecursiveHash(src=>$ic_update,update=>$ic);
      }
    }
  }
}

sub execLocalSteps {
  my $self = shift;
  my %args = @_;
  use PMTUtilities qw(icdefined);
  my $rnode = $args{'container'};
  my $steps = $rnode->xnode(data=>'steps/step',force_array=>1);
  for my $step (@$steps) {
    #print "doing setup step: $step";
    if ($step->evalPreReqs(condition_type=>'condition')) {
      # actually carry out the step
      $self->execLocalStep(stepnode=>$step);
    }
  }
}

sub run {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $xnode = $self->{'xnode'};
  my $name = $self->{'name'};

  $ic->log(message=>"Running PMTJobManager",domain=>"system",level=>"info");
  $ic->log(message=>"PMTJobManager using xnode",data=>$xnode,domain=>"system",level=>"debug");

  my $processmodel = $self->{'initparams'}->{'process'};

  my $ic_update;
  my $setup = $processmodel->xnode(data=>'setup');
  if (icdefined $setup) {
    $self->execLocalSteps(container=>$setup);
  }

  my $groupsnode = $xnode->xfind('//groups/xnode()');

  my $groups = $xnode->xfind('//groups/group/xnode()',force_array=>1);

  #print STDERR "TODO: Move the create conditions on the group to the actual create condition node\n";
  $ic->log(message=>"TODO: Move the create condition on the group to the actual create_condition node",domain=>"system",level=>"WARNING");
  my $processgroupmanagers = {};
  for my $g (@$groups) {
    my $name = $g->xfind('./@name/data(.)');
    $ic->log(message=>"Creating a processgroup manager with name $name",domain=>"system",level=>"info");
    
    my $condition_check = $g->evalPreReqs(condition_type=>'create_condition');
    if ($condition_check) {
      $ic->log(message=>"Creating group $name",domain=>"system",level=>"info");
      $processgroupmanagers->{$name} = new ProcessGroupManager(jobmanager=>$self,name=>$name,initialcontext=>$ic,xnode=>$g);
    }
    else {
      $ic->log(message=>"Dropping group $name since create conditions are not fullfilled",domain=>"system",level=>"info");
    }
  }

  my $run_count = scalar keys %$processgroupmanagers;

  # and now wait till they finish ...
  $ic->log(message=>"Waiting for $run_count processgroupmanager(s) to finish",domain=>"system",level=>"info");

  while ($run_count > 0) {
    $run_count = 0;
    for my $k (keys %$processgroupmanagers) {
      if ($processgroupmanagers->{$k}->isFinished()) {
        $ic->log(message=>"Processgroupmanager for group $name is finished",domain=>"system",level=>"debug");
        delete $processgroupmanagers->{$k};
      }
      else { 
        $run_count++;
      }
    }
    use Time::HiRes qw(sleep);
    sleep 0.05;
  }

  $ic->log(message=>"All processgroupmanagers are finished, PMTJobManager is done",domain=>"system",level=>"info");

  return;
}

1;
