package PMTDBConnection;

use strict;
use Carp;

sub new {
  my $class = shift;
  my %args = @_;
  my $dbh = $args{'connection'};
  my $dialect = $args{'dialect'};
  my $connection_type = $args{'connection_type'};
  my $ic = $args{'initialcontext'};
  my $o = {};
  $o->{'connection'} = $dbh;
  $o->{'dialect'} = $dialect;
  $o->{'connection_type'} = $connection_type;
  $o->{'initialcontext'} = $ic;
  bless $o;
  return $o;
}

sub getDialect {
  my $self = shift;
  return lc $self->{'dialect'};
}

sub AUTOLOAD {
  my $self = shift;
  our $AUTOLOAD;
  my @methodcomps = split('::',$AUTOLOAD);
  my $method = pop(@methodcomps);
  my $dbh = $self->{'connection'};
  return $dbh->$method(@_);
}

sub DESTROY {
  my $self = shift;
  my $dbh = $self->{'connection'};
  #print "killing the connection\n";
  $dbh->disconnect();
}

1;
