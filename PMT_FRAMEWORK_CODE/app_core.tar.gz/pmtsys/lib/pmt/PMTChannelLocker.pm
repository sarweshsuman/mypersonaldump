package PMTChannelLocker;
use strict;
use Carp;

select STDERR;
$|=1;

sub new {
  my $class = shift;
  my $helper = shift;
  my $ic = $helper->{'initialcontext'};
  my $o ={};
  $o->{'_channelwaslocked_'} = $helper->{'_channellocked_'};
  $o->{'_helper_'} = $helper;
  $o->{'initialcontext'} = $ic;
  bless $o;
  if ($o->{'_channelwaslocked_'} == 1) {
    #print STDERR "Channel was locked, opening\n";
    $helper->{'_channellocked_'} = 0;
  	$helper->send(type=>'unlock_channel');
  	$o->process_queue();
  }
  else {
     #print STDERR "Was allready open\n";
  }
  return $o;
}

sub process_queue {
  my $self = shift;
  my $h = $self->{'_helper_'};
  # ask how many messages there are
  my $d = $h->send(type=>'process_mqueue',wait_for=>'mqueue_size_response');
  use Data::Dumper;
  #print STDERR "Got message queue response: ",Dumper($d),"\n";
  my $r = $h->receive(wait_for=>'end_mqueue');
  #print STDERR "End of processing mqueue\n";
  #my $c = $d->{'size'};
  #for (my $i = 0; $i < $c; $i++) {
  #  print STDERR "receiving a message in the queue\n";
  #  $h->receive();
  #}
  #print STDERR "Done processing message_queue\n";
}
sub DESTROY {
  my $self = shift;
  my $h = $self->{'_helper_'};
  use Data::Dumper;
  my $handlers = $h->{'reader_handlers'}; #print STDERR "In channel locker, reader_handlers = ",Dumper($handlers),"\n";
  #print STDERR "Destroying the PMTChannelLocker\n";
  if ($self->{'_channelwaslocked_'} == 1) {
  	$h->send(type=>'lock_channel',wait_for=>'channel_locked');
    $h->{'_channellocked_'} = 1;
  	#print STDERR "Got confirmation about channel lock in destructor of PMTChannelLocker\n";
  }
  else {
    #print STDERR "I should not locked the channel since it was locked allready\n";
  }
}

1;
