package PMTDBConnectionManager;

use strict;
use Carp;
use DBI;

my $shared_connections;
my $supported_connections;

BEGIN {
  $shared_connections = {};
}


sub getConnection_oracle {
  my %args = @_;
  my $ic = $args{'initialcontext'};
  my $cs = $args{'data'};  # cs is short for connection_spec

  my $driver = $cs->{'driver'};
  my $service = $cs->{'service'};
  my $username = $cs->{'username'};
  my $password = $cs->{'password'};

  my $connection_name;
  if (defined $cs->{'connection_name'}) {
    $connection_name = lc $cs->{'connection_name'};
  }
  elsif (defined $args{'name'}) {
    $connection_name = lc $args{'name'};
  }

  use DBI;
  use DBD::Oracle;
  my $dbh;
  eval {
    $dbh = DBI->connect("DBI:Oracle:$service",$username,$password,{AutoCommit=>0,RaiseError=>1,PrintError=>1});
    $dbh->func( 1000000, 'dbms_output_enable' );
    $ic->log(message=>"Created Oracle DB Connection",level=>"debug",domain=>"system");
  };
  if ($@) {
    my $e = $@;
    $ic->log(message=>"Failed to create database connection",data=>$e,domain=>"system",level=>"error");
    croak { message=>"Failed to connect create database connection $connection_name : $@" };
  }
  use PMTDBConnection;
  return PMTDBConnection->new(connection=>$dbh,dialect=>'oracle',connection_type=>'oracle');
}

$supported_connections = {
  oracle=>\&getConnection_oracle
};


sub getConnection {
  my %args = @_;
  my $ic = $args{'initialcontext'};
  my $cs = $args{'data'};  # cs is short for connection_spec

  my $connection_name;
  if (defined $cs->{'connection_name'}) {
    $connection_name = lc $cs->{'connection_name'};
  }
  elsif (defined $args{'name'}) {
    $connection_name = lc $args{'name'};
  }
  my $shared;
  $shared = $cs->{'shared_connection'};
  if ($shared and not defined $connection_name) {
    # fall back to non shared
    $shared = 0;
  }
  #print "creating connection $connection_name\n";
  if ($shared and defined $shared_connections->{$connection_name}) {
    return $shared_connections->{$connection_name};
  }
  # we're still here
  my $driver = $cs->{'driver'}; 
  if (not $driver) {
    croak { message=>"Database driver not specified in ".__PACKAGE__ };
  }
  $driver = lc $driver;
  my $service = $cs->{'service'};
  my $username = $cs->{'username'};
  my $password = $cs->{'password'};

  my $dbh;
  if (defined $supported_connections->{$driver}) {
    my $f = $supported_connections->{$driver};
    $dbh = $f->(@_);
  }
  else {
    croak { "Unsupported database driver type : $driver" };
  }
  if ($shared) {
    $shared_connections->{$connection_name} = $dbh;
  }
  return $dbh;
}

END {
  for my $k (keys %$shared_connections) {
    $shared_connections->{$k}->disconnect;
    delete $shared_connections->{$k};
  }
}

1;

