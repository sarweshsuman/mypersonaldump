package PMTDbXmlManagerHelper;

use strict;
use Carp;

use Sleepycat::DbXml;
use Sleepycat::Db;
use PMTUtilities;

my $dbenv;

BEGIN {
  print "initializing environment\n";
  $dbenv = new DbEnv();
  my $db_dir = '/opt/PMT/var/db';
  $dbenv->open($db_dir,Db::DB_CREATE|Db::DB_INIT_MPOOL|Db::DB_INIT_LOCK|Db::DB_INIT_LOG|Db::DB_INIT_TXN,0);
}

sub new {
  my $p = shift;
  my %args = @_;
  my $o = {};
  print "manager creating\n";
  $o->{'_mgr_'} = new XmlManager($dbenv);
  print "manager created\n";
  bless $o;
  return $o; 
}

sub query {
  my $self = shift;
  my %args = @_;
}

sub DESTROY {
  my $self = shift;
  my $m = $self->{'_mgr_'};
  if ($m) {
    delete $self->{'_mgr_'};
    undef $m;
  }
}

END {
  if ($dbenv) {
    eval {
      # This segfaults, looks like perl takes care of it and we shouldnt explicitly
      #$dbenv->close();
    };
  }
}

1;
