package PMTSimpleResultCollector;

use strict;
use Carp;

use PMTIteratorBase;
our @ISA = qw(PMTIteratorBase);

use PMTUtilities qw(partial);

use Time::HiRes qw(time);

use overload q{<>} => \&iterator_overload,
             'bool'=>\&bool_overload,
             q{""} => sub { return "<" . __PACKAGE__ ." instance>"; };


sub new {
  my $package = shift;
  my %args = @_;
  my $ic = $args{'initialcontext'};
  my $xn = $args{'xnode'};
  my $list = $args{'list'};
  my $batchsize = $args{'batchsize'};
  if (not $batchsize) { $batchsize = 1; }
  if (not $list) { $list = []; }
  my $o = {};
  $o->{'_list_'} = [];
  for my $i (@$list) {
    push @{$o->{'_list_'}},$i;
  }
  $o->{'xnode'} = $xn;
  $o->{'initialcontext'} = $ic;
  $o->{'ended'} = 0;
  $o->{'batchsize'} = $xn->xfind('config/batchsize',default=>1);
  $o->{'empty'} =  uc $xn->xfind('config/empty_policy',default=>'undef');
  $o->{'force_array'} = $xn->xfind('config/force_array',default=>0);
  $o->{'signaled_end'} = 0;
  $o->{'seq'} = 0;

  my $bs = $o->{'batchsize'};
  $ic->log(message=>"Creating collector with batchsize $bs",domain=>"system",level=>"info");
  return bless $o;
}

sub bool_overload {
  my $self = shift;
  if ($self->{'signaled_end'} eq 0) {
    return 1;
  }
  else { return 0; }
}

sub iterator_overload {
  my $self = shift;
  return $self->next();
}

sub next {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $ended = $self->{'ended'};
  my $batchsize = $self->{'batchsize'};
  my $force_array = $self->{'force_array'};
  my $qs = scalar @{$self->{'_list_'}};
  use Data::Dumper;
  $ic->log(message=>"next called in PMTSimpleResultCollector [$ended][$batchsize][$qs]",domain=>"system",level=>"trace");
  my $item;
  if (scalar @{$self->{'_list_'}}) {
    if ($batchsize == 1) {
      $self->{'seq'} = $self->{'seq'} + 1;
			$item = shift @{$self->{'_list_'}};
			if ($force_array) {
				if (wantarray) { return ($self->{'seq'}, [$item]); } else { return [$item]; }
			}
			else {
        if (wantarray) { return ($self->{'seq'},$item); } else { return $item ; }
			}
    }
    else { # batchsize > 1
      if ($ended) {
        my $bs = scalar @{$self->{'_list_'}};
        $ic->log(message=>" Status is 'ended' and current size = $bs",domain=>"system",level=>"trace");
      	my @il;
        $self->{'seq'} = $self->{'seq'} + 1;
				while (scalar @il < $batchsize and scalar @{$self->{'_list_'}}) {
					push @il,shift @{$self->{'_list_'}};
				}
        $ic->log(message=>" Status is 'ended' and returning what I have",domain=>"system",level=>"trace");
         
        if (wantarray) { return ($self->{'seq'},\@il); } else { return \@il; }
      }
      else {
        if (scalar @{$self->{'_list_'}} < $batchsize) {
          if (wantarray) { return (undef,undef); } else { return undef; }
        }
        else {
					my @il;
          $self->{'seq'} = $self->{'seq'} + 1;
					while (scalar @il < $batchsize and scalar @{$self->{'_list_'}}) {
            my $i = shift @{$self->{'_list_'}};
						push @il,$i;
					}
          $ic->log(message=>"...not ended, returning ",data=>\@il,level=>"debug",domain=>"system");
          if (wantarray) { 
            return ($self->{'seq'},\@il);
          }
          else {
					  return \@il;
          }
        }
      }
    }
  }
  else {
    if ($ended) {
      $ic->log(message=>"Returning empty token",domain=>"system",level=>"trace");
      $self->{'signaled_end'} = 1;
      my $rv = bless {},'EMPTY_TOKEN';
      if (wantarray) { return (undef,$rv); } else { return $rv; }
    }
    else { 
      if (wantarray) { return (undef,undef); } else { return undef; }
    }
  }
}

sub append {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $item = $args{'item'};
  $ic->log(message=>"Adding item to result collector",data=>$item,level=>"trace",domain=>"system");
  push @{$self->{'_list_'}},$item;
}

sub end {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  $ic->log(message=>"END is called on PMTSimpleResultCollector",domain=>"system",level=>"debug");
  $self->{'ended'} = 1;
}

1;
