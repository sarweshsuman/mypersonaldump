package NodeAsHash;
use strict;
use Carp;
use Tie::Hash;

our @ISA = qw(Tie::Hash);

use PMTUtilities qw(evalBoolean any icdefined);
use overload q{""}  => \&asstring;


# ==========================================================================
#
# Constructor
#
# ==========================================================================

sub TIEHASH {
  my $class = shift;
  my %args = @_;
  

  my $obj = [0,{
  }];
  return bless $obj;
}

1;


package PMTXMLNodeWrapper;

use strict;
use Carp;
use overload q{""} => \&string_conversion;

sub new {
  my $class = shift;
  my %args = @_;
  my $o = {};

  $o->{'_rootparser_'} = $args{'rootparser'};
  $o->{'_basenode_'} = $args{'node'};
  if (ref $o->{'_basenode_'} eq __PACKAGE__) { return $o->{'_basenode_'}; }
  $o->{'initialcontext'} = $args{'initialcontext'};

  bless $o;
  return $o;
}

sub string_conversion {
  my $self = shift;
  my $basenode = $self->{'_basenode_'};
  return $basenode->toString(1);
}

sub xfind {
  my $self = shift;
  my $key = shift;
  my %args = @_;
  my $ic = $self->{'initialcontext'};
  $key = $ic->expand($key);
  my %args = @_;
  #print "doing xfind\n";
  my $basenode = $self->{'_basenode_'};
  my $rootparser=$self->{'_rootparser_'};
  my $result = $rootparser->preRead(key=>$key,iface=>"raw",rootnode=>$basenode,default=>$args{'default'});

  if ($args{'force_array'}) {
    if (ref $result eq 'ARRAY') {
      return $result;
    }
    else { return [$result]; }
  }
  else { 
    #print STDERR "in xfind result looking for $key is now : ",ref $result, "\n"; i
    return $result ; 
  }
}

sub xnodePath {
  my $self = shift;
  my $rp = $self->{'_rootparser_'};
  my $bn = $self->{'_basenode_'};
  my $p = $bn->nodePath();
  my $np = $rp->nodePath2PluginPath(path=>$p);
  return $np;
}

sub xfactory {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $p = shift;
  my $rs;
  if (defined $args{'data'}) {
    my $p = $args{'data'};
    $rs = $self->xfind($p);
  }
  else {
    $rs = $self;
  } 
  my $fullpath = $rs->xnodePath();
  my $rp = $self->{'_rootparser_'};
  my $bn = $self->{'_basenode_'}; 
  my %nargs = %args;
  $nargs{'data'} = $fullpath;
  use PMTUtilities qw(h2a);
  my $nargs = h2a(hash=>\%nargs);
  return  $ic->xfactory(@$nargs);
  print STDERR "found rs in path $p:",$rs->xnodePath(),"\n";
}

sub xnode {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $basenode = $self->{'_basenode_'};
  my $rootparser=$self->{'_rootparser_'};
  my %args = @_;
  my $force_array = $args{'force_array'};
  my $p = shift;
  my @rs;
  if (defined $args{'data'}) {
    my $p = $args{'data'};
    #print STDERR "rs in nodewrapper xnode looking for $p\n";
    @rs = $basenode->findnodes($p);
  }
  else {
    @rs = ($basenode);
  } 
  if (scalar @rs == 1 and not $force_array) {
    my $node = $rs[0];
    return new(__PACKAGE__,node=>$node,initialcontext=>$ic,rootparser=>$rootparser);
  }
  elsif (scalar @rs == 1 and $force_array) {
    my $node = $rs[0];
    return [new(__PACKAGE__,node=>$node,initialcontext=>$ic,rootparser=>$rootparser)]; 
  }
  elsif (scalar @rs == 0) { if ($force_array) { return []; } else {return undef;} }
  else {
    my @results = ();
    for my $r (@rs) {
      push @results,new(__PACKAGE__,node=>$r,initialcontext=>$ic,rootparser=>$rootparser);
    }
    return \@results;
  }
}

sub evalPreReqs {
  my $self = shift;
  my %args = @_;
  my $ic = $self->{'initialcontext'};
  my $condition_type = $args{'condition_type'};
  my $condition_node = $self->xnode(data=>'pre_reqs');
  use PMTSysUtils;
  my $r = PMTSysUtils::evalPreReqs(initialcontext=>$ic,condition_node=>$condition_node,condition_type=>$condition_type);
  return $r;
}

sub setIC {
  my $self = shift;
  my %args = @_;
  my $newic = $args{'initialcontext'};
  $self->{'initialcontext'} = $newic;
}

sub setRootParser {
  my $self = shift;
  my %args = @_;
  my $newrp = $args{'rootparser'};
  $self->{'_rootparser_'} = $newrp;
}

#the following for testing purposes .. 
sub texpand {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $arg = shift;
  return $ic->expand($arg);
}
sub AUTOLOAD {
  my $self = shift;
  my $basenode = $self->{'_basenode_'};
  our $AUTOLOAD;
  my @methodcomps = split('::',$AUTOLOAD);
  my $method = pop(@methodcomps);
  #print "looking for method $method\n";
  return $basenode->$method(@_);
}

sub DESTROY {
  my $self = shift;
  delete $self->{'_basenode_'};
  delete $self->{'_rootparser_'};
}

1;
