package ProcessGroup; 

use strict;
use Carp;
use PMTExecContext;

sub new {
  my $package = shift;
  my %args = @_;

  my $o = {};
  my $parent_ic = $args{'initialcontext'};
  my $xnode = $args{'xnode'};
  my $name = $args{'name'};
  my $worklist = $args{'worklist'};
  my $resultcollector = $args{'resultcollector'};

  print STDERR "In constructor of processgroup with name $name\n";
  # Cloning the ic ...
  $o->{'initialcontext'} = new PMTExecContext($parent_ic); #new PMTExecContext($parent_ic);
  $o->{'xnode'} = $xnode;
  $o->{'name'} = $name;
  $o->{'worklist'} = $worklist;
  $o->{'resultcollector'} = $resultcollector;
  $o->{'_pool_'} = {};

  my $ic = $o->{'initialcontext'}; print "In constructor of processgroup: ic = $ic\n";
  $ic->{'RUNTIME/EXEC/GROUP'} = $name;
  return bless $o;
}

sub setup {
	my $self = shift;
	my $xnode = $self->{'xnode'};
  my $ic = $self->{'initialcontext'};
  my $worklist = $self->{'worklist'};
  my $resultcollector = $self->{'resultcollector'};
 
  print "Doing setup in processgroup for xnode: $xnode\n";

  # I need the helper:

  # find the number of subprocesses:
  my $max_processes;
  if ($xnode->exists('config/param[@name="subprocesses"]')) {
    $max_processes = $xnode->xfind('config/param[@name="subprocesses"]');
  }
  else {
    # base ourselves on the Sys::CPU module
  	use Sys::CPU;
  	my $number_of_cpus = Sys::CPU::cpu_count();
    $max_processes = $number_of_cpus;
  }

  print "using max processes: $max_processes\n";

  print "worklist is here: $worklist\n";


  my $helper_node = $xnode->xfind('config/param[@name="helper"]');

  # and to I have a processmodel here ?
  # well the xnode is basically the processmodel;
  #print "looking for processmodel in processgroup: $xnode\n";




  #my $processmodel; my $worklist = new PMTWorkList(list=>['evert']); my $resultcollector;
  #my $number_of_subprocesses = 1;

  my $workercount = 0;
  my $item = <${worklist}>;
  use PMTWorkList;
  while ($workercount < $max_processes and defined $item) {
    my $h = $helper_node->xfind('./factory()');
    my $process_model = undef;
    if ($xnode->exists('process_model')) { $process_model = $xnode->xfind('process_model/xnode()'); }
    print "Creating a helperhelper with process_model $process_model\n";
    $h->setResources(process_model=>$process_model,worklist => new PMTWorkList(list=>[$item],parent=>$worklist),resultcollector=>$resultcollector);
    $h->setProcessModel(process_model=>$process_model);

    $self->{'_pool_'}->{$workercount} = $h;
    $item = <${worklist}>;
    $workercount++;
  }
  print STDERR "Using $workercount processes\n";

  # And now loop while there are items and or children are running ...
  print STDERR "End of SETUP in ProcessGroup\n";
}

sub start {
  my $self = shift;
  print STDERR "Doing start in process group\n";
}

sub end {
  my $self = shift;
  print STDERR "Doing end in process group\n";
}

sub run {
  my $self = shift;
  print STDERR "Doing run in processgroup\n";
  use Data::Dumper;
  eval {
    for my $h (values %{$self->{'_pool_'}}) {
      print STDERR "Invoking run on $h\n";
      # the following should really be a call to () don't forget to change this
      $h->();
      print STDERR "Invoked run on $h\n";
    }
  };
  if ($@) {
    print STDERR "Error calling run in workerpool\n",Dumper($@),"\n";
  }
  print STDERR "end of run in processgroup\n";
}

sub isFinished {
  my $self = shift;
  my $run_count = 0;
  #
  print STDERR "Checking workerpool\n";
  for my $h (keys %{$self->{'_pool_'}}) {
    print STDERR "checking helper $h\n";
    my $f = $self->{'_pool_'}->{$h}->isFinished();
    print "helper $h is finished: $f\n";
    if ($self->{'_pool_'}->{$h}->isFinished()) {
      # I don't think we should do anything here
      print STDERR "HelperHelper $h is finished\n";
      delete $self->{'_pool_'}->{$h};
    }
    else {
      $run_count++;
    }
    print STDERR "Done checking helper $h\n";
  }
  if ($run_count > 0) { return 0; } else { return 1; };
}

sub teardown {
  my $self = shift;
}

DESTROY {
  my $self = shift;
  print STDERR "In destructor of Processgroup\n";
  my $pool = $self->{'_pool_'};
  while (scalar @{$self->{'_pool_'}}) { 
    # The following line should invoke the destructor in the PMTHelperHelper;
    shift @{$self->{'_pool_'}};
  }
  print STDERR "End of destructor in Processgroup\n";
}

1;


package ParserManager;

use strict;
use Carp;

use Data::Dumper;
use File::Spec;
use PMTUtilities qw(serializeTo deserializeFrom getPMTSysConfig);
use Class::Loader;
use JSON;

sub new {
  my $class = shift;
  my %args = @_;

  my $o = {};
  $o->{'initialcontext'} = $args{'initialcontext'};
  $o->{'xnode'} = $args{'xnode'};
  $o->{'initparams'} = $args{'initparams'};

  bless $o;
  if ($o->{'xnode'}) {
	  print STDERR "Parsemanager Path of xnode = ",$o->{'xnode'}->xfind('./xnodePath()'),"\n";
  }
  else {
    #print STDERR "xnode is not defined in ParserManager";
  }
  return $o;
}

#sub run_multiprocess {
sub run {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $xnode = $self->{'xnode'};


  #print STDERR "run_multiprocess running with xnode\n$xnode\n";

  $ic->log(message=>"Running in MULTIPROCESSING mode",domain=>"system",level=>"info");

  use Sys::CPU;
  my $number_of_cpus = Sys::CPU::cpu_count();
  $ic->log("I got $number_of_cpus cpus",domain=>"system",level=>"info");

  # Retrive the filenames
  #my $directory = $xnode->xfind(q{//param[@name="directory"]/data()});
  #my $filepattern = $xnode->xfind(q{//param[@name="filepattern"]/data()},default=>'.*');

  #print STDERR "Looking for files $filepattern in directory $directory\n";
  #my @filenames = PMTUtilities::getFileList(full_path=>1,directory=>$self->{'config'}->{'directory'},filepattern=>$self->{'config'}->{'filepattern'});
  #my $number_of_files = scalar @filenames;
  #$ic->log("Got $number_of_files files",domain=>"system",level=>"info");

  #my $worklist; # = new WorkList(list=>\@filenames);
  #my $resultcollector;
  #my $processmodel = $ic->{q{JOBDEF///job/process/xnode()}};
  #print STDERR "Proceessmodel = now: $processmodel\n";

  my $processmodel = $self->{'initparams'}->{'process'};
  #print "processmodel is \n$processmodel\n";

  my $ic_update;
  print STDERR "TODO: In objects defined for ic_update (fileiterator etc, we should make sure that they get the xnode ... dunno if they do right now\n";
  if ($processmodel->exists('setup/ic_update')) {
    #$ic->{'SETTINGS/FACTORY/VERBOSE'} = 1;
    print STDERR "It does have a setup node\n";
    $ic_update = $processmodel->xfind('setup/ic_update');
    use Data::Dumper;
    #print STDERR "Got ic_update",Dumper($ic_update),"\n";
    use PMTUtilities qw(icdefined mergeRecursiveHash);
    if (icdefined $ic_update) {
      mergeRecursiveHash(src=>$ic_update,update=>$ic);
    }
    #$ic->{'SETTINGS/FACTORY/VERBOSE'} = 0;
  }
  else {
    print STDERR "Could not find a setup node\n";
  }


  my $groupsnode = $xnode->xfind('//groups/xnode()');
  #print "Groupsnode is now : \n$groupsnode\n";

  my $groups = $xnode->xfind('//groups/group/xnode()',force_array=>1);

  my $worklist = $ic->{'RUNTIME/RESOURCES/INFILE_ITERATOR'};
  my $resultcollector = $ic->{'RUNTIME/RESOURCES/RESULTCOLLECTOR'};

  my $processgroups = {};
  for my $g (@$groups) {
    my $name = $g->xfind('./@name/data(.)');
    print STDERR "Creating a processgroup with name $name\n";
    $processgroups->{$name} = new ProcessGroup(name=>$name,initialcontext=>$ic,xnode=>$g,worklist=>$worklist,resultcollector=>$resultcollector);
  }
  for my $pg ( values %$processgroups ) {
    $pg->setup();
  }
  print "Am I still alive after processgroups setup\n";
  for my $pg ( values %$processgroups ) {
    print  STDERR "Starting a processgroup\n";
    $pg->start();
  }
  print "am i still alive after processgroups start yes I am\n";
  #return;
  for my $pg ( values %$processgroups ) {
    print STDERR "Invoking run on processgroup $pg\n";
    $pg->run();
    print STDERR "Invoked run on progressgroup $pg\n";
  }
  print "am i still alive after processgroups run\n";
  #for my $pg ( values %$processgroups ) {
  #  $pg->end();
  #}

  # and now loop over all the processgroups until they are all finished
  my $run_count = scalar keys %$processgroups;

  # and now wait till they finish ...
  print STDERR "Waiting for processgroups to finish\n";
  while ($run_count > 0) {
    print STDERR "still got running processgroups ...\n";
    $run_count = 0;
    for my $k (keys %$processgroups) {
      if ($processgroups->{$k}->isFinished()) {
        # we shouldn't do anything here I guess
      }
      else { 
        $run_count++;
      }
    }
    print STDERR "run_count is $run_count in processgroups check\n";
    use Time::HiRes qw(sleep);
    sleep 0.05;
  }
  print STDERR "processgroup is finished or so it seems\n";

  return;

#   my $number_of_subprocesses;
#   if (defined $self->{'config'}->{'subprocesses'}) {
#     $number_of_subprocesses = $self->{'config'}->{'subprocesses'};
#     $number_of_subprocesses = $number_of_files < $number_of_subprocesses ? $number_of_files : $number_of_subprocesses;
#   }
#   else {
#     $number_of_subprocesses = $number_of_files < $number_of_cpus ? $number_of_files : $number_of_cpus;
#   }
# 
#   $ic->log(message=>"working with $number_of_subprocesses sub_processes",domain=>"system",level=>"info");
# 
#   $ic->log(message=>"processing filenames: ",data=>\@filenames,domain=>"system",level=>"info");
# 
#   use PMTHelperHelper;
# 
#   my $worklist; # = new WorkList(list=>\@filenames);
#   my $resultcollector;
#   my $processmodel = $ic->{q{JOBDEF///job/steps/xnode()}};
#   print STDERR "Proceessmodel = now: $processmodel\n";
# 
# 	my @workerpool = ();
# 
# 
#   sleep 30;


#   my $workerpool = { };
#   use IPC::Open2;
#   use IO::Socket::INET;
#   my $workerprocess = $self->{'config'}->{'workerscript'};
#   my $io_pid_mapping = {};
#   $ic->log(message=>"using workerprocess: $workerprocess",domain=>"system",level=>"info");
#   
#   #$SIG{'CHLD'} = 'IGNORE';
# 
#   use IO::Select;
#   use POSIX ":sys_wait_h";
#   my $selector = IO::Select->new();
#   my $do_continue = 1;
#   {
#     while ($do_continue > 0) {
#       # check if there are any dead processes
#       for my $pid (keys %$workerpool) {
#          my $check = kill 0=>$pid; 
#          if (not $check) {
#            print "pid $pid is dead\n";
#            delete $workerpool->{$pid};
#          }
#       } 
#       my @can_read = $selector->can_read(0.1);
#       if (scalar @can_read) {
#         #print "I have selectors from which I can read\n";
#         for my $h (@can_read) {
#           my $p = $io_pid_mapping->{$h};
#           #print "Looks like there's some input on pid $p\n";
#           if ($h->connected()) {
#             #print "and it is connected\n";
#             my $data = deserializeFrom(source=>$h,format=>"JSON");
#             if (defined $data->{"action"}) {
#             }
#             elsif (defined $data->{'end'}) {
#               # I should wait for it
#               #print "waiting for pid $p\n";
#               my $rc = waitpid($p,WNOHANG);
#               #print "waited for pid $p\n";
#               delete $workerpool->{$p};
#               delete $io_pid_mapping->{$h};
#               $selector->remove($h);
#             }
#           }
#           else {
#             #print "But it is not connected\n";
#             # means the socket is dead
#             delete $workerpool->{$p};
#             delete $io_pid_mapping->{$h};
#             $selector->remove($h);
#           }
#         }
#       }
#       while (scalar @filenames > 0 and scalar keys %$workerpool < $number_of_subprocesses) {
#         my $f = shift @filenames;
#         $ic->log(message=>"processing filename: $f",domain=>"system",level=>"info");
#         my $icinit = $ic->{'SYSTEM'};
#         my $icplugins = [
#           [ 'ENV',{class=>'PMTENVInterceptor'}],
#           [ 'JOBDEF',{class=>'PMTXPathInterceptor'}],
#           [ 'LOG',{class=>'PMTLogHelper'}, ],
#           [ 'RESOURCE',{class=>'PMTResourceHelper'}]
#         ];
#         # do I have the workerscript ?
#         my $xnode = $self->{'xnode'};
#         my $workernode_url = $xnode->xfind('//param[@name="workernode_url"]/data(.)');
#         print STDERR "I got the workerscript_url: $workernode_url\n";
#         my $h = { ic_init=>{SYSTEM=>$icinit}, 
#                   ic_boot=>{plugins=>$icplugins},
#                   config=>{workernode_url=>$workernode_url,driver=>'ExpatXSParser',initparams=>{saxhandler=>'SaxHandler_MGWPMT01D'}}, 
#                   params=>{uri=>$f} 
#                 };
#         my ($child_writer,$child_reader);
#         my $pid = open2($child_reader,$child_writer,$workerprocess);
#         use IO::Handle;
#         #serializeTo(data=>$h,target=>*STDERR,format=>'JSON');
#         serializeTo(data=>$h,target=>IO::Handle->new()->fdopen($child_writer,"w"),format=>'JSON',flush=>1);
#         my $handshake = deserializeFrom(source=>IO::Handle->new()->fdopen($child_reader,"r"),format=>"JSON");
#         my $socket = IO::Socket::INET->new(
#            PeerHost=>$handshake->{'host'},
#            PeerPort=>$handshake->{'port'},
#            Proto=>'tcp'
#         );
#         $selector->add($socket);
#         $workerpool->{$pid} = { reader=>IO::Handle->new()->fdopen($child_reader,"r"),writer=>IO::Handle->new()->fdopen($child_writer,"w"),status=>'RUNNING',filename=>$f,channel=>$socket};
# 
#         $io_pid_mapping->{$socket} = $pid;
#         $ic->log(message=>"I should open a socket to $handshake->{'host'}:$handshake->{'port'}",domain=>"system",level=>"info");
#       }
#       if (scalar @filenames == 0 and scalar keys %$workerpool == 0) {
#         $ic->log(message=>"ParserManager is done",domain=>"system",level=>"info");
#         $do_continue = 0;
#       }
#       else {
#         #print "still ", scalar @filenames, " to process\n";
#         #print "still ", scalar keys %$workerpool, " running processes\n";
#       }
#       sleep 0.1;
#     }
#   }

}


sub run_orig {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $xnode = $self->{'xnode'};

  return $self->run_multiprocess(@_);


  # ================ FOLLOWING IS (TEMP ?) DISABLED WITH RETURN ABOVE :-) 
  use PMTUtilities qw(icdefined);
  
  my $run_mode =  $xnode->xfind(q{//param[@name="run_mode"]/filterchain(filterchain=>'uc')},default=>'multiprocessing');

  print STDERR "running run_mode : $run_mode\n";

  my $result;
  if ($run_mode =~ m/^MULTIPROCESSING$/) {
    return $self->run_multiprocess(@_);
  }
  elsif ($run_mode =~ m/^THREADED$/) {
    return $self->run_threaded(@_);
  }
  elsif ($run_mode =~ m/^RPC$/) {
    return $self->run_rpc(@_);
  }
  else {
    print "Unknown mode $run_mode\n";
    return $self->run_singlethreaded(@_);
  }
}

1;
