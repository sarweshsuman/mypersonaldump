package PMTWorkList;
use strict;
use Carp;
use overload q{<>} => \&iterator_overload,
             'bool'=> \&bool_overload,
             '!' => \&neg_overload,
             q{""} => sub { return "<" . __PACKAGE__ ." instance>"; };

use threads;
use threads::shared;
use Thread::Queue;

sub new {
  my $package = shift;
  my %args = @_;
  my $list = $args{'list'};
  my $o = {};
  $o->{'_list_'} = [];
  for my $i (@$list) {
    push @{$o->{'_list_'}},$i;
  }
  if ($args{'recycle'}) {
    $o->{'recycle'} = $args{'recycle'};
  }
  else {
    $o->{'recycle'} = 0;
  }
  $o->{'recycle'} = 0;
  $o->{'parent'} = $args{'parent'};
  $o->{'recyclelist'} = [];
  $o->{'finished'} = 0;

  return bless $o;
}

sub iterator_overload {
  my $self = shift;
  return $self->next();
}

sub append {
  my $self = shift;
  
}

sub neg_overload {
  my $self = shift;
  if (scalar @{$self->{'_list_'}} > 0) { return 0; } else { return 1; }
}

sub bool_overload {
  my $self = shift;
  if (scalar @{$self->{'_list_'}} > 0) { return 1; } else { return 0; }
}

sub next {
  my $self = shift;
  if (wantarray) {
    my @l = ();
    if ($self->{'finished'}) { return @l; }
    while (scalar @{$self->{'_list_'}}) {
      push @l, shift @{$self->{'_list_'}};
    } 
    if ($self->{'parent'}) {
      my $sp = $self->{'parent'};
      my @pl = <$sp>;
      push @l,@pl;
    }
    $self->{'finished'} = 1;
    return @l;
  }
  elsif (defined wantarray) {
		my $val;
    if ($self->{'finished'}) { return undef; }
		if (scalar @{$self->{'_list_'}}) {
			$val = shift @{$self->{'_list_'}};
		}
		elsif (defined $self->{'parent'} and $self->{'parent'}) {
			 my $sp = $self->{'parent'}; 
			 $val = <${sp}>;
		}
		if ($val) {
      #print STDERR "WorkList returning $val\n";
			return $val;
		}
		else { 
			$self->{'finished'} = 1;
			return undef;
		}
  }
	else {
    if ($self->{'finished'}) { return undef; }
    my $val = undef;
		if (scalar @{$self->{'_list_'}}) {
			$val = shift @{$self->{'_list_'}}; undef;
		}
		elsif (defined $self->{'parent'} and $self->{'parent'}) {
			 my $sp = $self->{'parent'}; 
			 $val = <${sp}>;
		}
    if ($val) {
      # do nothing ?
    }
    else {
      $self->{'finished'} = 0;
    }
    return undef;
  }
}

DESTROY {
  my $self = shift;
  # if a parent is defined, and the parent has recycle mode we should return all the elements on the parent too
  # kinda tricky
}

1;
