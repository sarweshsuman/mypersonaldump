package PMTIteratorGuard;

use overload q{<>} => \&iterator_overload,
             'bool'=> \&bool_overload,
             '!' => \&neg_overload,
             q{""} => sub { return "<" . __PACKAGE__ ." instance>"; };


sub new {
  my $class = shift;
  my $protected = shift;

  my $o = {};
  $o->{'protected'} = $protected;

  return bless $o;
}

sub iterator_overload {
  my $self = shift;
  return $self->{'protected'}->iterator_overload(@_);
}

sub neg_overload {
  my $self = shift;
  return $self->{'protected'}->neg_overload(@_);
}

sub bool_overload {
  my $self = shift;
  return $self->{'protected'}->bool_overload(@_);
}

sub next {
  my $self = shift;
  return $self->{'protected'}->next(@_);
}

sub reset {
  my $self = shift;
  return $self->{'protected'}->reset(@_);
}

DESTROY {
  my $self = shift;
  $self->{'protected'}->reset();
}

1;
