package PMTRegister;

use strict;
use Carp;

sub new {
  my $package = shift;
  my %args = @_;
  my $o = {};

  bless $o;
  return $o;
}

sub run {
  my $self = shift;
}

1;
