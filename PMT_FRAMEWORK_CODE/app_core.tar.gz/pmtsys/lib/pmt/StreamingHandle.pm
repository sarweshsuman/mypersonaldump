package StreamingHandle;

use strict;
use Carp;
use Data::Buffer;

use IO::Handle;
#our @ISA = qw(IO::Handle);
use base qw(IO::Handle::Base);
  
sub new {
  my $class= shift;
  my $o = {};
  $o->{'buffer'} = Data::Buffer->new();
  my $oo = \*o;
  bless $oo;
  return $oo;
}

sub syswrite {
  my $self = shift; 
  my ($scalar,$length,$offset) = @_;

  print STDERR "SYSWRITE is called with $scalar,$length,$offset\n";
}
sub write {
  my $self = shift; 
  my ($scalar,$length,$offset) = @_;

  print STDERR "WRITE is called with $scalar,$length,$offset\n";
}

sub print {
  my $self = shift;
  my @args = @_;
  print STDOUT "print is called\n";
  return 1;
}

sub printf {
  my $self = shift;
  my $format = shift;
  my @args = @_;
  print STDERR "printf is called\n";
  return 1;
}

sub read {
  my $self = shift;
  my ($scalar,$length,$offset) = @_;

  print STDERR "Read was called with $length, $offset\n";
}

sub readline {
  my $self = shift;
  return "5";
}

sub getc {
  my $self = shift;
}

sub close {
  my $self = shift; 
}

sub open {
  my $self = shift;
  my ($filename) = @_;
}

sub binmode {
  my $self = shift;
}

sub eof {
  my $self = shift;
  return 0;
}

sub tell {
  my $self = shift;
  print STDERR "tell was called\n";
  
}

sub seek {
  my $self = shift;
  my ($offset,$whence) = @_;
  print STDERR "seek was called\n";
}

sub destroy {
  my $self = shift;
  print STDERR "destrou was called\n";
}


1;
