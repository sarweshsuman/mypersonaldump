# ####################################################################################################################################
#
# ####################################################################################################################################


# TODO:
# The old system using create request handlers should be simplified, it should not add it to the some stack


package WorkController;
  
use strict;
use Carp;
use PMTExecContext;
use PMTUtilities qw(partial);
use PMTChannelLocker;

use overload q{&{}} => \&call_overload, 
             q{""}  => sub { return "<". __PACKAGE__ . " instance>"};
sub new {
  my $class = shift;
  my %args = @_;
  my $controller = $args{'controller'};
  my $processmodel = $args{'process_model'};
  my $item = $args{'item'};
  


  my $o = {};
  $o->{'controller'} = $controller;
  $o->{'process_model'} = $processmodel;
  $o->{'started'} = 0;

  # I basically inherit the $ic from the controller, the helperhelper
  $o->{'initialcontext'} = $controller->{'initialcontext'};
  $o->{'current_step'} = -1;
  $o->{'current_step_node'} = undef;
  $o->{'iswaiting'} = 0;
  $o->{'item'} = $item;
  my $ic = $o->{'initialcontext'};
  $ic->log(message=>"Creating workdcontroller for item and process_model",data=>{item=>$item,processmodel=>"$processmodel"},domain=>"system",level=>"info");
  return bless $o;
}


sub call_overload {
  my $self = shift;
  return partial(\&run,$self);
}

sub isWaiting {
  my $self = shift;
  return $self->{'iswaiting'};
}

sub start {
  my $self = shift;
  my $controller = $self->{'controller'};
  my $ic = $self->{'initialcontext'};
  # this one should do the setup of all the instances, callables, whatever is in the objects node of the steps
  $ic->log(message=>"In workcontroller start building process for processmodel",data=>$self->{'processmodel'},domain=>"system",level=>"info");
  $controller->send(type=>'new_item',data=>{item=>$self->{'item'}});
  $controller->send(type=>'ic_update',data=>{set=>{'WORKLIST/ITEM'=>$self->{'item'}}});
  $ic->{'WORKLIST/ITEM'} = $self->{'item'};
  $ic->{'RUNTIME/ITEM/SUCCESS'} = 0;

  # the other ones being: RUNTIME/EXEC/GROUP
  #                  and: RUNTIME/EXEC/STEP # this is one we have to set here :-)
  my $pm = $self->{'process_model'};

  if ($pm->exists('objects/object[@lifecycle="item"]')) {
    my @os = ();
    my $sobjects = $pm->xnode(data=>'objects/object[@lifecycle="item"]',force_array=>1);
    for my $sob (@$sobjects) {
      if ($sob->evalPreReqs(condition_type=>'create_condition')) {
        my $npa = $sob->xnodePath();
        push @os,$npa;
      }
    }
    $ic->log(message=>"I found the following objects I should transmit",data=>\@os,domain=>"system",level=>"info");
    $controller->send(data=>\@os,type=>'process_setup');
    
    # and now we should wait for the response to that one to see if it was successfull, but this is somewhat confusing
  }
  
  $self->{'started'} = 1;
}

sub run {
  my $self = shift;
  my %args = @_;
  my $ic = $self->{'initialcontext'};
  $ic->log(message=>"Doing run in workcontroller",domain=>"system",level=>"debug"); 
  my $controller = $self->{'controller'};
  my $pm = $self->{'process_model'};
  my $directives = $args{'directives'};
  my $data = $args{'data'};
  if (not $self->{'started'}) {
    $self->start();
  }
  use Data::Dumper;
  $ic->log(message=>"In workcontroller, got args",data=>\%args,domain=>"system",level=>"debug");
  # end then start the process
  if (defined $args{'directives'}) {
    my $ld = $args{'directives'};
    if ($ld->{'type'} eq 'step_end') {
      my $ldd = $args{'data'};
      my $ldsn = $ldd->{'step'};
      my $ldss = $ldd->{'status'};
      if ($ldss =~ m/^fail$/i) {
        $ic->{"RUNTIME/CURRENT_ITEM/STEPS/${ldsn}/SUCCESS"} = 0;
        $ic->{"RUNTIME/CURRENT_ITEM/STEPS/${ldsn}/FAIL"} = 1;
      }
      else {
        $ic->{"RUNTIME/CURRENT_ITEM/STEPS/${ldsn}/FAIL"} = 0;
        $ic->{"RUNTIME/CURRENT_ITEM/STEPS/${ldsn}/SUCCESS"} = 1;
      }
    }
  }
  my $cs = $self->{'current_step'};
  $ic->log(message=>"In workcontroller, doing process setup",domain=>"system",level=>"debug");
  my $condition_ok = 1; my $no_wait = 1;
  if ($pm->exists("steps/step[\@seq > $cs]")) {
    my $sts = $pm->xnode(data=>"steps/step[\@seq > $cs]",force_array=>1);
    my @sorted_steps = sort { $a->xfind('./@seq') cmp $b->xfind('./@seq') } @$sts;
    my @loggable_steps = map { "$_" } @sorted_steps;
    $ic->log(message=>"Looking for suitable stepnode in",data=>\@loggable_steps,domain=>"system",level=>"debug");

    my $step_to_send;
    # now find the first step that I can send
    my $stepfound = undef;
    use Data::Dumper;
    STEPLOOP:
    for my $stnode (@sorted_steps) {
       my $stepname = $stnode->xfind('./@name');
       $ic->{"RUNTIME/CURRENT_ITEM/STEPS/$stepname/SUCCESS"} = 0;
       $ic->{"RUNTIME/CURRENT_ITEM/STEPS/$stepname/FAIL"} = 0;
       eval {
				 if ($stnode->evalPreReqs(condition_type=>'create_condition')) {
					 # all is well
					 $ic->log(message=>"Create condition for step $stepname are ok",domain=>"system",level=>"debug");
				 }
				 else {
					 # We can skip this all together
					 # and to avoid having to go through this one in the next run
					 $self->{'current_step'} = $stnode->xfind('./@seq');
					 $self->{'current_step_name'} = $stnode->xfind('./@name');
					 $self->{'current_step_node'} = $stnode->xfind('./nodePath()');
					 next STEPLOOP;
				 }
				 if ($stnode->evalPreReqs(condition_type=>'wait')) {
					 # that's ok too
					 $ic->log(message=>"wait_condition for step $stepname are ok",domain=>"system",level=>"debug");
				 }
				 else {
					 # OK, we have a wait condition here ... 
					 $no_wait = 0;
					 $self->{'iswaiting'} = 1;
					 last STEPLOOP;
				 }
				 if ($stnode->evalPreReqs(condition_type=>'condition')) {
					 # we're still good
					 $ic->log(message=>"condition for step $stepname is ok",domain=>"system",level=>"debug");
				 }
				 else {
					 $self->{'current_step'} = $stnode->xfind('./@seq');
					 $self->{'current_step_name'} = $stnode->xfind('./@name');
					 $self->{'current_step_node'} = $stnode->xfind('./nodePath()');
					 next STEPLOOP;
				 }
				 if ($condition_ok and $no_wait) {
					 # I can send the node
					 $self->{'iswaiting'} = 0;
					 $stepfound = $stnode;
					 my $stepname = $stnode->xfind('./@name',default=>'_unknown_');
					 $self->{'current_step'} = $stnode->xfind('./@seq');
					 $self->{'current_step_name'} = $stnode->xfind('./@name');
					 $self->{'current_step_node'} = $stnode->xfind('./nodePath()');

					 my $target = $stnode->xfind('./@target',default=>'helper');
					 $ic->{'RUNTIME/EXEC/STEP'} = $stepname;

					 if (uc $target eq 'HELPER') {
						 $ic->log(message=>"Sending service request to client for step $stepname",domain=>"system",level=>"debug");
						 my $eh = $controller->createRequestHandle(custom=>{request=>'STEP',stepnode=>$stnode->xfind('./xnodePath()')});
						 $controller->submit(request_handle=>$eh);
					 }
					 elsif (uc $target eq 'LOCAL') {
						 use Data::Dumper;
						 eval {
							 my $test = $ic->{'RUNTIME/EXEC/GROUP'};
							 $controller->execLocalStep(stepnode=>$stnode);
						 }; 
             if ($@) { 
               my $e = $@;
               $ic->log(message=>"An error occurred in run in workcontroller", data=>$e,domain=>"system",level=>"error"); 
             }
						 $self->run();
					 }
					 last STEPLOOP;
				 }
       };
       if ($@) {
         my $e = $@;
         $ic->log(message=>"Error ocurred during run in workcontroller",domain=>"system",level=>"info",data=>$e);
       }
    }
    if (not defined $stepfound and $no_wait) {
      $ic->log(message=>"No items found that match and nothing is waiting",domain=>"system",level=>"debug");
      $self->{'iswaiting'} = 0;
      $controller->send(type=>'item_end');
    }
    #else { 
    #  print STDERR "Why did I not send an item_end\nstepfound = $stepfound\n,condition_ok=$condition_ok\n,no_wait=>$no_wait\n";
    #}
  }
  else {
    $ic->log(message=>"No more steps, sending item_end",domain=>"system",level=>"debug");
    $self->{'iswaiting'} = 0;
    $controller->send(type=>'item_end');
  }
  $ic->log(message=>"End of run in workcontroller",domain=>"system",level=>"info");

}

1;

# ####################################################################################################################################
#
# ####################################################################################################################################

package PMTHelperHelper;

select STDERR;
$|=1;
use strict;
use Carp;
use Data::Dumper;

use POSIX ":sys_wait_h";
use IPC::Open2;
use IO::Select;
use IO::Socket::INET;
use PMTUtilities qw(icdefined partial serializeTo deserializeFrom);
use PMTChannelLocker;

use overload '&{}' => \&call_overload, q{""}=>\&as_string;

sub service_request_status_handler {
  my $controller = shift;
  my %args = @_;
  my $directives = $args{'directives'};
  my $data = $args{'data'};
  my $request_id = $data->{'request_id'};
  my $status = $data->{'status'};
#   my $q = $controller->{'run_queue'};
#   my @rh = grep { $_->{'local_id'} eq $request_id } @$q;
#   if (@rh) { $rh[0]->{'status'} = $status; }
#   print STDERR "Setting service request $request_id to status $status, in ",Dumper(\@rh),"\n";
}

sub service_request_response_handler {
  my $controller = shift;
  my %args = @_;
  my $directives = $args{'directives'};
  my $data = $args{'data'};
  my $request_id = $data->{'request_id'};
#   my $q = $controller->{'run_queue'};
#   my @rh = grep { $_->{'local_id'} eq $request_id } @$q;
#   if (@rh) {
#     $rh[0]->{'status'} = 'FINISHED';
#   }
#   use Data::Dumper;
#   print STDERR  "Got service response data:",Dumper($data),"\n";
}

sub service_request_accept_handler {
  my $controller = shift;
  my $ic = $controller->{'initialcontext'};
  # but this doesn't do anything usefull ?
  my %args = @_;
  my $directives = $args{'directives'};
  my $data = $args{'data'};
  my $request_id = $data->{'request_id'};
}

sub child_log_handler {
  my $controller = shift;
  my $ic = $controller->{'initialcontext'};
  my %args = @_;
  my $directives = $args{'directives'};
  my $data = $args{'data'};
  use Data::Dumper;
  # mmmm, this should really go to the log
  #print STDERR "Log handler doing something\n", Dumper(\%args),"\n";
  use PMTUtilities qw(h2a);
  my @lp = h2a(hash=>$data);
  $ic->log(@lp,context=>$directives->{'context'});
}

sub do_status_update { 
  # mmmm, this doesn't do anything usefull
  #print STDERR "Processing message of type status_update\n";
}

#sub do_data_summary { 
#  my $controller = shift;
#  print STDERR "Processing message of type data_summary\n";
#}

sub do_process_statistics { 
  my $controller = shift;
  my $ic = $controller->{'initialcontext'};
  my %args = @_;
  my $data = $args{'data'};
  my $directives = $args{'directives'};
  use Data::Dumper;
  # mmmm, this doesn't do anything usefull
  $ic->log(message=>"Processing a process_statistics message",data=>\%args,domain=>"system",level=>"debug");
}
sub do_new_status {
  # mmmm this doesn't do anything usefull
  #print STDERR "Processing message of type new_status\n";
}

sub do_event {
  my $controller = shift;
  my $ic = $controller->{'initialcontext'};
  my %args = @_;
  my $data = $args{'data'};
  my $directives = $args{'directives'};
  $ic->log(message=>"Processing an event message",data=>\%args,level=>"debug",domain=>"system");
  my $ic = $controller->{'initialcontext'};
  $ic->appendJLOG(data=>$data,directives=>$directives);
}

sub do_process_data {
  my $controller = shift;
  my $ic = $controller->{'initialcontext'};
  my %args = @_;
  my $data = $args{'data'};
  my $directives = $args{'directives'};
  my $ic = $controller->{'initialcontext'};
  $ic->appendJLOG(data=>$data,directives=>$directives);
}

sub do_monitoring_message {
  my $controller = shift;
  my $ic = $controller->{'initialcontext'};
  my %args = @_;
  my $data = $args{'data'};
  my $directives = $args{'directives'};
  $ic->MDBMessage(group=>$ic->{'RUNTIME/EXEC/GROUP'},data=>$data);
}


sub end_ack_handler {
  my $controller = shift;
  my $ic = $controller->{'initialcontext'};
  $controller->{'do_continue'} = 0;
  $controller->setFinished();
}

sub ask_work_handler {
  my $controller = shift;
  my $ic = $controller->{'initialcontext'};
  # this is basically about getting a new item to process
  my %args = @_;
  use Data::Dumper;
  $ic->log(message=>"Got args in ask_work_handler",data=>\%args,domain=>"system",level=>"debug");
 
  if (defined $args{'data'}) {
    my $d = $args{'data'};
    if (defined $d->{'response'} and $d->{'response'} eq 'initial_process_setup' and $d->{'errorcount'} gt 0) {
      $ic->log(message=>"Looks like initial_process_setup had problems :-(",data=>$d,level=>"error",domain=>"system");
      #print STDERR "Looks like initial_process_setup had problems\n";
      $controller->send(type=>'service_end');
      $controller->setFinished();
      return;
    }
    elsif (defined $d->{'response'} and $d->{'response'} eq 'initial_process_setup') {
      $ic->log(message=>"Looks like initial_process_setup went fine",domain=>"system",level=>"info");
    }
  }

  my $worklist = $controller->getResource(name=>'worklist');
  my $processmodel = $controller->getProcessModel();
  #print STDERR "ask_work_handler working with processmodel $processmodel\n";
  #print STDERR "worklist in ask_work_handler = ",$worklist,"\n";
  my $policy = $controller->{'worklist_policy'}; $policy = uc $policy;
  $ic->log(message=>"ask_work_handler called with policy $policy");
  if ($policy eq 'UNDEF') {
    my $item; 
    eval {
     	$item = <$worklist>;
    };
    if ($@) { print STDERR "Error occuured while picking item from worklist: $@\n"; }
    $ic->log(message=>"Picked item from worklist",data=>$item,domain=>"system",level=>"debug");
    if (defined $item) {
      my $work_controller = $controller->buildWorkController(item=>$item);
      $work_controller->(@_);
    }
    else {
      # send an end request
      use Data::Dumper;
      my $eh = $controller->createRequestHandle(custom=>{request=>'__end__'});
      $ic->log(message=>"I should send an end request in ask_work_handler",data=>$eh, domain=>"system",level=>"debug");
      $controller->submit(type=>'service_end',request_handle=>$eh);
       # now make a wait_function;
      #$controller->send(type=>'final_exit');
    }
  }
  elsif ($policy eq 'EMPTY_TOKEN') {
    my $item = <$worklist>;
    if (defined $item and ref $item eq 'EMPTY_TOKEN') {
      use Data::Dumper;
      my $eh = $controller->createRequestHandle(custom=>{request=>'__end__'});
      $ic->log(message=>"I should send an end request in ask_work_handler",domain=>"system",level=>"trace");
      $controller->submit(type=>'service_end',request_handle=>$eh);
    }
    elsif (defined $item) {
      $ic->log(message=>"I should start building a worklist for item",data=>$item,domain=>"system",level=>"debug");
      my $work_controller = $controller->buildWorkController(item=>$item);
      $work_controller->(@_);
    }
    else {
      $ic->log(message=>"Mmmmm, looks like there's nothing there for the time being, let's wait a while",domain=>"system",level=>"debug");
      $controller->send(type=>'wait_work');
    }
  }
  # during development, I will just send an end request
}

sub step_end_handler {
  my $controller = shift;
  my $ic = $controller->{'initialcontext'};
  my %args = @_;
  use Data::Dumper;
  $ic->log(message=>"step_end_handler with args",data=>\%args,domain=>"system",level=>"debug");
 
  my $workcontroller = $controller->getWorkController();
  $workcontroller->(@_);
}

sub helpersetup_handler {
  my $controller = shift;
  my %args = @_;

  my $ic = $controller->{'initialcontext'};
  #print STDERR "ic is now $ic\n";
  my $directives = $args{'directives'};
  my $data = $args{'data'};

  # I should send it everything I have under SYSTEM

  my $sysdata = $ic->{'SYSTEM'};
  #print STDERR "I should send it ",$sysdata,"\n";
  $controller->send(data=>{set=>{SYSTEM=>$sysdata}},type=>'ic_update');
  $controller->send(data=>{set=>{'RUNTIME/EXEC/GROUP'=>$ic->{'RUNTIME/EXEC/GROUP'}}},type=>'ic_update');
  if (icdefined $ic->{'CMDPARAM'}) {
    my $cmdparam = $ic->{'CMDPARAM'};
    $controller->send(data=>{set=>{CMDPARAM=>$cmdparam}},type=>'ic_update');
  }

  # And then the plugins
  # I need env, conf, and xpathinterceptor,and log, log is a little tricky for now
  my $env_helper = $ic->getNamedPlugin(name=>'ENV');
  #print STDERR "ENV helper = ",$env_helper,"\n";

  my $interceptors = $ic->getNamedPlugins(type=>'interceptor');
  my $plugins = [];
  for my $ii (@$interceptors) {
    # this is under the assumption that all we have here are cloneable or inheritable plugins
    #print STDERR "Checking for 'remotability' of plugin $ii->{'name'}\n";
    if ($ii->{'plugin'}->can('noRemoteClone') and $ii->{'plugin'}->noRemoteClone()) {
      # do nothing :-)
      #print STDERR "Plugin $ii->{'name'} cannot be remoted\n";
    }
    else {
      #print STDERR "Plugin $ii->{'name'} can be remoted\n";
      push @{$plugins},{ name=>$ii->{'name'},module=>ref $ii->{'plugin'},initparams=>$ii->{'plugin'}->getCloneData() };
    }
  }

  #push @$plugins, { name=>'LOG',module=>'PMTPLHelperLogHelper' };
  #my $plugins = [
  #  { name=>'ENV',module=>'PMTENVInterceptor',initparams=>$ic->getNamedPlugin(name=>'ENV')->getCloneData() },
  #  { name=>'CONFIG',module=>'PMTConfigInterceptor',initparams=>$ic->getNamedPlugin(name=>'CONFIG')->getCloneData() },
  #  { name=>'JOBDEF',module=>'PMTXPathInterceptor',initparams=>$ic->getNamedPlugin(name=>'JOBDEF')->getCloneData() }
  #];

  $controller->send(type=>'ic_setup',data=>{plugins=>$plugins});
  
  # I should basically send it ic_update and ic_setup data
}

use PMTExecContext;

sub new {
  my $package = shift;
  my %args = @_;
  my $o = {};
  $o->{'workerpool'} = {};
  $o->{'io_pid_mapping'} = {};
  $o->{'initialcontext'} = new PMTExecContext($args{'initialcontext'});
  $o->{'code'} = $args{'code'};
  $o->{'callable'} = $args{'callable'};
  $o->{'instance'} = $args{'instance'};
  $o->{'args'} = $args{'args'};
  $o->{'helperscript'} = $args{'helper'};
  if (exists $args{'async'}) { $o->{'async'} = $args{'async'}; } else { $o->{'async'} = -1};
  $o->{'ioselector'} = IO::Select->new();
  $o->{'state'} = undef;
  $o->{'channel'} = undef;
  $o->{'_workitemfinished_'} = 0;
  $o->{'type'}= undef;
  $o->{'run_queue'} = [];
  $o->{'xnode'} = $args{'xnode'};
  $o->{'local_request_counter'} = 0;
  $o->{'process_model'} = undef; #= $args{'process_model'}; # this should be an xnode
  $o->{'worklist'} = $args{'worklist'};
  $o->{'state'} = undef;
  $o->{'_finished_'} = 0;
  $o->{'_channellocked_'} = 0;
  $o->{'initial_item'} = $args{'initial_item'};
  $o->{'worklist_policy'} = undef;
  $o->{'child_pid'} = [];
  $o->{'helper_id'} = $args{'helper_id'};
  $o->{'_groupmanager_'} = undef;

  use Data::Dumper;
  my $xnode = $o->{'xnode'};
  $xnode->setIC(initialcontext=>$o->{'initialcontext'});
  my $group = $xnode->xfind('./ancestor::group[1]/@name/data(.)');
  my $ic = $o->{'initialcontext'};
  $ic->log(message=>"Building HelperHelper for group $group",domain=>"system",level=>"debug");
  $ic->{'RUNTIME/EXEC/GROUP'} = $group;
  
  if (not $o->{'args'}) {
    $o->{'args'} = {};
  }
  $o->{resources} = {};

  return bless $o;
}

sub setHelperId {
  my $self = shift;
  my $helper_id = shift;
  $self->{'helper_id'} = $helper_id;
}

sub setFinished {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $helper_id = $self->{'helper_id'};
  $ic->log(message=>"setFinished called in PMTHelperHelper $helper_id",domain=>"info",level=>"debug");
  $self->{'_finished_'} = 1;
}

sub setWorkListPolicy {
  my $self = shift;
  my %args = @_;
  my $policy = $args{'policy'};
  $self->{'worklist_policy'} = uc $policy;
  #print STDERR "Setting worklist policy to ",uc $policy,"\n";
}

sub isFinished {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  if ($self->{'_finished_'}) {
    #print STDERR "Mmmm who set this to finished\n";
    return 1;
  }
  my $helper_id = $self->{'helper_id'};
  $ic->log(message=>"isFinished is called in PMTHelperHelper",domain=>"system",level=>"trace");
  my $cl = new PMTChannelLocker($self);
  #print "ChannelLocker created in isFinished\n";
  #print "finished: _finished_ = $self->{'_finished_'}\n";
  if (not $self->{'_finished_'}) {
    # check if its waiting
    my $workcontroller = $self->getWorkController();
    if (not defined $workcontroller) {
      $ic->log(message=>"Eeeeh ? Workcontroller is not defined",domain=>"system",level=>"debug");
    }
    else {
      $ic->log(message=>"Workcontroller is defined ...",domain=>"system",level=>"debug");
    }
    if (defined $workcontroller and $workcontroller->isWaiting()) { 
      $workcontroller->();
    }
  }
  return $self->{'_finished_'};
}

sub getProcessModel {
  my $self = shift;
  return $self->{'process_model'};
}

sub setResources {
  my $self = shift;
  my %args = @_;
  for my $k (keys %args) {
    $self->{'resources'}->{uc $k} = $args{$k};
  }
}

sub setGroupManager {
  my $self = shift;
  my $gm = shift;
  $self->{'_groupmanager_'} = $gm;
}

sub getResource {
  my $self = shift;
  my %args = @_;
  my $resourcename = uc $args{'name'};
  return $self->{'resources'}->{$resourcename};
  
}

sub setProcessModel {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  $self->{'process_model'} = $ic->xnode(data=>$args{'process_model'});
  #$self->{'process_model'} $ic->
  #$self->{'process_model'}->setRootParser(rootparser=>$self->{'xnode'}->{'_rootparser'});
}

sub getProcessModel {
  my $self = shift;
  return $self->{'process_model'};
}

sub send {
  my $self = shift;
  my %args = @_;
  my $waitfor;
  my $channel_writer = $self->{'channel_writer'};
  return $channel_writer->(@_,reader=>partial(\&receive,$self));
}

sub receive {
 my $self = shift;
 # print STDERR "RECEIVE CALLED IN HELPERHEMPER\n";
 my $channel_reader = $self->{'channel_reader'};
 my $rhs = {};
  #print STDERR "CONFIGURING READER handlers\n";
 for my $rh (keys %{$self->{'reader_handlers'}}) {
  #print STDERR "Configuring handler: $rh\n";
  $rhs->{$rh} = partial($self->{'reader_handlers'}->{$rh},$self);
 }
 $channel_reader->(handlers=>$rhs,@_);
}

sub as_string {
  return "<PMTHelperHelper Instance>";
}

sub call_overload {
  my $self = shift;
  use PMTUtilities qw(partial);
  return partial(\&run,$self);
}

sub setup {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $cl = new PMTChannelLocker($self);
  $self->{'code'} = $args{'code'};
  $self->{'callable'} = $args{'callable'};
  $self->{'instance'} = $args{'instance'};
  $self->{'args'} = $args{'args'};
  
  
  my $code = $self->{'code'};
  my $instance = $self->{'instance'};
  my $callable = $self->{'callable'};
  my $args = $self->{'args'};

  my $helper_data = {};
  my $to_execute;
  if ($code) {
    $helper_data->{'code'} = $code;
    $self->{'type'} = 'code';
  }
  elsif (defined $callable) {
    $helper_data->{'callable'} = $callable;
    $self->{'type'} = 'callable';
  }
  elsif (defined $instance) {
    $helper_data->{'instance'} = $instance;
    $self->{'type'} = 'instance';
  }

  $helper_data->{'args'} = $args;

  print STDERR "PMTHelperHelper Waiting for ack for prepare\n";
  $self->send(type=>'setup',wait_for=>'ack',data=>{prepare=>$helper_data});
  print STDERR "PMTHelperHelper got ack\n";
}

sub buildWorkController {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $item = $args{'item'};
  $self->{'_workcontroller_'} = new WorkController(item=>$item,controller=>$self,process_model=>$self->{'process_model'});
  return $self->{'_workcontroller_'};
}

sub getWorkController {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  return $self->{'_workcontroller_'};
}

sub createRequestHandle {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $custom_request = $args{'custom'};

  my $async = $self->{'async'};
  my $channel = $self->{'channel'};
  
  my $type = $self->{'type'};

  my $request_data = {};

 
  my $returns = $args{'returns'}; if (not icdefined $returns) { $returns = 'ARRAY' };
  if ($custom_request) {
    $request_data->{'request'} = $custom_request->{'request'};
    $request_data->{'data'} = {};
    for my $k (keys %$custom_request) {
      if ($k ne 'request') {
        $request_data->{'data'}->{$k} = $custom_request->{$k};
      }
    }
  }
  else {
    if ($type eq 'instance') {
      if (defined $args{'method'}) { 
        $request_data->{'request'} = 'method';
        $request_data->{'method'} = $args{'method'};
      }
      else {
        $request_data->{'request'} = 'call';
        $request_data->{'method'} = 'overload::call';
      }
      $request_data->{'args'} = $args{'args'};
    }
    elsif ($type eq 'callable') {
      $request_data->{'request'} = 'call';
      $request_data->{'args'} = \%args;
    }
    elsif ($type eq 'code') {
      $request_data->{'request'} = 'call';
      $request_data->{'args'} = \%args;
    }
    if ($returns) {
      $request_data->{'returns'} = uc $returns;
    }
    $request_data->{'calling_convention'} = { initialcontext=>1, controller=>1 };
  }
  
  $self->{'local_request_counter'} = $self->{'local_request_counter'} + 1;
  my $request_handle = { request=>$request_data,status=>'WAITING',id=>undef, local_id => $self->{'local_request_counter'} };

  #push @{$self->{'run_queue'}},$request_handle;
  #print "Added the new request handle to the queue\n";

  return $request_handle;
}

sub submit {
  my $self = shift;
  my %args = @_;
  my $cl = new PMTChannelLocker($self);

  use Data::Dumper;
  #print STDERR "In submit, reader_handlers = ",Dumper($self->{'reader_handlers'}),"\n";

  my @to_submit;
  if (defined $args{'request_handle'}) {
    @to_submit = ($args{'request_handle'});
  }
  else {
    my @run_queue = @{$self->{'run_queue'}};
    #@to_submit = grep { $_->{'status'} eq 'WAITING' } @run_queue;
  }
  my $type; if (defined $args{'type'}) { $type = $args{'type'}; } else { $type = "service_request"; }
  
  for my $rh (@to_submit) {
    $self->send(type=>$type,data=>{request_id=>$rh->{'local_id'},data=>$rh->{'request'}});
    
    #print STDERR "$$ Sent service request to child with type $type\n";
    $rh->{'status'} = 'SUBMITTED';
    $self->{'status'} = 'RUNNING';
  }
  return;
}

sub helperSetup {
  my $self = shift;

  my $ic = $self->{'initialcontext'};
  my $xnode = $self->{'xnode'};
  my $processmodel = $self->{'process_model'};

  $ic->log(message=>"Building processmodel in helpersetup for xnode",domain=>"system",level=>"debug",data=>"$xnode");
  # This should do the startup of the helper ... 
  my $args = $self->{'args'};
  my $helperscript = $self->{'helperscript'};
  my $ident = $ic->expand('{{_PROCESSID_}}.{{SYSTEM/RUN/FLOWCD}}.{{SYSTEM/RUN/ROLE}}.{{RUNTIME/EXEC/GROUP}}');
  use File::Spec;
  my $helper_id = $self->{'helper_id'};
  my $l = File::Spec->catfile('/opt/PMT/tmp',$ic->expand("{{_PROCESSID_}}.{{SYSTEM/RUN/FLOWCD}}.{{SYSTEM/RUN/ROLE}}.{{RUNTIME/EXEC/GROUP}}.${helper_id}.log"));
  my $code = $self->{'code'};
  my $callable = $self->{'callable'};
  my $instance = $self->{'instance'};
  my $async = $self->{'async'};
  
  if (not defined $args) { $args = {}; }
  if (not defined $helperscript) { $helperscript = 'PMTPLHelper'; }

  my $do_continue = 1;
  my $workerpool = $self->{'workerpool'};
  my $io_pid_mapping = $self->{'io_pid_mapping'};
  my $selector = $self->{'ioselector'}; 


  my ($child_writer,$child_reader);
  my $cmd = "$helperscript --ident $ident --serr $l";
  my $pid = open2($child_reader,$child_writer,$cmd);
  $ic->log(message=>"Starting helper wuth command $cmd, giving me pid $pid",domain=>"system",level=>"debug");
  push @{$self->{'child_pid'}},$pid;

  my $wtr = IO::Handle->new()->fdopen($child_writer,"w");
  my $rdr = IO::Handle->new()->fdopen($child_reader,"r");

  serializeTo(type=>'handshake_request',data=>{request=>'handshake'},io=>$wtr);
  my $response_data = deserializeFrom(io=>$rdr,wait_for=>'handshake_response');
  my $handshake;
  if (defined $response_data->{'response'}->{'handshake'}) {
    $handshake = $response_data->{'response'}->{'handshake'};
    use Data::Dumper;
    $ic->log(message=>"Got handshake data from helper process",data=>$handshake,level=>"debug",domain=>"system");
  }
  else {
    croak {message=>'Protocol error in communication with child'};
  }
  my $socket = IO::Socket::INET->new(
      PeerHost=>$handshake->{'host'},
      PeerPort=>$handshake->{'port'},
      Proto=>'tcp'
  ) or die "Could not create connection: $!";  
  $ic->log(message=>"Created client socket in PMTHelperHelper",domain=>"system",level=>"trace");
  $selector->add($socket);
  $self->{'channel'} = $socket;
  $workerpool->{$pid} = { reader=>IO::Handle->new()->fdopen($child_reader,"r"),
                          writer=>IO::Handle->new()->fdopen($child_writer,"w"),
                          status=>'WAIT',
                          channel=>$socket
                        };

  $io_pid_mapping->{$socket} = $pid;

  $self->{'state'} = 'INITIALIZED';



  # Create a few shortcuts ...

  $self->{'reader_handlers'} = {
    service_request_status=>partial(\&service_request_status_handler),
    service_request_accept=>partial(\&service_request_accept_handler),
    ic_update_ack=> sub { },
    end_ack=>partial(\&end_ack_handler),
    ask_work=>partial(\&ask_work_handler),
    step_end=>partial(\&step_end_handler),
    #service_request_response=>sub { print STDERR "In service_request_response handler\n"; }, # partial(\&service_request_response_handler),
    service_request_response=>partial(\&service_request_response_handler),
    log=>partial(\&child_log_handler),
    status_update=>partial(\&do_status_update),
    # data_summary=>partial(\&do_data_summary),
    event=>partial(\&do_event),
    process_data=>partial(\&do_process_data),
    process_statistics=>(\&do_process_statistics),
    monitoring_message=>(\&do_monitoring_message),
    new_status=>(\&do_new_status)
  };
  my $cr = partial(\&deserializeFrom,io=>$socket);
  my $cw = partial(\&serializeTo,io=>$socket);
  $self->{'channel_writer'} = $cw;
  $self->{'channel_reader'} = $cr;

  #print STDERR "PMTHelper waiting for ack for prepare request in constructor\n";
  #$cw->(type=>'setup',data=>{prepare=>$helper_data},wait_for=>'ack');
  #print STDERR "PMTHelper got ack for prepare request in constructor\n";

}

sub run {
  my $self = shift;
  my $ic = $self->{'initialcontext'};

  if (not defined $self->{'state'}) {
    $self->helperSetup();
  }
  $self->helpersetup_handler();
  $self->send(type=>'lock_channel',wait_for=>'channel_locked');
  $self->{'_channellocked_'} = 1;
  my $pm = $self->{'process_model'};
  if ($pm->exists('objects/object[@lifecycle != "item"]')) {
    my $sobjects = $pm->xfind('objects/object[@lifecycle != "item"]/xnode()',force_array=>1);
    my @os = ();
    for my $sob (@$sobjects) {
      if ($sob->evalPreReqs(condition_type=>'create_condition')) {
        my $npa = $sob->xnodePath();
        push @os,$npa;
      }
    }
    $ic->log(message=>"In run, sending initial_process_setup data to helper process",data=>\@os,level=>"debug",domain=>"system");
    $self->send(data=>\@os,type=>'initial_process_setup');
    $ic->log(message=>"In run, sent initial_process_setup data to helper process",data=>\@os,level=>"debug",domain=>"system");
  }
  else {
    $ic->log(message=>"... and telling the helper process to get started",domain=>"system",level=>"trace");
    $self->send(type=>'helper_start');
  }
}



sub processQueue {
  my $self = shift;
  # Allthough this does not seem to do anything, the following line is absolutely crucial
  # Be very very carefull if you want to change this ... You have been warned :-)
  my $cl = new PMTChannelLocker($self);
}

sub isWorkItemFinished {
  my $self = shift;
  return $self->{'_workitemfinished_'};
}

sub join {
  my $self = shift;
  my %args = @_;
  my $ic = $self->{'initialcontext'};
  $ic->log(message=>"TODO: See if the join method in " . __PACKAGE__ ." can be completely removed",domain=>"system",level=>"warning");
}

####
## A Series of testfunctions ... 
## For UnitTesting or whatever
####

sub test_send_ic_update {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $data = $args{'data'};

  my $cl = new PMTChannelLocker($self);
  $self->send(data=>$data,wait_for=>'ic_update_ack',type=>'ic_update');
  #print STDERR "Got ack for ic_update\n";
}

sub kill {
  my $self = shift;
  # not clear yet what I have to do here ...
}

sub DESTROY {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  #print STDERR "$$ In destructor of PMTHelperHelper;\n";
  use Data::Dumper;
  my $rh = $self->{'reader_handlers'};
  #print STDERR "$$ In destructor, reader_handlers = ",Dumper($rh),"\n";
  if ($self->{'state'} eq 'TERMINATED') { return; }
  $self->join(_destructor_=>1);
  #print STDERR "PMTHelperHelper: I am done: I should somehow tell the child I'm exiting\n";
  #undef $self->{'channel_reader'};
  #undef $self->{'channel_writer'};
  $self->send(type=>'final_exit');
  #print STDERR "Shutting down channel in helperhelpeer\n";
  $self->{'channel'}->shutdown(2);
  $self->{'channel'}->close();
  # and finally wait for the child
  my $workerpool = $self->{'workerpool'};
  for my $p (keys %$workerpool) {
    #my $rc = waitpid($p,WNOHANG);
    my $rc = waitpid($p,0);
  }
  undef;
}

sub execLocalStep {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_; 
  my $test = $ic->{'RUNTIME/EXEC/GROUP'};
  my $stepnode = $args{'stepnode'};
  my $test2 = $stepnode->texpand('{{RUNTIME/EXEC/GROUP|default groupnotnown}}');
  # what can I find here
  $ic->log(message=>"Executing a local step",data=>"$stepnode",domain=>"system",level=>"debug");
  my $names = $stepnode->xfind('*[name() != "pre_reqs"]/name(.)',force_array=>1);
  for my $n (@$names) {
    $ic->log(message=>"Executing a local step of type $n",domain=>"system",level=>"debug");
  }
  my $stepelements = $stepnode->xnode(data=>'*[name() != "pre_reqs"]',force_array=>1);
  for my $sel (@$stepelements) {
    my $n = $sel->xfind('./name()');
    if ($n eq 'ic_update') {
      my $ic_update = $sel->xfind('./parseParamset()');
      use PMTUtilities qw(icdefined mergeRecursiveHash);
      if (icdefined $ic_update) {
        mergeRecursiveHash(src=>$ic_update,update=>$ic);
      }   
    }   
    elsif ($n eq 'call') {
      my $object = $sel->xfind('object');
      my $method = $sel->xfind('method');
     
      my $params;
      if ($sel->exists('params')) {
        $params = $sel->xfind('params');
      } else { $params = {};} 
      use Data::Dumper();
      my $item = $params->{'item'};
      eval {
        my $exp = $ic->expand($item);
      }; 
      if ($@) { print STDERR "Could not expand item: $item: $@\n"; }
      use PMTUtilities qw(h2a);
      my @cp = h2a(hash=>$params);
      eval {
        $object->$method(@cp);
      };
      if ($@) { print STDERR "Error occurred during execution of localstep: $@" };
    }
  }
}

1;

