# ##########################################################################
# MODULENAME          : PMTStackedDataHandler;
# DESCRIPTION         : StackedDataHandler is helper class for PMTExecContext;
# AUTHOR              : Evert Carton
# INPUTS              : NONE
# OUTPUTS             : NONE
# DEPENDENCY          : NONE
# REMARKS             : NONE
# VERSION             : 1.0
# REVISION HISTORY    : Initial Version
# ##########################################################################

# ==========================================================================
#
# Package Declaration
#
# ==========================================================================

package PMTStackedDataHandler;

# ==========================================================================
#
# Use and API declaration
#
# ==========================================================================
use strict;
use Carp;
use Tie::Hash;

our @ISA = qw(Tie::Hash);

use PMTUtilities qw(evalBoolean any icdefined);
use overload 
   'bool' => \&booleval,  
   '${}'  => \&ashash,
   '""'  => \&asstring;

# ==========================================================================
#
# Constructor
#
# ==========================================================================

sub TIEHASH {
  my $class = shift;
  my %args = @_;
  my @aa = @_;

  #my $path = $args{'path'};
  #my $parent = $args{'parent'};
  my $root = {};
  my $stack = [];
  my $deleted = [[]];
  my $current =$root;
  my $current_deleted = undef;
  my $obj = [0,{
    _initialcontext_      => $args{'initialcontext'},
    _constructor_args_      => \@aa,
    _root_                  => $root,
    _current_level_         => 0,
    _current_delete_level_  => 0,
    _deleted_               => [[]],
    _current_               => $current,
    _current_deleted_       => $current_deleted,
    _stack_                 => [$root],
    _image_                 => undef,
    _key_indices_           => undef,
    _needs_image_rebuild_   => 1,
    _interceptors           => [],
    _preset_interceptors_   => [],
    _postset_interceptors_  => [],
    _preread_interceptors_  => [],
    _postread_interceptors_ => [],
    _runinterceptors_       => 0,
    _subs_                  => [],
    _path_                  => undef,
    _parent_                => 0,
    _dynamic_               => 0,
    _aux_layers_            => [[]],
    _current_aux_layer      => undef
  }];
  $obj->[1]->{'_current_aux_layer_'} = $obj->[1]->{'_aux_layers_'}->[-1];
  bless $obj;
  return $obj;
}

# ==========================================================================
#
# Private Methods
#
# ==========================================================================
sub setInitialContext { 
  my $self = shift; my $S = $self->[1];
  my %args = @_;
  $S->{'_initialcontext_'} = $args{'initialcontext'};
}
sub setNeedsRebuild {
  my $self = shift; my $S = $self->[1];
  $S->{'_needs_image_rebuild_'} = 1;
  if ($self->hasParent()) {
    my $p = $S->{'_parent_'};
    $p->setNeedsRebuild();
  }
}

sub setDynamic {
  my $self = shift; my $S = $self->[1];
  $S->{'_dynamic_'} = 1;
}

sub setRawHash {
  my $self = shift; my $S = $self->[1];
  $S->{'_rawhash_'} = shift;
}
sub getRawHash {
  my $self = shift; my $S = $self->[1];
  my $rh = $S->{'_rawhash_'};
  if (wantarray) {
   return %$rh;
  }
  else {
    return $rh;
  }
}
sub getPath {
  my $self = shift; my $S = $self->[1];
  if (not defined $S->{'_parent_'}) {
    return undef;
  }
  return ($S->{'_parent_'}->getPath(),$S->{'_path_'})
}

sub setPath {
  my $self = shift; my $S = $self->[1];
  $S->{'_path_'} = shift;
}

sub setParent {
  my $self = shift; my $S = $self->[1];
  $S->{'_parent_'} = shift;
}

sub getTreeRoot {
  my $self = shift; my $S = $self->[1];
  return $S->{_root_};
}

sub addInterceptor {
  my $self = shift; my $S = $self->[1];
  my $interceptor = shift;
  my @p = $self->getPath();
  push (@{$S->{'_interceptors_'}},$interceptor);

  my $paths ;
  if ($interceptor->can('getPaths')) {
    $paths = $interceptor->getPaths();
    if (ref $paths eq 'ARRAY') {
      $paths = {
         preRead=>$paths,
         postRead=>$paths,
         preSet=>$paths,
         postSet=>$paths
      };
    }
  }
  else {
    $paths = {
      preRead=>['.*'],
      postRead=>['.*'],
      preSet=>['.*'],
      postSet=>['.*']
    };
  }

  my $raw = 0;
  if ($interceptor->can('needRaw')) {
    $raw = $interceptor->needRaw();
    #print STDERR "Adding interceptor ",ref $interceptor,"with raw $raw\n";
  }
  if ($interceptor->can('preSet')) {
    #print STDERR "adding intercepter $interceptor to preset_interceptors at @p\n";
    push (@{$S->{'_preset_interceptors_'}},{ raw=>$raw, interceptor=>$interceptor, paths=>$paths->{'preSet'} } );
  }
  if ($interceptor->can('postSet')) {
    #print STDERR "adding intercepter $interceptor to postset_interceptors at @p\n";
    push (@{$S->{'_postset_interceptors_'}},{raw=>$raw, interceptor=>$interceptor,paths=>$paths->{'postSet'}});
  }
  if ($interceptor->can('preRead')) {
    #print STDERR "adding intercepter $interceptor to preread_interceptors at @p\n";
    push (@{$S->{'_preread_interceptors_'}},{raw=>$raw, interceptor=>$interceptor,paths=>$paths->{'preRead'}});
  }
  if ($interceptor->can('postRead')) {
    #print STDERR "adding intercepter $interceptor to postread_interceptors at @p\n";
    push (@{$S->{'_postread_interceptors_'}},{raw=>$raw, interceptor=>$interceptor,paths=>$paths->{'postRead'}});
  }
  for my $sth (@{$S->{'_subs_'}}) { 
    #print STDERR "adding intercepter $interceptor to subs at @p\n";
    $sth->addInterceptor($interceptor);
  }
}

sub stopInterceptors {
  my $self = shift; my $S = $self->[1];
  $S->{'_runinterceptors_'} = 0;
  for my $sth (@{$S->{'_subs_'}}) {
    $sth->stopInterceptors();
  }
}

sub startInterceptors {
  my $self = shift; my $S = $self->[1];
  $S->{'_runinterceptors_'} = 1;
  for my $sth (@{$S->{'_subs_'}}) {
    $sth->startInterceptors();
  }
}

sub exportProcessImage {
  my $self = shift; my $S = $self->[1];
  my %args = @_;
  my $startlevel;
  if (defined $args{'fromlevel'}) {
    # Just to make sure we start from a recent image
    my $dummy = $self->getCurrentImage();
    $startlevel = $args{'fromlevel'} - 1;
  }
  else {
    $startlevel = 0;
  }

  my @pathcomponents = $self->getPath();
  if (scalar @pathcomponents > 1 and not defined $pathcomponents[0]) {
    my $throwaway = shift @pathcomponents;
  }

  my %image;
  my $levelcount = $S->{'_current_level_'} + 1;
  for (my $loopcounter = 0; $loopcounter < $levelcount; $loopcounter++) {
    my $levelelements = $S->{'_stack_'}->[$loopcounter];
    my $leveldeleted = $S->{'_deleted_'}->[$loopcounter];
    for my $k (keys %$levelelements) {
      #if ($k eq '__DYNAMIC__') {
        # I think we can discard this one here
      #}
      #else {
        #print STDERR "Exporting key $k at level [$loopcounter] at @pathcomponents\n";
        my $tk = $levelelements->{$k}->{'_value_'};
        if (icdefined $tk and ref $tk eq 'HASH') {
          #print STDERR "exporting hash:\n";
          for my $lk (%$tk) {
            #print STDERR "Key $lk found in HASH at $k: $tk->{$lk}\n";
          }
          my $ttk = tied($tk);
          if ($ttk) { print STDERR "I got a HASH and it is tied to $ttk\n"; $tk = $ttk->exportProcessImage(fromlevel=>$startlevel);}
          else { #print STDERR "I got a hash at $k but it is not tied\n";
          }
          $image{$k} = $tk;
        }
        elsif (icdefined $tk and ref $tk eq __PACKAGE__) {
          my $tmp = $tk->exportProcessImage(fromlevel=>$args{'fromlevel'});
          if (keys %$tmp) {
            my $t = {};
            for my $k (keys %$tmp) {
              $t->{$k} = $tmp->{$k}; 
            }
            $image{$k}  = $t;
          }
          
        }
        elsif (icdefined $tk) {
          if ($loopcounter >= $startlevel) {
            $image{$k} = $tk;
          }
        }
        else {
        }
      #}
    }
    for my $k (@$leveldeleted) {
      delete $image{$k};
    }
  }
  my @keys = sort keys %image;
  my $keycounter = 0;
  my @keylist = map ( {($_,$keycounter++)} @keys);
  my %keyindices = @keylist;

  return \%image;
}

sub getCurrentImage {
  my $self = shift; my $S = $self->[1];
  my %args = @_;
  my $startlevel = 0;
  my $parent = $args{'parent'};

  if ($S->{'_needs_image_rebuild_'} == 0) {
    return $S->{'_image_'};
  }

  my @pathcomponents = $self->getPath();
  if (scalar @pathcomponents > 1 and not defined $pathcomponents[0]) {
    my $throwaway = shift @pathcomponents;
  }

  # The image is what we will be building
  my %image;

  # A flag
  my $is_dynamic = 0;

  my $levelcount = $S->{'_current_level_'} + 1;
  for (my $loopcounter = $startlevel; $loopcounter < $levelcount; $loopcounter++) {
    my $levelelements = $S->{'_stack_'}->[$loopcounter];
    my $leveldeleted = $S->{'_deleted_'}->[$loopcounter];
    for my $k (keys %$levelelements) {
      my $rk = $levelelements->{$k};
      if (not ref $rk ) {
        # This should NEVER EVER HAPPEN !
        print STDERR "Serious programming error.Non ref found while building current image\n"; 
      }
      my $tk = $levelelements->{$k}->{'_value_'};
      if (icdefined $tk and ref $tk eq 'HASH') {
        # This should no longer occur after some rework elsewhere
        $image{$k} = $rk;
      }
      elsif (icdefined $tk and ref $tk eq __PACKAGE__) {
        # We just want it to compute its current image, but we don't use it directly
        my $dummy = $tk->getCurrentImage();
          
        # We reference it again, we should now have the new one, with recomputed current image
        $image{$k} = $levelelements->{$k};
      }
      elsif (icdefined $tk) {
        $image{$k} = $rk;
      }
    }
    for my $k (@$leveldeleted) {
      delete $image{$k};
    }
  }
  my @keys = sort keys %image;
  my $keycounter = 0;
  my @keylist = map ( {($_,$keycounter++)} @keys);
  my %keyindices = @keylist;

  # We do update the current state
  my $imref = \%image;
  $S->{'_image_'} = $imref;
  $S->{'_key_indices_'} = \%keyindices;
  $S->{'_needs_image_rebuild_'} = 0;

  return defined wantarray ? $imref : undef;
}

sub getCurrLevel {
  my $self = shift; my $S = $self->[1];
  return $S->{'_current_level_'};
}

sub getCurrent {
  my $self = shift; my $S = $self->[1];
  return $S->{'_stack_'}->[$self->getCurrLevel()];
}

sub getCurrentDeleteLayer {
  my $self = shift; my $S = $self->[1];
  my $currlevel = $self->getCurrLevel();
  return $S->{'_stack_'}->[$currlevel];
}
sub getCurrDeleteLevel {
  my $self = shift; my $S = $self->[1];
  return $S->{'_current_delete_level_'};
}

# ==========================================================================
#
# Implementation of HASH API
#
# ==========================================================================
sub STORE {
  my $self = shift; my $S = $self->[1];
  my $k = shift;
  my $val = shift;
  my $currlevel = $self->getCurrLevel();
  my $current = $self->getCurrent();

  my @pathcomponents = $self->getPath();
  if (scalar @pathcomponents > 1 and not defined $pathcomponents[0]) {
    my $throwaway = shift @pathcomponents;
  }
  if (ref $k eq 'ARRAY' or $k =~ m/\//) {
    if ($k =~ m/\//) {
      $k =~ s/^\///;
      $k =~ s/\/$//;
      my @splitk = split(/\//,$k);
      $k = \@splitk;
    }
    #print STDERR "Using a composite key @$k at @pathcomponents\n";
    my @localk = @$k;
    if (scalar @localk >0 and not defined $localk[0]) {
      shift @localk;
    }

    if (scalar @localk > 1) {
      my $l = shift @localk;
      $S->{'_rawhash_'}->{$l}->{\@localk} = $val;
      return;
    }
    else {
      $k = $localk[0];
      #print STDERR "Remaining local for key $k at @pathcomponents\n";
    }
  }

  
  if (ref $val eq PMTUtilities::VALUESPEC) {
  }
  if (ref $val eq 'HASH') {
  #print STDERR "Trying to save something of type ",ref $val, "(",tied(%$val),") under key $k at @pathcomponents\n";
  #print "    Keys:",keys %$val,"\n";
  }
  else {
  #print STDERR "Trying to save something of type ",ref $val, "under key $k at @pathcomponents\n";
  }
  my $image = $self->getCurrentImage();
  my $doesexist = exists $image->{$k};
  my $origvalue;
  if ($doesexist) {
    $origvalue = $image->{$k}->{'_value_'};
  }
  else {
    $origvalue = undef;
  }

  my $nosubtree = 0;
  my $volatile = 0;
  if (ref $val eq PMTUtilities::VALUESPEC) {
    my $vs = $val;
    if (exists $vs->{'_volatile_'}) {
     $volatile = evalBoolean(value=>$vs->{'_volatile_'});
    }
    $val = $vs->{'_value_'};
    if (exists $vs->{'_nosubtree_'}) {
      $nosubtree = evalBoolean(value=>$vs->{'_nosubtree_'});
    }
  }
  
  my $setvalue;
  if (ref $val eq 'HASH') {
    if (exists $val->{'__DYNAMIC__'}) {
      $setvalue = undef;
    }
    else {
      $setvalue = $val;
      #print "the setvalue is now set to $val\n";
    }
  }
  else {
    $setvalue = $val;
  }

  my $tmp_nvpair = { 
     key=>$k,
     setvalue=>$setvalue,
     value=>$setvalue,
     _exist_=>$doesexist,
     _origvalue_=>$origvalue,
     _volatile_=>$volatile 
  };

  if ($S->{'_runinterceptors_'}) {
    my $icntr = 0;

    if (defined $S->{'_preset_interceptors_'} ) {
      for my $pre_int (@{$S->{'_preset_interceptors_'}}) {
        my @dynpath = (@pathcomponents,$tmp_nvpair->{'key'});
        my $ckey = join('/',@dynpath);
        my @pths = @{$pre_int->{'paths'}};
        my @matches = map { if ($ckey =~ m:$_:)  { 1;} else { 0; }} @pths;
        if (any(sequence=>\@matches)) {
          my $preset_int = $pre_int->{'interceptor'};
          print STDERR "preset_int is now $preset_int\n";

        my $rnvpair = $preset_int->preSet(key=>$tmp_nvpair->{'key'},
                                     value=>$tmp_nvpair->{'value'},
                                     _volatile_=>$tmp_nvpair->{'_volatile_'},
                                     _exist_=>$doesexist, 
                                     _ckey_=>$ckey,
                                     _origvalue_=>$origvalue,
                                     _path_=>\@pathcomponents
                                    );
        if (defined $rnvpair) {
          if ($tmp_nvpair->{'key'} eq $rnvpair->{'key'}) {
            # I don't think I need to do anything here
            if (exists $rnvpair->{'value'}) {
              $tmp_nvpair->{'value'} = $rnvpair->{'value'};
            }
            else {
              if (exists $tmp_nvpair->{'value'}) {
                delete $tmp_nvpair->{'value'};
              }
            }
            if (exists $rnvpair->{'_volatile_'}) {
              $tmp_nvpair->{'_volatile_'} = $rnvpair->{'_volatile_'}; 
            }
            #print STDERR "keys haven't changed and value = now $tmp_nvpair->{'value'}\n";
            $icntr++;
          }
          else {
            # I should actually restart the loop ... 
            $icntr = 0;
            $doesexist = exists $image->{$rnvpair->{'key'}};
            if ($doesexist) {
              $origvalue = $image->{$rnvpair->{'key'}}->{'_value_'};
            }
            else {
              $origvalue = undef;
            }
            if (exists $rnvpair->{'value'}) {
              $tmp_nvpair->{'value'} = $rnvpair->{'value'};
            }
            else {
              if (exists $tmp_nvpair->{'value'}) {
                delete $tmp_nvpair->{'value'};
              }
            }
            $tmp_nvpair->{'key'} = $rnvpair->{'key'};
          }
          #$tmp_nvpair = { key=>$rnvpair->{'key'},value=>$rnvpair->{'value'},_volatile_=>0 };
        }
        else {
          $icntr++;
        }
        }
      } # end of while loop
    } # end of defined preset_interceptors
  }

  $setvalue = $tmp_nvpair->{'value'};
  my $hasvalue;
  if (exists $tmp_nvpair->{'value'}) {
    $hasvalue = 1;
    $setvalue = $tmp_nvpair->{'value'};
  }
  else {
    $hasvalue = 0;
    $setvalue = undef;
  }
  if (not $hasvalue) {
    return undef;
  }


  $volatile = evalBoolean(value=>$tmp_nvpair->{'_volatile_'});

  #if ($S->{'_dynamic_'}) {
  #print "After presetters, volatile = $volatile, setvalue = $setvalue\n";
  #croak { message=>'You cannot store data in a dynamically generated hash object' };
  #  if (ref $setvalue eq 'HASH' and $setvalue->{'__DYNAMIC__'}) {
  #    print STDERR "We'll let this one fly at @pathcomponents\n";
  #    #return $setvalue;
  #    # We still need to run through the postsetters
  #  }
  #  elsif (ref $setvalue eq 'HASH' and exists $setvalue->{'_volatile_'}) {
  #    print STDERR "Attempting to store a volatile value at @pathcomponents\n";
  #    # We still need the postsetters though
  #  }
  #  else {
  #    print STDERR "Attempting to store $setvalue\n";
  #    print STDERR "You cannot store data in a dynamically generated hash object at @pathcomponents as $tmp_nvpair->{'key'}\n";
  #    return $val;
  #  }
  #}
  #print STDERR "Storing $val under key '$k' in level $currlevel\n";

  if ($volatile) {
    #print STDERR "Volatile = $volatile and I am exiting\n";
    # We do not really need to store anything
  }
  else {
    if (exists $image->{$tmp_nvpair->{'key'}}) {
      #print STDERR "Modifying an existing value in the hash at @pathcomponents: $tmp_nvpair->{'key'}\n";
      #print STDERR "is setvalue set here: $setvalue\n";
      # it's an existing value ...
      if (ref $setvalue eq 'HASH') {
        #print "Settint to a hash\n";
        use PMTUtilities qw(mergeRecursiveHash);
        #mergeRecursiveHash(src=>$setvalue,update=>$self);
      }
      else {
				$current->{$tmp_nvpair->{'key'}}->{'_key_'} = $tmp_nvpair->{'key'};
				$current->{$tmp_nvpair->{'key'}}->{'_value_'} = $setvalue;
				$current->{$tmp_nvpair->{'key'}}->{'_modified_'} = time();
				$current->{$tmp_nvpair->{'key'}}->{'_path_'} = &{sub { my @pp = grep { defined $_ } $self->getPath(); my $p = \@pp; return $p; }}();
				$current->{$tmp_nvpair->{'key'}}->{'_layer_'} = $self->getCurrLevel();
				#if ($tmp_nvpair->{'key'} ne '__DYNAMIC__') {
				if ($tmp_nvpair->{'key'} ne '__DYNAMIC__' ) {
					push @{$S->{'_current_aux_layer_'}},$current->{$tmp_nvpair->{'key'}};
				}
      }
    }
    else {
      # It's a new value
      #print STDERR "Storing a new value $setvalue in the hash under key $tmp_nvpair->{'key'} at @pathcomponents\n";
      my $ts = time();
      # If interceptors have not been started yet, it's an initial value... 
      my $initial = 1 - $S->{'_runinterceptors_'};
      my $value_to_store = $setvalue;
      if ($S->{'_dynamic_'}) {
        #print STDERR "I need to persist myself for $value_to_store at @pathcomponents\n";
        $self->dynamic2persist();
      }
      #print STDERR "The NEW value = $value_to_store at @pathcomponents\n";
      if (ref $value_to_store eq __PACKAGE__ && $value_to_store->isDynamic()) {
        $value_to_store = {};
      }
      if (ref $value_to_store eq 'HASH') {
        #print STDERR "Creating a sublevel to store a HASH\n";
        my %stacked_parameters;
        $value_to_store = tie (%stacked_parameters,__PACKAGE__ ,@{$S->{'_constructor_args_'}});
        $value_to_store->setRawHash(\%stacked_parameters);
        #print STDERR "Created sublevel\n";
        $value_to_store->setParent($self);
        $value_to_store->setPath($tmp_nvpair->{'key'});
        while ($value_to_store->getNumberOfLevels() < $self->getNumberOfLevels()) {
           $value_to_store->addParameterStack();
        }
        for my $interceptor (@{$S->{'_interceptors_'}}) {
          $value_to_store->addInterceptor($interceptor);
        }
        push (@{$S->{'_subs_'}},$value_to_store);
        if ($S->{'_runinterceptors_'}) {
          $value_to_store->startInterceptors();
        }
        for my $nkey (keys %{$tmp_nvpair->{'value'}}) {
          #print STDERR "Storing new value $tmp_nvpair->{'value'}->{$nkey} under key $nkey in new hash\n";
          #$value_to_store->{$nkey} = $tmp_nvpair->{'value'}->{$nkey};
          $stacked_parameters{$nkey} = $tmp_nvpair->{'value'}->{$nkey};
        }
      }
      elsif ( ref $value_to_store eq __PACKAGE__ ) {
        #print STDERR "NEW value = ",__PACKAGE__,"\n";
        push (@{$S->{'_subs_'}},$value_to_store);
      }
      my $stval =  { _path_=>&{sub { my @pp = grep { defined $_ } $self->getPath(); my $p = \@pp; return $p; }}(),
                     _key_=> $tmp_nvpair->{'key'},
										 _created_ => $ts, 
                     _modified_ => $ts, 
                     _value_=>$value_to_store, 
                     _initial_=>$initial,
                     _layer_=>$self->getCurrLevel() };
      #$current->{$tmp_nvpair->{'key'}} = $tmp_nvpair->{'value'};
      $current->{$tmp_nvpair->{'key'}} = $stval;
      # and push that value to the _current_aux_layer
      #push @{$S->{'_current_aux_layer_'}},$key;
      if ($tmp_nvpair->{'key'} ne '__DYNAMIC__' and not grep (/$tmp_nvpair->{'key'}/,@{$S->{'_current_aux_layer'}})) {
      	push @{$S->{'_current_aux_layer_'}},$current->{$tmp_nvpair->{'key'}};
      }
    }
  }

  if ($S->{'_runinterceptors_'}) {
    my $keep_nvpair = { key=>$k,value=>$val};
    for my $postset_int (@{$S->{'_postset_interceptors_'}}) {
      my $ppint = $postset_int->{'interceptor'};
      #my $rnvpair = $ppint->postSet(key=>$tmp_nvpair->{'key'},
      #                                    value=>$setvalue,
      #                                    _exist_=>$doesexist,
      #                                    _volatile_=>$volatile,
      #                                    _origvalue_=>$origvalue,
      #                                    _path_=>\@pathcomponents
      #                                   );
      #if (defined $rnvpair) {
      #  # do I need to do something special with this ...  ?
      #}
    }
  }
  # rebuild current deleted;
  my @newcurrdeleted = grep (!/^$k$/,@{$S->{'_current_deleted_'}});
  #print STDERR "Do I make it to the end ?\n";
  $S->{'_deleted_'}->[$currlevel] = \@newcurrdeleted;
  $S->{'_needs_image_rebuild_'} = 1;
}

sub getElement {
  my $self = shift;my $S = $self->[1];
  my $k = shift;
  #print STDERR "getElement = looking for key $k\n";
  my $image = $self->getCurrentImage();
  my $rval = $image->{$k}->{'_value_'};
  if (ref $rval eq __PACKAGE__) {
    #print STDERR "Interesting, I'm accessing a sub\n";
    return $rval->getRawHash();
  # $rval = $rval->getElement($k);
  }
  #if (ref $rval eq 'HASH') {
    #print STDERR "keys in value to be returned:\n";
    #for my $kk (keys %$rval) {
    #  #print STDERR "   $kk\n";
    #}
  #}
  return $rval;
}

sub FETCH {
  my $self = shift;my $S = $self->[1];
  my $k = shift;
  
  my $doesexist;
  my $origvalue;
  my $dynamicvalue;

  my @pathcomponents = $self->getPath();
  #if (scalar @pathcomponents > 1 and not defined $pathcomponents[0]) {
  if (not defined $pathcomponents[0]) {
    my $throwaway = shift @pathcomponents;
  }

  if (not ref $k) {  # it is not split up yet , it's still a mere string
    #if (1) { print STDERR "Looking for key $k\n"; }
    my ($r,$p) = $k =~ m:^([^/]+)/(.*)$: ;
    # is the root one of the keys for the prereads or postreads ...
    for my $preread_ints (@{$S->{'_preread_interceptors_'}}) {
      my $iname = defined $preread_ints->{'interceptor'}->{'name'} ? $preread_ints->{'interceptor'}->{'name'} : $preread_ints->{'interceptor'};
      if ($preread_ints->{'raw'}) {
        #print STDERR "$iname is a raw interceptor\n";
        my $interceptor = $preread_ints->{'interceptor'};
        #if ($k=~ m/^JLOG/) { print STDERR "It is a raw interceptor for $k\n"; }
        for my $ip (@{$preread_ints->{'paths'}}) {
          #if ($k =~ m/JLOG/) { print STDERR "matching $ip against $k ... "; }
          if ("$k" =~ m/$ip/) {
            #if ($k =~ m/JLOG/) { print "Matches:\n"; }
            my $interceptor = $preread_ints->{'interceptor'};
            my $v = $interceptor->preRead(key=>$p);
            if (defined $v and defined $v->{'value'}) { 
             if (0) { 
                use Data::Dumper;print STDERR "Got return value from interceptor: ",Dumper($v),"\n"; 
                my @call = caller(2);
                print STDERR "Caller = @call\n";
             }
             return  $v->{'value'};  
            }
            $v = { __DYNAMIC__ => 1 };
            return bless $v, 'VOID';
          }
          else {
            #if ($k =~ m/JLOG/) { print STDERR "it doesn't match\n"; }
          } 
        }
      }
      else {
      #print STDERR "$preread_ints->{'interceptor'}->{'name'} is not a raw interceptor\n";
      }
    }
  }

  # I think the above should not return ... it cases troubles elsewhere

  # Another way of phrasing coalesce ... 
  if (not ref $k and $k =~ m/,/) {
    my @possibilities = split(/,/,$k);
    for my $poss (@possibilities) {
      if (icdefined $S->{'_rawhash_'}->{$poss}) {
        return $S->{'_rawhash_'}->{$poss};
      }
    }
    my $none = {};
    $none->{'__DYNAMIC__'} = 1;
    bless $none,'VOID';
    return $none;
  }



  if (ref $k eq 'ARRAY' or $k =~ m/\//) {
    if ($k =~ m/\//) {
      #print STDERR "KEY IS A string: $k\n";
      #$k =~ s/^\///;
      $k =~ s/\/$//;
      my @splitk = split(/\//,$k);
      $k = \@splitk;
    }
    else {
      #print STDERR "KEY IS A is a an array: @$k\n";
    }
    #print STDERR "Using an array key @$k at @pathcomponents\n";
    my @localk = @$k;
    @localk = grep {icdefined $_ } @localk;
		use Data::Dumper;
    #print STDERR "localk is now ",Dumper(\@localk),"\n";
    if (scalar @localk > 1 and not defined $localk[0]) {
      shift @localk;
      #print STDERR "Moving to root\n";
      my $r = $self->getRootLevel()->getRawHash();
      return $r->{\@localk};
    }
    #elsif (scalar @localk >0 and not defined $localk[0]) {
    #}
    if (scalar @localk > 1) {
      my $l = shift @localk;
      my $rc; 
      use Data::Dumper;
      eval {
        if (scalar @localk) {
      	$rc = $S->{'_rawhash_'}->{$l}->{\@localk};
        }
        else { $rc = $S->{'_rawhash_'}->{$l}; }
      };
      if ($@) {
        print STDERR "Strange error in stackeddatahandler: $@\n$l,",Dumper(\@localk),"\n";
      }
      else {
      return $rc;
      }
    }
    else {
      $k = $localk[0];
      #print STDERR "Remaining local for key $k at @pathcomponents\n";
      return $S->{'_rawhash_'}->{$k};
    }
  }

  
  my $image;
  $image = $self->getCurrentImage();

   #if (exists $S->{'__DYNAMIC__'}) {
   #}
   #else {
   #$image = {};
   #}

  $doesexist = exists $image->{$k};
  $origvalue;
  $dynamicvalue;

  my $tmp_nvpair = {};

  if ($doesexist) {
    $origvalue = $image->{$k}->{'_value_'};
    $dynamicvalue = 0;
  }
  else {
    # It does not exist ...

    #print STDERR "Am I here looking for key $k\n";

    # Test the raw interceptors first
# 		if (not ref $k) {  # it is not split up yet , it's still a mere string
# 			#if (1) { print STDERR "Looking for key $k\n"; }
# 			my ($r,$p) = $k =~ m:^([^/]+)/(.*)$: ;
# 			# is the root one of the keys for the prereads or postreads ...
# 			for my $preread_ints (@{$S->{'_preread_interceptors_'}}) {
# 				my $iname = defined $preread_ints->{'interceptor'}->{'name'} ? $preread_ints->{'interceptor'}->{'name'} : $preread_ints->{'interceptor'};
# 				if ($preread_ints->{'raw'}) {
# 					#print STDERR "$iname is a raw interceptor\n";
# 					my $interceptor = $preread_ints->{'interceptor'};
# 					#if ($k=~ m/^JLOG/) { print STDERR "It is a raw interceptor for $k\n"; }
# 					for my $ip (@{$preread_ints->{'paths'}}) {
# 						#if ($k =~ m/JLOG/) { print STDERR "matching $ip against $k ... "; }
# 						if ("$k" =~ m/$ip/) {
# 							#if ($k =~ m/JLOG/) { print "Matches:\n"; }
# 							my $interceptor = $preread_ints->{'interceptor'};
# 							my $v = $interceptor->preRead(key=>$p);
# 							if (defined $v) { 
# 							 if (1) { 
# 									print STDERR "Got return value from interceptor: $v\n"; 
# 									my @call = caller(2);
# 									print STDERR "Caller = @call\n";
# 							 }
# 							 $tmp_nvpair->{'value'} = $v->{'value'};
# 							}
#               else { print STDERR "did not get a value from the preRead\n"; }
# 							#return bless $v, 'VOID';
# 						}
# 						else {
# 							#if ($k =~ m/JLOG/) { print STDERR "it doesn't match\n"; }
# 						} 
# 					}
# 				}
# 				else {
# 				#print STDERR "$preread_ints->{'interceptor'}->{'name'} is not a raw interceptor\n";
# 				}
# 			}
#       if (exists $tmp_nvpair->{'value'}) { return $tmp_nvpair->{'value'}; }
# 		}

    #if (not defined $tmp_nvpair->{'value'}) {
			if ($S->{'_runinterceptors_'}) {
				#print "value $k does not exist in image: Checking interceptors\n";
				$tmp_nvpair->{key} = $k;
				for my $preread_ints (@{$S->{'_preread_interceptors_'}}) {
					my $rnvpair;
					my @dynpath = (@pathcomponents,$tmp_nvpair->{'key'});
					my $ckey = join('/',@dynpath);
					my @pths = @{$preread_ints->{'paths'}};
					#print STDERR "Testing $preread_ints->{'interceptor'} against $ckey\n";
					my @matches = map { if ($ckey =~ m:$_:)  { 1;} else { 0; }} @pths;
					#print STDERR "matches = @matches\n";
					if (any(sequence=>\@matches)) {
						my $preread_int = $preread_ints->{'interceptor'};

						#print STDERR "Using interceptor $preread_int for dynamic value at @dynpath\n";
						if (exists $tmp_nvpair->{'value'}) {
							$rnvpair = $preread_int->preRead(key=>$tmp_nvpair->{'key'},
																							value=>$tmp_nvpair->{'value'},
																							_exists_=>0,
																							_path_=>\@dynpath,
																							_ckey_=>$ckey,
																							_dynamicvalue_=>1,
																							_origvalue_=>undef
																					 );
						}
						else {
							$rnvpair = $preread_int->preRead(key=>$tmp_nvpair->{'key'},
																							_exists_=>0,
																							_path_=>\@dynpath,
																							_ckey_=>$ckey,
																							_dynamicvalue_=>1,
																							_origvalue_=>undef
																					 );
						}
						if (defined $rnvpair and ref $rnvpair ne 'HASH') {
							print STDERR "Got a strange rnvpair: ",ref $rnvpair,"\n";
							if (ref $rnvpair eq 'ARRAY') {
								use Data::Dumper;
								print STDERR "Got an array:",Dumper($rnvpair),"\n";
							}
						}
						elsif (defined $rnvpair and ref $rnvpair eq 'HASH' and exists $rnvpair->{'value'}) {
							$tmp_nvpair->{'value'} = $rnvpair->{'value'};
						}
						elsif (defined $rnvpair and ref $rnvpair eq 'HASH' and $rnvpair->{'_unset_'}) {
							delete $tmp_nvpair->{'value'};
						}
					}
					else {
					 # print STDERR "$preread_ints->{'interceptor'} not applicable for $ckey\n";
					}
				} # end of loop

				#print STDERR "After preread data at @pathcomponents = $tmp_nvpair->{'value'}\n";

				if (exists $tmp_nvpair->{'value'}) {
					for my $postread_ints (@{$S->{'_postread_interceptors_'}}) {
						my @dynpath = (@pathcomponents,$tmp_nvpair->{'key'});
						my $ckey = join('/',@dynpath);
						my @pths = @{$postread_ints->{'paths'}};
						my @matches = map { if ($ckey =~ m/$_/)  { 1;} else { 0; }} @pths;
						if (any(sequence=>\@matches)) {
							my $rnvpair;
							my $postread_int = $postread_ints->{'interceptor'};

							$rnvpair = $postread_int->postRead(key=>$tmp_nvpair->{'key'},
																							 value=>$tmp_nvpair->{'value'},
																							 _exists_=>0,
																							 _path_=>\@dynpath,
																							 _spath_=>join('/',@dynpath),
																							 _dynamicvalue_=>1
																							);

							if (defined $rnvpair and exists $rnvpair->{'value'}) {
								$tmp_nvpair->{'value'} = $rnvpair->{'value'};
							}
							elsif (defined $rnvpair and $rnvpair->{'_unset_'}) {
								delete $tmp_nvpair->{'value'};
							}
						}
					}
				}
				if (exists $tmp_nvpair->{'value'}) {
					my $d = $tmp_nvpair->{'value'};
					if (ref $d eq 'HASH') {
						#print STDERR "keys in returned hash at @pathcomponents for $k: ",keys %$d,"\n";
						$S->{_rawhash_}->{$tmp_nvpair->{'key'}} = $d;
						# I need to do something special with the hash
						return $S->{_rawhash_}->{$tmp_nvpair->{'key'}};
						
					}
					return $tmp_nvpair->{'value'};
				}
			} # end of if I have just run through the preRead Interceptors
    #}

    #print STDERR "End of preread in FETCH\n";
    #print STDERR "Creating the dynamic hash in FETCH at @pathcomponents\n";
    my %helperhash;
    #print STDERR "Dynamicvalue now has keys",keys %$dynamicvalue,"\n";
    my $helperstackhandler = tie(%helperhash,__PACKAGE__);
    $helperstackhandler->setPath($k);
    $helperstackhandler->setParent($self);
    while ($helperstackhandler->getNumberOfLevels() < $self->getNumberOfLevels()) {
      $helperstackhandler->addParameterStack();
    }
    $helperhash{__DYNAMIC__} = 1;
    $helperstackhandler->setDynamic();
    $dynamicvalue = \%helperhash;
    #print STDERR "Dynamicvalue now has keys",keys %helperhash,"\n";
    $helperstackhandler->setRawHash(\%helperhash);
    

    # Copy the interceptors
    
    my $dynlevel;
    for my $inter (@{$S->{_interceptors_}}) {
      $helperstackhandler->addInterceptor($inter);
    }
    if ($S->{'_runinterceptors_'}) {
      $helperstackhandler->startInterceptors();
    }
    #print STDERR "Dynamicvalue now has keys",keys %$dynamicvalue,"\n";
    if ($S->{'_runinterceptors_'}) {
      #my $tmp_nvpair = { key=>$k,value=>undef };
      for my $postread_int (@{$S->{'_postread_interceptors_'}}) {
        my $rnvpair;

        #print STDERR "Using interceptor $postread_int for dynamic value at @pathcomponents\n";
        $rnvpair = $postread_int->postRead(key=>$tmp_nvpair->{'key'},
                                           value=>$tmp_nvpair->{'value'},
                                           _exists_=>0,
                                           _path_=>\@pathcomponents,
                                           _dynamicvalue_=>1
                                        );
        if (defined $rnvpair and exists $rnvpair->{'value'}) {
          $tmp_nvpair->{'value'} = $rnvpair->{'value'};
          #$tmp_nvpair = { key=>$rnvpair->{'key'},value=>$rnvpair->{'value'}};
        }
        elsif (defined $rnvpair and $rnvpair->{'_unset_'}) {
          delete $tmp_nvpair->{$k};
        }
      } # end of loop
    } # end of loop
    #print STDERR "Fetch returns $dynamicvalue\n";
    #print STDERR "Dynamicvalue now has keys",keys %$dynamicvalue,"\n";
    if (exists $tmp_nvpair->{'value'}) {
      #return $tmp_nvpair->{'value'};
    }
    else {
      $tmp_nvpair->{'value'} = $dynamicvalue ;
    }
    return $tmp_nvpair->{'value'};
  } # end of if it does not exist

  # At this point we can assume it does exist ... 
  #print STDERR "Starting the postreaders at @pathcomponents for $k\n";
  #print STDERR "Doing fetch in StackedDataHandler\n";
  my $val = $self->getElement($k);
  #print STDERR "got $val from getElement\n";
  $tmp_nvpair->{'value'} = $val;
  if ($S->{'_runinterceptors_'}) {
    my $keep_nvpair = { key=>$k,value=>$val};
    for my $postread_int (@{$S->{'_postread_interceptors_'}}) {
      my $rnvpair;

      $rnvpair = $postread_int->postRead(key=>$tmp_nvpair->{'key'},
                                          value=>$tmp_nvpair->{'value'},
                                          _exists_=>1,
                                          _origvalue_=>$origvalue,
                                          _path_=>\@pathcomponents,
                                          _dynamicvalue_=>0
                                         );
      if (defined $rnvpair and exists $rnvpair->{'value'}) {
        $tmp_nvpair->{'value'} = $rnvpair->{'value'};
      }
      elsif (defined $rnvpair and $rnvpair->{'_unset_'}) {
        delete $tmp_nvpair->{'value'};
      }
    }
  }
  return $tmp_nvpair->{'value'};
}

sub DELETE {
  my $self = shift;my $S = $self->[1];
  my $k = shift;
  #print "Doing delete of key $k\n";
  if ($k eq '__DYNAMIC__') {
    # This is a very special case
    # use this to enforce that only this module can delete this one
    my $clr = (caller(0))[0];
    if ($clr eq __PACKAGE__) {
      my $current = $self->getCurrent();
      return delete $current->{$k};
    }
    else { 
      croak { message=>"Unallowed delete\n"};
    }
  }
  my $deleted_element = $self->getElement($k);
  if ($self->getCurrDeleteLevel() eq 0) {
    #print "delete in root\n";
    my $current = $self->getCurrent();
    delete $current->{$k};
    $S->{'_needs_image_rebuild_'} = 1;
    return $deleted_element;
  }
  #print STDERR "Doing delete in $S->{_current_delete_level_}\n";
  my $current = $S->{'stack'}->[-1];
  delete $current->{$k};
  my $currentdeleted = $S->{'_deleted_'}->[$S->{'_current_delete_level_'}];
  print STDERR "DELETE PMTStackedDataHandler: $k in current layer:",$self->getCurrLevel()," delete layer: $S->{_current_delete_level_}\n";
  if ( grep (/^$k$/,@$currentdeleted)) {
    # Do nothing
    print STDERR "$k is allready in deleted keys\n";
  }
  else {
    #print STDERR "$k is not in deleted keys,adding it\n";
    push @$currentdeleted,$k;
    push @{$S->{'_current_aux_layer_'}},{_layer_=>,$self->getCurrLevel(),'_deleted_'=>1,_key_=>$k,_path_=>join('/', grep { defined $k } $self->getPath())};
  }
  
  $S->{'_needs_image_rebuild_'} = 1;
  return $deleted_element;
}

sub EXISTS {
  my $self = shift;my $S = $self->[1];
  my @pathc = $self->getPath();
  my $k = shift;
  #print STDERR "Is EXISTS called here somewhere ? Yes for key $k\n";
  if (ref $k eq 'ARRAY' and scalar @$k > 1) {
    print STDERR "Print I should check for the existence of an array-key\n"; 
  }
  else {
    if (ref $k eq 'ARRAY') {
      $k = $k->[0];
    }
    #print STDERR "Checking for $k at @pathc\n";
    #my @pathcomponents = $self->getPath();
    my $image = $self->getCurrentImage();
    my $ex = exists $image->{$k};
    return $ex;
    #my $v = $image->{$k};
    #return $ex if $ex;
    #print STDERR "key $k does not exist at @pathc\n";
    #my %helperhash;
    #my $helperstack = tie (%helperhash, __PACKAGE__);
    #$helperstack->setPath($k);
    #return $ex;
  }
}

sub CLEAR {
  my $self = shift;my $S = $self->[1];
  croak {message=>'CLEAR not implemented yet'};
}

sub SCALAR {
  my $self = shift;my $S = $self->[1];
  croak { message=>'SCALAR not implemented yet'};
}

sub FIRSTKEY {
  my $self = shift;my $S = $self->[1];
  my $im = $self->getCurrentImage();
  my @allkeys = sort keys %$im;
  if (scalar @allkeys gt 0) {
    return $allkeys[0];
  }
  return undef;
}

sub NEXTKEY {
  my $self = shift;my $S = $self->[1];
  my $lastkey = shift;
  my $im = $self->getCurrentImage();
  my @allkeys = sort keys %$im;
  if (scalar @allkeys eq 0) {
    return undef;
  }
  my $indices = $S->{'_key_indices_'};
  my $lastindex = $indices->{$lastkey};
  my $nextindex = $lastindex + 1;
  my $rval = $allkeys[$nextindex];
  #print STDERR "returning key :$rval\n";
  return $rval;
}

# ==========================================================================
#
# Public Methods
#
# ==========================================================================
sub getRootLevel {
  my $self = shift;my $S = $self->[1];
  my %args = @_;

  if ($self->hasParent()) {
    return $self->getParent()->getRootLevel();
  }
  else {
    return $self;
  }
  return $S->{'_root_'};
}

sub hasParent {
  my $self = shift; my $S = $self->[1];
  return defined $S->{'_parent_'};
}

sub getNumberOfLevels {
  my $self = shift;my $S = $self->[1];
  return scalar @{$S->{'_stack_'}};
}

sub getCurrentLevel {
  my $self = shift;my $S = $self->[1];
  return $S->{'_stack_'}->[-1];
}

sub addParameterStack {
  my $self = shift;my $S = $self->[1];
  my @pathcomponents = $self->getPath();
  if (scalar @pathcomponents > 1 and not defined $pathcomponents[0]) {
    my $throwaway = shift @pathcomponents;
  }
  if (not @pathcomponents) {
   @pathcomponents = ('-');
  }
  my $numlevels = $self->getNumberOfLevels();
  #print STDERR "Adding paramterstack at $numlevels @pathcomponents\n";
  my $newparams = {};
  push @{$S->{'_stack_'}},$newparams;
  my $newdeleted = [];
  push @{$S->{'_deleted_'}},$newdeleted;
  $S->{'_current_level_'} = $S->{'_current_level_'} + 1;
  
  $S->{'_current_delete_level_'} = $S->{'_current_delete_level_'} + 1;
  #push @{$S->{'_aux_layers_'}},[];
  #$S->{'_current_aux_layer_'} = $S->{'_aux_layers_'}->[-1];
  for my $s (@{$S->{'_subs_'}}) {
    $s->addParameterStack();
  }
  return $newparams;
}

sub getLayerData {
  my $self = shift; my $S = $self->[1];

  #print STDERR "Doing getlayerdata\n";

  
  my %args = @_;
  if (not $args{'__recursive_call__'}) {
    my $d = $self->getCurrentImage();
    use Data::Dumper;
    #print STDERR "Current Image is now : ",Dumper($d),"\n";
  }
	my $cua = $S->{'_current_aux_layer_'};
	my $layer_level = defined $args{'layer'} ? $args{'layer'} : $self->getCurrLevel();
	my @elements = ();
	for my $c (@$cua) {
		#print STDERR "Doing currentlayerdata, it is in root: ",Dumper($c),"\n";
		if (ref $c->{'_value_'} eq __PACKAGE__) {
			#print "I should dive into a subtree at $c->{'_key_'}\n";
			my @a = $c->{'_value_'}->getLayerData(__recursive_call__=>1,layer=>$layer_level);
			push @elements,@a;
		}
		elsif ($c->{'_layer_'} eq $layer_level)  {
			push @elements,$c;
		}
    my $layerdeleted = $S->{'_deleted_'}->[$layer_level];
    #print STDERR "Some elemeents are deleted at this level: ",Dumper($layerdeleted),"\n";
	}

	if ($args{'__recursive_call__'}) {
		return @elements;
	}
	else {
		print STDERR "I am at root in getcurrentlayerdata\n";
    use Data::Dumper;
    print STDERR "Found elements for current layer:",Dumper(\@elements),"\n";
    #print STDERR "DO I EVEN SEE THIS\n";
    #print STDERR "Do I even have an ic: ",$S->{'_initialcontext_'},"\n";
    my $rv = { set=>{},delete=>[]};
    for my $e (@elements) {
      if ($e->{'_deleted_'}) {
        my $k;
        if (length($e->{'_path_'})) {
          $k = join('/',(@{$e->{'_path_'}},$e->{'_key_'}));
        }
        else {
          $k = $e->{'_key_'};
        }
        if (not icdefined $S->{'_initialcontext_'}->{$k}) {
        	push @{$rv->{'delete'}},$k;
        }
        else {
          #print STDERR "mmmm , a key still exists: $k = $S->{'_initialcontext_'}->{$k}\n";
        }
      }
      else {
      	$rv->{'set'}->{join('/',(@{$e->{'_path_'}},$e->{'_key_'}))} = $e->{'_value_'};
      }
    }
    # We should handle the deletes here as well, not implemented yet
		return $rv;
	}
}

sub popParameterStack {
  my $self = shift;my $S = $self->[1];
  my @pathcomponents = $self->getPath();
  my $numlevels = $self->getNumberOfLevels();
  #if (scalar @pathcomponents > 1 and not defined $pathcomponents[0]) {
  if (not defined $pathcomponents[0]) {
    my $throwaway = shift @pathcomponents;
  }
  #print "Attempting to pop at @pathcomponents, level $numlevels\n";
  if (scalar @{$S->{'_stack_'}} eq 1) {
    #print STDERR "Cannot pop last element from empty stack at @pathcomponents\n";
    croak {message=>'Cannot pop top element from parameter stack'};
  }
  else {
    #print STDERR "Popping element from empty stack at @pathcomponents\n";
    my $popped = pop @{$S->{'_stack_'}};
    my $popdeleted = pop @{$S->{'_deleted_'}};
    $S->{'_current_level_'} = $S->{'_current_level_'} - 1;
    $S->{'_current_delete_level_'} = $S->{'_current_delete_level_'} - 1;
    $S->{'_needs_image_rebuild_'} = 1;
    for my $s (@{$S->{'_subs_'}}) {
      $s->popParameterStack();
    }
    return $popped;
  }
}

sub booleval {
  my ($self,$k,$v) = @_;my $S = $self->[1];
  my $rh = $self->getRawHash();
  print STDERR "Doing boolean evaluation\n";
  if ($S->{'_dynamic_'}) {
    return 0;
  }
  return 1;
}

sub addSub {
  my $self = shift; my $S = $self->[1];
  my %args = @_;
  my $toadd = $args{'sub'};
  my $key = $args{'key'};
  my @p = $self->getPath();
  #print STDERR "Adding sub $toadd at @p for key $key\n";
  my $isrunning = $S->{'_runinterceptors_'};
  my $rh = $S->{'_rawhash_'};
  $S->{'_runinterceptors_'} = 0;
  if (exists $S->{'_rawhash_'}->{'__DYNAMIC__'}) {
    #print STDERR "Removing dynamic character at @p\n";
    delete $S->{'_rawhash_'}->{'__DYNAMIC__'};
  }
  else {
    #print "I am not dynamic anyway at @p\n";
  }
  #print STDERR "OK, now really adding $toadd to @p for key $key\n";
  $S->{'_rawhash_'}->{$key} = bless {_value_=>$toadd,_volatile_=>0},PMTUtilities::VALUESPEC;
  #print STDERR "OK, really added $toadd to @p for key $key\n";
  #push (@{$S->{'_subs_'}},$toadad);
  if ($isrunning) {
    $S->{'_runinterceptors_'} = $isrunning;
  }
}
sub isDynamic {
  my $self = shift; my $S = $self->[1];
  return $S->{'_dynamic_'};
}

sub dynamic2persist {
  my $self = shift; my $S = $self->[1];
  my $d = $S->{'_dynamic_'};
  my @p = $self->getPath();
  #print STDERR "dynamic2persist at @p\n";
  my $parent = $S->{'_parent_'};
  if ($d) {

    my $current = $self->getCurrent();
    delete $current->{'__DYNAMIC__'};

    if (defined $parent and $parent->isDynamic()) {
      #my $pisrunning = $parent->[1]->{'_runinterceptors_'};
      #$parent->[1]->{'_runinterceptors_'} = 0;
      #$parent->[1]->{'_runinterceptors_'} = 0;
      #print STDERR "Doing py parent first\n";
      $parent->dynamic2persist();
      #print STDERR "Parent done\n";
    }
    $S->{'_dynamic_'} = 0;
    #print STDERR "Setting myself to persistent at @p\n";
    if (defined $parent) {
      my @pp = $parent->getPath();
      #print STDERR "OK, now adding @p to @pp\n";
      $parent->addSub(sub=>$self,key=>$S->{'_path_'});
    }
    else {
      #print STDERR "Parent not defined at @p\n";
    }
    #if (exists $S->{'_rawhash_'}->{'__DYNAMIC__'}) {
      #print STDERR "Removing dynamic character at @p\n";
    #  my $current = $self->getCurrent();
    #  my $number_of_levels = $self->getNumberOfLevels();
    #print STDERR "Deleting DYNAMIC at @p in $number_of_levels\n";
    #  for (my $l=0; $l < $number_of_levels; $l++) {
    #    my $layer = $S->{'_stack_'}->[$l];
    #    delete $layer->{'__DYNAMIC__'};
    #  }
    #  $self->setNeedsRebuild();
    #}
   
    #print STDERR "I made myself persistent at @p\n";
  }
  else {
    print STDERR "I am allready persisted at @p\n";
    if (defined $parent) {
      #print STDERR "And I do have a parent\n";
    }
    else {
      #print STDERR "And I do not have a parent\n";
    }
  }
}

sub ashash {
   my $self = shift;my $S = $self->[1];
   my $rh = $self->getRawHash();
   print "Returning the raw hash\n";
   return %$rh;
}

sub asstring {
  my $self = shift;my $S = $self->[1];
  if ($S->{'_dynamic_'}) {
    return '__VOID__VALUE__';
  }
  return 'DataHandlerInstance';
}

1;

__END__

# ==========================================================================
#
# POD
#
# ==========================================================================

=pod

=head1 NAME

  PMTStackedDataHandler
  
=head1 Synopsis

  PMTStackedDataHandler is a datacontainer, acting as a regular HASH
  that does allow one to store data in multiple layers.
  
=head1 Description

  PMTStackedDataHandler is a datacontainer, acting just like a regular
  HASH, that does allow one to store data in multiple layers.
  
  If we say it acts like a regular HASH, it really does, it is an object
  that fully implements the HASH interface; one can thus apply the regular
  HASH operations like "exists", "keys" ... . Storing and retrieving values
  works just a like a normal HASH.
  
  But there's more: 
  It allows one to store data in multiple layers, or stacks. When one stores
  data it is by default always stored in the highest (the newest) stack.
  When retrieving data, the entire stack is searched, from the bottom up, and
  the highest value that can be found is returned.
  
  This can be used, for instance, to store the JOB_SEQ of a JOB at root level,
  and the JOB_SEQ's related to a given file, in a higher stack. When one
  retrieves the JOB_SEQ from the handler, the "current" JOB_SEQ, the one
  related to the file being loaded, will be returned.
  
  As it is meant to be the internal storage mechanism for the PMTExecContext,
  this module will not be documented in detail here. Only the methods that are
  supposed to be public here, will be mentioned.
  
=head1 METHODS

=over

=head2 getRootLevel

=over

=item Usage

  getRootLevel()
  
=item Synopsis

  Returns a reference to the root level HASH of the stack

=item Description

  Returns a reference to the root level HASH of the stack
  
=item Returns

  Returns a reference to the root level HASH of the stack
  
=back

=back

=over

=head2 getCurrentLevel

=over

=item Usage

  getCurrentLevel

=item Synopsis

  Returns a reference to the highest HASH in the stack
  
=item Description

  Returns a reference to the highest HASH in the stack
  
=item Returns

  A reference to the highest HASH in the stack
    
=back

=back

=over

=head2 addParameterStack

=over

=item Usage

  addParameterStack()
  
=item Synopsis

  Adds a layer to the datastack. This new layer is now also 
  considered the 'current' layer

=item Description

  Adds a layer to the datastack. This new layer is now also 
  considered the 'current' layer
  
=item Returns

  This method does not return a value
  
=back

=back

=over

=head2 popParameterStack

=over

=item Usage

  popParameterStack()
  
=item Synopsis

  removes the top layer of the stack and returns it.
  This is a regular HASH
  
=item Description

  removes the top layer of the stack and returns it.
  The removed and returned layer is a regular HASH.
  
=item Returns

  The removed top layer of the stack, which is a regular HASH.
  
=back

=back

=head1 ENVIRONMENT

  PERL5LIB
  
=head1 VERSION

  Version = 1.0
  
=head1 AUTHOR

  Evert Carton
  
=cut

