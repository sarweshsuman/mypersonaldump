package PMTSysUtils;

use strict;
use Carp;

#use Config::Simple;
use Data::Dumper;

require Exporter;
our @ISA=qw(Exporter);
our @EXPORT_OK = qw(evalPreReqs getJobDefinitions getJobConfig initializeLog closeLog isFlowRunning getFlowDef publishFlowDef toMultiPartFormData parseMultiPartFormData);

use PMTUtilities qw(dprint getPMTSysConfig fileExists parseURI);
use Data::Structure::Util qw( unbless signature);

# sub isFlowRunning {
#  my %args = @_;
#  my $flowcd = $args{'flowcd'};
#  use PMTDbXmlUtils qw(isFlowRunning);
#  return DBisFlowRunning(flowcd=>$flowcd);
# }

# sub registerFlowRun {
#   my %args = @_;
#   my $flowcd = $args{'flowcd'};
#   my $options = $args{'options'};
#   my $cmdparams = $args{'params'};
#   my $loptions = { force=>0 };
#   if (defined $options) {
#     for my $k (keys %$options) {
#       $loptions->{$k} = $options->{$k};
#     }
#   }
#   if (not defined $flowcd) {
#     croak { message=>'Flowcd not defined while registering flowrun' };
#   }
#   print "Registering flow run in ",__PACKAGE__,"\n";
#   use PMTDbXmlUtils qw(DBregisterFlowRun);
#   return DBregisterFlowRun(flowcd=>$flowcd,options=>$loptions,params=>$cmdparams);
# }

# sub roleIsEnabled {
#   my %args = @_;
#   my $flowcd = $args{'flowcd'};
#   my $role = $args{'role'};
#   use PMTDbXmlUtils qw(DBroleIsEnabled );
#   return DBroleIsEnabled (flowcd=>$flowcd,role=>$role);
# }

# sub getJobConfig {
#   my %args = @_;
#   my $flowcd = $args{'flowcd'};
#   my $role = $args{'role'};
#   use PMTDbXmlUtils qw(DBgetJobConfig);
#   my $jobconfig = DBgetJobConfig(flowcd=>$flowcd,role=>$role);
#   return $jobconfig;
# }

# sub initializeLog {
#   my %args = @_;
#   my $flowcd = $args{'flowcd'};
#   my $role = $args{'role'};
#   my $runid = $args{'runid'};
#   use PMTDbXmlUtils qw(DBinitializeLog);
#   my $seq_nr = DBinitializeLog(flowcd=>$flowcd,runid=>$runid,role=>$role);
#   return $seq_nr;
# }

# sub closeLog {
#   my %args = @_;
#   my $flowcd = $args{'flowcd'};
#   my $role = $args{'role'};
#   my $runid = $args{'runid'};
#   my $seq = $args{'seq'};
#   use PMTDbXmlUtils qw(DBcloseLog);
#   DBcloseLog(flowcd=>$flowcd,role=>$role,runid=>$runid,seq=>$seq);
# }

my $json_serializer = sub {
  my %args = @_;
  my $data = $args{'data'};

  use JSON;
  my $json_text = to_json($data, {ascii=>1,pretty=>0});
  return $json_text;
};

my $convertors = {
  PERLHASH=>{
    'application/json'=> $json_serializer
            },
  PERLARRAY=>{
    'application/json'=> $json_serializer
  },
  HASHOBJECT=>{
    'application/json' => $json_serializer
  },
  ARRAYOBJECT=>{
    'application/json'=> $json_serializer
  },
  'text/.*'=> { 'text/.*' => sub { my %args = @_; my $data = $args{'data'}; return $data; } }
};

sub convert {
  my %args = @_;
  my $source_rcd = $args{'source'};
  my $adjusted_rcd = $args{'adjusted'};
  
  my $found_convertor = undef;
  for my $k (keys %$convertors) {
    if ($adjusted_rcd->{'source_type'} =~ m:$k:) {
      for my $l (keys %{$convertors->{$k}}) {
        if ($adjusted_rcd->{'target_type'} =~ m:$l:) {
          $found_convertor = $convertors->{$k}->{$l};
        }
      }
    }
  }
  if (defined $found_convertor) {
    my @common_params = (source_options=>$adjusted_rcd->{'source_type_options'},target_options=>$adjusted_rcd->{'target_type_options'});
    if (defined $adjusted_rcd->{'data'}) {
       return $found_convertor->(data=>$adjusted_rcd->{'data'},@common_params);
    }
    else {
       return $found_convertor->(data=>$source_rcd->{'data'},@common_params);
    }
  }
}

sub parseMIMEHeaders {
  my %args = @_;
  my $headers = $args{'headers'};

  my @headerlines;
  if (ref $headers eq 'ARRAY') {
    @headerlines = @$headers;  
  }
  elsif (ref $headers eq 'HASH') {
    return $headers;
  }
  else {
    @headerlines = split(/\n/,$headers);
  }
  my $rc = {};
  for my $l (@headerlines) {
    my ($n,$v) = $l =~ m/^([^:]+)\s*:\s*(.*)$/;
    $rc->{lc $n} = $v;
  }
  # for convenience we may also split up the content-type
  if (defined $rc->{'content-type'}) {
    my @splitcttype = $rc->{'content-type'} =~ m/^\s*([^\s;]+)\s*;?\s*(.*?)\s*$/;
    my $base_type = lc $1;
    my $type_options = $2;
    dprint "setting base content type to $base_type\n";
    $rc->{'content-type/base'} = $base_type;
    if ($type_options) {
    	$rc->{'content-type/options'} = $type_options;
    }
    
    dprint "the split content type = @splitcttype\n";
    
  }
  else {
    $rc->{'content-type'} = 'text/plain';
    #$rc->{'content-type/base'} = 'text/plain';
    #$rc->{'content-type/options'} = undef;
  }

  # and the same for content-disposition
  if (defined $rc->{'content-disposition'}) {
    my @splitcttype = $rc->{'content-disposition'} =~ m/^\s*([^\s;]+)\s*;?\s*(.*?)\s*$/;
    my $base_type = lc $1;
    #dprint "disposition base: $base_type\n";
    my $type_options = $2;
    #dprint "disposition options: $type_options\n";
    $rc->{'content-disposition/base'} = $base_type;
    if ($type_options) {
    	$rc->{'content-disposition/options'} = $type_options;
      if ($type_options =~ m/name\s*=\s*"([^"]+)"\s*/) {
        my $item_name = $1;
        $rc->{'content-disposition/name'} = $item_name;
        $rc->{'__datablock__/name'} = $item_name;
      }
      else {
        #dprint "could not determine a name\n";
      }
    }
  }
  else {
    $rc->{'content-disposition'} = 'inline';
    $rc->{'x-content-disposition/base'} = 'inline';
    $rc->{'x-content-disposition/options'} = undef;
  }
  return $rc;
}

sub json_parser {
  my %args = @_;
  my $data = $args{'data'};

  use JSON qw(from_json);

  return from_json($data);
}

my $bodyparsers = {
  'application/json' => \&json_parser,
  'text/.*' => sub { my %args = @_; return $args{'data'}; }
};

sub parseMultiPartFormData_messagepart {
  my %args = @_;
  my $data = $args{'data'};
  
  use bytes;

  $data =~ s:^(\s|\n)*::s;

  my @hlines = ();
  
  while (my @m = $data =~ m/^(\S+[^\n]+\n)/s) {
    my $hline = $m[0];
    chomp $hline;
    push @hlines,$hline;
    $data =~ s/^(\S+[^\n]+\n)//s;
  }
  # and then drop the empty line
  $data =~ s/^\s*\n//s;

  my $headers = \@hlines;
  my $body = $data;

  #my ($headers,$body) = $data =~ m:^(.*)\n\s*\n(.*):s;
  dprint "splitdocument is now: headers:\n", join("\n",@hlines),"\n----\nand body $body\n";
  my $pheaders = parseMIMEHeaders(headers=>$headers);
  my $clh = $pheaders->{'content-length'};   # clh = content length from headers
  my $clb = length $body;                    # clb = content length from body
  if (defined $clh and $clb < $clh) {
    croak { message=>"Malformed body, body length is smaller then MIME header suggests",
            data=>{data=>$body,body_length=>$clb, content_length_header=>$clh}
          };
  }
  elsif (defined $clh and $clb > $clh) {
    $clb = $clh;
  }
  dprint "and body appears ok, length $clb\n";
  my $pbody = substr($body,0,$clb);

  my $ptype;
  dprint "what partheaders do I have ?\n";
  for my $l (keys %$pheaders) {
    dprint "content-header: $l = $pheaders->{$l}\n";
  }
  if (defined $pheaders->{'content-type/base'}) {
    dprint "base type is defined\n";
    $ptype = $pheaders->{'content-type/base'};
  }
  else {
    # this is a default set by the parseMIMEHeaders sub
    $ptype = $pheaders->{'content-type'};
  }
  my $parser;
  if (defined $bodyparsers->{$ptype}) {
    $parser = $bodyparsers->{$ptype};
  }
  else {
    for my $k (keys %$bodyparsers) {
      if ($ptype =~ m/$k/i) {
        $parser = $bodyparsers->{$k};
      }
    }
  }
  if (not defined $parser) {
  	dprint "mmmm could not find a parser for $ptype\n";
    croak { message=>"Could not determine parser for content-type $ptype"};
  }
  my $parsed_data = $parser->(data=>$pbody,options=>$pheaders->{'content-type/options'});
  dprint "=================================\n";
  dprint "parsed data is now ",$parsed_data;
  dprint "=================================\n";

  return {
    name=>$pheaders->{'__datablock__/name'},
    data=>$parsed_data,
    unparsed_data=>$pbody,
    headers=>$pheaders
  };
}

sub parseMultiPartFormData {
  my %args = @_;
  my $data = $args{'data'};
  my $boundary = $args{'boundary'};
  dprint "Parsing :\n${data}\n";
  # we do not really need the boundary I think ... If the message is well formed, it begins and ends with the boundary
  my $sdb; # short for self_determined_boundary ... I will try to determine the boundary myself ...
  my @m_sdb = $data =~ m:^(\s|\n)*(--[^\s\n]+).*$2(\s|\n)*$:s;
  $sdb = $2;
  if (not defined $sdb) {
    croak { message=>"Malformed multipart/form-data data, could not determine boundary",data=>[$data] };
  }
  if (defined $boundary and $sdb !~ m/--$boundary/) {
    croak { message=>"Specified boundary and self found boundary do not correspond in multipart/form-data message",data=>{data=>$data,self_found_boundary=>$sdb,specified_boundary=>$boundary}};
  }

  # We're still alive ... ? 
  # strip the boundary from the end and the start of the data 
  $data =~ s:^(\s|\n)*$sdb::s;
  $data =~ s:$sdb(\s|\n)*$::s;
  
  my $parsed_body = { };
  #my @unnameds = ();

  my @dataparts = split(/$sdb/s,$data);
  for my $dpart (@dataparts) {
    dprint "==============================================\n";
    my $parsed_datapart = parseMultiPartFormData_messagepart(data=>$dpart);
    if (defined $parsed_datapart->{'name'}) {
      #$parsed_body->{'named'}->{$parsed_datapart->{'name'}} = $parsed_datapart; 
      $parsed_body->{$parsed_datapart->{'name'}} = $parsed_datapart; 
    }
    else {
      croak { message=>"Invalid Message in multipart/form-data: name not specified" };
    }
  }
 
  return $parsed_body;
  
}

sub toMultiPartFormData {
  my %args = @_;
  my $data = $args{'data'};
  my $boundary = $args{'boundary'};

  use overload;
  my $buffer='';
  my $adjusted_data = {};
  for my $elname (keys %$data) {
    $adjusted_data->{$elname} = {};
    my $localdata = $data->{$elname}->{'data'};
    #$buffer .= "--$boundary\n";
    #$buffer .= "Content-Disposition: form-data; name=\"$elname\"\n";
  	my $target_type;
    my $target_type_options;

    if (defined $data->{$elname}->{'content_type'}) {
      $target_type = $data->{$elname}->{'content_type'};
      if ($target_type =~ m/([^;]+)?;(.*)/) {
        $target_type = $1;
        $target_type_options = $2;
        if ($target_type_options) {
          $target_type_options =~ s/^\s*//;
          $target_type_options =~ s/\s*$//;
        }
      }
      $adjusted_data->{$elname}->{'target_type'} = $target_type;
      $adjusted_data->{$elname}->{'target_type_options'} = $target_type_options;
    } 
    dprint "using target_type $target_type and options $target_type_options\n";
  	my $source_type;
    my $source_type_options;
    if (defined $data->{$elname}->{'source_type'}) {
      $source_type = $data->{$elname}->{'source_type'};
      if ($source_type =~ m/([^;]+)?;(.*)/) {
        $source_type = $1;
        $source_type_options = $2;
        if ($source_type_options) {
          $source_type_options =~ s/^\s*//;
          $source_type_options =~ s/\s*$//;
        }
      }
      $adjusted_data->{$elname}->{'source_type'} = $target_type;
      $adjusted_data->{$elname}->{'source_type_options'} = $target_type;
    }
    else {
      # try to derive the source_content_type from the type of data
      dprint "checking element: $elname = $data->{$elname}->{'data'}\n";
      my $dummy_type="$data->{$elname}->{'data'}";
      dprint "dummy_type=$dummy_type\n";
      if (ref $data->{$elname}->{'data'} ) {
        my $dtype=ref $data->{$elname}->{'data'};
        dprint "checking for type $dtype for \n";
        if ($dtype eq 'HASH') {
           print STDERR "I got a perlhash\n";
           $source_type = 'PERLHASH';
					 $adjusted_data->{$elname}->{'source_type'} = 'PERLHASH';
					 $adjusted_data->{$elname}->{'source_type_options'} = undef;
        }
        elsif ($dtype eq 'ARRAY') {
           print STDERR "I got a perlarray\n";
           $source_type = 'PERLARRAY';
					 $adjusted_data->{$elname}->{'source_type'} = 'PERLARRAY';
					 $adjusted_data->{$elname}->{'source_type_options'} = undef;
        }
        elsif ($dtype eq 'FORMDATA_GENERATOR') {
          # this is a special case
          #my $fdata = $localdata->(); to be developed
        }
        elsif ($dtype eq 'CODE') {
           # we need to execute the code, and return again
        }
        # now check for objects that are based on ... HASH or a ARRAY I 
        elsif ($dummy_type =~ m/^[^=]+=ARRAY/) {
          dprint "looks like dummy type is an array\n";
					$adjusted_data->{$elname}->{'source_type'} = 'PERLARRAY';
					$adjusted_data->{$elname}->{'source_type_options'} = undef;
          my $dmpr = new Data::Dumper([$data->{$elname}->{'data'}]);
          $dmpr->Indent(0)->Purity(1)->Useperl(1)->Terse(1);
          $adjusted_data->{$elname}->{'data'} = unbless eval($dmpr->Dump());
        }
        elsif ($dummy_type =~ m/^[^=]+=HASH/) {
          dprint "looks like dummy type is a HASH\n";
					$adjusted_data->{$elname}->{'source_type'} = 'PERLHASH';
					$adjusted_data->{$elname}->{'source_type_options'} = undef;
          my $dmpr = new Data::Dumper([$data->{$elname}->{'data'}]);
          $dmpr->Indent(0)->Purity(1)->Useperl(1)->Terse(1);
          $adjusted_data->{$elname}->{'data'} = unbless eval($dmpr->Dump());
        }
        elsif (defined overload::Method($data->{$elname}->{'data'},'%{}')) {
           dprint "It is an overload of a HASH\n";
					 $adjusted_data->{$elname}->{'source_type'} = 'HASHOBJECT';
					 $adjusted_data->{$elname}->{'source_type_options'} = undef;
        }
        elsif (defined overload::Method($data->{$elname}->{'data'},'@{}')) {
           dprint "It is an overload of a ARRAY\n";
					 $adjusted_data->{$elname}->{'source_type'} = 'ARRAYOBJECT';
					 $adjusted_data->{$elname}->{'source_type_options'} = undef;
        }
        else {
          dprint "This is case is not implemented yet:",ref $data->{$elname}->{'data'},"\n";
          croak { message=>"Could not determine source type for serialization" };
        }
      }
      else {
        dprint "element $elname does not seem to have a ref\n";
        $source_type='TEXT';
      }
    }

    if (not defined $adjusted_data->{$elname}->{'target_type'} and defined $adjusted_data->{$elname}->{'source_type'}) {
      my $stype = $adjusted_data->{$elname}->{'source_type'};
      if ($stype =~ m/PERLHASH|PERLARRAY|HASHOBJECT|ARRAYOBJECT/) {
        $adjusted_data->{$elname}->{'target_type'} = 'application/json';
      }
    }
    else {
      dprint "target_type is not defined\n";
    }
  }

  for my $elname (keys %$data) {
    use bytes;
    if (defined $adjusted_data->{$elname}->{'target_type'}) {
      $buffer .= "--$boundary\n";
      $buffer .= "Content-Disposition: form-data; name = \"$elname\"\n";
      $buffer .= "Content-Type: ".$adjusted_data->{$elname}->{'target_type'};
      if (defined $adjusted_data->{$elname}->{'target_type_options'}) {
        $buffer .= " ; ".$adjusted_data->{$elname}->{'target_type_options'};
      }
      $buffer .= "\n";
      my $rdata = convert(source=>$data->{$elname},adjusted=>$adjusted_data->{$elname});
      $buffer .= 'Content-Length: '. length $rdata ; $buffer .= "\n";
      if (defined $data->{$elname}->{'add_headers'}) {
        my $ahs = $data->{$elname}->{'add_headers'};
        for my $ahk (keys %$ahs) {
          $buffer .= "$ahk: $ahs->{$ahk}\n";
        }
      }
    	$buffer .= "\n";
      $buffer .= $rdata;
      $buffer .= "\n";
    }
  }
  $buffer .= "--$boundary\n";

  return $buffer;

}

sub httpPostData {
  my %args = @_;
  my $headers = $args{'headers'};
  my $data = $args{'data'};
  my $uri = $args{'uri'};
  
  if (not defined $uri) {
    croak { message=>'uri not defined for posting data' }
  }

  my $parseduri;
  if (ref $uri eq 'HASH') {
    $parseduri = $uri;
  }
  else {
    use PMTUtilities qw(parseURI);
    $parseduri = parseURI(uri=>$uri,resolve_credentials=>1);
  }
  #for my $k (keys %$parseduri) {
  #  dprint "httpPostData: $k = $parseduri->{$k}\n";
  #}

  my $localheaders = {};
  for my $k (keys %$headers) {
    $localheaders->{$k} = $headers->{$k};
  }
  if (not defined $headers->{'Content-Length'}) {
    use bytes;
    $localheaders->{'Content-Length'} = length $data;
  }
  my @aheaders = ();
  for my $h (keys %$localheaders) {
     push @aheaders,"${h}: $localheaders->{$h}";
  }
  push @aheaders, "User-Agent: BGCPMTSysLib/1.0";
  #push @aheaders, "Except: ";
  #for my $l (@aheaders) {
  #  dprint "set header: $l\n";
  #}

  #dprint "data = \n--${data}--\n";

  use Net::Curl::Easy qw(:constants);

  my $fgenerator = sub {
    use bytes;
    my $data = shift;
    my $remaining = length $data;
    my $pos = 0;
    my $reader = sub {
      use bytes;
      my ($easy,$size,$userdata ) = @_;
      my $bytes_to_read = $size;
      if ($bytes_to_read > $remaining) {
        $bytes_to_read = $remaining;
      }
      #dprint "i was asked for $size bytes but i can only give $bytes_to_read\n";
      if ($bytes_to_read > 0) {
      	my $d = substr($data,$pos,$bytes_to_read);
      	$pos += $bytes_to_read;
      	$remaining -= $bytes_to_read;
      	#$buffer = $d;
        #dprint "returning: --${d}--", length $d," bytes";
        return \$d;
      }
      else {
        dprint "returning 0\n";
        return 0;
      }
    };
    return $reader;
  };

  {
		use bytes;
		my $curl = Net::Curl::Easy->new();
		$curl->setopt(CURLOPT_URL,$uri);
		$curl->setopt(CURLOPT_HEADER,0);
		$curl->setopt(CURLOPT_HTTPHEADER,\@aheaders);
		#$curl->setopt(CURLOPT_WRITEHEADER,\@aheaders);
		$curl->setopt(CURLOPT_POST,1);
		$curl->setopt(CURLOPT_INFILESIZE,length $data);
		$curl->setopt(CURLOPT_UPLOAD,1);
		$curl->setopt(CURLOPT_READFUNCTION,$fgenerator->($data));
		
		$curl->perform();
  }
  
}

# sub getFlowDef {
#   my %args = @_;
#   my $flowcd = $args{'flowcd'};
# 
#   if (not defined $flowcd) {
#     croak { message=>"Flowname not defined in getting flow definition" };
#   }
# 
#   my $options = $args{'options'};
#   if (not defined $options) {
#     $options = { accept=>'text/xml' };
#   }
# 
#   use PMTDbXmlUtils qw(retrieveFlowDef);
#   my $doc = retrieveFlowDef(name=>$flowcd);
#   return $doc;
# }


# sub registerFlowRun {
#   my %args = @_;
#   my $flowcd = $args{'flowcd'};
#   my $options = $args{'options'};
#   if (not defined $flowcd) {
#     croak { message=>"Flowname not specified when registering a run" };
#   }
#   if (not defined $options) {
#     $options = { force=>0 };
#   }
#   # First check if the flow exists
#   use PMTDbXmlUtils qw(flowdefExists);
#   my $e = flowdefExists(flowcd=>$flowcd);
#   if (not $e) {
#     croak { message=>"Flow $flowcd does not exist" };
#   }
# }

# sub publishFlowDef {
#   my %args = @_;
#   my $flowcd = $args{'flowcd'};
#   my $filename = $args{'filename'};
#   my $io = $args{'io'};
#   my $force = $args{'force'};
#   my $update = $args{'update'};
#   my $delete = $args{'delete'};
#   my $copy = $args{'copy'}; # not implemented yet ....
# 
#   if (not defined $force) {
#     $force = 0;
#   }
#   if (not defined $update) {
#     $update = 0;
#   }
#   if (not defined $delete) {
#     $delete = 0;
#   }
#   my $uri = $args{'uri'};
# 
#   use Sleepycat::DbXml;
#   use Sleepycat::Db;
#   use Net::Curl::Easy qw(:constants);
#   use CGI;
# 
#   my $pmtsys = getPMTSysConfig(section=>'pmtsys');
# 
#   # we need to extend this, source could also be specified by io or content
#   if (not defined $filename) {
#     croak { message=>"filename is not specified"};
#   }
#   if ( not fileExists(file=>$filename) ) {
#     croak { message=>"File $filename does not exist"};
#   }
#   my $parsed_uri = parseURI(uri=>$filename,resolve_credentials=>1);
#   for my $k (keys %$parsed_uri) {
#     dprint "$k -> $parsed_uri->{$k}\n";
#   }
#   # i need key 'fetch'
#   use PMTUtilities qw(loadResource);
#   my $filecontent = loadResource(resource=>$parsed_uri);
#   ##dprint "$filecontent\n";
# 
#   my $action;
#   if ($update) { $action="UPDATE";} elsif ($delete) { $action = "DELETE";} else { $action="CREATE"; }
#   if (not defined $flowcd and $action =~ m/CREATE|UPDATE/i) {
#     #print "I should try to find the name from the content\n";
#     use XML::DOM;
#     my $parser = XML::DOM::Parser->new();
#     my $doc = $parser->parse($filecontent);
#     my $de = $doc->getDocumentElement();
#     # it should have an attribute name
#     my $nameatt = $de->getAttribute('name');
#     if ($nameatt) {
#       $flowcd = $nameatt;
#     }
#     else {
#       croak { message=>"flow name not specified and not available in source document" };
#     }
#   }
#   elsif (not defined $flowcd and $action =~ m/DELETE/i) {
#     croak=>{message=>"No flowcd specified for action DELETE" };
#   }
# 
#   my $add_headers = {};
#   
#   my $postoptions = { force=>$force }; # ,update=>$update };
#   $postoptions->{'action'} = $action;
#   if (defined $flowcd) {
#     $postoptions->{'flowcd'} = $flowcd;
#   }
#   my $postdata = {};
#   if ($action =~ m/CREATE/i) {
#     $postdata->{'flowdef'} = { add_headers=>$add_headers,content_type=>'text/xml; encoding="UTF-8"',source_type=>'text/xml',data=>$filecontent }; 
#     $postoptions->{'flowdefinition'} = 'flowdef';
#   }
#   $postdata->{'__requestoptions__'} = {data=>$postoptions};
#   #my $postdata = { requestoptions=>{data=>$postoptions}, flowdef=>{ add_headers=>$add_headers,content_type=>'text/xml; encoding="UTF-8"',source_type=>'text/xml',data=>$filecontent}};
# 
#   my $boundary = signature $postdata;
#   my $encdata = toMultiPartFormData(data=>$postdata,boundary=>$boundary);
#   
#   my $http_headers;
#   {
#   	use bytes;
#   	$http_headers = {
#     	'Content-Type'=>"multipart/form-data; boundary=$boundary",
#     	'x-pmt-application'=>"flowdefinition; action=$action",
#     	'Accept'=>"application/json",
#     	'Content-Length'=>length $encdata
#   	};
#   }
# 
# 
#   if (not defined $uri) {
#   	use PMTUtilities qw(getPMTSysConfig);
#   	my $pmtsysconfig = getPMTSysConfig(section=>'pmtsys');
#     $uri = $pmtsysconfig->{'config_server'};
#   };
# 
#   dprint "posting data to $uri\n";
#   httpPostData ( data=>$encdata, headers=>$http_headers, uri=>$uri);
#    
# 
#   dprint "All is well,uploading file $filename\n";
# }
# 
# sub getJobDefinitions {
#   my %args = @_;
#   my $flowcd = $args{'flowcd'};
#   my $role = $args{'role'};
#   my $runid = $args{'runid'};
# 
#   use PMTDbXmlUtils qw(DBgetJobDefinitions);
#   my $jd = DBgetJobDefinitions(flowcd=>$flowcd,role=>$role,runid=>$runid);
#   dprint "got the XML for jobdefinitions: $jd\n";
#   return {}
# }

sub evalSimpleCondition {
  my %args = @_;
  my $cnode = $args{'condition_node'};
  my $ic = $args{'initialcontext'};
  # what kind of beast do we have
  my $cname = $cnode->xfind('./name()');
  $cname = uc $cname;
  if ($cname eq 'EVALVALUE') {
    my $val = $cnode->xfind('./data()');
    use PMTUtilities qw(evalBoolean);
    $val = evalBoolean(value=>$val);
    #print STDERR "evalvalue found value : $val\n";
    return $val;
	}
  elsif ($cname eq 'EXISTS') {
    return 1;
  }
  elsif ($cname eq 'NOTEXISTS') {
    return 1;
  }
}

sub evalAndCondition {
  my %args = @_;
  my $cnode = $args{'condition_node'};
  my $ic = $args{'initialcontext'};
  my @results = ();
  my $childnodes = $cnode->xnode(data=>'./*',force_array=>1);
  print STDERR "CHILDNODES = now ",$childnodes,"\n";
  if (scalar @$childnodes == 0) { return 1; }
  for my $cn (@$childnodes) {
    my $cnn = $cn->xfind('./name()');
    $cnn = uc $cnn;
    if ($cnn eq 'AND') {
      push @results,evalAndCondition(condition_node=>$cn,initialcontext=>$ic);
    }
    elsif ($cnn eq 'OR') {
      push @results,evalOrCondition(condition_node=>$cn,initialcontext=>$ic);
    }
    else {
      push @results,evalSimpleCondition(condition_node=>$cn,initialcontext=>$ic);
    }
  }
  my $false_count = grep { $_ == 0 } @results;
  if ($false_count > 0) { return 0; } else { return 1; }
}
sub evalOrCondition {
  my %args = @_;
  my $cnode = $args{'condition_node'};
  my $ic = $args{'initialcontext'};
  my @results = ();
  my $childnodes = $cnode->xnode(data=>'./*',force_array=>1);
  if (scalar @$childnodes == 0) { return 1; }
  for my $cn (@$childnodes) {
    my $cnn = $cn->xfind('./name()');
    $cnn = uc $cnn;
    if ($cnn eq 'AND') {
      push @results,evalAndCondition(condition_node=>$cn,initialcontext=>$ic);
    }
    elsif ($cnn eq 'OR') {
      push @results,evalOrCondition(condition_node=>$cn,initialcontext=>$ic);
    }
    else {
      push @results,evalSimpleCondition(condition_node=>$cn,initialcontext=>$ic);
    }
  }
  
  my $true_count = grep { $_ > 0 } @results;
  if ($true_count > 0) { return 1; } else { return 0; }
}
sub evalCondition {
  my %args = @_;
  my $cnode = $args{'condition_node'};
  my $ic = $args{'initialcontext'};
  my $conditions = $cnode->xnode(data=>'./*',force_array=>1);
  if (scalar @$conditions == 0) { return 1; }
  if (scalar @$conditions > 1) { print STDERR "Invalid Condition Element: multiple conditions specified\n"; return 1; }
  # the following is a little like specifying conditions in LDAP
  # either the first one is an element
  my $bcond = $conditions->[0];
  my $bcond_name = $bcond->xfind('./name()');
  $bcond_name = uc $bcond_name;
  if ($bcond_name eq 'OR') {
    return evalOrCondition(condition_node=>$bcond,initialcontext=>$ic);
  }
  elsif ($bcond_name eq 'AND') {
    return evalAndCondition(condition_node=>$bcond,initialcontext=>$ic);
  }
  else {
    return evalSimpleCondition(condition_node=>$bcond,initialcontext=>$ic);
  }
}

sub evalPreReqs {
  my %args = @_;
  my $ic = $args{'initialcontext'};
  my $cnode = $args{'condition_node'};
  my $condition_type  = $args{'condition_type'};

  use PMTUtilities qw(icdefined);
  if (not icdefined $cnode) { return 1; } 
  if (not $cnode->exists($condition_type)) {
    return 1;
  }
  return evalCondition(initialcontext=>$ic,condition_node=>$cnode->xnode(data=>$condition_type))
}

1;
