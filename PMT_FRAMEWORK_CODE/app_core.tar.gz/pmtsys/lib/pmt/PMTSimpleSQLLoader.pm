package PMTSimpleSQLLoader;

use strict;
use Carp;

sub new {
  my $class = shift;
  my %args = @_;

  my $o = {};
  my $ic = $args{'initialcontext'};
  my $xnode = $args{'xnode'};
  $o->{'initialcontext'} = $ic;
  $o->{'xnode'} = $xnode;
  $o->{'start_tm'} = undef;
  $o->{'end_tm'} = undef;
  $o->{'cmd_output'} = undef;
  return bless $o;
}

sub run {
  my $self = shift;
  my %args = @_;
  my $ic = $self->{'initialcontext'};
  my $item = $ic->{'WORKLIST/ITEM'};
  my $xnode = $self->{'xnode'};
  my $controller = $ic->{'RUNTIME/SYSTEM/CONTROLLER'};
  $ic->log(message=>"Running PMTSimpleSQLLoader for item",data=>$item,domain=>"system",level=>"info");
  #use PMTUtilities qw(runSysCommand expand);
  # create a parfile
  # create a control_file
  # Those can actually be fifos 
  use Data::Dumper;
  my $template_directory;
  my $template_file; 
  my $par_template_file; 

  my $e;

  eval {
   $template_directory = $xnode->xfind('config/template_dir');
   $template_file = $xnode->xfind('config/ctlfile_template');
   $par_template_file = $xnode->xfind('config/parfile_template');
    
   $ic->log(message=>"template directory: $template_directory",domain=>"system",level=>"info");
   $ic->log(message=>"template file: $template_file",domain=>"system",level=>"info");
   $ic->log(message=>"template par_template file: $par_template_file",domain=>"system",level=>"info");
  };
  if ($@) { print STDERR "Error occurred while trying to find file locations in PMTSimpleSQLLoader: ",Dumper($@),"\n"; }

  use PMTUtilities qw(expand loadResource);
  use File::Spec;

  my $full_template;
  my $template_contents;
  my $expanded_template;

  $full_template = File::Spec->catfile($template_directory,$template_file);
  # check if the files we need to at least exist, otherwise, we might as well call it quits here ...
  if (-f $full_template and -f $par_template_file) {
    # all is well
  }
  else {
    if (not -f $full_template) {
      croak { message=>"Control file template $template_file does not exist" };
    } 
    if (not -f $par_template_file) {
      croak { message=>"Par file template file $par_template_file does not exist" };
    }
  }

  $ic->addParameterStack();
  $template_contents = loadResource(resource=>$full_template);
  $ic->log(message=>"using template",domain=>"system",level=>"debug",data=>$template_contents);
  $expanded_template = expand(src=>$template_contents,evalcontext=>[$ic]);
  $ic->log(message=>"using expanded template",domain=>"system",level=>"debug",data=>$expanded_template);

  use File::Temp;
  use IO::File;
  my $logfile = $ic->expand('{{ENV/PMTROOT}}/logs/sqlldr/sqlldr_log.{{_PROCESSID_}}.{{_NOW_|formatDateTime %Y%m%d%H%M%S}}.log');
  my $ctlfile = tmpnam(); $ctlfile="$ctlfile.ctl"; $ic->log(message=>"Control file written to $ctlfile",domain=>"system",level=>"info"); 
  my $parfile = tmpnam(); $parfile="$parfile.par"; $ic->log(message=>"Parfile written to $parfile",domain=>"system",level=>"info"); 

  $ic->{'_LOCAL_/CONTROLFILE'} = $ctlfile;

  my $par_file_contents;
  eval {
  my $par_template_contents = loadResource(resource=>$par_template_file);
  $par_file_contents = expand(src=>$par_template_contents,nokeysplit=>1,evalcontext=>[$ic]);
  $ic->log(message=>"Using parfile contents",domain=>"system",level=>"info",data=>$par_file_contents);
  }; 
  if ($@) { 
    $e = $@;
    $ic->log(message=>"Error occuured while tryin to expand parfile template",data=>$e,domain=>"system",level=>"error");
  }

  my $file_generation_ok = 1;
  if (not $e) {
    eval {
      my $f_ctlfile = IO::File->new($ctlfile,'w');
      my $f_parfile = IO::File->new($parfile,'w');
      print $f_ctlfile $expanded_template;
      print $f_parfile $par_file_contents;
      $f_ctlfile->close();
      $f_parfile->close();
    };
    if ($@) { 
      $e = $@;
      $file_generation_ok = 0; 
      $ic->log(message=>"Error occurred while trying to write files ",data=>$e,domain=>"system",level=>"error"); 
    }
  }


  $ic->popParameterStack();

  if ($e) {
    if (ref $e eq 'HASH') {
      croak $e;
    }
    else {
      croak { message=>$e };
    }
  }
  
  if ($file_generation_ok) {
  	use PMTUtilities qw(runSysCmd);
    my $cmd = "sqlldr parfile=$parfile log=$logfile";
    $ic->log(message=>"Running sqlldr with following command",data=>$cmd,level=>"info",domain=>"system");
  	my $result = runSysCmd(command=>"$cmd 2>&1");
    my $logfile_contents;
    if (-f $logfile) {
      local $/ = undef;
      my $lf;
      open ($lf,"<",$logfile);
      $logfile_contents = <$lf>;
      close $lf;
    }

    # parse the logfile
    # we get something  like this or we don't ...
    # Table T_MSS_PM_TCPIP_NORM:
    # 32556 Rows successfully loaded.
    # 0 Rows not loaded due to data errors.
    # 0 Rows not loaded because all WHEN clauses were failed.
    #  0 Rows not loaded because all fields were null.

    #Total logical records skipped:          0    
    # Total logical records read:         32556
    # Total logical records rejected:         0    
    # Total logical records discarded:        0 

    my $parse_result = {
      loaded=>0,
      not_loaded_data_error=>0,
      not_loaded_no_matching_when=>0,
      not_loaded_null_record=>0,
      read=>0
    };


    if ($logfile_contents and $logfile_contents =~ m/Rows successfully loaded/m) {
      if ($logfile_contents =~ m/(\d+) Rows successfully loaded/m) { $parse_result->{'loaded'} = $1; }
      if ($logfile_contents =~ m/(\d+) Rows not loaded due to data errors/m) { $parse_result->{'not_loaded_data_error'} = $1; }
      if ($logfile_contents =~ m/(\d+) Rows not loaded because all WHEN clauses where failed/m) { $parse_result->{'not_loaded_no_matching_when'} = $1; }
      if ($logfile_contents =~ m/(\d+) Rows not loaded because all fields were null/m) { $parse_result->{'not_loaded_null_record'} = $1; }
      if ($logfile_contents =~ m/Total logical records read:\s*(\d+)/m) { $parse_result->{'read'} = $1; }
      $ic->log(message=>"Found following statistics in SQLLdr Logfile:",data=>$parse_result,domain=>"system",level=>"info");
      my $monitoringdata = [
        { message_type=>'RECORDS_READ',
          message=>$parse_result->{'read'}
        },
        { message_type=>'RECORDS_LOADED',
          message=>$parse_result->{'loaded'}
        }
      ];
      $controller->send(type=>'monitoring_message',data=>$monitoringdata);
    }
    else {
      $ic->log(message=>"SQLLdr Logfile does not contain interesting statistics",domain=>"system",level=>"warning");
    }
    
  	my $rc = $result->{'rc'};
  	if (-f $ctlfile ) { unlink $ctlfile; }
  	if (-f $parfile ) { unlink $parfile; }
  	if ($rc == 0) {
      $ic->log(message=>"SQLLDR ran absolutely fine",domain=>"system",level=>"info");
      $ic->log(message=>"SQLLdr Log: ",data=>$logfile_contents,domain=>"system",level=>"debug");
      if ($args{'cleanup'}) {
        my $cl = $item; if (ref $cl eq 'ARRAY') { } else { $cl = [$cl]; }
        for my $c (@$cl) { my $rc = `rm -f $c`; }
      }
  		if (-f $logfile ) { unlink $logfile; }
  	}
  	else {
      $ic->log(message=>"SQLLdr ran with issues, rc = $rc",domain=>"system",level=>"warning",data=>$logfile_contents);
  	}
  }
}

sub initialize {
  my $self = shift;
  #print STDERR "Doing initialize in PMTSimpleSQLLoader\n";
}

sub logProcessStatistics {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  $ic->log(message=>"Doing process statistics in PMTSimpleSQLLoader",domain=>"system",level=>"debug");
  # Parse the output 
}

1;
