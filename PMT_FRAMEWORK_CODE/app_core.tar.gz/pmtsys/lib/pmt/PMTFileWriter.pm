package PMTFileWriter;

use strict;
use Carp;
use IO::File;
use File::Spec;

sub new {
  my $class=shift;

  my %args = @_;
  my $o = {};
  my $filename = $args{'filename'};
  my $lfilename = $filename;
  if ($args{'directory'}) {
    $o->{'directory'} = $args{'directory'};
    $lfilename=File::Spec->catfile($args{'directory'},$filename);
  }
  $o->{'filename'} = $filename;
  $o->{'lfilename'} = $lfilename;
  my $io;
  if (uc $filename eq 'STDERR') {
  }
  elsif (uc $filename eq 'STDOUT' or not defined $filename or $filename =~ m/^\s*-\s*$/) {
  }
  else {
    $io = IO::File->new($lfilename,'w');
    if ($args{'temporary'}) {
      $o->{'temp'} = 1;
    }
  }
  
  if ($args{'compress'}) {
    binmode $io,":gzip";
  }
  elsif ($args{'binary'}) {
    binmode $io;
  }
  if ($args{'autoflush'}) {
    $io->autoflush(1);
  }
  $o->{'io'} = $io;

  bless $o;
  return $o;
}

sub DESTROY {
  my $self = shift;
  if ($self->{'io'}) {
    $self->{'io'}->close();
  }
  if ($self->{'temp'}) {
    unlink ($self->{'filename'}); 
  }
}

1;
