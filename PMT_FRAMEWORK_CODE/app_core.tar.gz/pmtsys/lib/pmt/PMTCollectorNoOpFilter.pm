package PMTCollectorNoOpFilter;

use strict;
use Carp;
use PMTUtilities qw(partial);

use overload q{&{}} => \&call_overload, 
             q{""}  => sub { return "<". __PACKAGE__ . " instance>"};


sub new {
  my $package = shift;
  my $o = {};
  return bless $o;
}

sub call_overload {
  my $self = shift;
  return partial(\&filter,$self);
}


sub filter {
  my $self = shift;
  my %args = @_;
  my $f = $args{'data'};
  if (wantarray) {
    return @$f;
  }
  elsif (defined wantarray) {
    return $f;
  }
  return undef;
}

1;
