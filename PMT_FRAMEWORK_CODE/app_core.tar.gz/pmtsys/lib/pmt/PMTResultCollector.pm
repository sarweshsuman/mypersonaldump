package PMTResultCollector;


use PMTUtilities qw(partial);
use PMTHelperBase;

our @ISA = qw(PMTHelperBase);

sub new {
  my $package = shift;
  my %args = @_;
  my $list = $args{'list'};
  if (not $list) { $list = []; }
  my $o = {};
  $o->{'_list_'} = [];
  for my $i (@$list) {
    push @{$o->{'_list_'}},$i;
  }

  return bless $o;
}

sub pushResult {
  my $self = shift;
  my $item = shift;
  push @{$self->{'_list_'}},$item;
}

sub setResultPlugin {
}

1;
