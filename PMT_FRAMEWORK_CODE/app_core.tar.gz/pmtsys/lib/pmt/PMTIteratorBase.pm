package PMTIteratorBase;

use overload q{<>} => \&iterator_overload,
             'bool'=> \&bool_overload,
             '!' => \&neg_overload,
             q{""} => sub { return "<" . __PACKAGE__ ." instance>"; };


# ##############################################################
#
# This is basically a placeholder
# It doesn't need any methods, only required to build an 
# an inheritance-tree
# 
# ##############################################################

sub iterator_overload { }

sub neg_overload {}

sub bool_overload {}

sub next {}

sub reset {}

1;
