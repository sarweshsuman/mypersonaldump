package PMTFactories;

use strict;
use Data::Dumper;
use Carp;

sub DBLookupResourceFactory {
  my %args = @_;
  my $ic = $args{'initialcontext'};
  my $n = $args{'data'};
  my $xnode = $args{'xnode'};
  my $name = $n->getAttribute('name');

  my $resource_definition = $n->xfind("resource_definition");
  my $db_connection = $n->xfind('db_connection/resource_factory()');
  $resource_definition->{'dbconn'} = $db_connection;
  $resource_definition->{'initialcontext'} = $ic;
  $resource_definition->{'xnode'} = $xnode;

  use PMTUtilities qw(h2a);
  $a = h2a(hash=>$resource_definition);

  $ic->log(message=>"Creating a DBLookupResourceFactory",domain=>"system",level=>"debug");

  use DBTie;
  my %hh;
  tie %hh,'DBTie',@$a;
  $ic->log(message=>"Created a DBLookupResourceFactory",domain=>"system",level=>"debug");
  return \%hh;
}

sub DBConnection {
  my %args = @_;
  my $data = $args{'data'};
  my $ic = $args{'initialcontext'};
  my $name = $args{'name'};
  my $xnode = $args{'xnode'};

  $ic->log(message=>"Creating a DBConnection with name $name parameters",data=>$data,domain=>"system",level=>"debug");
  use PMTDBConnectionManager ;
  return PMTDBConnectionManager::getConnection(name=>$name,initialcontext=>$ic,data=>$data);
}

1;
