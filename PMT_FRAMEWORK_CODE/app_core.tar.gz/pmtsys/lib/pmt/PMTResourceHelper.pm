# ##########################################################################
# MODULENAME          : PMTLogHelper
# DESCRIPTION         : PMT Helper Class: Logging
# AUTHOR              : Evert Carton
# INPUTS              : NONE
# OUTPUTS             : NONE
# DEPENDENCY          : NONE
# REMARKS             : NONE
# VERSION             : 1.0
# REVISION HISTORY    : Initial Version
# ##########################################################################

# ==========================================================================
#
# Package Declaration
#
# ==========================================================================

package PMTResourceHelper;

# ==========================================================================
#
# Use Declarations
#
# ==========================================================================

use strict;
use Carp;

use PMTHelperBase;

our @ISA = qw(PMTHelperBase);

use PMTUtilities qw(expand icdefined);

sub new {
  my $class = shift;
  my %args = @_;
  my $context = $args{'initialcontext'};
  my $obj = {};
  $obj->{'initialcontext'} = $context;
  bless $obj;
  print STDERR "Created a resourcehelper\n";
  return $obj;
}

# ==========================================================================
#
# System Methods
#
# ==========================================================================

sub getResource {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $rname = $args{'name'};
  my $t = $args{'resource_type'};
  my $ic = $self->{'initialcontext'};
  my $res;
  $ic->addParameterStack();
  eval {
  	print STDERR "looking for resource $rname\n";
    $ic->{'_LOCAL_/RESOURCENAME'} = $rname;
    my $lstring ;
    if ($t) {
       $ic->{'_LOCAL_/RESOURCETYPE'} = $t;
       $lstring = 'JOBDEF/resources/resource[@name="{{_LOCAL_/RESOURCENAME}}" and @resource_type="{{_LOCAL_/RESOURCETYPE}}"]/xnode()';
    }
    else {
      $lstring = 'JOBDEF/resources/resource[@name="{{_LOCAL_/RESOURCENAME}}"]/xnode()';
    }
    $res = $ic->resolve($lstring);
    if (not icdefined $res) {
      if ($t) {
        croak { message=>"Could not find resource definition for $rname and type $t" };
      }
      else {
        croak { message=>"Could not find resource definition for $rname " };
      }
    }
    #my $res = $ic->resolve('JOBDEF/resources/resource/prettystring()');
    if (ref $res eq 'ARRAY') {
       # prolly two different types ...
       my $types = $ic->resolve('JOBDEF/resources/resource[@name="{{_LOCAL_/RESOURCENAME}}"]/@resource_type/data()');
       croak { message=>"More than one resource with the same name $rname",data=>$types};
    }
    if ($t) {
      $lstring = 'JOBDEF/resources/resource[@name="{{_LOCAL_/RESOURCENAME}}" and @resource_type="{{_LOCAL_/RESOURCETYPE}}"]/resource_factory()';
    }
    else {
      $lstring = 'JOBDEF/resources/resource[@name="{{_LOCAL_/RESOURCENAME}}"]/resource_factory()';
    }
    $res = $ic->resolve($lstring);
    print STDERR "Resourcedef = ",$res,"\n";
  };
  if ($@) {
    my $e = $@;
    print STDERR "an error occurred while looking for resource\n";
    $ic->popParameterStack();
    croak $e;
  }
  $ic->popParameterStack();
  return $res;
}

1;


