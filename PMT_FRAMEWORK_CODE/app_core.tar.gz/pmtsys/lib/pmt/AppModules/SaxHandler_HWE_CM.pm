package AppModules::SaxHandler_HWE_CM;

use strict;
use Carp;

use base qw(XML::SAX::Base);
use PMTUtilities qw(partial);
use XML::Simple;
use Time::HiRes qw(time);
use Data::Dumper;

sub new {
  my $class = shift;
  my %params = @_;
  my $o = {};
  $o->{'initialcontext'} = $params{'initialcontext'};
  $o->{'xnode'} = $params{'xnode'};
  my $ic = $params{'initialcontext'};
  $o->{'currentelement'} = [];
  $o->{'path'} = '';
  $o->{'currenttext'} = undef;
  $o->{'texttargets'} = {};
  $o->{'currenttexttarget'} = [];
  $o->{'state'} = {};
        $o->{'io_out'} = undef; #$params{'out'};
  $o->{'writer'} = undef; #$params{'writer'};
  $o->{'record_count'} = 0;
  $o->{'error_count'} = 0;
  $o->{'process_start'} = undef;
  $o->{'process_end'} = undef;
  $o->{'field_separator'} = ',';
  $o->{'xnode'} = $params{'xnode'};

  $o->{'endhandler_stack'} = [];
  $o->{'starthandler_stack'} = [];

  if ($params{'out'} and not $params{'writer'}) {
    $o->{'writer'} = partial(
      sub { my $self = shift; my $ofile = shift; my $r = shift; my $line=join($self->{'field_separator'},@$r); print $ofile "$line\n"; },
      $o,$params{'out'}
    );
    $o->{'io_out'} = undef;
  }
  elsif ($params{'writer'}) {
    $o->{'writer'} = $params{'writer'};
  }

  $o->{'elementstarthandlers'} = {
    '1'=>partial(
      sub {
        my $self = shift; my $e = shift;
      },
      $o
    ),
    '2'=>partial(
      sub {
        my $self = shift; my $e = shift;
	return if($e->{'LocalName'} !~ /subsession/);
        my $attributes = $e->{'Attributes'};
        my $neid = $attributes->{'{}neid'}->{'Value'};
        my $netype= $attributes->{'{}netype'}->{'Value'};
	my $neversion= $attributes->{'{}neversion'}->{'Value'};
        $self->{'ne_id'}=$self->{'id'};
	$self->{'id'}++;
        if (defined $self->{'writer'}) {
	    $self->{'line_count'}++;
	    $self->{'writer'}->([$self->{'ne_id'},$self->{'file_type'},'subsession',$neid,$netype,$neversion,$self->{'line_count'}]);
            #$self->{'writer'}->([$self->{'ne_id'},'subsession','neid',$neid,'','']);
	    #$self->{'writer'}->([$self->{'ne_id'},'subsession','netype',$netype,'','']);
	    #$self->{'writer'}->([$self->{'ne_id'},'subsession','neversion',$neversion,'','']);
        }
	#push(@{$self->{'parent_id_array'}},$self->{'ne_id'});
	#$self->{$self->{'subsession'}}->{'pop_parent_id_on_close_tag'}=1;
	undef $self->{'Transmission'};
	undef $self->{'Radio'};
	$self->{'Transmission'}={};
	$self->{'Radio'}={};
      } , $o
    ),
'5' => partial ( sub {
        my $self = shift; my $e = shift;

	if($e->{'LocalName'} =~ /Transmission/){
		$self->{'Block'}='Transmission';
	}
	elsif($e->{'LocalName'} =~ /Radio/){
		$self->{'Block'}='Radio';
	}
if($e->{'LocalName'} =~ /attributes/){
	$self->{'node_id'}=$self->{'tmp_node_id'};
	$self->{'node_name'}=$self->{'tmp_node_name'};
	$self->{'id'}++;
	$self->{'Previous_Local_Name'}='attributes';

	#if($self->{'Block'} =~ /Transmission/ ){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};	
		$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}={};
	#}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
	$self->{'currenttexttarget'}->[-1]->{'r'} = 1;
	$self->{'attribute_name'}=$e->{'LocalName'};
}
else{
	$self->{'tmp_node_id'}=$self->{'id'};
	$self->{'tmp_node_name'}=$e->{'LocalName'};
}
},$o),
   '6'=>partial(
sub {
        my $self = shift; my $e = shift;
if($e->{'LocalName'} =~ /attributes/){
	$self->{'node_id'}=$self->{'tmp_node_id'};
	$self->{'node_name'}=$self->{'tmp_node_name'};
	$self->{'id'}++;
	$self->{'Previous_Local_Name'}='attributes';
	#if($self->{'Block'} =~ /Transmission/ ){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};	
		$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}={};
	#}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
	$self->{'currenttexttarget'}->[-1]->{'r'} = 1;
	$self->{'attribute_name'}=$e->{'LocalName'};
}
else{
	$self->{'tmp_node_id'}=$self->{'id'};
	$self->{'tmp_node_name'}=$e->{'LocalName'};
}
},$o),
'7' => partial ( sub {
        my $self = shift; my $e = shift;

if($e->{'LocalName'} =~ /attributes/){
	$self->{'node_id'}=$self->{'tmp_node_id'};
	$self->{'node_name'}=$self->{'tmp_node_name'};
	$self->{'id'}++;
	$self->{'Previous_Local_Name'}='attributes';
	#if($self->{'Block'} =~ /Transmission/ ){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};	
		$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}={};
	#}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
	$self->{'currenttexttarget'}->[-1]->{'r'} = 1;
	$self->{'attribute_name'}=$e->{'LocalName'};
}
else{
	$self->{'tmp_node_id'}=$self->{'id'};
	$self->{'tmp_node_name'}=$e->{'LocalName'};
}
},$o),
'8' => partial ( sub {
        my $self = shift; my $e = shift;

if($e->{'LocalName'} =~ /attributes/){
	$self->{'node_id'}=$self->{'tmp_node_id'};
	$self->{'node_name'}=$self->{'tmp_node_name'};
	$self->{'id'}++;
	$self->{'Previous_Local_Name'}='attributes';	
	#if($self->{'Block'} =~ /Transmission/ ){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};	
		$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}={};
	#}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
	$self->{'currenttexttarget'}->[-1]->{'r'} = 1;
	$self->{'attribute_name'}=$e->{'LocalName'};
}
else{
	$self->{'tmp_node_id'}=$self->{'id'};
	$self->{'tmp_node_name'}=$e->{'LocalName'};
}
},$o),
'9'  => partial ( sub {
        my $self = shift; my $e = shift;

if($e->{'LocalName'} =~ /attributes/){
	$self->{'node_id'}=$self->{'tmp_node_id'};
	$self->{'node_name'}=$self->{'tmp_node_name'};
	$self->{'id'}++;
	$self->{'Previous_Local_Name'}='attributes';	
	#if($self->{'Block'} =~ /Transmission/ ){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};	
		$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}={};
	#}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
	$self->{'currenttexttarget'}->[-1]->{'r'} = 1;
	$self->{'attribute_name'}=$e->{'LocalName'};
}
else{
	$self->{'tmp_node_id'}=$self->{'id'};
	$self->{'tmp_node_name'}=$e->{'LocalName'};
}
},$o),
'10' => partial ( sub {
        my $self = shift; my $e = shift;

if($e->{'LocalName'} =~ /attributes/){
	$self->{'node_id'}=$self->{'tmp_node_id'};
	$self->{'node_name'}=$self->{'tmp_node_name'};
	$self->{'id'}++;
	$self->{'Previous_Local_Name'}='attributes';	
	#if($self->{'Block'} =~ /Transmission/ ){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};	
		$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}={};
	#}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
	$self->{'currenttexttarget'}->[-1]->{'r'} = 1;
	$self->{'attribute_name'}=$e->{'LocalName'};
}
else{
	$self->{'tmp_node_id'}=$self->{'id'};
	$self->{'tmp_node_name'}=$e->{'LocalName'};
}
},$o),
'11'  => partial ( sub {
        my $self = shift; my $e = shift;

if($e->{'LocalName'} =~ /attributes/){
        $self->{'node_id'}=$self->{'tmp_node_id'};
        $self->{'node_name'}=$self->{'tmp_node_name'};
        $self->{'id'}++;
        $self->{'Previous_Local_Name'}='attributes';
	#if($self->{'Block'} =~ /Transmission/ ){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};	
		$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}={};
	#}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
        $self->{'currenttexttarget'}->[-1]->{'r'} = 1;
        $self->{'attribute_name'}=$e->{'LocalName'};
}
else{
        $self->{'tmp_node_id'}=$self->{'id'};
        $self->{'tmp_node_name'}=$e->{'LocalName'};
}
},$o),
'12'  => partial ( sub {
        my $self = shift; my $e = shift;

if($e->{'LocalName'} =~ /attributes/){
        $self->{'node_id'}=$self->{'tmp_node_id'};
        $self->{'node_name'}=$self->{'tmp_node_name'};
        $self->{'id'}++;
        $self->{'Previous_Local_Name'}='attributes';
	#if($self->{'Block'} =~ /Transmission/ ){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};	
		$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}={};
	#}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
        $self->{'currenttexttarget'}->[-1]->{'r'} = 1;
        $self->{'attribute_name'}=$e->{'LocalName'};
}
else{
        $self->{'tmp_node_id'}=$self->{'id'};
        $self->{'tmp_node_name'}=$e->{'LocalName'};
}
},$o),
};
  $o->{'elementendhandlers'} = {
 '1'=>partial(
      sub {
        my $self = shift; my $e = shift;
      },
      $o
    ),
  '2'=>partial(
      sub {
        my $self = shift; my $e = shift;
	return if($e->{'LocalName'} !~ /subsession/);
	undef $self->{'ne_id'};
        #pop(@{$self->{'parent_id_array'}});
        #undef $self->{$self->{'subsession'}}->{'pop_parent_id_on_close_tag'};

      } , $o
    ),
'5' => partial ( sub {
        my $self = shift; my $e = shift;
if($e->{'LocalName'} =~ /attributes/){
	undef $self->{'Previous_Local_Name'};
	return if ($self->{'node_name'} =~ /^UPCCPCH$/i or $self->{'node_name'} =~ /^NODEB_SEC$/i or $self->{'node_name'} =~ /^NODEB_SITE$/i or $self->{'node_name'} =~ /^USCCPCHBASIC$/i);
	push(@{$self->{'parent_id_array'}},$self->{'node_id'});
	push(@{$self->{'parent_name_array'}},$self->{'node_name'});
	$self->{$self->{'node_name'}}->{'pop_parent_id_on_close_tag'}=1;
	if($self->{'Block'} eq 'Transmission'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};
		#$self->{'Transmission'}->{$heirarchy_name}->{$self->{'node_id'}}->{'id'}=$self->{'node_id'};	
		#print Dumper $self->{'Transmission'};die;
	}
	elsif($self->{'Block'} eq 'Radio'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};
		#print $heirarchy_name,"\n";
		if(defined $self->{'Transmission'}->{$heirarchy_name}){
		my $radio_att_name='';
		my $radio_att_value='';
		foreach my $key (keys %{$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}}){
			$radio_att_name=$radio_att_name.$key;
			$radio_att_value=$radio_att_value.$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$key};
		}
			#print " $heirarchy_name defined in Transmission ";
			foreach my $key (keys %{$self->{'Transmission'}->{$heirarchy_name}}){
				my $att_name='';
				my $att_value='';
				foreach my $att (keys %{$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}}){
					$att_name=$att_name.$att;
					$att_value=$att_value.$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}->{$att};
				}
				if($radio_att_name eq $att_name and $radio_att_value eq $att_value){
					pop(@{$self->{'parent_id_array'}});
					push(@{$self->{'parent_id_array'}},$key);
					#print "using id $key instead of $self->{'node_id'}\n";
					last;
				}	
			}
		}
	}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
	$self->{'attribute_value'}=$self->getElementText();
		  #  if (defined $self->{'io_out'}) {
		#	my $of = $self->{'io_out'};
		#.	print $of "$self->{'node_id'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},$self->{'parent_id'}\n";
		#}
		#
		#if($self->{'Block'} =~ /Transmission/ ){
		my $heirarchy_name=join ',',@{$self->{'parent_name_array'}},$self->{'node_name'};
		#$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$self->{'attribute_name'}}=$self->{'attribute_value'};
		#}
		if (defined $self->{'writer'}) {
			$self->{'line_count'}++;
			return if(defined $self->{'Transmission'}->{$heirarchy_name} and $self->{'Block'} =~ /Radio/);
			$self->{'writer'}->([$self->{'node_id'},$self->{'file_type'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},${$self->{'parent_id_array'}}[$#{$self->{'parent_id_array'}}],${$self->{'parent_name_array'}}[$#{$self->{'parent_name_array'}}],$self->{'ne_id'},$self->{'line_count'},'']); 
		}
}
else{
	if($self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'} == 1){
		pop(@{$self->{'parent_id_array'}});
		pop(@{$self->{'parent_name_array'}});
		undef $self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'};
	}
}
},$o),
'6' => partial( sub { 
        my $self = shift; my $e = shift;

if($e->{'LocalName'} =~ /attributes/){
	undef $self->{'Previous_Local_Name'};
	return if ($self->{'node_name'} =~ /^UPCCPCH$/i or $self->{'node_name'} =~ /^NODEB_SEC$/i or $self->{'node_name'} =~ /^NODEB_SITE$/i or $self->{'node_name'} =~ /^USCCPCHBASIC$/i);
	push(@{$self->{'parent_id_array'}},$self->{'node_id'});
	push(@{$self->{'parent_name_array'}},$self->{'node_name'});
	$self->{$self->{'node_name'}}->{'pop_parent_id_on_close_tag'}=1;
	if($self->{'Block'} eq 'Transmission'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};
		#$self->{'Transmission'}->{$heirarchy_name}->{$self->{'node_id'}}->{'id'}=$self->{'node_id'};	
		#print Dumper $self->{'Transmission'};die;
	}
	elsif($self->{'Block'} eq 'Radio'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};
		#print $heirarchy_name,"\n";
		#print $heirarchy_name," defined in Transmission \n" if(defined $self->{'Transmission'}->{$heirarchy_name});
		if(defined $self->{'Transmission'}->{$heirarchy_name}){
		my $radio_att_name='';
		my $radio_att_value='';
		foreach my $key (keys %{$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}}){
			$radio_att_name=$radio_att_name.$key;
			$radio_att_value=$radio_att_value.$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$key};
		}
			#print " $heirarchy_name defined in Transmission ";
			foreach my $key (keys %{$self->{'Transmission'}->{$heirarchy_name}}){
				my $att_name='';
				my $att_value='';
				foreach my $att (keys %{$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}}){
					$att_name=$att_name.$att;
					$att_value=$att_value.$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}->{$att};
				}
				if($radio_att_name eq $att_name and $radio_att_value eq $att_value){
					pop(@{$self->{'parent_id_array'}});
					push(@{$self->{'parent_id_array'}},$key);
					#print "using id $key instead of $self->{'node_id'}\n";
					last;
				}	
			}
		}
	}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
	$self->{'attribute_value'}=$self->getElementText();
		  #  if (defined $self->{'io_out'}) {
		#	my $of = $self->{'io_out'};
		#.	print $of "$self->{'node_id'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},$self->{'parent_id'}\n";
		#}
		#if($self->{'Block'} =~ /Transmission/ ){
		my $heirarchy_name=join ',',@{$self->{'parent_name_array'}},$self->{'node_name'};
		#$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$self->{'attribute_name'}}=$self->{'attribute_value'};
#}
		if (defined $self->{'writer'}) {
			$self->{'line_count'}++;
			return if(defined $self->{'Transmission'}->{$heirarchy_name} and $self->{'Block'} =~ /Radio/);
			$self->{'writer'}->([$self->{'node_id'},$self->{'file_type'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},${$self->{'parent_id_array'}}[$#{$self->{'parent_id_array'}}],${$self->{'parent_name_array'}}[$#{$self->{'parent_name_array'}}],$self->{'ne_id'},$self->{'line_count'},$self->{'Block'}]); 
		}
}
else{
	if($self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'} == 1){
		pop(@{$self->{'parent_id_array'}});
		pop(@{$self->{'parent_name_array'}});
		undef $self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'};
	}
}
},$o),
'7' => partial ( sub {
        my $self = shift; my $e = shift;

if($e->{'LocalName'} =~ /attributes/ ){
	undef $self->{'Previous_Local_Name'};
	return if ($self->{'node_name'} =~ /^UPCCPCH$/i or $self->{'node_name'} =~ /^NODEB_SEC$/i or $self->{'node_name'} =~ /^NODEB_SITE$/i or $self->{'node_name'} =~ /^USCCPCHBASIC$/i);
	push(@{$self->{'parent_id_array'}},$self->{'node_id'});
	push(@{$self->{'parent_name_array'}},$self->{'node_name'});
	$self->{$self->{'node_name'}}->{'pop_parent_id_on_close_tag'}=1;
	if($self->{'Block'} eq 'Transmission'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}},$self->{'node_name'};
		#$self->{'Transmission'}->{$heirarchy_name}->{$self->{'node_id'}}->{'id'}=$self->{'node_id'};	
		#print Dumper $self->{'Transmission'};die;
	}
	elsif($self->{'Block'} eq 'Radio'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};
		#print $heirarchy_name,"\n";
		#print $heirarchy_name," defined in Transmission \n" if(defined $self->{'Transmission'}->{$heirarchy_name});
		if(defined $self->{'Transmission'}->{$heirarchy_name}){
		my $radio_att_name='';
		my $radio_att_value='';
		foreach my $key (keys %{$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}}){
			$radio_att_name=$radio_att_name.$key;
			$radio_att_value=$radio_att_value.$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$key};
		}
			#print " $heirarchy_name defined in Transmission ";
			foreach my $key (keys %{$self->{'Transmission'}->{$heirarchy_name}}){
				my $att_name='';
				my $att_value='';
				foreach my $att (keys %{$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}}){
					$att_name=$att_name.$att;
					$att_value=$att_value.$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}->{$att};
				}
				if($radio_att_name eq $att_name and $radio_att_value eq $att_value){
					pop(@{$self->{'parent_id_array'}});
					push(@{$self->{'parent_id_array'}},$key);
					#print "using id $key instead of $self->{'node_id'}\n";
					last;
				}	
			}
		}
	}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
	$self->{'attribute_value'}=$self->getElementText();
		  #  if (defined $self->{'io_out'}) {
		#	my $of = $self->{'io_out'};
		#.	print $of "$self->{'node_id'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},$self->{'parent_id'}\n";
		#}
		#if($self->{'Block'} =~ /Transmission/ ){
		my $heirarchy_name=join ',',@{$self->{'parent_name_array'}},$self->{'node_name'};
		#$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$self->{'attribute_name'}}=$self->{'attribute_value'};
		#}
		if (defined $self->{'writer'}) {
			$self->{'line_count'}++;
			return if(defined $self->{'Transmission'}->{$heirarchy_name} and $self->{'Block'} =~ /Radio/);
			$self->{'writer'}->([$self->{'node_id'},$self->{'file_type'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},${$self->{'parent_id_array'}}[$#{$self->{'parent_id_array'}}],${$self->{'parent_name_array'}}[$#{$self->{'parent_name_array'}}],$self->{'ne_id'},$self->{'line_count'},$self->{'Block'}]);
		}
}
else{
	if($self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'} == 1){
		pop(@{$self->{'parent_id_array'}});
		pop(@{$self->{'parent_name_array'}});
		undef $self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'};
	}
}
},$o),
'8'  => partial( sub {
        my $self = shift; my $e = shift;

if($e->{'LocalName'} =~ /attributes/ ){
	undef $self->{'Previous_Local_Name'};
	return if ($self->{'node_name'} =~ /^UPCCPCH$/i or $self->{'node_name'} =~ /^NODEB_SEC$/i or $self->{'node_name'} =~ /^NODEB_SITE$/i or $self->{'node_name'} =~ /^USCCPCHBASIC$/i);
	push(@{$self->{'parent_id_array'}},$self->{'node_id'});
	push(@{$self->{'parent_name_array'}},$self->{'node_name'});
	$self->{$self->{'node_name'}}->{'pop_parent_id_on_close_tag'}=1;
	if($self->{'Block'} eq 'Transmission'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};
		#$self->{'Transmission'}->{$heirarchy_name}->{$self->{'node_id'}}->{'id'}=$self->{'node_id'};	
		#print Dumper $self->{'Transmission'};die;
	}
	elsif($self->{'Block'} eq 'Radio'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};
		#print $heirarchy_name,"\n";
		#print $heirarchy_name," defined in Transmission \n" if(defined $self->{'Transmission'}->{$heirarchy_name});
		if(defined $self->{'Transmission'}->{$heirarchy_name}){
		my $radio_att_name='';
		my $radio_att_value='';
		foreach my $key (keys %{$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}}){
			$radio_att_name=$radio_att_name.$key;
			$radio_att_value=$radio_att_value.$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$key};
		}
			#print " $heirarchy_name defined in Transmission ";
			foreach my $key (keys %{$self->{'Transmission'}->{$heirarchy_name}}){
				my $att_name='';
				my $att_value='';
				foreach my $att (keys %{$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}}){
					$att_name=$att_name.$att;
					$att_value=$att_value.$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}->{$att};
				}
				if($radio_att_name eq $att_name and $radio_att_value eq $att_value){
					pop(@{$self->{'parent_id_array'}});
					push(@{$self->{'parent_id_array'}},$key);
					#print "using id $key instead of $self->{'node_id'}\n";
					last;
				}	
			}
		}
	}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
	$self->{'attribute_value'}=$self->getElementText();
		#if($self->{'Block'} =~ /Transmission/ ){
		my $heirarchy_name=join ',',@{$self->{'parent_name_array'}},$self->{'node_name'};
		#$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$self->{'attribute_name'}}=$self->{'attribute_value'};
		#}
		if (defined $self->{'io_out'}) {
			my $of = $self->{'io_out'};
			print $of "$self->{'node_id'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},$self->{'parent_id'}\n";
		}
		if (defined $self->{'writer'}) {
			$self->{'line_count'}++;
			return if(defined $self->{'Transmission'}->{$heirarchy_name} and $self->{'Block'} =~ /Radio/);
			$self->{'writer'}->([$self->{'node_id'},$self->{'file_type'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},${$self->{'parent_id_array'}}[$#{$self->{'parent_id_array'}}],${$self->{'parent_name_array'}}[$#{$self->{'parent_name_array'}}],$self->{'ne_id'},$self->{'line_count'},$self->{'Block'}]);
		}
}
else{
	if($self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'} == 1){
		pop(@{$self->{'parent_id_array'}});
		pop(@{$self->{'parent_name_array'}});
		undef $self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'};
	}
}
},$o),
'9'  => partial ( sub {
        my $self = shift; my $e = shift;

if($e->{'LocalName'} =~ /attributes/){
	undef $self->{'Previous_Local_Name'};
	return if ($self->{'node_name'} =~ /^UPCCPCH$/i or $self->{'node_name'} =~ /^NODEB_SEC$/i or $self->{'node_name'} =~ /^NODEB_SITE$/i or $self->{'node_name'} =~ /^USCCPCHBASIC$/i);
	push(@{$self->{'parent_id_array'}},$self->{'node_id'});
	push(@{$self->{'parent_name_array'}},$self->{'node_name'});
	$self->{$self->{'node_name'}}->{'pop_parent_id_on_close_tag'}=1;
	if($self->{'Block'} eq 'Transmission'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};
		#$self->{'Transmission'}->{$heirarchy_name}->{$self->{'node_id'}}->{'id'}=$self->{'node_id'};	
		#print Dumper $self->{'Transmission'};die;
	}
	elsif($self->{'Block'} eq 'Radio'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};
		#print $heirarchy_name,"\n";
		#print $heirarchy_name," defined in Transmission \n" if(defined $self->{'Transmission'}->{$heirarchy_name});
		if(defined $self->{'Transmission'}->{$heirarchy_name}){
		my $radio_att_name='';
		my $radio_att_value='';
		foreach my $key (keys %{$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}}){
			$radio_att_name=$radio_att_name.$key;
			$radio_att_value=$radio_att_value.$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$key};
		}
			#print " $heirarchy_name defined in Transmission ";
			foreach my $key (keys %{$self->{'Transmission'}->{$heirarchy_name}}){
				my $att_name='';
				my $att_value='';
				foreach my $att (keys %{$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}}){
					$att_name=$att_name.$att;
					$att_value=$att_value.$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}->{$att};
				}
				if($radio_att_name eq $att_name and $radio_att_value eq $att_value){
					pop(@{$self->{'parent_id_array'}});
					push(@{$self->{'parent_id_array'}},$key);
					#print "using id $key instead of $self->{'node_id'}\n";
					last;
				}	
			}
		}
	}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
	$self->{'attribute_value'}=$self->getElementText();
		#if($self->{'Block'} =~ /Transmission/ ){
		my $heirarchy_name=join ',',@{$self->{'parent_name_array'}},$self->{'node_name'};
		#$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$self->{'attribute_name'}}=$self->{'attribute_value'};
		#}
		if (defined $self->{'io_out'}) {
			my $of = $self->{'io_out'};
			print $of "$self->{'node_id'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},$self->{'parent_id'}\n";
		}
		if (defined $self->{'writer'}) {
			$self->{'line_count'}++;
			return if(defined $self->{'Transmission'}->{$heirarchy_name} and $self->{'Block'} =~ /Radio/);
			$self->{'writer'}->([$self->{'node_id'},$self->{'file_type'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},${$self->{'parent_id_array'}}[$#{$self->{'parent_id_array'}}],${$self->{'parent_name_array'}}[$#{$self->{'parent_name_array'}}],$self->{'ne_id'},$self->{'line_count'},$self->{'Block'}]);
		}
}
else{
	if($self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'} == 1){
		pop(@{$self->{'parent_id_array'}});
		pop(@{$self->{'parent_name_array'}});
		undef $self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'};		
	}
}
},$o),
'10'  => partial( sub {
        my $self = shift; my $e = shift;

if($e->{'LocalName'} =~ /attributes/ ){
	undef $self->{'Previous_Local_Name'};
	return if ($self->{'node_name'} =~ /^UPCCPCH$/i or $self->{'node_name'} =~ /^NODEB_SEC$/i or $self->{'node_name'} =~ /^NODEB_SITE$/i or $self->{'node_name'} =~ /^USCCPCHBASIC$/i);
	push(@{$self->{'parent_id_array'}},$self->{'node_id'});
	push(@{$self->{'parent_name_array'}},$self->{'node_name'});
	$self->{$self->{'node_name'}}->{'pop_parent_id_on_close_tag'}=1;
	if($self->{'Block'} eq 'Transmission'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};
		#$self->{'Transmission'}->{$heirarchy_name}->{$self->{'node_id'}}->{'id'}=$self->{'node_id'};	
		#print Dumper $self->{'Transmission'};die;
	}
	elsif($self->{'Block'} eq 'Radio'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};
		#print $heirarchy_name,"\n";
		#print $heirarchy_name," defined in Transmission \n" if(defined $self->{'Transmission'}->{$heirarchy_name});
		if(defined $self->{'Transmission'}->{$heirarchy_name}){
		my $radio_att_name='';
		my $radio_att_value='';
		foreach my $key (keys %{$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}}){
			$radio_att_name=$radio_att_name.$key;
			$radio_att_value=$radio_att_value.$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$key};
		}
			#print " $heirarchy_name defined in Transmission ";
			foreach my $key (keys %{$self->{'Transmission'}->{$heirarchy_name}}){
				my $att_name='';
				my $att_value='';
				foreach my $att (keys %{$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}}){
					$att_name=$att_name.$att;
					$att_value=$att_value.$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}->{$att};
				}
				if($radio_att_name eq $att_name and $radio_att_value eq $att_value){
					pop(@{$self->{'parent_id_array'}});
					push(@{$self->{'parent_id_array'}},$key);
					#print "using id $key instead of $self->{'node_id'}\n";
					last;
				}	
			}
		}
	}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
	$self->{'attribute_value'}=$self->getElementText();
		#if($self->{'Block'} =~ /Transmission/ ){
		my $heirarchy_name=join ',',@{$self->{'parent_name_array'}},$self->{'node_name'};
		#$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$self->{'attribute_name'}}=$self->{'attribute_value'};
		#}
		if (defined $self->{'io_out'}) {
			my $of = $self->{'io_out'};
			print $of "$self->{'node_id'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},$self->{'parent_id'}\n";
		}
		if (defined $self->{'writer'}) {
			$self->{'line_count'}++;
			return if(defined $self->{'Transmission'}->{$heirarchy_name} and $self->{'Block'} =~ /Radio/);
			$self->{'writer'}->([$self->{'node_id'},$self->{'file_type'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},${$self->{'parent_id_array'}}[$#{$self->{'parent_id_array'}}],${$self->{'parent_name_array'}}[$#{$self->{'parent_name_array'}}],$self->{'ne_id'},$self->{'line_count'},$self->{'Block'}]) ;
		}
}
else{
	if($self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'} == 1){
		pop(@{$self->{'parent_id_array'}});
		pop(@{$self->{'parent_name_array'}});
		undef $self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'};		
	}
}
},$o),
'11'  => partial( sub {
        my $self = shift; my $e = shift;

if($e->{'LocalName'} =~ /attributes/ ){
	undef $self->{'Previous_Local_Name'};
	return if ($self->{'node_name'} =~ /^UPCCPCH$/i or $self->{'node_name'} =~ /^NODEB_SEC$/i or $self->{'node_name'} =~ /^NODEB_SITE$/i or $self->{'node_name'} =~ /^USCCPCHBASIC$/i);
        push(@{$self->{'parent_id_array'}},$self->{'node_id'});
	push(@{$self->{'parent_name_array'}},$self->{'node_name'});
        $self->{$self->{'node_name'}}->{'pop_parent_id_on_close_tag'}=1;
	if($self->{'Block'} eq 'Transmission'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};
		#$self->{'Transmission'}->{$heirarchy_name}->{$self->{'node_id'}}->{'id'}=$self->{'node_id'};	
		#print Dumper $self->{'Transmission'};die;
	}
	elsif($self->{'Block'} eq 'Radio'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};
		#print $heirarchy_name,"\n";
		#print $heirarchy_name," defined in Transmission \n" if(defined $self->{'Transmission'}->{$heirarchy_name});
		if(defined $self->{'Transmission'}->{$heirarchy_name}){
		my $radio_att_name='';
		my $radio_att_value='';
		foreach my $key (keys %{$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}}){
			$radio_att_name=$radio_att_name.$key;
			$radio_att_value=$radio_att_value.$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$key};
		}
			#print " $heirarchy_name defined in Transmission ";
			foreach my $key (keys %{$self->{'Transmission'}->{$heirarchy_name}}){
				my $att_name='';
				my $att_value='';
				foreach my $att (keys %{$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}}){
					$att_name=$att_name.$att;
					$att_value=$att_value.$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}->{$att};
				}
				if($radio_att_name eq $att_name and $radio_att_value eq $att_value){
					pop(@{$self->{'parent_id_array'}});
					push(@{$self->{'parent_id_array'}},$key);
					#print "using id $key instead of $self->{'node_id'}\n";
					last;
				}	
			}
		}
	}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
        $self->{'attribute_value'}=$self->getElementText();
		#if($self->{'Block'} =~ /Transmission/ ){
		my $heirarchy_name=join ',',@{$self->{'parent_name_array'}},$self->{'node_name'};
		#$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$self->{'attribute_name'}}=$self->{'attribute_value'};
		#}
                if (defined $self->{'io_out'}) {
                        my $of = $self->{'io_out'};
                        print $of "$self->{'node_id'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},$self->{'parent_id'}\n";
                }
                if (defined $self->{'writer'}) {
			$self->{'line_count'}++;
			return if(defined $self->{'Transmission'}->{$heirarchy_name} and $self->{'Block'} =~ /Radio/);
                        $self->{'writer'}->([$self->{'node_id'},$self->{'file_type'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},${$self->{'parent_id_array'}}[$#{$self->{'parent_id_array'}}],${$self->{'parent_name_array'}}[$#{$self->{'parent_name_array'}}],$self->{'ne_id'},$self->{'line_count'},$self->{'Block'}]);
                }
}
else{
        if($self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'} == 1){
                pop(@{$self->{'parent_id_array'}});
		pop(@{$self->{'parent_name_array'}});
                undef $self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'};
        }
}
},$o),
'12'  => partial( sub {
        my $self = shift; my $e = shift;

if($e->{'LocalName'} =~ /attributes/ ){
	undef $self->{'Previous_Local_Name'};
	return if ($self->{'node_name'} =~ /^UPCCPCH$/i or $self->{'node_name'} =~ /^NODEB_SEC$/i or $self->{'node_name'} =~ /^NODEB_SITE$/i or $self->{'node_name'} =~ /^USCCPCHBASIC$/i);
        push(@{$self->{'parent_id_array'}},$self->{'node_id'});
	push(@{$self->{'parent_name_array'}},$self->{'node_name'});
        $self->{$self->{'node_name'}}->{'pop_parent_id_on_close_tag'}=1;
	if($self->{'Block'} eq 'Transmission'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};
		#$self->{'Transmission'}->{$heirarchy_name}->{$self->{'node_id'}}->{'id'}=$self->{'node_id'};	
		#print Dumper $self->{'Transmission'};die;
	}
	elsif($self->{'Block'} eq 'Radio'){
		my  $heirarchy_name=join ',',@{$self->{'parent_name_array'}};
		#print $heirarchy_name,"\n";
		#print $heirarchy_name," defined in Transmission \n" if(defined $self->{'Transmission'}->{$heirarchy_name});
		if(defined $self->{'Transmission'}->{$heirarchy_name}){
		my $radio_att_name='';
		my $radio_att_value='';
		foreach my $key (keys %{$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}}){
			$radio_att_name=$radio_att_name.$key;
			$radio_att_value=$radio_att_value.$self->{'Radio'}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$key};
		}
			#print " $heirarchy_name defined in Transmission ";
			foreach my $key (keys %{$self->{'Transmission'}->{$heirarchy_name}}){
				my $att_name='';
				my $att_value='';
				foreach my $att (keys %{$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}}){
					$att_name=$att_name.$att;
					$att_value=$att_value.$self->{'Transmission'}->{$heirarchy_name}->{$key}->{'attributes'}->{$att};
				}
				if($radio_att_name eq $att_name and $radio_att_value eq $att_value){
					pop(@{$self->{'parent_id_array'}});
					push(@{$self->{'parent_id_array'}},$key);
					#print "using id $key instead of $self->{'node_id'}\n";
					last;
				}	
			}
		}
	}
}
elsif($self->{'Previous_Local_Name'} =~ /attributes/) {
        $self->{'attribute_value'}=$self->getElementText();
		#if($self->{'Block'} =~ /Transmission/ ){
		my $heirarchy_name=join ',',@{$self->{'parent_name_array'}},$self->{'node_name'};
		#$heirarchy_name=$heirarchy_name.','.$self->{'node_name'};
		$heirarchy_name=~ s/^\,//;
		$self->{$self->{'Block'}}->{$heirarchy_name}->{$self->{'node_id'}}->{'attributes'}->{$self->{'attribute_name'}}=$self->{'attribute_value'};
		#}
                if (defined $self->{'io_out'}) {
                        my $of = $self->{'io_out'};
                        print $of "$self->{'node_id'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},$self->{'parent_id'}\n";
                }
                if (defined $self->{'writer'}) {
			$self->{'line_count'}++;
			return if(defined $self->{'Transmission'}->{$heirarchy_name} and $self->{'Block'} =~ /Radio/);
                        $self->{'writer'}->([$self->{'node_id'},$self->{'file_type'},$self->{'node_name'},$self->{'attribute_name'},$self->{'attribute_value'},${$self->{'parent_id_array'}}[$#{$self->{'parent_id_array'}}],${$self->{'parent_name_array'}}[$#{$self->{'parent_name_array'}}],$self->{'ne_id'},$self->{'line_count'},$self->{'Block'}]);
                }
}
else{
        if($self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'} == 1){
                pop(@{$self->{'parent_id_array'}});
		pop(@{$self->{'parent_name_array'}});
                undef $self->{$e->{'LocalName'}}->{'pop_parent_id_on_close_tag'};
        }
}
},$o),
  };
  $o->{'currentelementhandler'} = undef;
  $o->{'texthandler'} = undef;

  bless $o;
  return $o;
}

sub getProcessStatistics {
  my $self = shift;
  my $td = $self->{'process_end'} - $self->{'process_start'};
  my $rate = $self->{'record_count'} / $td;
  my $s = {
    start_time=>$self->{'process_start'},
    end_time=>$self->{'process_end'},
    record_count=>$self->{'record_count'},
    error_count=>$self->{'error_count'},
    parse_rate=>$rate
  };
  return $s;
}

sub initialize {
  my $self = shift;
  $self->{'currentelement'} = [];
  $self->{'path'} = '';
  $self->{'currenttext'} = undef;
  $self->{'texttargets'} = {};
  $self->{'currenttexttarget'} = [];
  $self->{'state'} = {};
  $self->{'io_out'} = undef; #$params{'out'};
  $self->{'writer'} = undef; #$params{'writer'};
  $self->{'record_count'} = 0;
  $self->{'process_start'} = undef;
  $self->{'process_end'} = undef;
	
  
  #if(defined $self->{'id'}){
   #$self->{'id'}++;
  #}
  #else {
  #      use DBI;
  #      my $dbh=DBI->connect("DBI:Oracle:PMT01D","PMTCM","PMTCM");
  #      my $sth=$dbh->prepare("select max(id) from pmtcm.T_HWE_CM_L1");
  #      $sth->execute();
  #      if(my $id=$sth->fetchrow_array()){
  #               $self->{'id'}=$id+1;
#		$sth=$dbh->prepare("select count(*) from  pmtcm.T_HWE_CM_L1");
#		$sth->execute();
#		if(my $count=$sth->fetchrow_array()){
#			$self->{'line_count'}=$count;
#		}
#		$sth=$dbh->prepare("select count(*) from  pmtcm.T_HWE_CM_NEID_L1");
#		$sth->execute();
#                if(my $count=$sth->fetchrow_array()){
#                        $self->{'line_count'}=$self->{'line_count'}+$count;
#                }
#        }
#        else {
#                $self->{'id'}=1;
#		$self->{'line_count'}=0;
#        }
#        undef $sth;
#        $dbh->disconnect;
#  }
  $self->{'id'}=1;
  $self->{'line_count'}=0;
  #print STDERR "sarwesh=$self->{'id'}\n";
  my $ic=$self->{'initialcontext'};
  $self->{'file_type'} = $ic->expand('{{WORKLIST/ITEM|regExtract (\w{4})Export.*}}');
  $self->{'parent_id_array'}=[];
  $self->{'parent_name_array'}=[];
  $self->{'Block'}='';
  $self->{'Transmission'}={};
  $self->{'Radio'}={};
  undef $self->{'Previous_Local_Name'};
}

sub getDataSummary {
  return {};
}

sub setIOSpec {
  my $self = shift;
  my %params = @_;
  if ($params{'out'} and not $params{'writer'}) {
    $self->{'writer'} = partial(
      sub { my $self = shift; my $ofile = shift; my $r = shift; my $line=join($self->{'field_separator'},@$r); print $ofile "$line\n"; },
      $self,$params{'out'}
    );
    $self->{'io_out'} = undef;
  }
  elsif ($params{'writer'}) {
    $self->{'writer'} = $params{'writer'};
  }
}
sub write_record {
  my $self = shift;
  my $io = $self->{'io_out'};
  my %args = @_;
  my $line = $args{'line'};
  #print STDERR "line: $line";
  print $io $line;
}

sub start_document {
  my ($self,$doc) = @_;
  $self->{'process_start'} = time();
}

sub end_document {
  my ($self,$doc) = @_;
  $self->{'process_end'} = time();
}

sub getElementStartHandler {
  my $self = shift;
  my $path = $self->{'path'};
  my $length=shift;
  $length++; # increasing because perl stores array from 0 1 2 index
  #print STDERR "searching for handler for $path\n";
  # if( not defined $self->{'elementstarthandlers'}->{$path} and scalar @{$self->{'starthandler_stack'}}) {
    # return $self->{'starthandler_stack'}->[-1];
  # }
  # elsif (defined $self->{'elementstarthandlers'}->{$self->{'path'}}) {
    # return $self->{'elementstarthandlers'}->{$self->{'path'}};
  # }
  # return partial(sub { print STDERR "dummy start function for $path\n"; });
	
  #for my $k (keys %{$self->{'elementstarthandlers'}}) {
  #  #print STDERR "parentid= ${$self->{'parent_id_array'}}[$#{$self->{'parent_id_array'}}]\nstart\n$path checking $k\n";
  #  if ($path =~ m/^${k}$/i) {
  #    return $self->{'elementstarthandlers'}->{$k};
  #  }
  #}
  return $self->{'elementstarthandlers'}->{$length} if(defined $self->{'elementstarthandlers'}->{$length});
  
  return partial(sub { print STDERR "dummy start function for $path length $length\n"; });
}

sub getElementEndHandler {
  my $self = shift;
  my $path = $self->{'path'};
  my $length=shift;
  $length++;
  #print STDERR "searching for handler for $path\n";
  #print "Looking for elementendhandler for $path\n";
  # if( not defined $self->{'elementendhandlers'}->{$path} and scalar @{$self->{'endhandler_stack'}}) {
    # return $self->{'endhandler_stack'}->[-1];
  # }
  # elsif (defined $self->{'elementendhandlers'}->{$path}) {
    # return $self->{'elementendhandlers'}->{$path};
  # }
  # return partial(sub { print STDERR "dummy end function for $path\n"; });
  #for my $k (keys %{$self->{'elementendhandlers'}}) {
  #  #print STDERR "parentid= ${$self->{'parent_id_array'}}[$#{$self->{'parent_id_array'}}]\nend\n$path checking $k\n";
  #  if ($path =~ m/^${k}$/i) {
  #    return $self->{'elementendhandlers'}->{$k};
  #  }
  #}
  return $self->{'elementendhandlers'}->{$length} if(defined $self->{'elementendhandlers'}->{$length});
  return partial(sub { print STDERR "dummy end function for $path\n"; });
}

sub getCharacterHandler {
}

sub start_element {
  my ($self,$el) = @_;
  my $locname = $el->{'LocalName'};
  push @{$self->{'currentelement'}},$locname;
  $self->{'path'} = join ('.',@{$self->{'currentelement'}});
  #print STDERR "Starting element ",$el->{'LocalName'},"\n";
  push @{$self->{'currenttexttarget'}},{'r'=>0,'text'=>undef};
  my $elhandler = $self->getElementStartHandler($#{$self->{'currentelement'}});
  $elhandler->($el);
}

sub end_element {
  my ($self,$el) = @_;
  use Data::Dumper;
  eval {
    my $elhandler = $self->getElementEndHandler($#{$self->{'currentelement'}});
    $elhandler->($el);
  };
  if ($@) {
    #print STDERR "In SaxHandler end_elemenet: An error has occurred",Dumper($@),"\n";
  }

  #print STDERR "popping from texttargets for ",$self->{'path'},"\n";
  my $tt = pop @{$self->{'currenttexttarget'}};
  pop @{$self->{'currentelement'}};
  $self->{'path'} = join ('.',@{$self->{'currentelement'}});
  #print STDERR "Starting element ",$el->{'LocalName'},"\n";
  #print STDERR "Ending element\n";
}

sub setElementText {
  my ($self,$characters) = @_;
}

sub getElementText {
  my $self = shift;
  #print STDERR "retrieving element text for ",$self->{'path'},"\n";
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];
  #print STDERR $currenttexttarget,"\n";
  return $currenttexttarget->{'text'};
}

sub characters {
  my ($self,$characters) = @_;
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];

  if ($currenttexttarget->{'r'} == 1) {
  #print STDERR "characters called with $characters->{'Data'}\n";
  if (not defined $currenttexttarget->{'text'}) { $currenttexttarget->{'text'} = ''; }
        $currenttexttarget->{'text'} = $currenttexttarget->{'text'} . $characters->{'Data'};
  }
 #print STDERR "Get Characters: $characters->{'Data'} \n";
}

sub comment {
  my ($self,$comment) = @_;
  #print STDERR "Doing Comment\n";
}

sub processing_instruction {
  my ($self,$pi) = @_;
  #print STDERR "Doing $pi\n";
}




1;
