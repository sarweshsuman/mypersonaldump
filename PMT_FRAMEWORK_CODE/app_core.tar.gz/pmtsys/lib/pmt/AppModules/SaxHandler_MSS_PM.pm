package AppModules::SaxHandler_MSS_PM;

use strict;
use Carp;

use base qw(XML::SAX::Base);
use PMTUtilities qw(partial);
use Time::HiRes qw(time);

sub new {
  my $class = shift;
  my %params = @_;
  my $o = {};
  $o->{'initialcontext'} = $params{'initialcontext'};
  $o->{'xnode'} = $params{'xnode'};
  my $ic = $params{'initialcontext'};
  $o->{'currentelement'} = [];
  $o->{'path'} = '';
  $o->{'currenttext'} = undef;
  $o->{'texttargets'} = {};
  $o->{'currenttexttarget'} = [];
  $o->{'state'} = {};
	$o->{'io_out'} = undef; #$params{'out'};
  $o->{'writer'} = undef; #$params{'writer'};
  $o->{'record_count'} = 0;
  $o->{'error_count'} = 0;
  $o->{'process_start'} = undef;
  $o->{'process_end'} = undef;
  $o->{'field_separator'} = ',';
  $o->{'xnode'} = $params{'xnode'};

  $o->{'endhandler_stack'} = [];
  $o->{'starthandler_stack'} = [];
#  $o->{'ref_file'}={};


#	my $ref_file="/opt/PMT/pmtsys/lib/pmt/AppModules/Ref_Data/KPI_MSS_PM.txt";
#	open READ, "<$ref_file" or die "Cannot Open Ref File $ref_file";
#	my $measkey;
#	while($measkey=<READ>){
#		print STDERR "sarwesh=pusinh=$measkey";
#		$o->{'ref_file'}->{$measkey}="Y";
#	}
#	close READ;
  if ($params{'out'} and not $params{'writer'}) {
    $o->{'writer'} = partial(
      sub { my $self = shift; my $ofile = shift; my $r = shift; my $line=join($self->{'field_separator'},@$r); print $ofile "$line\n"; },
      $o,$params{'out'}
    );
    $o->{'io_out'} = undef;
  }
  elsif ($params{'writer'}) {
    $o->{'writer'} = $params{'writer'};
  }

  $o->{'state'}={ 'runseq' => $o->{'initialcontext'}->expand('{{SYSTEM/RUN/RUNSEQ}}')};
  $o->{'lookup'} = { db_lookup_dn=>{},
                     db_lookup_measid=>{},
                     db_lookup_measkey=>{},
                     db_lookup_meastype=>{},
                     db_lookup_targetkey=>{}
                   };

  for my $resource_name (keys %{$o->{'lookup'}}) {
    print STDERR "In SaxHandler: Trying to get resource $resource_name\n";
#    eval {
      my $r = $ic->getResource(name=>$resource_name);
      print STDERR "In SaxHandler: I got the resource $resource_name\n";
      $o->{'lookup'}->{$resource_name} = $r;
#    };
#    if ($@) {
#      if (ref $@ eq 'HASH') { print STDERR "Error: $@->{'message'}\n"; }
#                       else { print STDERR "Error: $@\n"; }
#    }
  }

  print STDERR "CREATED THE RESOURCES IN SAXHANDLER\n";
 
  $o->{'elementstarthandlers'} = {
    'OMeS'=>partial(
      sub {
        my $self = shift; my $e = shift; 
      },
      $o
    ),
    'OMeS.PMSetup'=>partial(
      sub { 
        my $self = shift; my $e = shift; 
        #print STDERR "e = $e\n";
        #print STDERR "self = $self\n";
        # I need the attributes startTime and interval
        my $attributes = $e->{'Attributes'};
        #print STDERR "attributes for pmsetup:",keys %$attributes,"\n";
        $self->{'state'}->{'startTime'} = $attributes->{'{}startTime'}->{'Value'};
        $self->{'state'}->{'interval'} = $attributes->{'{}interval'}->{'Value'};
      } , $o
    ),
    'OMeS.PMSetup.PMMOResult'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        #print STDERR "handling a PMMResult\n"; 
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.MO'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        #print STDERR "Handling a PMMResult.MO\n"; 
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.MO.DN'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        $self->{'currenttexttarget'}->[-1]->{'r'} = 1;
        #print STDERR "handling a DN-start\n"; 
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget'=> partial(
      sub {
        my $self = shift; my $e = shift; 
        my $attributes = $e->{'Attributes'};
        #print STDERR "attributes",%$attributes,"keys:",keys %{$attributes},"\n";
        #for my $k (keys %$attributes) { print STDERR "$k - "; }
        #print STDERR "\n";
        my $meastype = $attributes->{'{}measurementType'}->{'Value'};
        $self->{'state'}->{'measurementType'} = $meastype;
        $self->{'state'}->{'measurementType_id'} = $self->{'lookup'}->{'db_lookup_meastype'}->{$meastype} ;
        push @{$self->{'starthandler_stack'}},$self->{'elementstarthandlers'}->{'OMeS.PMSetup.PMMOResult.PMTarget.counter'};
        push @{$self->{'endhandler_stack'}},$self->{'elementendhandlers'}->{'OMeS.PMSetup.PMMOResult.PMTarget.counter'};
       # $self->{'state'}->{'dn_id'} = $self->{'lookup'}->{'db_lookup_dn'}->{$self->{'state'}->{'dn'}.":$$"} ;
        $self->{'state'}->{'dn_id'} = $self->{'state'}->{'dn'};
        #print STDERR "handling a PMTarget with measurementState " .$attributes->{'measurementType'}."\n"; 
      }, $o
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget.counter'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        $self->{'currenttexttarget'}->[-1]->{'r'} = 1;
        $self->{'state'}->{'countername'} = $e->{'LocalName'};
        #print STDERR "handling another element ",$e->{'LocalName'},"\n"; 
      } ,$o
    )
  };
  $o->{'elementendhandlers'} = {
    'OMeS'=>partial(
      sub {
        my $self = shift; my $e = shift; 
      } ,$o
    ),
    'OMeS.PMSetup'=>partial(
      sub { 
        my $self = shift; my $e = shift; 
        delete $self->{'state'}->{'startTime'};
        delete $self->{'state'}->{'interval'};
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        undef $self->{'state'}->{'dn'};
        #print STDERR "handling a PMMResult\n"; 
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.MO'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        #print STDERR "Handling a PMMResult.MO\n"; 
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.MO.DN'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        my $dn = $self->getElementText();
        if(defined $self->{'state'}->{'dn'}){
                (my $dnn)=($dn =~ /^PLMN-PLMN(.*)/);
                $self->{'state'}->{'dn'}.=$dnn;
        }
        else{
                $self->{'state'}->{'dn'} = $dn;
        }
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget'=> partial(
      sub {
        my $self = shift; my $e = shift; 
        #print STDERR "handling a PMTarget\n"; 
        delete $self->{'state'}->{'measurementType'};
        #print STDERR "popping handler from the stack\n";
        pop @{$self->{'starthandler_stack'}};
        pop @{$self->{'endhandler_stack'}};
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget.counter'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        my $text = $self->getElementText();
        my $localname = $self->{'state'}->{'countername'};
        #print STDERR "Handling an endcounter with $localname\n";
        if ($localname eq $self->{'state'}->{'measurementType'}) {
        	#print STDERR "Investigatng: $e->{'LocalName'}  vs $self->{'state'}->{'measurementType'}\n";
          #print STDERR "Element = measurementType, discarding\n";
        }
        else {
          #print STDERR "Processing a measid $localname\n";
          my ($measid,$dummy,$pos) = ($localname =~ /^M(\d+)(\D)(\d*)/);
          my $measkey = $self->{'state'}->{'measurementType'}."_".$measid;
          $self->{'state'}->{'measkey_id'} = $self->{'lookup'}->{'db_lookup_measkey'}->{$measkey} ;
          #print STDERR "Registered measkey $measkey\n";
          $self->{'state'}->{'measid_id'} = $self->{'lookup'}->{'db_lookup_measid'}->{$measid} ;
          $self->{'state'}->{'pmttarget_id'} = $self->{'lookup'}->{'db_lookup_targetkey'}->{$localname} ;
	  $self->{'state'}->{'pmttarget'}=$text;
	my $ic = $self->{'initialcontext'};
	my $file_ts = $ic->expand('{{WORKLIST/ITEM|regExtract .*_.*_(\d{14})|parseDateTime %Y%m%d%H%M%S|formatDateTime %Y%m%d%H%M%S}}');
	my $file_seq = $ic->expand('{{WORKLIST/ITEM|regExtract .*_(\d+)\.xml.*}}');
        #print STDERR "sarwesh=$file_ts and  $file_seq\n";
          #my $ic = $self->{'initialcontext'};
	  #my $file_ts = $ic->expand('{{WORKLIST/ITEM|regExtract .*_(MSC|CDS)_(\d{14})|parseDateTime %Y%m%d%H%M%S}}');
	  #print STDERR "filetimestamp is :: $file_ts \n";
          #print STDERR "end of handling another element ",$e->{'LocalName'}," with text $text and $measkey\n"; 
          my $outline;
	 my $kpi;
	 #print STDERR "sarwesh=$self->{'ref_file'}->{$measkey} : $measkey\n";
          if(defined $self->{'ref_file'}->{$measkey}){
		$kpi="KPI";	
		
	  }
	 else{
		$kpi="NONKPI";
	}
          $outline = [
			$kpi,
			$self->{'state'}->{'measkey_id'},
                         "\"".$self->{'state'}->{'dn_id'}."\"",
                         $self->{'state'}->{'measid_id'},
                         $self->{'state'}->{'measurementType_id'},
                         $self->{'state'}->{'startTime'},
                         #$self->{'state'}->{'startTime'},
                         $self->{'state'}->{'interval'},
                         $self->{'state'}->{'pmttarget'},
                         $self->{'state'}->{'pmttarget_id'},
			$file_ts,
			$file_seq];
	  push(@{$self->{'out_data'}},$outline);
          $self->{'record_count'} = $self->{'record_count'} + 1;
         # if (defined $self->{'io_out'}) {
         # 	my $soutline = join(',',@$outline);
         # 	my $of = $self->{'io_out'};
         # 	#print $of "$soutline\n";
         # }
         # if (defined $self->{'writer'}) {
         #   $self->{'writer'}->($outline);
         # }
        }
      } ,$o
    )
  };
  $o->{'currentelementhandler'} = undef;
  $o->{'texthandler'} = undef;

  bless $o;
  #print STDERR "END OF CONSTRUCTOR IN SAXHANDLER\n";
  return $o;
}

sub getProcessStatistics {
  my $self = shift;
  #print "Doing ProcessStatistics\n";
  my $td = $self->{'process_end'} - $self->{'process_start'};
  my $rate = $self->{'record_count'} / $td; 
  my $s = {
    start_time=>$self->{'process_start'},
    end_time=>$self->{'process_end'},
    record_count=>$self->{'record_count'},
    error_count=>$self->{'error_count'},
    parse_rate=>$rate
  };
  #print "Done ProcessStatistics\n";
  return $s;
}

sub initialize {
  my $self = shift;

  #print STDERR "Doing initialize in SaxHandler\n";
  #print STDERR "And the lookups are: ",Dumper($self->{'lookup'}),"\n";
  $self->{'currentelement'} = [];
  $self->{'path'} = '';
  $self->{'currenttext'} = undef;
  $self->{'texttargets'} = {};
  $self->{'currenttexttarget'} = [];
  $self->{'state'} = {};
	$self->{'io_out'} = undef; #$params{'out'};
  $self->{'writer'} = undef; #$params{'writer'};
  $self->{'record_count'} = 0;
  $self->{'process_start'} = undef;
  $self->{'process_end'} = undef;

  $self->{'ref_file'}={};

        my $ref_file="/opt/PMT/pmtsys/lib/pmt/AppModules/Ref_Data/KPI_MSS_PM.txt";
        open READ, "<$ref_file" or die "Cannot Open Ref File $ref_file";
        my $measkey;
        while($measkey=<READ>){
		chomp $measkey;
                $self->{'ref_file'}->{$measkey}="Y";
        }
        close READ;

  use Data::Dumper;
  $self->{'out_data'}=[];
  #print STDERR "And the lookups are: ",Dumper($self->{'lookup'}),"\n";
}

sub getDataSummary {
  return {};
}

sub setIOSpec {
  my $self = shift;
  my %params = @_;
  if ($params{'out'} and not $params{'writer'}) {
    $self->{'writer'} = partial(
      sub { my $self = shift; my $ofile = shift; my $r = shift; my $line=join($self->{'field_separator'},@$r); print $ofile "$line\n"; },
      $self,$params{'out'}
    );
    $self->{'io_out'} = undef;
  }
  elsif ($params{'writer'}) {
    $self->{'writer'} = $params{'writer'};
  }
}
sub write_record {
  my $self = shift;
  my $io = $self->{'io_out'};
  my %args = @_;
  my $line = $args{'line'};
  #print STDERR "line: $line";
  print $io $line;
}

sub start_document {
  my ($self,$doc) = @_;
  $self->{'process_start'} = time();
}

sub end_document {
  my ($self,$doc) = @_;
  #$self->{'io_out'}->close();
  $self->{'process_end'} = time();
  #my $interval = $self->{'process_end'} - $self->{'process_start'};
  #my $processrate = $self->{'record_count'} / $interval;
  #my $rcount = $self->{'record_count'};
  #my $ic = $self->{'initialcontext'};
  #$ic->log(message=>sprintf("Processing rate: $rcount records in %.3f seconds,%.3f records/second",$interval,$processrate),domain=>"system",level=>"info");
  if (defined $self->{'writer'}){
  	foreach my $outline (@{$self->{'out_data'}}){
	            $self->{'writer'}->($outline);
        }
  }
}

sub getElementStartHandler {
  my $self = shift;
  my $path = $self->{'path'};
  #print STDERR "searching for handler for $path\n";
  if( not defined $self->{'elementstarthandlers'}->{$path} and scalar @{$self->{'starthandler_stack'}}) {
    return $self->{'starthandler_stack'}->[-1];
  }
  elsif (defined $self->{'elementstarthandlers'}->{$self->{'path'}}) {
    return $self->{'elementstarthandlers'}->{$self->{'path'}};
  }
  return partial(sub { print STDERR "dummy start function for $path\n"; });

  #for my $k (keys %{$self->{'elementstarthandlers'}}) {
    #print STDERR "checking $k\n";
  #  if ($path =~ m/^${k}$/) {
  #    return $self->{'elementstarthandlers'}->{$k};
  #  }
  #}
  #return partial(sub { print STDERR "dummy start function for $path\n"; });
}

sub getElementEndHandler {
  my $self = shift;
  my $path = $self->{'path'};
  #print STDERR "searching for handler for $path\n";
  #print "Looking for elementendhandler for $path\n";
  if( not defined $self->{'elementendhandlers'}->{$path} and scalar @{$self->{'endhandler_stack'}}) {
    return $self->{'endhandler_stack'}->[-1];
  }
  elsif (defined $self->{'elementendhandlers'}->{$path}) {
    return $self->{'elementendhandlers'}->{$path};
  }
  return partial(sub { print STDERR "dummy end function for $path\n"; });
  #for my $k (keys %{$self->{'elementendhandlers'}}) {
    #print STDERR "checking $k\n";
  #  if ($path =~ m/^${k}$/) {
  #    return $self->{'elementendhandlers'}->{$k};
  #  }
  #}
  #return partial(sub { print STDERR "dummy end function for $path\n"; });
}

sub getCharacterHandler {
}

sub start_element {
  my ($self,$el) = @_;
  my $locname = $el->{'LocalName'};
  if (scalar @{$self->{'currentelement'}} == 0) {
    #print STDERR "Starting document with element $locname\n";
  }
  push @{$self->{'currentelement'}},$locname;
  $self->{'path'} = join ('.',@{$self->{'currentelement'}});
  #print STDERR "Starting element ",$el->{'LocalName'},"\n";

  push @{$self->{'currenttexttarget'}},{'r'=>0,'text'=>undef};
  my $elhandler = $self->getElementStartHandler();
  $elhandler->($el);
}

sub end_element {
  my ($self,$el) = @_;

  use Data::Dumper;
  eval {
    my $elhandler = $self->getElementEndHandler();
    $elhandler->($el);
  };
  if ($@) {
    print STDERR "In SaxHandler end_elemenet: An error has occurred",Dumper($@),"\n";
  }

  #print STDERR "popping from texttargets for ",$self->{'path'},"\n";
  my $tt = pop @{$self->{'currenttexttarget'}};
  pop @{$self->{'currentelement'}};
  $self->{'path'} = join ('.',@{$self->{'currentelement'}});
  #print STDERR "Starting element ",$el->{'LocalName'},"\n";
  #print STDERR "Ending element\n";
}

sub setElementText {
  my ($self,$characters) = @_;
}

sub getElementText {
  my $self = shift;
  #print STDERR "retrieving element text for ",$self->{'path'},"\n";
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];
  #print STDERR $currenttexttarget,"\n";
  return $currenttexttarget->{'text'};
}

sub characters {
  my ($self,$characters) = @_;
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];
 
  if ($currenttexttarget->{'r'} == 1) {
  #print STDERR "characters called with $characters->{'Data'}\n";
  if (not defined $currenttexttarget->{'text'}) { $currenttexttarget->{'text'} = ''; }
  	$currenttexttarget->{'text'} = $currenttexttarget->{'text'} . $characters->{'Data'};
  }
 #print STDERR "Get Characters: $characters->{'Data'} \n";
}

sub comment {
  my ($self,$comment) = @_;
  #print STDERR "Doing Comment\n";
}

sub processing_instruction {
  my ($self,$pi) = @_;
  #print STDERR "Doing $pi\n";
}




1;

