package AppModules::SaxHandler_TGOFLEXI_PM;

use strict;
use Carp;

use base qw(XML::SAX::Base);
use PMTUtilities qw(partial);
use Time::HiRes qw(time);

  my $PMSetup_C=1;
  my $PMMOResult_C=1;
  my $PMTarget_C=1;

sub new {
  my $class = shift;
  my %params = @_;
  my $o = {};
  $o->{'initialcontext'} = $params{'initialcontext'};
  $o->{'xnode'} = $params{'xnode'};
  my $ic = $params{'initialcontext'};
  $o->{'currentelement'} = [];
  $o->{'path'} = '';
  $o->{'currenttext'} = undef;
  $o->{'texttargets'} = {};
  $o->{'currenttexttarget'} = [];
  $o->{'state'} = {};
	$o->{'io_out'} = undef; #$params{'out'};
  $o->{'writer'} = undef; #$params{'writer'};
  $o->{'record_count'} = 0;
  $o->{'error_count'} = 0;
  $o->{'process_start'} = undef;
  $o->{'process_end'} = undef;
  $o->{'field_separator'} = ',';
  $o->{'xnode'} = $params{'xnode'};
  

  if ($params{'out'} and not $params{'writer'}) {
    $o->{'writer'} = partial(
      sub { my $self = shift; my $ofile = shift; my $r = shift; my $line=join($self->{'field_separator'},@$r); print $ofile "$line\n"; },
      $o,$params{'out'}
    );
    $o->{'io_out'} = undef;
  }
  elsif ($params{'writer'}) {
    $o->{'writer'} = $params{'writer'};
  }

  
  $o->{'lookup'} = { db_lookup_tgoflexi_dn=>{},
                     db_lookup_tgoflexi_measid=>{},
                     db_lookup_tgoflexi_measkey=>{},
                     db_lookup_tgoflexi_meastype=>{},
                     db_lookup_tgoflexi_targetkey=>{}
                   };

  for my $resource_name (keys %{$o->{'lookup'}}) {
    print STDERR "In SaxHandler: Trying to get resource $resource_name\n";
      my $r = $ic->getResource(name=>$resource_name);
      print STDERR "In SaxHandler: I got the resource $resource_name\n";
      $o->{'lookup'}->{$resource_name} = $r;
  }
  print STDERR "CREATED THE RESOURCES IN SAXHANDLER\n";
  $o->{'elementstarthandlers'} = {
    'OMeS.PMSetup'=>partial(
      sub { 
        my $self = shift; my $e = shift; 
        my $attributes = $e->{'Attributes'};
        $self->{'state'}->{'startTime'} = $attributes->{'{}startTime'}->{'Value'};
        $self->{'state'}->{'interval'} = $attributes->{'{}interval'}->{'Value'};
	
	#storing in hash
	$self->{store}->{PMSetup}->{$PMSetup_C}->{startTime}=$self->{'state'}->{'startTime'};
	$self->{store}->{PMSetup}->{$PMSetup_C}->{interval}=$self->{'state'}->{'interval'};
      } , $o
    ),
    'OMeS.PMSetup.PMMOResult'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
	undef $self->{'state'}->{'dn'};
	$self->{store}->{PMSetup}->{$PMSetup_C}->{PMMOResult}->{$PMMOResult_C}={};
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.MO'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.MO.DN'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        $self->{'currenttexttarget'}->[-1]->{'r'} = 1;
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget'=> partial(
      sub {
        my $self = shift; my $e = shift; 
        my $attributes = $e->{'Attributes'};
        my $meastype = $attributes->{'{}measurementType'}->{'Value'};
        $self->{'state'}->{'measurementType'} = $meastype;
	$self->{store}->{PMSetup}->{$PMSetup_C}->{PMMOResult}->{$PMMOResult_C}->{PMTarget}->{$PMTarget_C}->{measurementType}=$meastype;
        #$self->{'state'}->{'measurementType_id'} = $self->{'lookup'}->{'db_lookup_tgoflexi_meastype'}->{$meastype} ;
        #$self->{'state'}->{'dn_id'} = $self->{'lookup'}->{'db_lookup_tgoflexi_dn'}->{$self->{'state'}->{'dn'}} ;
	undef $self->{'state'}->{'measkey_id'};
	undef $self->{'state'}->{'measid_id'};
      }, $o
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget..*'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        $self->{'currenttexttarget'}->[-1]->{'r'} = 1;
      } ,$o
    )
  };
  $o->{'elementendhandlers'} = {
    'OMeS.PMSetup'=>partial(
      sub { 
        my $self = shift; my $e = shift; 
        delete $self->{'state'}->{'startTime'};
        delete $self->{'state'}->{'interval'};
	$PMSetup_C++;
	$PMMOResult_C=1;
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        undef $self->{'state'}->{'dn'};
	$PMMOResult_C++;
	$PMTarget_C=1;
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.MO'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.MO.DN'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        my $dn = $self->getElementText();
        #$self->{'state'}->{'dn'} = $dn;
        if(defined $self->{'state'}->{'dn'}){
                (my $dnn)=($dn =~ /^PLMN-PLMN(.*)/);
                $self->{'state'}->{'dn'}.=$dnn;
        }
        else{
                $self->{'state'}->{'dn'} = $dn;
        }
		$self->{store}->{PMSetup}->{$PMSetup_C}->{PMMOResult}->{$PMMOResult_C}->{DN}=$self->{'state'}->{'dn'};	
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget'=> partial(
      sub {
        my $self = shift; my $e = shift; 
	$PMTarget_C++;
	#print "increasing PMT TARGET $PMTarget_C\n";
        delete $self->{'state'}->{'measurementType'};
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget..*'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        my $text = $self->getElementText();
        my $localname = $e->{'LocalName'};
	return if ($localname !~ /^M/i);
	$self->{store}->{PMSetup}->{$PMSetup_C}->{PMMOResult}->{$PMMOResult_C}->{PMTarget}->{$PMTarget_C}->{$localname}=$text;	
        #my ($measid,$dummy,$pos) = ($localname =~ /^M(\d+)(\D)(\d*)/i);
        #my $measkey = $self->{'state'}->{'measurementType'}."_".$measid;
        #$self->{'skip_PMTTarget'}=1;
	#my $skip_counter=0;
        #if ( $self->{'enable_ref_file_check'} =~ /Y/i){
	#	print STDERR "Sarwesh enable_file_check is ON";
        #        if ( defined $self->{'meta'}->{'measurement_type'}->{$measkey} ){
	#		print STDERR "$measkey is defined ";
        #                $self->{'skip_PMTTarget'}=0;
	#		print STDERR "$localname check";
	#		if(not defined $self->{'meta'}->{'measurement_type'}->{$measkey}->{'cnt'}->{$localname}){
	#			print STDERR "Sarwesh $localname is not defined";
	#			$skip_counter=1;
	#		}
        #        }	
        #        elsif ( defined $self->{'meta'}->{'cnt_number'} and $self->{'meta'}->{'measurement_type'}->{'name'} =~ /$measkey/i) {
        #                $self->{'skip_PMTTarget'}=0;
	#		 if(not defined $self->{'meta'}->{'cnt'}->{$localname}){
	#			$skip_counter=1;
	#		}
        #        }
        #}
        #else {
        #        $self->{'skip_PMTTarget'}=0;
	#	$skip_counter=0;
        #}
        #$self->{'state'}->{'measkey_id'} = $self->{'lookup'}->{'db_lookup_tgoflexi_measkey'}->{$measkey} if ( not defined $self->{'state'}->{'measkey_id'} );
        #$self->{'state'}->{'measid_id'} = $self->{'lookup'}->{'db_lookup_tgoflexi_measid'}->{$measid} if ( not defined $self->{'state'}->{'measid_id'} );
        #$self->{'state'}->{'pmttarget_id'} = $self->{'lookup'}->{'db_lookup_tgoflexi_targetkey'}->{$localname} ;
	#$self->{'state'}->{'pmttarget'}=$text;
	#if($self->{'skip_PMTTarget'} == 0 and $skip_counter == 0){	
        #	my $ic = $self->{'initialcontext'};
        #	my $file_ts = $ic->expand('{{WORKLIST/ITEM|regExtract .*_.*_(\d{14})|parseDateTime %Y%m%d%H%M%S|formatDateTime %Y%m%d%H%M%S}}');
       	#	 my $file_seq = $ic->expand('{{WORKLIST/ITEM|regExtract .*_(\d+)\.xml.*}}');
        #  	my $outline = [$self->{'state'}->{'measkey_id'},
        #                 $self->{'state'}->{'dn_id'},
        #                 $self->{'state'}->{'measid_id'},
        #                 $self->{'state'}->{'measurementType_id'},
        #                 $self->{'state'}->{'startTime'},
        #                 $self->{'state'}->{'interval'},
        #                 $self->{'state'}->{'pmttarget'},
        #                 $self->{'state'}->{'pmttarget_id'},$file_ts,$file_seq];
        # 	$self->{'record_count'} = $self->{'record_count'} + 1;
        # 	if (defined $self->{'io_out'}) {
        # 		my $soutline = join(',',@$outline);
        #  		my $of = $self->{'io_out'};
        #  		print $of "$soutline\n";
        # 	}
        # 	if (defined $self->{'writer'}) {
        #   	 $self->{'writer'}->($outline);
        # 	}
	#}
      } ,$o
    )
  };
  $o->{'currentelementhandler'} = undef;
  $o->{'texthandler'} = undef;

  bless $o;
  print STDERR "END OF CONSTRUCTOR IN SAXHANDLER\n";
  return $o;
}

sub getProcessStatistics {
  my $self = shift;
  print "Doing ProcessStatistics\n";
  my $td = $self->{'process_end'} - $self->{'process_start'};
  my $rate = $self->{'record_count'} / $td; 
  my $s = {
    start_time=>$self->{'process_start'},
    end_time=>$self->{'process_end'},
    record_count=>$self->{'record_count'},
    error_count=>$self->{'error_count'},
    parse_rate=>$rate
  };
  print "Done ProcessStatistics\n";
  return $s;
}

sub initialize {
  my $self = shift;

  print STDERR "Doing initialize in SaxHandler\n";
  $self->{'currentelement'} = [];
  $self->{'path'} = '';
  $self->{'currenttext'} = undef;
  $self->{'texttargets'} = {};
  $self->{'currenttexttarget'} = [];
  $self->{'state'} = {};
  $self->{'io_out'} = undef; #$params{'out'};
  $self->{'writer'} = undef; #$params{'writer'};
  $self->{'record_count'} = 0;
  $self->{'process_start'} = undef;
  $self->{'process_end'} = undef;
  use Data::Dumper;
  undef $self->{'meta'};
  my $ic = $self->{'initialcontext'};
  $self->{'enable_ref_file_check'}=$ic->expand('{{CONFIG/parameters/{{SYSTEM/RUN/FLOWCD}}.enable_ref_file_check}}');
  if ( $self->{'enable_ref_file_check'} =~ /Y/i){
  	$self->{'ref_file'}=$ic->expand('{{CONFIG/parameters/{{SYSTEM/RUN/FLOWCD}}.ref_file}}');
	$self->{'meta'}=convertFsubsetToHash($self->{'ref_file'});
  }
  $self->{'store'}->{'id'}={};
  $self->{'store'}->{'PMSetup'}={};
  $PMSetup_C=1;
  $PMMOResult_C=1;
  $PMTarget_C=1;
  #use Data::Dumper;
  #print STDERR Dumper $self->{'meta'};
}

sub getDataSummary {
  return {};
}

sub setIOSpec {
  my $self = shift;
  my %params = @_;
  if ($params{'out'} and not $params{'writer'}) {
    $self->{'writer'} = partial(
      sub { my $self = shift; my $ofile = shift; my $r = shift; my $line=join($self->{'field_separator'},@$r); print $ofile "$line\n"; },
      $self,$params{'out'}
    );
    $self->{'io_out'} = undef;
  }
  elsif ($params{'writer'}) {
    $self->{'writer'} = $params{'writer'};
  }
}
sub write_record {
  my $self = shift;
  my $io = $self->{'io_out'};
  my %args = @_;
  my $line = $args{'line'};
  #print STDERR "line: $line";
  print $io $line;
}

sub start_document {
  my ($self,$doc) = @_;
  $self->{'process_start'} = time();
}

sub end_document {
  my ($self,$doc) = @_;
  #$self->{'io_out'}->close();
  $self->{'process_end'} = time();
  my $ic = $self->{'initialcontext'};
  my $file_ts = $ic->expand('{{WORKLIST/ITEM|regExtract .*_.*_(\d{14})|parseDateTime %Y%m%d%H%M%S|formatDateTime %Y%m%d%H%M%S}}');  
  my $file_seq = $ic->expand('{{WORKLIST/ITEM|regExtract .*_(\d+)\.xml.*}}');
  #print Dumper $self->{store};
  #all Data loaded into hash now ---processing begin-----
  foreach my $pmsetup (keys $self->{store}->{PMSetup}){
	my $starttime=$self->{store}->{PMSetup}->{$pmsetup}->{startTime};
	my $interval=$self->{store}->{PMSetup}->{$pmsetup}->{interval};
	foreach my $pmmoresult (keys $self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}){
		my $dn_id;
		my $measType_id;
		my $measid_id;
		my $measType;
		my $measKey;
		my $measKey_id;
		my $measid;
		my $dummy;
		my $pos;
		my $localname_v={};
		if(defined $self->{store}->{id}->{DN}->{$self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{DN}}){
		 	$dn_id=$self->{store}->{id}->{DN}->{$self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{DN}};
		}
		else {
			$dn_id=$self->{'lookup'}->{'db_lookup_tgoflexi_dn'}->{$self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{DN}};
			$self->{store}->{id}->{DN}->{$self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{DN}}=$dn_id;
		}
		foreach my $pmtarget (keys $self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{PMTarget}){
			my $flag=0;
			foreach my $localname (keys $self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{PMTarget}->{$pmtarget}){
				if($localname eq 'measurementType'){
					$measType=$self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{PMTarget}->{$pmtarget}->{$localname};
					if(defined $self->{store}->{id}->{measurementType}->{$measType}){
						$measType_id=$self->{store}->{id}->{measurementType}->{$measType};
					}
					else {
						$measType_id=$self->{'lookup'}->{'db_lookup_tgoflexi_meastype'}->{$measType};
						$self->{store}->{id}->{measurementType}->{$measType}=$measType_id;
					}
				}
				else {
					if ( $flag == 0 ){
						($measid,$dummy,$pos) = ( $localname =~ /^M(\d+)(\D)(\d*)/i);
						if(defined $self->{store}->{id}->{measid}->{$measid}){
							$measid_id=$self->{store}->{id}->{measid}->{$measid};
						}
						else {
							$measid_id=$self->{'lookup'}->{'db_lookup_tgoflexi_measid'}->{$measid};
							$self->{store}->{id}->{measid}->{$measid}=$measid_id;
						}
						$flag= 1;
					}
					if ( defined $self->{store}->{id}->{localname}->{$localname}){
						$localname_v->{$localname}->{id}=$self->{store}->{id}->{localname}->{$localname};	
					}
					else {
						$localname_v->{$localname}->{id}=$self->{'lookup'}->{'db_lookup_tgoflexi_targetkey'}->{$localname} ;
						$self->{store}->{id}->{localname}->{$localname}=$localname_v->{$localname}->{id};
					}
					$localname_v->{$localname}->{value}=$self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{PMTarget}->{$pmtarget}->{$localname};	
				}
			}
			$measKey=$measType.'_'.$measid;
			if ( defined $self->{store}->{id}->{measkey}->{$measKey} ){
				$measKey_id=$self->{store}->{id}->{measkey}->{$measKey} ;
			}
			else {
				$measKey_id=$self->{'lookup'}->{'db_lookup_tgoflexi_measkey'}->{$measKey};
				$self->{store}->{id}->{measkey}->{$measKey}=$measKey_id;
			}
			my @arr_tmp=();
			my $counter=0;
			foreach my $ln (keys $localname_v){
				$arr_tmp[$counter]=[$measKey_id,$dn_id,$measid_id,$measType_id,$starttime,$interval,$localname_v->{$ln}->{value},$localname_v->{$ln}->{id},$file_ts,$file_seq];
                		if (defined $self->{'writer'}) {
                 			$self->{'writer'}->($arr_tmp[$counter]);
                		}
				$counter++;
			}	
		}
	}
  }
  #print "Sarwesh\n";
  #print Dumper  $self->{'store'}->{'id'},'\n';
  #my $interval = $self->{'process_end'} - $self->{'process_start'};
  #my $processrate = $self->{'record_count'} / $interval;
  #my $rcount = $self->{'record_count'};
  #my $ic = $self->{'initialcontext'};
  #$ic->log(message=>sprintf("Processing rate: $rcount records in %.3f seconds,%.3f records/second",$interval,$processrate),domain=>"system",level=>"info");
}

sub getElementStartHandler {
  my $self = shift;
  my $path = $self->{'path'};
  #print STDERR $path," START\n";return $self->{'elementstarthandlers'}->{'OMeS.PMSetup'};
  if ( defined $self->{'elementstarthandlers'}->{$path}) {return $self->{'elementstarthandlers'}->{$path};}
  if( $path =~ m/OMeS\.PMSetup\.PMMOResult\.PMTarget\..*/i) { return $self->{'elementstarthandlers'}->{'OMeS.PMSetup.PMMOResult.PMTarget..*'}; }
  #print STDERR "searching for handler for $path\n";
  #for my $k (keys %{$self->{'elementstarthandlers'}}) {
  #  #print STDERR "checking $k\n";
  #  if ($path =~ m/^${k}$/) {
  #    return $self->{'elementstarthandlers'}->{$k};
  #  }
  #}
  return partial(sub { print STDERR "dummy start function for $path\n"; });
}

sub getElementEndHandler {
  my $self = shift;
  my $path = $self->{'path'};
  #print STDERR $path," END\n";return $self->{'elementstarthandlers'}->{'OMeS.PMSetup'};
  #print STDERR "searching for handler for $path\n";
  if ( defined $self->{'elementendhandlers'}->{$path}) {return $self->{'elementendhandlers'}->{$path};}
  if( $path =~ m/OMeS\.PMSetup\.PMMOResult\.PMTarget\..*/i) { return $self->{'elementendhandlers'}->{'OMeS.PMSetup.PMMOResult.PMTarget..*'}; }
  #for my $k (keys %{$self->{'elementendhandlers'}}) {
  #  #print STDERR "checking $k\n";
  #  if ($path =~ m/^${k}$/) {
  #    return $self->{'elementendhandlers'}->{$k};
  #  }
  #}
  return partial(sub { print STDERR "dummy end function for $path\n"; });
}

sub getCharacterHandler {
}

sub start_element {
  my ($self,$el) = @_;
  my $locname = $el->{'LocalName'};
  if (scalar @{$self->{'currentelement'}} == 0) {
    #print STDERR "Starting document with element $locname\n";
  }
  push @{$self->{'currentelement'}},$locname;
  $self->{'path'} = join ('.',@{$self->{'currentelement'}});
  #print STDERR "Starting element ",$el->{'LocalName'},"\n";

  push @{$self->{'currenttexttarget'}},{'r'=>0,'text'=>undef};
  my $elhandler = $self->getElementStartHandler();
  $elhandler->($el);
}

sub end_element {
  my ($self,$el) = @_;

  use Data::Dumper;
  eval {
    my $elhandler = $self->getElementEndHandler();
    $elhandler->($el);
  };
  if ($@) {
    print STDERR "In SaxHandler end_elemenet: An error has occurred",Dumper($@),"\n";
  }

  #print STDERR "popping from texttargets for ",$self->{'path'},"\n";
  my $tt = pop @{$self->{'currenttexttarget'}};
  pop @{$self->{'currentelement'}};
  $self->{'path'} = join ('.',@{$self->{'currentelement'}});
  #print STDERR "Starting element ",$el->{'LocalName'},"\n";
  #print STDERR "Ending element\n";
}

sub setElementText {
  my ($self,$characters) = @_;
}

sub getElementText {
  my $self = shift;
  #print STDERR "retrieving element text for ",$self->{'path'},"\n";
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];
  #print STDERR $currenttexttarget,"\n";
  return $currenttexttarget->{'text'};
}

sub characters {
  my ($self,$characters) = @_;
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];
 
  if ($currenttexttarget->{'r'} == 1) {
  #print STDERR "characters called with $characters->{'Data'}\n";
  if (not defined $currenttexttarget->{'text'}) { $currenttexttarget->{'text'} = ''; }
  	$currenttexttarget->{'text'} = $currenttexttarget->{'text'} . $characters->{'Data'};
  }
 #print STDERR "Get Characters: $characters->{'Data'} \n";
}

sub comment {
  my ($self,$comment) = @_;
  #print STDERR "Doing Comment\n";
}

sub processing_instruction {
  my ($self,$pi) = @_;
  #print STDERR "Doing $pi\n";
}

sub convertFsubsetToHash{
        my $fname=shift;
        my $xml = new XML::Simple(KeepRoot=>1);
        my $hash=$xml->XMLin($fname);
        return $hash->{'ref_data'};
}


1;

