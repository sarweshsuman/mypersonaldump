package AppModules::SaxHandler_TGOFLEXI_PM2;

use strict;
use Carp;

use base qw(XML::SAX::Base);
use PMTUtilities qw(partial);
use Time::HiRes qw(time);

  my $PMSetup_C=1;
  my $PMMOResult_C=1;
  my $PMTarget_C=1;

sub new {
  my $class = shift;
  my %params = @_;
  my $o = {};
  $o->{'initialcontext'} = $params{'initialcontext'};
  $o->{'xnode'} = $params{'xnode'};
  my $ic = $params{'initialcontext'};
  $o->{'currentelement'} = [];
  $o->{'path'} = '';
  $o->{'currenttext'} = undef;
  $o->{'texttargets'} = {};
  $o->{'currenttexttarget'} = [];
  $o->{'state'} = {};
	$o->{'io_out'} = undef; #$params{'out'};
  $o->{'writer'} = undef; #$params{'writer'};
  $o->{'record_count'} = 0;
  $o->{'error_count'} = 0;
  $o->{'process_start'} = undef;
  $o->{'process_end'} = undef;
  $o->{'field_separator'} = ',';
  $o->{'xnode'} = $params{'xnode'};
  

  if ($params{'out'} and not $params{'writer'}) {
    $o->{'writer'} = partial(
      sub { my $self = shift; my $ofile = shift; my $r = shift; my $line=join($self->{'field_separator'},@$r); print $ofile "$line\n"; },
      $o,$params{'out'}
    );
    $o->{'io_out'} = undef;
  }
  elsif ($params{'writer'}) {
    $o->{'writer'} = $params{'writer'};
  }

  
  $o->{'lookup'} = { db_lookup_tgoflexi_dn=>{},
                     db_lookup_tgoflexi_measid=>{},
                     db_lookup_tgoflexi_measkey=>{},
                     db_lookup_tgoflexi_meastype=>{},
                     db_lookup_tgoflexi_targetkey=>{}
                   };

  for my $resource_name (keys %{$o->{'lookup'}}) {
    print STDERR "In SaxHandler: Trying to get resource $resource_name\n";
      my $r = $ic->getResource(name=>$resource_name);
      print STDERR "In SaxHandler: I got the resource $resource_name\n";
      $o->{'lookup'}->{$resource_name} = $r;
  }
  print STDERR "CREATED THE RESOURCES IN SAXHANDLER\n";
  $o->{'elementstarthandlers'} = {
    'OMeS.PMSetup'=>partial(
      sub { 
        my $self = shift; my $e = shift; 
        my $attributes = $e->{'Attributes'};
        $self->{'state'}->{'startTime'} = $attributes->{'{}startTime'}->{'Value'};
        $self->{'state'}->{'interval'} = $attributes->{'{}interval'}->{'Value'};
	
	#storing in hash
	$self->{store}->{PMSetup}->{$PMSetup_C}->{startTime}=$self->{'state'}->{'startTime'};
	$self->{store}->{PMSetup}->{$PMSetup_C}->{interval}=$self->{'state'}->{'interval'};
      } , $o
    ),
    'OMeS.PMSetup.PMMOResult'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
	undef $self->{'state'}->{'dn'};
	$self->{store}->{PMSetup}->{$PMSetup_C}->{PMMOResult}->{$PMMOResult_C}={};
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.MO'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.MO.DN'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        $self->{'currenttexttarget'}->[-1]->{'r'} = 1;
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget'=> partial(
      sub {
        my $self = shift; my $e = shift; 
        my $attributes = $e->{'Attributes'};
        my $meastype = $attributes->{'{}measurementType'}->{'Value'};
        $self->{'state'}->{'measurementType'} = $meastype;
	$self->{store}->{PMSetup}->{$PMSetup_C}->{PMMOResult}->{$PMMOResult_C}->{PMTarget}->{$PMTarget_C}->{measurementType}=$meastype;
        #$self->{'state'}->{'measurementType_id'} = $self->{'lookup'}->{'db_lookup_tgoflexi_meastype'}->{$meastype} ;
        #$self->{'state'}->{'dn_id'} = $self->{'lookup'}->{'db_lookup_tgoflexi_dn'}->{$self->{'state'}->{'dn'}} ;
	undef $self->{'state'}->{'measkey_id'};
	undef $self->{'state'}->{'measid_id'};
      }, $o
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget..*'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        $self->{'currenttexttarget'}->[-1]->{'r'} = 1;
      } ,$o
    )
  };
  $o->{'elementendhandlers'} = {
    'OMeS.PMSetup'=>partial(
      sub { 
        my $self = shift; my $e = shift; 
        delete $self->{'state'}->{'startTime'};
        delete $self->{'state'}->{'interval'};
	$PMSetup_C++;
	$PMMOResult_C=1;
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        undef $self->{'state'}->{'dn'};
	$PMMOResult_C++;
	$PMTarget_C=1;
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.MO'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.MO.DN'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        my $dn = $self->getElementText();
        #$self->{'state'}->{'dn'} = $dn;
        if(defined $self->{'state'}->{'dn'}){
                (my $dnn)=($dn =~ /^PLMN-PLMN(.*)/);
                $self->{'state'}->{'dn'}.=$dnn;
        }
        else{
                $self->{'state'}->{'dn'} = $dn;
        }
		$self->{store}->{PMSetup}->{$PMSetup_C}->{PMMOResult}->{$PMMOResult_C}->{DN}=$self->{'state'}->{'dn'};	
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget'=> partial(
      sub {
        my $self = shift; my $e = shift; 
	$PMTarget_C++;
	#print "increasing PMT TARGET $PMTarget_C\n";
        delete $self->{'state'}->{'measurementType'};
      } ,$o
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget..*'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        my $text = $self->getElementText();
        my $localname = $e->{'LocalName'};
	return if ($localname !~ /^M/i);
	$self->{store}->{PMSetup}->{$PMSetup_C}->{PMMOResult}->{$PMMOResult_C}->{PMTarget}->{$PMTarget_C}->{$localname}=$text;	
        #my ($measid,$dummy,$pos) = ($localname =~ /^M(\d+)(\D)(\d*)/i);
        #my $measkey = $self->{'state'}->{'measurementType'}."_".$measid;
        #$self->{'skip_PMTTarget'}=1;
	#my $skip_counter=0;
        #if ( $self->{'enable_ref_file_check'} =~ /Y/i){
	#	print STDERR "Sarwesh enable_file_check is ON";
        #        if ( defined $self->{'meta'}->{'measurement_type'}->{$measkey} ){
	#		print STDERR "$measkey is defined ";
        #                $self->{'skip_PMTTarget'}=0;
	#		print STDERR "$localname check";
	#		if(not defined $self->{'meta'}->{'measurement_type'}->{$measkey}->{'cnt'}->{$localname}){
	#			print STDERR "Sarwesh $localname is not defined";
	#			$skip_counter=1;
	#		}
        #        }	
        #        elsif ( defined $self->{'meta'}->{'cnt_number'} and $self->{'meta'}->{'measurement_type'}->{'name'} =~ /$measkey/i) {
        #                $self->{'skip_PMTTarget'}=0;
	#		 if(not defined $self->{'meta'}->{'cnt'}->{$localname}){
	#			$skip_counter=1;
	#		}
        #        }
        #}
        #else {
        #        $self->{'skip_PMTTarget'}=0;
	#	$skip_counter=0;
        #}
        #$self->{'state'}->{'measkey_id'} = $self->{'lookup'}->{'db_lookup_tgoflexi_measkey'}->{$measkey} if ( not defined $self->{'state'}->{'measkey_id'} );
        #$self->{'state'}->{'measid_id'} = $self->{'lookup'}->{'db_lookup_tgoflexi_measid'}->{$measid} if ( not defined $self->{'state'}->{'measid_id'} );
        #$self->{'state'}->{'pmttarget_id'} = $self->{'lookup'}->{'db_lookup_tgoflexi_targetkey'}->{$localname} ;
	#$self->{'state'}->{'pmttarget'}=$text;
	#if($self->{'skip_PMTTarget'} == 0 and $skip_counter == 0){	
        #	my $ic = $self->{'initialcontext'};
        #	my $file_ts = $ic->expand('{{WORKLIST/ITEM|regExtract .*_.*_(\d{14})|parseDateTime %Y%m%d%H%M%S|formatDateTime %Y%m%d%H%M%S}}');
       	#	 my $file_seq = $ic->expand('{{WORKLIST/ITEM|regExtract .*_(\d+)\.xml.*}}');
        #  	my $outline = [$self->{'state'}->{'measkey_id'},
        #                 $self->{'state'}->{'dn_id'},
        #                 $self->{'state'}->{'measid_id'},
        #                 $self->{'state'}->{'measurementType_id'},
        #                 $self->{'state'}->{'startTime'},
        #                 $self->{'state'}->{'interval'},
        #                 $self->{'state'}->{'pmttarget'},
        #                 $self->{'state'}->{'pmttarget_id'},$file_ts,$file_seq];
        # 	$self->{'record_count'} = $self->{'record_count'} + 1;
        # 	if (defined $self->{'io_out'}) {
        # 		my $soutline = join(',',@$outline);
        #  		my $of = $self->{'io_out'};
        #  		print $of "$soutline\n";
        # 	}
        # 	if (defined $self->{'writer'}) {
        #   	 $self->{'writer'}->($outline);
        # 	}
	#}
      } ,$o
    )
  };
  $o->{'currentelementhandler'} = undef;
  $o->{'texthandler'} = undef;

  bless $o;
  print STDERR "END OF CONSTRUCTOR IN SAXHANDLER\n";
  return $o;
}

sub getProcessStatistics {
  my $self = shift;
  print "Doing ProcessStatistics\n";
  my $td = $self->{'process_end'} - $self->{'process_start'};
  my $rate = $self->{'record_count'} / $td; 
  my $s = {
    start_time=>$self->{'process_start'},
    end_time=>$self->{'process_end'},
    record_count=>$self->{'record_count'},
    error_count=>$self->{'error_count'},
    parse_rate=>$rate
  };
  print "Done ProcessStatistics\n";
  return $s;
}

sub initialize {
  my $self = shift;

  print STDERR "Doing initialize in SaxHandler\n";
  $self->{'currentelement'} = [];
  $self->{'path'} = '';
  $self->{'currenttext'} = undef;
  $self->{'texttargets'} = {};
  $self->{'currenttexttarget'} = [];
  $self->{'state'} = {};
  $self->{'io_out'} = undef; #$params{'out'};
  $self->{'writer'} = undef; #$params{'writer'};
  $self->{'record_count'} = 0;
  $self->{'process_start'} = undef;
  $self->{'process_end'} = undef;
  use Data::Dumper;
  undef $self->{'meta'};
  my $ic = $self->{'initialcontext'};
  $self->{'enable_ref_file_check'}=$ic->expand('{{CONFIG/parameters/{{SYSTEM/RUN/FLOWCD}}.enable_ref_file_check}}');
  if ( $self->{'enable_ref_file_check'} =~ /Y/i){
  	$self->{'ref_file'}=$ic->expand('{{CONFIG/parameters/{{SYSTEM/RUN/FLOWCD}}.ref_file}}');
	$self->{'meta'}=convertFsubsetToHash($self->{'ref_file'});
  }
  print 
  $self->{'store'}->{'id'}={};
  $self->{'store'}->{'PMSetup'}={};
  $PMSetup_C=1;
  $PMMOResult_C=1;
  $PMTarget_C=1;
  #use Data::Dumper;
  #print STDERR Dumper $self->{'meta'};
}

sub getDataSummary {
  return {};
}

sub setIOSpec {
  my $self = shift;
  my %params = @_;
  if ($params{'out'} and not $params{'writer'}) {
    $self->{'writer'} = partial(
      sub { my $self = shift; my $ofile = shift; my $r = shift; my $line=join($self->{'field_separator'},@$r); print $ofile "$line\n"; },
      $self,$params{'out'}
    );
    $self->{'io_out'} = undef;
  }
  elsif ($params{'writer'}) {
    $self->{'writer'} = $params{'writer'};
  }
}
sub write_record {
  my $self = shift;
  my $io = $self->{'io_out'};
  my %args = @_;
  my $line = $args{'line'};
  #print STDERR "line: $line";
  print $io $line;
}

sub start_document {
  my ($self,$doc) = @_;
  $self->{'process_start'} = time();
}

sub end_document {
  my ($self,$doc) = @_;
  #$self->{'io_out'}->close();
  $self->{'process_end'} = time();
  my $ic = $self->{'initialcontext'};
  my $file_ts = $ic->expand('{{WORKLIST/ITEM|regExtract .*_.*_(\d{14})|parseDateTime %Y%m%d%H%M%S|formatDateTime %Y%m%d%H%M%S}}');  
  my $file_seq = $ic->expand('{{WORKLIST/ITEM|regExtract .*_(\d+)\.xml.*}}');
  #print Dumper $self->{store};
  my $file_name="etlexpmx_$$";
  my $data_file_dir=$ic->expand("{{CONFIG/parameters/{{SYSTEM/RUN/FLOWCD}}.ora_datafile_dir}}");
  my $OUTPUT_HANDLE={};
my $IUMM={'M16C000'=>'YES','M16C001'=>'YES','M16C002'=>'YES','M16C003'=>'YES','M16C004'=>'YES','M16C005'=>'YES','M16C006'=>'YES','M16C007'=>'YES','M16C008'=>'YES','M16C009'=>'YES','M16C010'=>'YES','M16C011'=>'YES','M16C012'=>'YES','M16C013'=>'YES','M16C014'=>'YES','M16C015'=>'YES','M16C016'=>'YES','M16C017'=>'YES','M16C018'=>'YES','M16C019'=>'YES','M16C020'=>'YES','M16C021'=>'YES','M16C022'=>'YES','M16C023'=>'YES','M16C024'=>'YES','M16C025'=>'YES','M16C026'=>'YES','M16C027'=>'YES','M16C028'=>'YES','M16C029'=>'YES','M16C030'=>'YES','M16C031'=>'YES','M16C032'=>'YES','M16C033'=>'YES','M16C034'=>'YES','M16C035'=>'YES','M16C036'=>'YES','M16C037'=>'YES','M16C038'=>'YES','M16C039'=>'YES','M16C040'=>'YES','M16C041'=>'YES','M16C042'=>'YES','M16C043'=>'YES','M16C044'=>'YES','M16C045'=>'YES','M16C046'=>'YES','M16C047'=>'YES','M16C048'=>'YES','M16C049'=>'YES','M16C050'=>'YES','M16C051'=>'YES','M16C052'=>'YES','M16C053'=>'YES','M16C054'=>'YES','M16C055'=>'YES','M16C056'=>'YES','M16C057'=>'YES','M16C058'=>'YES','M16C059'=>'YES','M16C060'=>'YES','M16C063'=>'YES','M16C064'=>'YES','M16C065'=>'YES','M16C066'=>'YES','M16C067'=>'YES','M16C068'=>'YES','M16C069'=>'YES','M16C070'=>'YES','M16C071'=>'YES','M16C072'=>'YES','M16C075'=>'YES','M16C076'=>'YES','M16C077'=>'YES','M16C078'=>'YES','M16C079'=>'YES','M16C080'=>'YES','M16C081'=>'YES','M16C082'=>'YES','M16C083'=>'YES','M16C084'=>'YES','M16C085'=>'YES','M16C086'=>'YES','M16C087'=>'YES','M16C088'=>'YES','M16C089'=>'YES','M16C090'=>'YES','M16C091'=>'YES','M16C092'=>'YES','M16C093'=>'YES','M16C094'=>'YES','M16C095'=>'YES','M16C096'=>'YES','M16C097'=>'YES','M16C098'=>'YES','M16C099'=>'YES','M16C100'=>'YES','M16C101'=>'YES','M16C102'=>'YES','M16C103'=>'YES','M16C104'=>'YES','M16C105'=>'YES','M16C106'=>'YES','M16C107'=>'YES','M16C108'=>'YES','M16C109'=>'YES','M16C110'=>'YES','M16C111'=>'YES','M16C112'=>'YES','M16C113'=>'YES','M16C114'=>'YES','M16C115'=>'YES','M16C116'=>'YES','M16C117'=>'YES','M16C118'=>'YES','M16C119'=>'YES','M16C120'=>'YES','M16C121'=>'YES','M16C122'=>'YES','M16C123'=>'YES','M16C124'=>'YES','M16C125'=>'YES','M16C126'=>'YES','M16C127'=>'YES','M16C128'=>'YES','M16C129'=>'YES','M16C130'=>'YES','M16C131'=>'YES','M16C132'=>'YES','M16C133'=>'YES','M16C134'=>'YES','M16C135'=>'YES','M16C136'=>'YES','M16C137'=>'YES','M16C138'=>'YES','M16C139'=>'YES','M16C140'=>'YES','M16C141'=>'YES','M16C142'=>'YES','M16C143'=>'YES','M16C144'=>'YES','M16C145'=>'YES','M16C146'=>'YES','M16C147'=>'YES','M16C148'=>'YES','M16C149'=>'YES','M16C150'=>'YES','M16C151'=>'YES','M16C152'=>'YES','M16C153'=>'YES','M16C154'=>'YES','M16C155'=>'YES','M16C156'=>'YES','M16C157'=>'YES','M16C158'=>'YES','M16C159'=>'YES','M16C160'=>'YES','M16C161'=>'YES','M16C162'=>'YES','M16C163'=>'YES','M16C164'=>'YES','M16C165'=>'YES','M16C166'=>'YES','M16C167'=>'YES','M16C168'=>'YES','M16C169'=>'YES','M16C170'=>'YES','M16C171'=>'YES','M16C172'=>'YES','M16C173'=>'YES','M16C174'=>'YES','M16C175'=>'YES','M16C176'=>'YES','M16C177'=>'YES','M16C178'=>'YES','M16C179'=>'YES','M16C180'=>'YES','M16C181'=>'YES','M16C182'=>'YES','M16C183'=>'YES','M16C184'=>'YES','M16C185'=>'YES','M16C186'=>'YES','M16C187'=>'YES','M16C188'=>'YES','M16C189'=>'YES','M16C190'=>'YES','M16C191'=>'YES','M16C192'=>'YES','M16C193'=>'YES','M16C194'=>'YES','M16C195'=>'YES','M16C196'=>'YES','M16C197'=>'YES','M16C198'=>'YES','M16C199'=>'YES','M16C200'=>'YES','M16C201'=>'YES','M16C202'=>'YES','M16C203'=>'YES','M16C204'=>'YES','M16C205'=>'YES','M16C206'=>'YES','M16C207'=>'YES','M16C208'=>'YES','M16C209'=>'YES','M16C210'=>'YES','M16C211'=>'YES','M16C212'=>'YES','M16C213'=>'YES','M16C214'=>'YES','M16C215'=>'YES','M16C216'=>'YES','M16C217'=>'YES','M16C218'=>'YES','M16C219'=>'YES','M16C220'=>'YES','M16C221'=>'YES','M16C222'=>'YES','M16C223'=>'YES','M16C224'=>'YES','M16C225'=>'YES','M16C226'=>'YES','M16C227'=>'YES','M16C228'=>'YES','M16C229'=>'YES','M16C230'=>'YES','M16C231'=>'YES','M16C232'=>'YES','M16C233'=>'YES','M16C234'=>'YES','M16C235'=>'YES','M16C236'=>'YES','M16C237'=>'YES','M16C238'=>'YES','M16C239'=>'YES','M16C240'=>'YES','M16C241'=>'YES','M16C242'=>'YES','M16C243'=>'YES','M16C244'=>'YES','M16C245'=>'YES','M16C246'=>'YES','M16C247'=>'YES','M16C248'=>'YES','M16C249'=>'YES','M16C250'=>'YES','M16C251'=>'YES','M16C252'=>'YES','M16C253'=>'YES','M16C254'=>'YES','M16C255'=>'YES','M16C256'=>'YES','M16C257'=>'YES','M16C258'=>'YES','M16C259'=>'YES','M16C260'=>'YES','M16C261'=>'YES','M16C262'=>'YES','M16C263'=>'YES','M16C264'=>'YES','M16C265'=>'YES','M16C266'=>'YES','M16C267'=>'YES','M16C268'=>'YES','M16C269'=>'YES','M16C270'=>'YES','M16C271'=>'YES','M16C272'=>'YES','M16C273'=>'YES','M16C274'=>'YES','M16C275'=>'YES','M16C276'=>'YES','M16C277'=>'YES','M16C278'=>'YES','M16C279'=>'YES','M16C280'=>'YES','M16C281'=>'YES','M16C282'=>'YES','M16C283'=>'YES','M16C284'=>'YES','M16C285'=>'YES','M16C286'=>'YES','M16C287'=>'YES','M16C288'=>'YES','M16C289'=>'YES','M16C290'=>'YES','M16C291'=>'YES','M16C292'=>'YES','M16C293'=>'YES','M16C294'=>'YES','M16C295'=>'YES','M16C296'=>'YES','M16C297'=>'YES','M16C298'=>'YES','M16C299'=>'YES','M16C300'=>'YES','M16C301'=>'YES','M16C302'=>'YES','M16C303'=>'YES','M16C304'=>'YES','M16C305'=>'YES','M16C306'=>'YES','M16C307'=>'YES','M16C308'=>'YES','M16C309'=>'YES','M16C310'=>'YES','M16C311'=>'YES','M16C312'=>'YES','M16C313'=>'YES','M16C314'=>'YES','M16C315'=>'YES','M16C320'=>'YES','M16C321'=>'YES','M16C322'=>'YES','M16C323'=>'YES','M16C324'=>'YES','M16C325'=>'YES','M16C326'=>'YES','M16C327'=>'YES','M16C328'=>'YES','M16C329'=>'YES','M16C330'=>'YES','M16C331'=>'YES','M16C332'=>'YES','M16C333'=>'YES','M16C334'=>'YES','M16C335'=>'YES','M16C336'=>'YES','M16C337'=>'YES','M16C338'=>'YES','M16C339'=>'YES','M16C340'=>'YES','M16C341'=>'YES','M16C342'=>'YES','M16C343'=>'YES','M16C344'=>'YES','M16C345'=>'YES','M16C346'=>'YES','M16C347'=>'YES','M16C348'=>'YES','M16C349'=>'YES','M16C350'=>'YES','M16C351'=>'YES','M16C352'=>'YES','M16C353'=>'YES','M16C354'=>'YES','M16C355'=>'YES','M16C356'=>'YES','M16C357'=>'YES','M16C358'=>'YES','M16C359'=>'YES','M16C360'=>'YES','M16C361'=>'YES','M16C362'=>'YES','M16C363'=>'YES','M16C364'=>'YES','M16C365'=>'YES','M16C366'=>'YES','M16C367'=>'YES','M16C368'=>'YES','M16C369'=>'YES','M16C370'=>'YES','M16C371'=>'YES','M16C372'=>'YES','M16C373'=>'YES','M16C374'=>'YES','M16C375'=>'YES','M16C376'=>'YES','M16C377'=>'YES','M16C378'=>'YES','M16C379'=>'YES','M16C380'=>'YES','M16C381'=>'YES','M16C382'=>'YES','M16C383'=>'YES','M16C384'=>'YES','M16C385'=>'YES','M16C386'=>'YES','M16C387'=>'YES','M16C388'=>'YES','M16C389'=>'YES','M16C390'=>'YES','M16C391'=>'YES','M16C392'=>'YES','M16C393'=>'YES','M16C394'=>'YES','M16C395'=>'YES','M16C396'=>'YES','M16C397'=>'YES','M16C398'=>'YES','M16C399'=>'YES','M16C400'=>'YES','M16C401'=>'YES','M16C402'=>'YES','M16C403'=>'YES','M16C404'=>'YES','M16C405'=>'YES','M16C406'=>'YES','M16C407'=>'YES','M16C408'=>'YES','M16C409'=>'YES','M16C410'=>'YES','M16C411'=>'YES','M16C412'=>'YES','M16C413'=>'YES','M16C414'=>'YES','M16C415'=>'YES','M16C416'=>'YES','M16C417'=>'YES','M16C418'=>'YES','M16C419'=>'YES','M16C420'=>'YES','M16C421'=>'YES','M16C422'=>'YES','M16C423'=>'YES','M16C424'=>'YES','M16C425'=>'YES','M16C426'=>'YES','M16C427'=>'YES','M16C428'=>'YES','M16C429'=>'YES','M16C430'=>'YES','M16C431'=>'YES','M16C432'=>'YES','M16C433'=>'YES','M16C434'=>'YES','M16C435'=>'YES','M16C436'=>'YES','M16C437'=>'YES','M16C438'=>'YES','M16C439'=>'YES','M16C440'=>'YES','M16C441'=>'YES','M16C442'=>'YES','M16C443'=>'YES','M16C444'=>'YES','M16C445'=>'YES','M16C446'=>'YES','M16C447'=>'YES','M16C448'=>'YES','M16C449'=>'YES','M16C450'=>'YES','M16C451'=>'YES','M16C452'=>'YES','M16C453'=>'YES','M16C454'=>'YES','M16C455'=>'YES','M16C456'=>'YES','M16C457'=>'YES','M16C458'=>'YES','M16C459'=>'YES','M16C460'=>'YES','M16C461'=>'YES','M16C462'=>'YES','M16C463'=>'YES','M16C464'=>'YES','M16C465'=>'YES','M16C466'=>'YES','M16C467'=>'YES','M16C468'=>'YES','M16C469'=>'YES','M16C470'=>'YES','M16C471'=>'YES','M16C472'=>'YES','M16C473'=>'YES','M16C474'=>'YES','M16C475'=>'YES','M16C476'=>'YES','M16C477'=>'YES','M16C478'=>'YES','M16C479'=>'YES','M16C480'=>'YES','M16C481'=>'YES','M16C482'=>'YES','M16C483'=>'YES','M16C484'=>'YES','M16C485'=>'YES','M16C486'=>'YES','M16C487'=>'YES','M16C488'=>'YES','M16C489'=>'YES','M16C490'=>'YES','M16C491'=>'YES','M16C492'=>'YES','M16C493'=>'YES','M16C494'=>'YES','M16C495'=>'YES','M16C496'=>'YES' };
my $MOBMGMT={'M01C000'=>'YES','M01C002'=>'YES','M01C003'=>'YES','M01C004'=>'YES','M01C005'=>'YES','M01C006'=>'YES','M01C007'=>'YES','M01C008'=>'YES','M01C009'=>'YES','M01C010'=>'YES','M01C011'=>'YES','M01C012'=>'YES','M01C013'=>'YES','M01C014'=>'YES','M01C015'=>'YES','M01C016'=>'YES','M01C017'=>'YES','M01C018'=>'YES','M01C019'=>'YES','M01C020'=>'YES','M01C021'=>'YES','M01C022'=>'YES','M01C025'=>'YES','M01C026'=>'YES','M01C027'=>'YES','M01C028'=>'YES','M01C029'=>'YES','M01C030'=>'YES','M01C031'=>'YES','M01C032'=>'YES','M01C033'=>'YES','M01C034'=>'YES','M01C035'=>'YES','M01C036'=>'YES','M01C037'=>'YES','M01C038'=>'YES','M01C039'=>'YES','M01C040'=>'YES','M01C041'=>'YES','M01C042'=>'YES','M01C043'=>'YES','M01C044'=>'YES','M01C045'=>'YES','M01C046'=>'YES','M01C048'=>'YES','M01C052'=>'YES','M01C053'=>'YES','M01C054'=>'YES','M01C055'=>'YES','M01C056'=>'YES','M01C057'=>'YES','M01C059'=>'YES','M01C060'=>'YES','M01C062'=>'YES','M01C063'=>'YES','M01C064'=>'YES','M01C065'=>'YES','M01C066'=>'YES','M01C067'=>'YES','M01C069'=>'YES','M01C070'=>'YES','M01C071'=>'YES','M01C072'=>'YES','M01C073'=>'YES','M01C074'=>'YES','M01C075'=>'YES','M01C076'=>'YES','M01C077'=>'YES','M01C078'=>'YES','M01C079'=>'YES','M01C080'=>'YES','M01C081'=>'YES','M01C082'=>'YES','M01C083'=>'YES','M01C084'=>'YES','M01C085'=>'YES','M01C086'=>'YES','M01C087'=>'YES','M01C088'=>'YES','M01C089'=>'YES','M01C090'=>'YES','M01C091'=>'YES','M01C092'=>'YES','M01C093'=>'YES','M01C094'=>'YES','M01C095'=>'YES','M01C096'=>'YES','M01C097'=>'YES','M01C098'=>'YES','M01C099'=>'YES','M01C100'=>'YES','M01C101'=>'YES','M01C102'=>'YES','M01C103'=>'YES','M01C104'=>'YES','M01C105'=>'YES','M01C106'=>'YES','M01C107'=>'YES','M01C108'=>'YES','M01C109'=>'YES','M01C110'=>'YES','M01C111'=>'YES','M01C112'=>'YES','M01C113'=>'YES','M01C114'=>'YES','M01C115'=>'YES','M01C116'=>'YES','M01C117'=>'YES','M01C118'=>'YES','M01C119'=>'YES','M01C120'=>'YES','M01C121'=>'YES','M01C122'=>'YES','M01C123'=>'YES','M01C124'=>'YES','M01C125'=>'YES','M01C126'=>'YES','M01C127'=>'YES','M01C128'=>'YES','M01C129'=>'YES','M01C130'=>'YES','M01C131'=>'YES','M01C132'=>'YES','M01C133'=>'YES','M01C134'=>'YES','M01C135'=>'YES','M01C136'=>'YES','M01C137'=>'YES','M01C138'=>'YES','M01C139'=>'YES','M01C140'=>'YES','M01C141'=>'YES','M01C142'=>'YES','M01C143'=>'YES','M01C144'=>'YES','M01C145'=>'YES','M01C146'=>'YES','M01C147'=>'YES','M01C148'=>'YES','M01C149'=>'YES','M01C150'=>'YES','M01C151'=>'YES','M01C152'=>'YES','M01C153'=>'YES','M01C154'=>'YES','M01C155'=>'YES','M01C156'=>'YES','M01C157'=>'YES','M01C158'=>'YES','M01C159'=>'YES','M01C160'=>'YES','M01C161'=>'YES','M01C162'=>'YES','M01C163'=>'YES','M01C164'=>'YES','M01C165'=>'YES','M01C166'=>'YES','M01C167'=>'YES','M01C168'=>'YES','M01C169'=>'YES','M01C170'=>'YES','M01C171'=>'YES','M01C172'=>'YES','M01C173'=>'YES','M01C174'=>'YES','M01C175'=>'YES','M01C176'=>'YES','M01C177'=>'YES','M01C178'=>'YES','M01C179'=>'YES','M01C180'=>'YES','M01C181'=>'YES','M01C182'=>'YES','M01C183'=>'YES','M01C184'=>'YES','M01C185'=>'YES','M01C186'=>'YES','M01C187'=>'YES','M01C188'=>'YES','M01C189'=>'YES','M01C190'=>'YES','M01C191'=>'YES','M01C192'=>'YES','M01C193'=>'YES','M01C194'=>'YES','M01C195'=>'YES','M01C196'=>'YES','M01C197'=>'YES','M01C198'=>'YES','M01C199'=>'YES','M01C200'=>'YES','M01C201'=>'YES','M01C202'=>'YES','M01C203'=>'YES','M01C204'=>'YES','M01C205'=>'YES','M01C206'=>'YES','M01C207'=>'YES','M01C208'=>'YES','M01C209'=>'YES','M01C210'=>'YES','M01C211'=>'YES','M01C212'=>'YES','M01C213'=>'YES','M01C214'=>'YES','M01C215'=>'YES','M01C216'=>'YES','M01C217'=>'YES','M01C218'=>'YES','M01C219'=>'YES','M01C220'=>'YES','M01C221'=>'YES','M01C222'=>'YES','M01C223'=>'YES','M01C224'=>'YES','M01C225'=>'YES','M01C226'=>'YES','M01C227'=>'YES','M01C228'=>'YES','M01C229'=>'YES','M01C230'=>'YES','M01C231'=>'YES','M01C232'=>'YES','M01C233'=>'YES','M01C234'=>'YES','M01C235'=>'YES','M01C236'=>'YES','M01C237'=>'YES','M01C238'=>'YES','M01C239'=>'YES','M01C240'=>'YES','M01C241'=>'YES','M01C242'=>'YES','M01C243'=>'YES','M01C244'=>'YES','M01C245'=>'YES','M01C246'=>'YES','M01C247'=>'YES','M01C248'=>'YES','M01C249'=>'YES','M01C250'=>'YES','M01C251'=>'YES','M01C252'=>'YES','M01C253'=>'YES','M01C254'=>'YES','M01C255'=>'YES','M01C256'=>'YES','M01C257'=>'YES','M01C258'=>'YES','M01C259'=>'YES','M01C260'=>'YES','M01C261'=>'YES','M01C262'=>'YES','M01C263'=>'YES','M01C264'=>'YES','M01C265'=>'YES','M01C266'=>'YES','M01C267'=>'YES','M01C268'=>'YES','M01C269'=>'YES','M01C270'=>'YES','M01C271'=>'YES','M01C272'=>'YES','M01C273'=>'YES','M01C274'=>'YES','M01C275'=>'YES','M01C276'=>'YES','M01C277'=>'YES','M01C278'=>'YES','M01C279'=>'YES','M01C280'=>'YES','M01C281'=>'YES','M01C282'=>'YES','M01C283'=>'YES','M01C284'=>'YES','M01C285'=>'YES','M01C286'=>'YES','M01C287'=>'YES','M01C288'=>'YES','M01C289'=>'YES','M01C290'=>'YES','M01C291'=>'YES','M01C292'=>'YES','M01C293'=>'YES','M01C294'=>'YES','M01C295'=>'YES','M01C296'=>'YES','M01C297'=>'YES','M01C298'=>'YES','M01C299'=>'YES','M01C300'=>'YES','M01C301'=>'YES','M01C302'=>'YES','M01C303'=>'YES','M01C304'=>'YES','M01C305'=>'YES','M01C306'=>'YES','M01C307'=>'YES','M01C308'=>'YES','M01C309'=>'YES','M01C310'=>'YES','M01C311'=>'YES','M01C312'=>'YES','M01C313'=>'YES','M01C314'=>'YES','M01C315'=>'YES','M01C316'=>'YES','M01C317'=>'YES','M01C318'=>'YES','M01C319'=>'YES','M01C320'=>'YES','M01C321'=>'YES','M01C322'=>'YES','M01C323'=>'YES','M01C324'=>'YES','M01C325'=>'YES','M01C326'=>'YES','M01C327'=>'YES','M01C328'=>'YES','M01C329'=>'YES','M01C330'=>'YES','M01C331'=>'YES','M01C332'=>'YES','M01C333'=>'YES','M01C334'=>'YES','M01C335'=>'YES','M01C336'=>'YES','M01C337'=>'YES','M01C338'=>'YES','M01C339'=>'YES','M01C340'=>'YES','M01C341'=>'YES','M01C342'=>'YES','M01C343'=>'YES','M01C344'=>'YES','M01C345'=>'YES','M01C346'=>'YES','M01C347'=>'YES','M01C348'=>'YES','M01C349'=>'YES','M01C350'=>'YES','M01C351'=>'YES','M01C352'=>'YES','M01C353'=>'YES','M01C354'=>'YES','M01C355'=>'YES','M01C356'=>'YES','M01C357'=>'YES','M01C358'=>'YES','M01C359'=>'YES','M01C360'=>'YES','M01C361'=>'YES','M01C362'=>'YES','M01C363'=>'YES','M01C364'=>'YES','M01C365'=>'YES','M01C366'=>'YES','M01C367'=>'YES','M01C368'=>'YES','M01C369'=>'YES','M01C370'=>'YES','M01C371'=>'YES','M01C372'=>'YES','M01C373'=>'YES','M01C374'=>'YES','M01C375'=>'YES','M01C376'=>'YES','M01C377'=>'YES','M01C378'=>'YES','M01C379'=>'YES','M01C380'=>'YES','M01C381'=>'YES','M01C382'=>'YES','M01C383'=>'YES','M01C384'=>'YES','M01C385'=>'YES','M01C386'=>'YES','M01C387'=>'YES','M01C388'=>'YES','M01C389'=>'YES','M01C390'=>'YES','M01C391'=>'YES','M01C392'=>'YES','M01C393'=>'YES','M01C394'=>'YES','M01C395'=>'YES','M01C396'=>'YES','M01C397'=>'YES','M01C398'=>'YES','M01C399'=>'YES','M01C400'=>'YES','M01C401'=>'YES','M01C402'=>'YES'};
my $IUSM={'M17C000'=>'YES','M17C001'=>'YES','M17C002'=>'YES','M17C003'=>'YES','M17C004'=>'YES','M17C005'=>'YES','M17C006'=>'YES','M17C007'=>'YES','M17C008'=>'YES','M17C009'=>'YES','M17C010'=>'YES','M17C011'=>'YES','M17C012'=>'YES','M17C013'=>'YES','M17C014'=>'YES','M17C015'=>'YES','M17C016'=>'YES','M17C017'=>'YES','M17C018'=>'YES','M17C019'=>'YES','M17C020'=>'YES','M17C021'=>'YES','M17C022'=>'YES','M17C023'=>'YES','M17C031'=>'YES','M17C032'=>'YES','M17C033'=>'YES','M17C034'=>'YES','M17C035'=>'YES','M17C036'=>'YES','M17C037'=>'YES','M17C038'=>'YES','M17C039'=>'YES','M17C040'=>'YES','M17C041'=>'YES','M17C042'=>'YES','M17C043'=>'YES','M17C044'=>'YES','M17C045'=>'YES','M17C046'=>'YES','M17C047'=>'YES','M17C048'=>'YES','M17C049'=>'YES','M17C050'=>'YES','M17C051'=>'YES','M17C052'=>'YES','M17C053'=>'YES','M17C054'=>'YES','M17C055'=>'YES','M17C056'=>'YES','M17C057'=>'YES','M17C058'=>'YES','M17C059'=>'YES','M17C060'=>'YES','M17C061'=>'YES','M17C062'=>'YES','M17C063'=>'YES','M17C064'=>'YES','M17C065'=>'YES','M17C066'=>'YES','M17C067'=>'YES','M17C068'=>'YES','M17C069'=>'YES','M17C070'=>'YES','M17C071'=>'YES','M17C072'=>'YES','M17C073'=>'YES','M17C074'=>'YES','M17C075'=>'YES','M17C076'=>'YES','M17C078'=>'YES','M17C079'=>'YES','M17C080'=>'YES','M17C081'=>'YES','M17C082'=>'YES','M17C083'=>'YES','M17C084'=>'YES','M17C085'=>'YES','M17C086'=>'YES','M17C087'=>'YES','M17C088'=>'YES','M17C089'=>'YES','M17C090'=>'YES','M17C091'=>'YES','M17C093'=>'YES','M17C094'=>'YES','M17C095'=>'YES','M17C096'=>'YES','M17C097'=>'YES','M17C098'=>'YES','M17C099'=>'YES','M17C100'=>'YES','M17C101'=>'YES','M17C102'=>'YES','M17C103'=>'YES','M17C104'=>'YES','M17C105'=>'YES','M17C106'=>'YES','M17C107'=>'YES','M17C108'=>'YES','M17C109'=>'YES','M17C110'=>'YES','M17C111'=>'YES','M17C112'=>'YES','M17C113'=>'YES','M17C114'=>'YES','M17C115'=>'YES','M17C116'=>'YES','M17C117'=>'YES','M17C118'=>'YES','M17C119'=>'YES','M17C120'=>'YES','M17C121'=>'YES','M17C122'=>'YES','M17C123'=>'YES','M17C124'=>'YES','M17C125'=>'YES','M17C126'=>'YES','M17C148'=>'YES','M17C149'=>'YES','M17C150'=>'YES'};
my $SESMGMT={'M02C000'=>'YES','M02C001'=>'YES','M02C004'=>'YES','M02C005'=>'YES','M02C006'=>'YES','M02C007'=>'YES','M02C008'=>'YES','M02C009'=>'YES','M02C010'=>'YES','M02C011'=>'YES','M02C012'=>'YES','M02C013'=>'YES','M02C014'=>'YES','M02C015'=>'YES','M02C016'=>'YES','M02C017'=>'YES','M02C018'=>'YES','M02C019'=>'YES','M02C020'=>'YES','M02C021'=>'YES','M02C022'=>'YES','M02C023'=>'YES','M02C024'=>'YES','M02C025'=>'YES','M02C026'=>'YES','M02C027'=>'YES','M02C028'=>'YES','M02C029'=>'YES','M02C030'=>'YES','M02C031'=>'YES','M02C032'=>'YES','M02C033'=>'YES','M02C034'=>'YES','M02C035'=>'YES','M02C036'=>'YES','M02C037'=>'YES','M02C038'=>'YES','M02C039'=>'YES','M02C040'=>'YES','M02C041'=>'YES','M02C042'=>'YES','M02C043'=>'YES','M02C044'=>'YES','M02C045'=>'YES','M02C046'=>'YES','M02C047'=>'YES','M02C048'=>'YES','M02C049'=>'YES','M02C050'=>'YES','M02C051'=>'YES','M02C052'=>'YES','M02C053'=>'YES','M02C054'=>'YES','M02C055'=>'YES','M02C056'=>'YES','M02C057'=>'YES','M02C064'=>'YES','M02C065'=>'YES','M02C066'=>'YES','M02C076'=>'YES','M02C079'=>'YES','M02C082'=>'YES','M02C083'=>'YES','M02C084'=>'YES','M02C085'=>'YES','M02C086'=>'YES','M02C087'=>'YES','M02C088'=>'YES','M02C089'=>'YES','M02C090'=>'YES','M02C091'=>'YES','M02C092'=>'YES','M02C093'=>'YES','M02C094'=>'YES','M02C095'=>'YES','M02C096'=>'YES','M02C097'=>'YES','M02C098'=>'YES','M02C099'=>'YES','M02C100'=>'YES','M02C101'=>'YES','M02C102'=>'YES','M02C103'=>'YES','M02C104'=>'YES','M02C105'=>'YES','M02C106'=>'YES','M02C107'=>'YES','M02C108'=>'YES','M02C109'=>'YES','M02C110'=>'YES','M02C111'=>'YES','M02C112'=>'YES','M02C113'=>'YES','M02C114'=>'YES','M02C115'=>'YES','M02C116'=>'YES','M02C117'=>'YES','M02C118'=>'YES','M02C119'=>'YES','M02C120'=>'YES','M02C121'=>'YES','M02C122'=>'YES','M02C123'=>'YES','M02C124'=>'YES','M02C125'=>'YES','M02C126'=>'YES','M02C127'=>'YES','M02C128'=>'YES','M02C129'=>'YES','M02C130'=>'YES','M02C131'=>'YES','M02C132'=>'YES','M02C133'=>'YES','M02C134'=>'YES','M02C135'=>'YES','M02C136'=>'YES','M02C137'=>'YES','M02C138'=>'YES','M02C139'=>'YES','M02C140'=>'YES','M02C141'=>'YES','M02C142'=>'YES','M02C143'=>'YES','M02C144'=>'YES','M02C145'=>'YES','M02C146'=>'YES','M02C147'=>'YES','M02C148'=>'YES','M02C149'=>'YES'};

  #all Data loaded into hash now ---processing begin-----
  foreach my $pmsetup (keys $self->{store}->{PMSetup}){
	my $starttime=$self->{store}->{PMSetup}->{$pmsetup}->{startTime};
	my $interval=$self->{store}->{PMSetup}->{$pmsetup}->{interval};
	foreach my $pmmoresult (keys $self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}){
		my $dn_id;
		my $measType_id;
		my $measid_id;
		my $measType;
		my $measKey;
		my $measKey_id;
		my $measid;
		my $dummy;
		my $pos;
		my $localname_v={};
		if(defined $self->{store}->{id}->{DN}->{$self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{DN}}){
		 	$dn_id=$self->{store}->{id}->{DN}->{$self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{DN}};
		}
		else {
			$dn_id=$self->{'lookup'}->{'db_lookup_tgoflexi_dn'}->{$self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{DN}};
			$self->{store}->{id}->{DN}->{$self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{DN}}=$dn_id;
		}
		foreach my $pmtarget (keys $self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{PMTarget}){
			my $flag=0;
			foreach my $localname (keys $self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{PMTarget}->{$pmtarget}){
				if($localname eq 'measurementType'){
					$measType=$self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{PMTarget}->{$pmtarget}->{$localname};
					if(defined $self->{store}->{id}->{measurementType}->{$measType}){
						$measType_id=$self->{store}->{id}->{measurementType}->{$measType};
					}
					else {
						$measType_id=$self->{'lookup'}->{'db_lookup_tgoflexi_meastype'}->{$measType};
						$self->{store}->{id}->{measurementType}->{$measType}=$measType_id;
					}
				}
				else {
					if ( $flag == 0 ){
						($measid,$dummy,$pos) = ( $localname =~ /^M(\d+)(\D)(\d*)/i);
						if(defined $self->{store}->{id}->{measid}->{$measid}){
							$measid_id=$self->{store}->{id}->{measid}->{$measid};
						}
						else {
							$measid_id=$self->{'lookup'}->{'db_lookup_tgoflexi_measid'}->{$measid};
							$self->{store}->{id}->{measid}->{$measid}=$measid_id;
						}
						$flag= 1;
					}
					if ( defined $self->{store}->{id}->{localname}->{$localname}){
						$localname_v->{$localname}->{id}=$self->{store}->{id}->{localname}->{$localname};	
					}
					else {
						$localname_v->{$localname}->{id}=$self->{'lookup'}->{'db_lookup_tgoflexi_targetkey'}->{$localname} ;
						$self->{store}->{id}->{localname}->{$localname}=$localname_v->{$localname}->{id};
					}
					$localname_v->{$localname}->{value}=$self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{PMTarget}->{$pmtarget}->{$localname};	
				}
			}
			$measKey=$measType.'_'.$measid;
			if ( defined $self->{store}->{id}->{measkey}->{$measKey} ){
				$measKey_id=$self->{store}->{id}->{measkey}->{$measKey} ;
			}
			else {
				$measKey_id=$self->{'lookup'}->{'db_lookup_tgoflexi_measkey'}->{$measKey};
				$self->{store}->{id}->{measkey}->{$measKey}=$measKey_id;
			}
			my @arr_tmp=();
			my $counter=0;
			unless(defined $OUTPUT_HANDLE->{$measKey}){
				open $OUTPUT_HANDLE->{$measKey},">>$data_file_dir/$file_name.$measKey.loading";
			}
			if ( $measKey !~ /MOBMGMNT_01/ and $measKey !~ /IUSM_17/ and $measKey !~ /IUMM_16/ and $measKey !~ /SESMGMNT_02/ ){
				foreach my $ln (keys $localname_v){
					$arr_tmp[$counter]="$measKey_id,$dn_id,$measid_id,$measType_id,$starttime,$interval,".$localname_v->{$ln}->{value}.",".$localname_v->{$ln}->{id}.",$file_ts,$file_seq";
		#if ( -e $data_file_dir.'/'.$file_name.'.'.$measType ) {
					print {$OUTPUT_HANDLE->{$measKey}} $arr_tmp[$counter],"\n";
					#`echo $arr_tmp[$counter] >> $data_file_dir/$file_name.$measType`;
       		         		#if (defined $self->{'writer'}) {
       			          		#	$self->{'writer'}->($arr_tmp[$counter]);
       		         		#}
					$counter++;
				}	
			}
                        else {
                                my ($measid)=($measKey =~ /.*_(\d+)/);
                                my ($flexins_id)=($self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{DN} =~ /.*\/FLEXINS-(\d+)\/.*/ );
                                my $str='';
                                foreach my $ln (sort keys  $localname_v){
                                        next if ( $measKey =~ /SESMGMNT_02/ and not defined $SESMGMT->{$ln} );
                                        next if ( $measKey =~ /IUMM_16/ and not defined $IUMM->{$ln} );
                                        next if ( $measKey =~ /IUSM_17/ and not defined $IUSM->{$ln} );
                                        next if ( $measKey =~ /MOBMGMNT_01/ and not defined $MOBMGMT->{$ln} );
                                        $str=$str.$localname_v->{$ln}->{value}.",";
                                }
                                        $str=~ s/,$//;
                                        print {$OUTPUT_HANDLE->{$measKey}} "$starttime,$interval,".$self->{store}->{PMSetup}->{$pmsetup}->{PMMOResult}->{$pmmoresult}->{DN}.",$measid,$measType,$flexins_id,$str\n";

                        }
		}
	}
  }
  foreach my $hndl (keys $OUTPUT_HANDLE){
	close($OUTPUT_HANDLE->{$hndl});
 } 
  #print "Sarwesh\n";
  #print Dumper  $self->{'store'}->{'id'},'\n';
  #my $interval = $self->{'process_end'} - $self->{'process_start'};
  #my $processrate = $self->{'record_count'} / $interval;
  #my $rcount = $self->{'record_count'};
  #my $ic = $self->{'initialcontext'};
  #$ic->log(message=>sprintf("Processing rate: $rcount records in %.3f seconds,%.3f records/second",$interval,$processrate),domain=>"system",level=>"info");
}

sub getElementStartHandler {
  my $self = shift;
  my $path = $self->{'path'};
  #print STDERR $path," START\n";return $self->{'elementstarthandlers'}->{'OMeS.PMSetup'};
  if ( defined $self->{'elementstarthandlers'}->{$path}) {return $self->{'elementstarthandlers'}->{$path};}
  if( $path =~ m/OMeS\.PMSetup\.PMMOResult\.PMTarget\..*/i) { return $self->{'elementstarthandlers'}->{'OMeS.PMSetup.PMMOResult.PMTarget..*'}; }
  #print STDERR "searching for handler for $path\n";
  #for my $k (keys %{$self->{'elementstarthandlers'}}) {
  #  #print STDERR "checking $k\n";
  #  if ($path =~ m/^${k}$/) {
  #    return $self->{'elementstarthandlers'}->{$k};
  #  }
  #}
  return partial(sub { print STDERR "dummy start function for $path\n"; });
}

sub getElementEndHandler {
  my $self = shift;
  my $path = $self->{'path'};
  #print STDERR $path," END\n";return $self->{'elementstarthandlers'}->{'OMeS.PMSetup'};
  #print STDERR "searching for handler for $path\n";
  if ( defined $self->{'elementendhandlers'}->{$path}) {return $self->{'elementendhandlers'}->{$path};}
  if( $path =~ m/OMeS\.PMSetup\.PMMOResult\.PMTarget\..*/i) { return $self->{'elementendhandlers'}->{'OMeS.PMSetup.PMMOResult.PMTarget..*'}; }
  #for my $k (keys %{$self->{'elementendhandlers'}}) {
  #  #print STDERR "checking $k\n";
  #  if ($path =~ m/^${k}$/) {
  #    return $self->{'elementendhandlers'}->{$k};
  #  }
  #}
  return partial(sub { print STDERR "dummy end function for $path\n"; });
}

sub getCharacterHandler {
}

sub start_element {
  my ($self,$el) = @_;
  my $locname = $el->{'LocalName'};
  if (scalar @{$self->{'currentelement'}} == 0) {
    #print STDERR "Starting document with element $locname\n";
  }
  push @{$self->{'currentelement'}},$locname;
  $self->{'path'} = join ('.',@{$self->{'currentelement'}});
  #print STDERR "Starting element ",$el->{'LocalName'},"\n";

  push @{$self->{'currenttexttarget'}},{'r'=>0,'text'=>undef};
  my $elhandler = $self->getElementStartHandler();
  $elhandler->($el);
}

sub end_element {
  my ($self,$el) = @_;

  use Data::Dumper;
  eval {
    my $elhandler = $self->getElementEndHandler();
    $elhandler->($el);
  };
  if ($@) {
    print STDERR "In SaxHandler end_elemenet: An error has occurred",Dumper($@),"\n";
  }

  #print STDERR "popping from texttargets for ",$self->{'path'},"\n";
  my $tt = pop @{$self->{'currenttexttarget'}};
  pop @{$self->{'currentelement'}};
  $self->{'path'} = join ('.',@{$self->{'currentelement'}});
  #print STDERR "Starting element ",$el->{'LocalName'},"\n";
  #print STDERR "Ending element\n";
}

sub setElementText {
  my ($self,$characters) = @_;
}

sub getElementText {
  my $self = shift;
  #print STDERR "retrieving element text for ",$self->{'path'},"\n";
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];
  #print STDERR $currenttexttarget,"\n";
  return $currenttexttarget->{'text'};
}

sub characters {
  my ($self,$characters) = @_;
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];
 
  if ($currenttexttarget->{'r'} == 1) {
  #print STDERR "characters called with $characters->{'Data'}\n";
  if (not defined $currenttexttarget->{'text'}) { $currenttexttarget->{'text'} = ''; }
  	$currenttexttarget->{'text'} = $currenttexttarget->{'text'} . $characters->{'Data'};
  }
 #print STDERR "Get Characters: $characters->{'Data'} \n";
}

sub comment {
  my ($self,$comment) = @_;
  #print STDERR "Doing Comment\n";
}

sub processing_instruction {
  my ($self,$pi) = @_;
  #print STDERR "Doing $pi\n";
}

sub convertFsubsetToHash{
        my $fname=shift;
        my $xml = new XML::Simple(KeepRoot=>1);
        my $hash=$xml->XMLin($fname);
        return $hash->{'ref_data'};
}
sub writeToFile {
	my $ic=shift;
	my $measType=shift;
	my $str=shift;
	my $file_name=$ic->expand("{{WORKLIST/ITEM|basename}}");
	my $data_file_dir=$ic->expand("{{CONFIG/parameters/{{SYSTEM/RUN/FLOWCD}}.ora_datafile_dir}}");
	#if ( -e $data_file_dir.'/'.$file_name.'.'.$measType ) {
		`echo $str >> $data_file_dir/$file_name.$measType`;
	#}
}

1;

