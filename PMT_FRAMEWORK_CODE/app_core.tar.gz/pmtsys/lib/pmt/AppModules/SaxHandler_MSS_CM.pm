package AppModules::SaxHandler_MSS_CM;

use strict;
use Carp;

use base qw(XML::SAX::Base);
use PMTUtilities qw(partial);
use Time::HiRes qw(time);

sub new {
  my $class = shift;
  my %params = @_;
  my $o = {};
  $o->{'initialcontext'} = $params{'initialcontext'};
  $o->{'xnode'} = $params{'xnode'};
  my $ic = $params{'initialcontext'};
  $o->{'currentelement'} = [];
  $o->{'path'} = '';
  $o->{'currenttext'} = undef;
  $o->{'texttargets'} = {};
  $o->{'currenttexttarget'} = [];
  $o->{'state'} = {};
	$o->{'io_out'} = undef; #$params{'out'};
  $o->{'writer'} = undef; #$params{'writer'};
  $o->{'record_count'} = 0;
  $o->{'error_count'} = 0;
  $o->{'process_start'} = undef;
  $o->{'process_end'} = undef;
  $o->{'field_separator'} = ',';
  $o->{'xnode'} = $params{'xnode'};

  $o->{'endhandler_stack'} = [];
  $o->{'starthandler_stack'} = [];

  if ($params{'out'} and not $params{'writer'}) {
    $o->{'writer'} = partial(
      sub { my $self = shift; my $ofile = shift; my $r = shift; my $line=join($self->{'field_separator'},@$r); print $ofile "$line\n"; },
      $o,$params{'out'}
    );
    $o->{'io_out'} = undef;
  }
  elsif ($params{'writer'}) {
    $o->{'writer'} = $params{'writer'};
  }

  $o->{'state'}={ 'runseq' => $o->{'initialcontext'}->expand('{{SYSTEM/RUN/RUNSEQ}}')};
  

  print STDERR "RunSequence = $o->{'state'}->{'runseq'} \n";
 
  $o->{'elementstarthandlers'} = {
    'raml'=>partial(
      sub {
        my $self = shift; my $e = shift; 
      },
      $o
    ),
    'raml.cmData.header.log'=>partial(
      sub { 
        my $self = shift; my $e = shift; 
        my $attributes = $e->{'Attributes'};
        $self->{'state'}->{'log'}->{'dateTime'} = $attributes->{'{}dateTime'}->{'Value'};
	$self->{'state'}->{'log'}->{'dateTime'} =~ s/T/ /;
      } , $o
    ),
    'raml.cmData.managedObject'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        my $attributes = $e->{'Attributes'};
		$self->{'state'}->{'managedObject'}->{'class'} = $attributes->{'{}class'}->{'Value'};
		$self->{'state'}->{'managedObject'}->{'version'} = $attributes->{'{}version'}->{'Value'};		
		$self->{'state'}->{'managedObject'}->{'distName'} = $attributes->{'{}distName'}->{'Value'};				
		$self->{'state'}->{'managedObject'}->{'id'} = $attributes->{'{}id'}->{'Value'};				
      } ,$o
    ),
    'raml.cmData.managedObject.p'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        my $attributes = $e->{'Attributes'};		
	$self->{'currenttexttarget'}->[-1]->{'r'} = 1;
	$self->{'state'}->{'managedObject'}->{'p'}->{'name'}=$attributes->{'{}name'}->{'Value'};
      } ,$o
    ),
    'raml.cmData.managedObject.list'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        my $attributes = $e->{'Attributes'};		
	$self->{'state'}->{'managedObject'}->{'list'}->{'name'} = $attributes->{'{}name'}->{'Value'};
	$self->{'state'}->{'managedObject'}->{'list'}->{'item'}->{'id'}=0;
      } ,$o
    ),
    'raml.cmData.managedObject.list.p'=> partial(
      sub {
        my $self = shift; my $e = shift; 
		$self->{'currenttexttarget'}->[-1]->{'r'} = 1;
      }, $o
    ),
    'raml.cmData.managedObject.list.item'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
	$self->{'state'}->{'managedObject'}->{'list'}->{'item'}->{'p'}={};
	$self->{'state'}->{'managedObject'}->{'list'}->{'item'}->{'id'}++;
      } ,$o
	),
    'raml.cmData.managedObject.list.item.p'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
        my $attributes = $e->{'Attributes'};	
	$self->{'state'}->{'managedObject'}->{'list'}->{'item'}->{'p'}->{'name'}= $attributes->{'{}name'}->{'Value'};
        $self->{'currenttexttarget'}->[-1]->{'r'} = 1;
      } ,$o	  
    )
  };
  $o->{'elementendhandlers'} = {
    'raml'=>partial(
      sub {
        my $self = shift; my $e = shift; 
      },
      $o
    ),
    'raml.cmData.header.log'=>partial(
      sub { 
        my $self = shift; my $e = shift; 
        my $attributes = $e->{'Attributes'};
        $self->{'state'}->{'startTime'} = $attributes->{'{}startTime'}->{'Value'};
        $self->{'state'}->{'interval'} = $attributes->{'{}interval'}->{'Value'};
      } , $o
    ),
    'raml.cmData.managedObject'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
      } ,$o
    ),
    'raml.cmData.managedObject.p'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
		my $text = $self->getElementText();
		# write out TS_MEAS , $self->{'state'}->{'managedObject'}->{'class'} , $self->{'state'}->{'managedObject'}->{'id'} , $self->{'state'}->{'managedObject'}->{'version'} , $self->{'state'}->{'managedObject'}->{'distName'} ,  origin, NULL, $attributes->{'{}name'}->{'Value'} , get the saved character
        my $outline = [
						$self->{'state'}->{'log'}->{'dateTime'},
						$self->{'state'}->{'managedObject'}->{'class'},
						$self->{'state'}->{'managedObject'}->{'id'},
						$self->{'state'}->{'managedObject'}->{'version'},
						$self->{'state'}->{'managedObject'}->{'distName'},
						$self->{'origin'},
						'','',
						$self->{'state'}->{'managedObject'}->{'p'}->{'name'},
						$text
					];

          if (defined $self->{'writer'}) {
            $self->{'writer'}->($outline);
          }
										
		#$self->{'state'}->{'managedObject'}->{'p'}->{'name'}->{$attributes->{'{}name'}->{'Value'}}=$e->{'LocalName'};
        #print STDERR "Handling a PMMResult.MO\n"; 
      } ,$o
    ),
    'raml.cmData.managedObject.list'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
		undef $self->{'state'}->{'managedObject'}->{'list'}->{'name'};
      } ,$o
    ),
    'raml.cmData.managedObject.list.p'=> partial(
      sub {
        my $self = shift; my $e = shift; 
		my $text = $self->getElementText();
		# Writing out TS_MEAS , $self->{'state'}->{'managedObject'}->{'class'} , $self->{'state'}->{'managedObject'}->{'id'} , $self->{'state'}->{'managedObject'}->{'version'} , $self->{'state'}->{'managedObject'}->{'distName'} ,  origin, $self->{'state'}->{'managedObject'}->{'list'}->{'name'}, 'OPTIONS' , get the saved character
	my 	$outline = [
						$self->{'state'}->{'log'}->{'dateTime'},
						$self->{'state'}->{'managedObject'}->{'class'},
						$self->{'state'}->{'managedObject'}->{'id'},
						$self->{'state'}->{'managedObject'}->{'version'},
						$self->{'state'}->{'managedObject'}->{'distName'},
						$self->{'origin'},
						$self->{'state'}->{'managedObject'}->{'list'}->{'name'},'',
						'OPTIONS',
						$text
					];		

          if (defined $self->{'writer'}) {
            $self->{'writer'}->($outline);
          }
					
		#$self->{'state'}->{'managedObject'}->{'list'}->{'p'}->{$e->{'LocalName'}}='';		
      }, $o
    ),
    'raml.cmData.managedObject.list.item'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
		# Write out the array in one line
      } ,$o
	),
    'raml.cmData.managedObject.list.item.p'=> partial(
      sub { 
        my $self = shift; my $e = shift; 
		my $text = $self->getElementText();		
		# Writing out TS_MEAS , $self->{'state'}->{'managedObject'}->{'class'} , $self->{'state'}->{'managedObject'}->{'id'} , $self->{'state'}->{'managedObject'}->{'version'} , $self->{'state'}->{'managedObject'}->{'distName'} ,  origin, $self->{'state'}->{'managedObject'}->{'list'}->{'name'}, $attributes->{'{}name'}->{'Value'} , get the saved character		
my 		$outline = [
						$self->{'state'}->{'log'}->{'dateTime'},
						$self->{'state'}->{'managedObject'}->{'class'},
						$self->{'state'}->{'managedObject'}->{'id'},
						$self->{'state'}->{'managedObject'}->{'version'},
						$self->{'state'}->{'managedObject'}->{'distName'},
						$self->{'origin'},
						$self->{'state'}->{'managedObject'}->{'list'}->{'name'},
						$self->{'state'}->{'managedObject'}->{'list'}->{'item'}->{'id'},
						$self->{'state'}->{'managedObject'}->{'list'}->{'item'}->{'p'}->{'name'},
						$text
					];				

          if (defined $self->{'writer'}) {
            $self->{'writer'}->($outline);
          }
					
		#$self->{'state'}->{'managedObject'}->{'list'}->{'item'}->{'p'}->{$attributes->{'{}name'}->{'Value'}}=$e->{'LocalName'};
      } ,$o	  
    )
};
  $o->{'currentelementhandler'} = undef;
  $o->{'texthandler'} = undef;

  bless $o;
  return $o;
}

sub getProcessStatistics {
  my $self = shift;
  #print "Doing ProcessStatistics\n";
  my $td = $self->{'process_end'} - $self->{'process_start'};
  my $rate = $self->{'record_count'} / $td; 
  my $s = {
    start_time=>$self->{'process_start'},
    end_time=>$self->{'process_end'},
    record_count=>$self->{'record_count'},
    error_count=>$self->{'error_count'},
    parse_rate=>$rate
  };
  #print "Done ProcessStatistics\n";
  return $s;
}

sub initialize {
  my $self = shift;

  #print STDERR "Doing initialize in SaxHandler\n";
  #print STDERR "And the lookups are: ",Dumper($self->{'lookup'}),"\n";
  $self->{'currentelement'} = [];
  $self->{'path'} = '';
  $self->{'currenttext'} = undef;
  $self->{'texttargets'} = {};
  $self->{'currenttexttarget'} = [];
  $self->{'state'} = {};
	$self->{'io_out'} = undef; #$params{'out'};
  $self->{'writer'} = undef; #$params{'writer'};
  $self->{'record_count'} = 0;
  $self->{'process_start'} = undef;
  $self->{'process_end'} = undef;

  $self->{'ref_file'}={};
  my $ic = $self->{'initialcontext'};
  $self->{'origin'}=$ic->expand('{{WORKLIST/ITEM|regExtract .*-(\w+)\.xml}}');
  print STDERR "sarwesh=$self->{'origin'}\n";
}

sub getDataSummary {
  return {};
}

sub setIOSpec {
  my $self = shift;
  my %params = @_;
  if ($params{'out'} and not $params{'writer'}) {
    $self->{'writer'} = partial(
      sub { my $self = shift; my $ofile = shift; my $r = shift; my $line=join($self->{'field_separator'},@$r); print $ofile "$line\n"; },
      $self,$params{'out'}
    );
    $self->{'io_out'} = undef;
  }
  elsif ($params{'writer'}) {
    $self->{'writer'} = $params{'writer'};
  }
}
sub write_record {
  my $self = shift;
  my $io = $self->{'io_out'};
  my %args = @_;
  my $line = $args{'line'};
  #print STDERR "line: $line";
  print $io $line;
}

sub start_document {
  my ($self,$doc) = @_;
  $self->{'process_start'} = time();
}

sub end_document {
  my ($self,$doc) = @_;
  #$self->{'io_out'}->close();
  $self->{'process_end'} = time();
  #my $interval = $self->{'process_end'} - $self->{'process_start'};
  #my $processrate = $self->{'record_count'} / $interval;
  #my $rcount = $self->{'record_count'};
  #my $ic = $self->{'initialcontext'};
  #$ic->log(message=>sprintf("Processing rate: $rcount records in %.3f seconds,%.3f records/second",$interval,$processrate),domain=>"system",level=>"info");
}

sub getElementStartHandler {
  my $self = shift;
  my $path = $self->{'path'};
  #print STDERR "searching for handler for $path\n";
  if( not defined $self->{'elementstarthandlers'}->{$path} and scalar @{$self->{'starthandler_stack'}}) {
    return $self->{'starthandler_stack'}->[-1];
  }
  elsif (defined $self->{'elementstarthandlers'}->{$self->{'path'}}) {
    return $self->{'elementstarthandlers'}->{$self->{'path'}};
  }
  return partial(sub { print STDERR "dummy start function for $path\n"; });

  #for my $k (keys %{$self->{'elementstarthandlers'}}) {
    #print STDERR "checking $k\n";
  #  if ($path =~ m/^${k}$/) {
  #    return $self->{'elementstarthandlers'}->{$k};
  #  }
  #}
  #return partial(sub { print STDERR "dummy start function for $path\n"; });
}

sub getElementEndHandler {
  my $self = shift;
  my $path = $self->{'path'};
  if( not defined $self->{'elementendhandlers'}->{$path} and scalar @{$self->{'endhandler_stack'}}) {
    return $self->{'endhandler_stack'}->[-1];
  }
  elsif (defined $self->{'elementendhandlers'}->{$path}) {
    return $self->{'elementendhandlers'}->{$path};
  }
  return partial(sub { print STDERR "dummy end function for $path\n"; });
}

sub getCharacterHandler {
}

sub start_element {
  my ($self,$el) = @_;
  my $locname = $el->{'LocalName'};
  if (scalar @{$self->{'currentelement'}} == 0) {
    #print STDERR "Starting document with element $locname\n";
  }
  push @{$self->{'currentelement'}},$locname;
  $self->{'path'} = join ('.',@{$self->{'currentelement'}});
  #print STDERR "Starting element ",$el->{'LocalName'},"\n";

  push @{$self->{'currenttexttarget'}},{'r'=>0,'text'=>undef};
  my $elhandler = $self->getElementStartHandler();
  $elhandler->($el);
}

sub end_element {
  my ($self,$el) = @_;

  use Data::Dumper;
  eval {
    my $elhandler = $self->getElementEndHandler();
    $elhandler->($el);
  };
  if ($@) {
    print STDERR "In SaxHandler end_elemenet: An error has occurred",Dumper($@),"\n";
  }

  #print STDERR "popping from texttargets for ",$self->{'path'},"\n";
  my $tt = pop @{$self->{'currenttexttarget'}};
  pop @{$self->{'currentelement'}};
  $self->{'path'} = join ('.',@{$self->{'currentelement'}});
  #print STDERR "Starting element ",$el->{'LocalName'},"\n";
  #print STDERR "Ending element\n";
}

sub setElementText {
  my ($self,$characters) = @_;
}

sub getElementText {
  my $self = shift;
  #print STDERR "retrieving element text for ",$self->{'path'},"\n";
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];
  #print STDERR $currenttexttarget,"\n";
  return $currenttexttarget->{'text'};
}

sub characters {
  my ($self,$characters) = @_;
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];
 
  if ($currenttexttarget->{'r'} == 1) {
  #print STDERR "characters called with $characters->{'Data'}\n";
  if (not defined $currenttexttarget->{'text'}) { $currenttexttarget->{'text'} = ''; }
  	$currenttexttarget->{'text'} = $currenttexttarget->{'text'} . $characters->{'Data'};
  }
 #print STDERR "Get Characters: $characters->{'Data'} \n";
}

sub comment {
  my ($self,$comment) = @_;
  #print STDERR "Doing Comment\n";
}

sub processing_instruction {
  my ($self,$pi) = @_;
  #print STDERR "Doing $pi\n";
}




1;

