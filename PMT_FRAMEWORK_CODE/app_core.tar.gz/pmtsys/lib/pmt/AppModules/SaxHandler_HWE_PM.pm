package AppModules::SaxHandler_HWE_PM;

use strict;
use Carp;

use base qw(XML::SAX::Base);
use PMTUtilities qw(partial);
use Time::HiRes qw(time);

use XML::Simple;

sub new {
  my $class = shift;
  my %params = @_;
  my $o = {};
  $o->{'initialcontext'} = $params{'initialcontext'};
  $o->{'xnode'} = $params{'xnode'};
  my $ic = $params{'initialcontext'};
  $o->{'currentelement'} = [];
  $o->{'path'} = '';
  $o->{'currenttext'} = undef;
  $o->{'texttargets'} = {};
  $o->{'currenttexttarget'} = [];
  $o->{'state'} = {};
        $o->{'io_out'} = undef; #$params{'out'};
  $o->{'writer'} = undef; #$params{'writer'};
  $o->{'record_count'} = 0;
  $o->{'error_count'} = 0;
  $o->{'process_start'} = undef;
  $o->{'process_end'} = undef;
  $o->{'field_separator'} = ',';
  $o->{'xnode'} = $params{'xnode'};

  $o->{'endhandler_stack'} = [];
  $o->{'starthandler_stack'} = [];

  if ($params{'out'} and not $params{'writer'}) {
    $o->{'writer'} = partial(
      sub { my $self = shift; my $ofile = shift; my $r = shift; my $line=join($self->{'field_separator'},@$r); print $ofile "$line\n"; },
      $o,$params{'out'}
    );
    $o->{'io_out'} = undef;
  }
  elsif ($params{'writer'}) {
    $o->{'writer'} = $params{'writer'};
  }

  $o->{'state'}={ 'runseq' => $o->{'initialcontext'}->expand('{{SYSTEM/RUN/RUNSEQ}}')};


  $o->{'elementstarthandlers'} = {
    'measCollecFile.fileHeader'=>partial(
      sub {
        my $self = shift; my $e = shift;
                my $attributes = $e->{'Attributes'};
                $self->{'state'}->{'fileFormatVersion'}= $attributes->{'{}fileFormatVersion'}->{'Value'};
                $self->{'state'}->{'vendorName'}= $attributes->{'{}vendorName'}->{'Value'};
      },
      $o
    ),
    'measCollecFile.fileHeader.fileSender'=>partial(
      sub {
        my $self = shift; my $e = shift;
        my $attributes = $e->{'Attributes'};
        $self->{'state'}->{'elementType'}= $attributes->{'{}elementType'}->{'Value'};
      } , $o
    ),
    'measCollecFile.fileHeader.measCollec'=> partial(
      sub {
        my $self = shift; my $e = shift;
        my $attributes = $e->{'Attributes'};
                $self->{'state'}->{'beginTime'} = $attributes->{'{}beginTime'}->{'Value'};
		($self->{'state'}->{'beginTime'})=($self->{'state'}->{'beginTime'} =~ /^(.*)\+.*$/);
		$self->{'state'}->{'beginTime'}=~ s/T//g;
		$self->{'state'}->{'beginTime'}=~ s/://g;
		$self->{'state'}->{'beginTime'}=~ s/\-//g;
      } ,$o
    ),
    'measCollecFile.measData.managedElement'=> partial(
      sub {
        my $self = shift; my $e = shift;
        my $attributes = $e->{'Attributes'};
                $self->{'state'}->{'userLabel'} = $attributes->{'{}userLabel'}->{'Value'};
      } ,$o
    ),
    'measCollecFile.measData.measInfo'=> partial(
      sub {
        my $self = shift; my $e = shift;
        my $attributes = $e->{'Attributes'};
        $self->{'state'}->{'measInfoId'} = $attributes->{'{}measInfoId'}->{'Value'};
        $self->{'skip'}=1 if (not defined $self->{'meta'}->{'fsubset'}->{$self->{'state'}->{'measInfoId'}});
      } ,$o
    ),
    'measCollecFile.measData.measInfo.granPeriod'=> partial(
      sub {
        my $self = shift; my $e = shift;
                return if(defined $self->{'skip'} and $self->{'skip'}==1);
                 my $attributes = $e->{'Attributes'};
                 $self->{'state'}->{'duration'} = $attributes->{'{}duration'}->{'Value'};
                 $self->{'state'}->{'endTime'} = $attributes->{'{}endTime'}->{'Value'};
                ($self->{'state'}->{'endTime'})=($self->{'state'}->{'endTime'} =~ /^(.*)\+.*$/);
                $self->{'state'}->{'endTime'}=~ s/T//g;
                $self->{'state'}->{'endTime'}=~ s/://g;
		$self->{'state'}->{'endTime'}=~ s/\-//g;

      }, $o
    ),
    'measCollecFile.measData.measInfo.measTypes'=> partial(
      sub {
        my $self = shift; my $e = shift;
                return if(defined $self->{'skip'} and $self->{'skip'}==1);
                $self->{'currenttexttarget'}->[-1]->{'r'} = 1;
      } ,$o
        ),
    'measCollecFile.measData.measInfo.measValue'=> partial(
      sub {
        my $self = shift; my $e = shift;
                return if(defined $self->{'skip'} and $self->{'skip'}==1);
        my $attributes = $e->{'Attributes'};
                $self->{'state'}->{'measObjLdn'}= $attributes->{'{}measObjLdn'}->{'Value'};
      } ,$o
    ),
    'measCollecFile.measData.measInfo.measValue.measResults'=> partial(
      sub {
        my $self = shift; my $e = shift;
                return if(defined $self->{'skip'} and $self->{'skip'}==1);
        $self->{'currenttexttarget'}->[-1]->{'r'} = 1;
      } ,$o
    )
  };
  $o->{'elementendhandlers'} = {
    'measCollecFile.fileHeader'=>partial(
      sub {
        my $self = shift; my $e = shift;
      },
      $o
    ),
    'measCollecFile.fileHeader.fileSender'=>partial(
      sub {
        my $self = shift; my $e = shift;
        my $attributes = $e->{'Attributes'};
      } , $o
    ),
    'measCollecFile.fileHeader.measCollec'=> partial(
      sub {
        my $self = shift; my $e = shift;
        my $attributes = $e->{'Attributes'};
      } ,$o
    ),
    'measCollecFile.measData.managedElement'=> partial(
      sub {
        my $self = shift; my $e = shift;
        my $attributes = $e->{'Attributes'};
      } ,$o
    ),
    'measCollecFile.measData.measInfo'=> partial(
      sub {
        my $self = shift; my $e = shift;
        my $attributes = $e->{'Attributes'};
                undef $self->{'skip'};
      } ,$o
    ),
    'measCollecFile.measData.measInfo.granPeriod'=> partial(
      sub {
        my $self = shift; my $e = shift;
                return if(defined $self->{'skip'} and $self->{'skip'}==1);
      }, $o
    ),
    'measCollecFile.measData.measInfo.measTypes'=> partial(
      sub {
        my $self = shift; my $e = shift;
                return if(defined $self->{'skip'} and $self->{'skip'}==1);
                $self->{'state'}->{'measTypes'}=$self->getElementText();
                $self->{'state'}->{'measTypes'}=~ s/^\s+//;
                $self->{'state'}->{'measTypes'}=~ s/\s+$//;
      } ,$o
        ),
    'measCollecFile.measData.measInfo.measValue'=> partial(
      sub {
        my $self = shift; my $e = shift;
                return if(defined $self->{'skip'} and $self->{'skip'}==1);

                # Generating Attribute Value
                # i need  $self->{'state'}->{'measObjLdn'}  ,   $self->{'state'}->{'elementType'} , $self->{'state'}->{'beginTime'}
                my $parent='NULL';
                if($self->{'origin'} =~ /^(.*)\.(.*)$/)
                {
                        $parent=$1;
                }
                my $obj_ldn=$self->{'state'}->{'measObjLdn'};

		my $techonology;

		if($self->{'state'}->{'elementType'} =~ /GSM/){
			$techonology='2G';
		}
		else {
			$techonology='3G';
		}

                return if(defined $self->{'obj_ldn_cache'}->{$obj_ldn});
                my $lx;
                if ( $parent eq 'NULL'){
                        $lx=1;
                }
                else {
                        $lx=2;
                }
                while( $obj_ldn =~ /(.+)\/(.+)\:(.+)$/ ){
                        $self->{'obj_ldn_cache'}->{$obj_ldn}=1;
                        my $obj_level= ( $obj_ldn =~ tr/\/// ) + $lx;
                        my $obj_tag=$2;
                        my $obj_parent=$1;
                        my $obj_attributes=$3;
                        my $obj_parent_type;

                        if($parent eq 'NULL'){
                                $obj_parent_type='ROOT';
                        }
                        else {
                                $obj_parent_type='NODEB';
                        }
                        my @attributes = split(/\,/,$obj_attributes);
                        if(scalar @attributes == 1 ){
                                my $attribute_name = 'OBJ_LABEL';
                                my $attribute_value = $attributes[0];

                                # check for single attribute

                                my @object_value = split (/\=/,$attributes[0]);

                                #if it is the case => change the attr / val pair
                                if( @object_value > 1 ){
                                        $attribute_name= $object_value[0];
                                        $attribute_value=$object_value[1];
                                }
                                if( $obj_parent =~ /.*\/(\S+)\:.+$/){
                                        $obj_parent_type= $1;
                                }
                                my $record=[
                                                        "\"".$self->{'origin'}."\"",
                                                        "\"".$self->{'file_ts'}."\"",
                                                        "\"".'ATTRIBUTE'."\"" ,
                                                        "\"".$self->{'state'}->{'beginTime'}."\"" ,
                                                        "\"".$self->{'state'}->{'elementType'}."\"",
                                                        "\"".$obj_ldn."\"" ,
                                                        "\"".$obj_tag."\"",
                                                        "\"".$attribute_name."\"",
                                                        "\"".$attribute_value."\"",
                                                        "\"".$obj_parent."\"",
                                                        "\"".$obj_level."\"",
							"\"".$techonology."\"",
                                                        "\"".$obj_parent_type."\""
                                ];
								if (defined $self->{'writer'}) {
								$self->{'writer'}->($record);
								}								
                        }
                        else {
                                foreach my $iattribute (@attributes){
                                        my @object_value = split (/\=/,$iattribute);
                                        my $attribute_name= $object_value[0];
                                        my $attribute_value=$object_value[1];
                                        if( $obj_parent =~ /.*\/(\S+)\:.+$/){
                                                $obj_parent_type= $1;
                                        }
                                my $record=[
                                                        "\"".$self->{'origin'}."\"",
                                                        "\"".$self->{'file_ts'}."\"",
                                                        "\"".'ATTRIBUTE'."\"" ,
                                                        "\"".$self->{'state'}->{'beginTime'}."\"" ,
                                                        "\"".$self->{'state'}->{'elementType'}."\"",
                                                        "\"".$obj_ldn."\"",
                                                        "\"".$obj_tag."\"",
                                                        "\"".$attribute_name."\"",
                                                        "\"".$attribute_value."\"",
                                                        "\"".$obj_parent."\"",
                                                        "\"".$obj_level."\"",
							"\"".$techonology."\"",
                                                        "\"".$obj_parent_type."\""
                                ];
								if (defined $self->{'writer'}) {
								$self->{'writer'}->($record);
								}								
                          }
                        }
                        $obj_ldn=$obj_parent;
                        last if (defined $self->{'obj_ldn_cache'}->{$obj_ldn} );
                }
                if( defined $obj_ldn && not defined $self->{'obj_ldn_cache'}->{$obj_ldn} ){
                        $self->{'obj_ldn_cache'}->{$obj_ldn}=1;
                        if( $parent eq 'NULL' || !($obj_ldn =~ /NODEB/i)){
                                my $record=[
                                                        "\"".$self->{'origin'}."\"",
                                                        "\"".$self->{'file_ts'}."\"",
                                                        "\"".'ATTRIBUTE'."\"" ,
                                                        "\"".$self->{'state'}->{'beginTime'}."\"" ,
                                                        "\"".$self->{'state'}->{'elementType'}."\"",
                                                        "\"".$obj_ldn."\"",
                                                        "\"".'ROOT'."\"",
                                                        "\"".'OBJ_LABEL'."\"",
                                                        "\"".$obj_ldn."\"",
                                                        "\"".'NULL'."\"",
                                                        "\"1\"",
							"\"".$techonology."\"",
                                                        "\"".'NULL'."\""
                                ];
								if (defined $self->{'writer'}) {
								$self->{'writer'}->($record);
								}								
                        }
                        else {
                        my $record=[
                                                        "\"".$self->{'origin'}."\"",
                                                        "\"".$self->{'file_ts'}."\"",
                                                        "\"".'ATTRIBUTE'."\"" ,
                                                        "\"".$self->{'state'}->{'beginTime'}."\"" ,
                                                        "\"".$self->{'state'}->{'elementType'}."\"",
                                                        "\"".$obj_ldn."\"",
                                                        "\"".'NODEB'."\"",
                                                        "\"".'OBJ_LABEL'."\"",
                                                        "\"".$obj_ldn."\"",
                                                        "\"".$parent."\"",
                                                        "\"2\"",
							"\"".$techonology."\"",
                                                        "\"".'RNC'."\""
                                ];
						if (defined $self->{'writer'}) {
						$self->{'writer'}->($record);
						}
                        my $record=[
                                                        "\"".$self->{'origin'}."\"",
                                                        "\"".$self->{'file_ts'}."\"",
                                                        "\"".'ATTRIBUTE'."\"" ,
                                                        "\"".$self->{'state'}->{'beginTime'}."\"" ,
                                                        "\"".$self->{'state'}->{'elementType'}."\"",
                                                        "\"".$parent."\"" ,
                                                        "\"".'RNC'."\"",
                                                        "\"".'OBJ_LABEL'."\"",
                                                        "\"".$obj_ldn."\"",
                                                        "\"".'NULL'."\"",
                                                        "\"1\"",
							"\"".$techonology."\"",
                                                        "\"".'NULL'."\""
                                ];
								if (defined $self->{'writer'}) {
								$self->{'writer'}->($record);
								}								
                        }
                }
      } ,$o
    ),
    'measCollecFile.measData.measInfo.measValue.measResults'=> partial(
      sub {
        my $self = shift; my $e = shift;
                return if(defined $self->{'skip'} and $self->{'skip'}==1);
                $self->{'state'}->{'measResults'}=$self->getElementText();
                $self->{'state'}->{'measResults'}=~ s/^\s+//;
                $self->{'state'}->{'measResults'}=~ s/\s+$//;
                my @mValues = split( / +/, $self->{'state'}->{'measResults'} );
                my @tValues = split( / +/, $self->{'state'}->{'measTypes'} );
                my $c   = 0;
                my @val = ();
                $val[249]='';
                # swap the order
                # based on the order defined in the REF data
                foreach my $type (@tValues) {
                                # counter defined
                                if ( exists $self->{'meta'}->{'fsubset'}->{$self->{'state'}->{'measInfoId'}}->{cnt}->{$type} ) {
                                                $val[ $self->{'meta'}->{'fsubset'}->{$self->{'state'}->{'measInfoId'}}->{cnt}->{$type}->{'cnt_index'} - 1] = &getnum($mValues[$c]); # get NUMBER values/Exclude NILL
                                                $c++;
                                } else {
                                                $c++;  # move in the types array = ignore not existing counters
                                }
                }

       		my ( $object_tag, $tmp ) = ( $self->{'state'}->{'measObjLdn'} =~ /.*\/(\S+)\:(.+)$/ );
    		$object_tag = 'ROOT'   unless defined $object_tag;
  		if ($object_tag eq 'ROOT' and ($self->{'state'}->{'measObjLdn'} =~ /NODEB/i)) {
        		$object_tag = 'NODEB';
  		}


                my $record=[
					"\"".$self->{'origin'}."\"",
                                        "\"".$self->{'file_ts'}."\"",
                  "\"".'COUNTER'."\"" , "\"".$self->{'state'}->{'beginTime'}."\"" , "\"".$self->{'state'}->{'endTime'}."\"" , "\"".$self->{'state'}->{'measObjLdn'}."\"" ,
                                   , "\"".$self->{'state'}->{'userLabel'}."\"" , "\"".$self->{'state'}->{'elementType'}."\"" , "\"".$self->{'state'}->{'fileFormatVersion'}."\"" ,
                                   "\"".$self->{'state'}->{'duration'}."\"",  "\"".$self->{'meta'}->{'fsubset'}->{$self->{'state'}->{'measInfoId'}}->{fset_id}."\"",
                                   "\"".$self->{'meta'}->{'fsubset'}->{$self->{'state'}->{'measInfoId'}}->{fset_name}."\"",
                                   "\"".$self->{'state'}->{'measInfoId'}."\"",
                                   "\"".$self->{'meta'}->{'fsubset'}->{$self->{'state'}->{'measInfoId'}}->{fsubset_name}."\"","\"".$object_tag."\"",
                        , "\"".$self->{'meta'}->{'fsubset'}->{$self->{'state'}->{'measInfoId'}}->{'cnt_number'}."\"",@val
                                        ];
					if (defined $self->{'writer'}) {
					$self->{'writer'}->($record);
					}
      } ,$o
    )
};
  $o->{'currentelementhandler'} = undef;
  $o->{'texthandler'} = undef;

  bless $o;
  return $o;
}

sub getProcessStatistics {
  my $self = shift;
  my $td = $self->{'process_end'} - $self->{'process_start'};
  my $rate = $self->{'record_count'} / $td;
  my $s = {
    start_time=>$self->{'process_start'},
    end_time=>$self->{'process_end'},
    record_count=>$self->{'record_count'},
    error_count=>$self->{'error_count'},
    parse_rate=>$rate
  };
  return $s;
}

sub initialize {
  my $self = shift;

  $self->{'currentelement'} = [];
  $self->{'path'} = '';
  $self->{'currenttext'} = undef;
  $self->{'texttargets'} = {};
  $self->{'currenttexttarget'} = [];
  $self->{'state'} = {};
  $self->{'io_out'} = undef;
  $self->{'writer'} = undef;
  $self->{'record_count'} = 0;
  $self->{'process_start'} = undef;
  $self->{'process_end'} = undef;

  $self->{'ref_file'}='/opt/PMT/pmtsys/lib/pmt/AppModules/Ref_Data/HWE_PM/fsubset_ref.xml';
  $self->{'meta'}=convertFsubsetToHash($self->{'ref_file'});
  my $ic = $self->{'initialcontext'};
  $self->{'origin'}=$ic->expand('{{WORKLIST/ITEM|basename|regExtract A.*\\d+_([a-zA-Z0-9._]+)\.xml}}');  #A20140623.1500+0200-1600+0200_03BKCBUH.14THW_NODEB_1.xml
  my $tmp_date = $ic->expand("{{WORKLIST/ITEM|basename|regExtract A(\\d+)\.\\d+\+.*\.xml}}");
  my $tmp_hour = $ic->expand("{{WORKLIST/ITEM|basename|regExtract A\\d+\.(\\d+)\+.*\.xml}}");
  $self->{'file_ts'}=$tmp_date.$tmp_hour;

  #print STDERR "sarwesh=$self->{'origin'}\n";
}

sub getDataSummary {
  return {};
}

sub setIOSpec {
  my $self = shift;
  my %params = @_;
  if ($params{'out'} and not $params{'writer'}) {
    $self->{'writer'} = partial(
      sub { my $self = shift; my $ofile = shift; my $r = shift; my $line=join($self->{'field_separator'},@$r); print $ofile "$line\n"; },
      $self,$params{'out'}
    );
    $self->{'io_out'} = undef;
  }
  elsif ($params{'writer'}) {
    $self->{'writer'} = $params{'writer'};
  }
}
sub write_record {
  my $self = shift;
  my $io = $self->{'io_out'};
  my %args = @_;
  my $line = $args{'line'};
  print $io $line;
}

sub start_document {
  my ($self,$doc) = @_;
  $self->{'process_start'} = time();
}

sub end_document {
  my ($self,$doc) = @_;
  $self->{'process_end'} = time();
}

sub getElementStartHandler {
  my $self = shift;
  my $path = $self->{'path'};
  if( not defined $self->{'elementstarthandlers'}->{$path} and scalar @{$self->{'starthandler_stack'}}) {
    return $self->{'starthandler_stack'}->[-1];
  }
  elsif (defined $self->{'elementstarthandlers'}->{$self->{'path'}}) {
    return $self->{'elementstarthandlers'}->{$self->{'path'}};
  }
  return partial(sub { print STDERR "dummy start function for $path\n"; });
}

sub getElementEndHandler {
  my $self = shift;
  my $path = $self->{'path'};
  if( not defined $self->{'elementendhandlers'}->{$path} and scalar @{$self->{'endhandler_stack'}}) {
    return $self->{'endhandler_stack'}->[-1];
  }
  elsif (defined $self->{'elementendhandlers'}->{$path}) {
    return $self->{'elementendhandlers'}->{$path};
  }
  return partial(sub { print STDERR "dummy end function for $path\n"; });
}

sub getCharacterHandler {
}

sub start_element {
  my ($self,$el) = @_;
  my $locname = $el->{'LocalName'};
  if (scalar @{$self->{'currentelement'}} == 0) {
  }
  push @{$self->{'currentelement'}},$locname;
  $self->{'path'} = join ('.',@{$self->{'currentelement'}});

  push @{$self->{'currenttexttarget'}},{'r'=>0,'text'=>undef};
  my $elhandler = $self->getElementStartHandler();
  $elhandler->($el);
}

sub end_element {
  my ($self,$el) = @_;

  use Data::Dumper;
  eval {
    my $elhandler = $self->getElementEndHandler();
    $elhandler->($el);
  };
  if ($@) {
    print STDERR "In SaxHandler end_elemenet: An error has occurred",Dumper($@),"\n";
  }
  my $tt = pop @{$self->{'currenttexttarget'}};
  pop @{$self->{'currentelement'}};
  $self->{'path'} = join ('.',@{$self->{'currentelement'}});
}

sub setElementText {
  my ($self,$characters) = @_;
}

sub getElementText {
  my $self = shift;
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];
  return $currenttexttarget->{'text'};
}

sub characters {
  my ($self,$characters) = @_;
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];

  if ($currenttexttarget->{'r'} == 1) {
  if (not defined $currenttexttarget->{'text'}) { $currenttexttarget->{'text'} = ''; }
        $currenttexttarget->{'text'} = $currenttexttarget->{'text'} . $characters->{'Data'};
  }
}

sub comment {
  my ($self,$comment) = @_;
}

sub processing_instruction {
  my ($self,$pi) = @_;
}

sub convertFsubsetToHash{
        my $fname=shift;
        my $xml = new XML::Simple(KeepRoot=>1);
        my $hash=$xml->XMLin($fname);
        return $hash->{'ref_data'};
}
sub getnum {
    use POSIX qw(strtod);
    my $str = shift;
    $str =~ s/^\s+//;
    $str =~ s/\s+$//;
    $! = 0;
    my($num, $unparsed) = strtod($str);
    if (($str eq '') || ($unparsed != 0) || $!) {
        return;
    } else {
        return $num;
    }
}



1;

