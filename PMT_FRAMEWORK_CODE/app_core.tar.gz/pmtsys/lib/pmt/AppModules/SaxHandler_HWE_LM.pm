package AppModules::SaxHandler_HWE_LM;

use strict;
use Carp;

use base qw(XML::SAX::Base);
use PMTUtilities qw(partial);
use XML::Simple;
use Time::HiRes qw(time);

sub new {
  my $class = shift;
  my %params = @_;
  my $o = {};
  $o->{'initialcontext'} = $params{'initialcontext'};
  $o->{'xnode'} = $params{'xnode'};
  my $ic = $params{'initialcontext'};
  $o->{'currentelement'} = [];
  $o->{'path'} = '';
  $o->{'currenttext'} = undef;
  $o->{'texttargets'} = {};
  $o->{'currenttexttarget'} = [];
  $o->{'state'} = {};
        $o->{'io_out'} = undef; #$params{'out'};
  $o->{'writer'} = undef; #$params{'writer'};
  $o->{'record_count'} = 0;
  $o->{'error_count'} = 0;
  $o->{'process_start'} = undef;
  $o->{'process_end'} = undef;
  $o->{'field_separator'} = ',';
  $o->{'xnode'} = $params{'xnode'};

  $o->{'endhandler_stack'} = [];
  $o->{'starthandler_stack'} = [];

  if ($params{'out'} and not $params{'writer'}) {
    $o->{'writer'} = partial(
      sub { my $self = shift; my $ofile = shift; my $r = shift; my $line=join($self->{'field_separator'},@$r); print $ofile "$line\n"; },
      $o,$params{'out'}
    );
    $o->{'io_out'} = undef;
  }
  elsif ($params{'writer'}) {
    $o->{'writer'} = $params{'writer'};
  }


  $o->{'elementstarthandlers'} = {
    'LicenseDataFile.LicenseData.NetworkElement'=>partial(
      sub {
        my $self = shift; my $e = shift;
			 my $attributes = $e->{'Attributes'};
			$self->{'NEName'}=$attributes->{'{}NEName'}->{'Value'};
			$self->{'lsn'}=$attributes->{'{}lsn'}->{'Value'};
      },
      $o
    ),
    'LicenseDataFile.LicenseData.NetworkElement.Operator'=>partial(
    sub {
        my $self = shift; my $e = shift;
		my $attributes = $e->{'Attributes'};
		$self->{'opName'}=$attributes->{'{}opName'}->{'Value'};
      } , $o
    ),
	'LicenseDataFile.LicenseData.NetworkElement.Operator.(\w+)' => partial ( sub {
        my $self = shift; my $e = shift;
		if($e->{'LocalName'} =~ /SubNE/)
		{
			my $attributes = $e->{'Attributes'};
			$self->{'SubNEName'}=$attributes->{'{}name'}->{'Value'};
		}
		else {
		$self->{'SubNEName'}='';
			# it is LicItem 
               	 my $attributes = $e->{'Attributes'};
               	 $self->{'LicItem'}=$attributes->{'{}id'}->{'Value'};
               	 $self->{'desc'}=$attributes->{'{}desc'}->{'Value'};
               	 $self->{'allocvalue'}=$attributes->{'{}allocvalue'}->{'Value'};
               	 $self->{'usage'}=$attributes->{'{}usage'}->{'Value'};
        	 $self->{'expireDate'}=$attributes->{'{}expireDate'}->{'Value'};
     	    	 my $outline = [
                                                         $self->{'file_type'},
                                                         $self->{'file_timestamp'},
                                                         $self->{'NEName'},
                                                         $self->{'lsn'},
                                                         $self->{'opName'},
                                                         $self->{'SubNEName'},
                                                         $self->{'LicItem'},
                                                         "\"".$self->{'desc'}."\"",
                                                         $self->{'allocvalue'},
                                                         $self->{'usage'},
                                                         $self->{'expireDate'}
                                                ];
         		 $self->{'record_count'} = $self->{'record_count'} + 1;
        	          if (defined $self->{'io_out'}) {
  	                              my $soutline = join(',',@$outline);
                                	my $of = $self->{'io_out'};
                        	        print $of "$soutline\n";
                 	 }
                	  if (defined $self->{'writer'}) {
        	                $self->{'writer'}->($outline);
	                  }
		
		}
	},$o),
    'LicenseDataFile.LicenseData.NetworkElement.Operator.SubNE.LicItem'=>partial(
	sub {
        my $self = shift; my $e = shift;	
		my $attributes = $e->{'Attributes'};
		$self->{'LicItem'}=$attributes->{'{}id'}->{'Value'};
		$self->{'desc'}=$attributes->{'{}desc'}->{'Value'};
		$self->{'allocvalue'}=$attributes->{'{}allocvalue'}->{'Value'};
		$self->{'usage'}=$attributes->{'{}usage'}->{'Value'};
		$self->{'expireDate'}=$attributes->{'{}expireDate'}->{'Value'};
          my $outline = [
							 $self->{'file_type'},
							 $self->{'file_timestamp'},
							 $self->{'NEName'},
							 $self->{'lsn'},
							 $self->{'opName'},
							 $self->{'SubNEName'},
							 $self->{'LicItem'},
							 "\"".$self->{'desc'}."\"",
							 $self->{'allocvalue'},
							 $self->{'usage'},
							 $self->{'expireDate'}
						];
          $self->{'record_count'} = $self->{'record_count'} + 1;
		  if (defined $self->{'io_out'}) {
				my $soutline = join(',',@$outline);
				my $of = $self->{'io_out'};
				print $of "$soutline\n";
		  }
		  if (defined $self->{'writer'}) {
			$self->{'writer'}->($outline);
		  }

	},$o),
};
  $o->{'elementendhandlers'} = {
    'LicenseDataFile.LicenseData.NetworkElement'=>partial(
      sub {
        my $self = shift; my $e = shift;
      },
      $o
    ),
    'LicenseDataFile.LicenseData.NetworkElement.Operator'=>partial(
      sub {
        my $self = shift; my $e = shift;
      } , $o
    ),
	'LicenseDataFile.LicenseData.NetworkElement.Operator.SubNE' => partial ( sub {
        my $self = shift; my $e = shift;
	},$o),
    'LicenseDataFile.LicenseData.NetworkElement.Operator.SubNE.LicItem'=>partial(
	sub {
	},$o),
};
  $o->{'currentelementhandler'} = undef;
  $o->{'texthandler'} = undef;

  bless $o;
  return $o;
}

sub getProcessStatistics {
  my $self = shift;
  my $td = $self->{'process_end'} - $self->{'process_start'};
  my $rate = $self->{'record_count'} / $td;
  my $s = {
    start_time=>$self->{'process_start'},
    end_time=>$self->{'process_end'},
    record_count=>$self->{'record_count'},
    error_count=>$self->{'error_count'},
    parse_rate=>$rate
  };
  return $s;
}

sub initialize {
  my $self = shift;
  $self->{'currentelement'} = [];
  $self->{'path'} = '';
  $self->{'currenttext'} = undef;
  $self->{'texttargets'} = {};
  $self->{'currenttexttarget'} = [];
  $self->{'state'} = {};
  $self->{'io_out'} = undef; #$params{'out'};
  $self->{'writer'} = undef; #$params{'writer'};
  $self->{'record_count'} = 0;
  $self->{'process_start'} = undef;
  $self->{'process_end'} = undef;
	
  my $ic=$self->{'initialcontext'};
  my $file_name=$ic->expand('{{WORKLIST/ITEM|basename}}');
  $self->{'file_type'} = $1 if($file_name =~ /LM_.*\.(\w+)_\d+.xml/);
  $self->{'file_timestamp'}= $1 if($file_name =~ /LM_.*\.\w+_(\d+).xml/);
  #$self->{'file_timestamp'}=$ic->expand('{{WORKLIST/ITEM|regExtract LM_.*._(\d+).*.xml}}');
  #print STDERR "$self->{'file_type'} and $self->{'file_timestamp'}\n";
}

sub getDataSummary {
  return {};
}

sub setIOSpec {
  my $self = shift;
  my %params = @_;
  if ($params{'out'} and not $params{'writer'}) {
    $self->{'writer'} = partial(
      sub { my $self = shift; my $ofile = shift; my $r = shift; my $line=join($self->{'field_separator'},@$r); print $ofile "$line\n"; },
      $self,$params{'out'}
    );
    $self->{'io_out'} = undef;
  }
  elsif ($params{'writer'}) {
    $self->{'writer'} = $params{'writer'};
  }
}
sub write_record {
  my $self = shift;
  my $io = $self->{'io_out'};
  my %args = @_;
  my $line = $args{'line'};
  #print STDERR "line: $line";
  print $io $line;
}

sub start_document {
  my ($self,$doc) = @_;
  $self->{'process_start'} = time();
}

sub end_document {
  my ($self,$doc) = @_;
  $self->{'process_end'} = time();
}

sub getElementStartHandler {
  my $self = shift;
  my $path = $self->{'path'};
  #print STDERR "searching for handler for $path\n";
  # if( not defined $self->{'elementstarthandlers'}->{$path} and scalar @{$self->{'starthandler_stack'}}) {
    # return $self->{'starthandler_stack'}->[-1];
  # }
  # elsif (defined $self->{'elementstarthandlers'}->{$self->{'path'}}) {
    # return $self->{'elementstarthandlers'}->{$self->{'path'}};
  # }
  # return partial(sub { print STDERR "dummy start function for $path\n"; });
	
  for my $k (keys %{$self->{'elementstarthandlers'}}) {
    if ($path =~ m/^${k}$/i) {
      return $self->{'elementstarthandlers'}->{$k};
    }
  }
  return partial(sub { print STDERR "dummy start function for $path \n"; });
}

sub getElementEndHandler {
  my $self = shift;
  my $path = $self->{'path'};
  print STDERR "searching for handler for $path\n";
  # if( not defined $self->{'elementendhandlers'}->{$path} and scalar @{$self->{'endhandler_stack'}}) {
    # return $self->{'endhandler_stack'}->[-1];
  # }
  # elsif (defined $self->{'elementendhandlers'}->{$path}) {
    # return $self->{'elementendhandlers'}->{$path};
  # }
  # return partial(sub { print STDERR "dummy end function for $path\n"; });
  for my $k (keys %{$self->{'elementendhandlers'}}) {
    if ($path =~ m/^${k}$/i) {
      return $self->{'elementendhandlers'}->{$k};
    }
  }
  return partial(sub { print STDERR "dummy end function for $path\n"; });
}

sub getCharacterHandler {
}

sub start_element {
  my ($self,$el) = @_;
  my $locname = $el->{'LocalName'};
  push @{$self->{'currentelement'}},$locname;
  $self->{'path'} = join ('.',@{$self->{'currentelement'}});
  push @{$self->{'currenttexttarget'}},{'r'=>0,'text'=>undef};
  my $elhandler = $self->getElementStartHandler();
  $elhandler->($el);
}

sub end_element {
  my ($self,$el) = @_;
  use Data::Dumper;
  #eval {
  #  my $elhandler = $self->getElementEndHandler();
  #  $elhandler->($el);
  #};
  #if ($@) {
  #}
  my $tt = pop @{$self->{'currenttexttarget'}};
  pop @{$self->{'currentelement'}};
  $self->{'path'} = join ('.',@{$self->{'currentelement'}});
}

sub setElementText {
  my ($self,$characters) = @_;
}

sub getElementText {
  my $self = shift;
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];
  return $currenttexttarget->{'text'};
}

sub characters {
  my ($self,$characters) = @_;
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];
  if ($currenttexttarget->{'r'} == 1) {
  if (not defined $currenttexttarget->{'text'}) { $currenttexttarget->{'text'} = ''; }
        $currenttexttarget->{'text'} = $currenttexttarget->{'text'} . $characters->{'Data'};
  }
}

sub comment {
  my ($self,$comment) = @_;
}

sub processing_instruction {
  my ($self,$pi) = @_;
}




1;
