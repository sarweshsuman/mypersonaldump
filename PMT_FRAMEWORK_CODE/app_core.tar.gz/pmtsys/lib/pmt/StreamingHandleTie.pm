package StreamingHandleTie;

use strict;
use Carp;
use Data::Buffer;
use threads;
use threads::shared;
use Thread::Semaphore;

sub TIEHANDLE {
  my $class= shift;
  my $o = {};
  $o->{'buffer'} = Data::Buffer->new();
  $o->{'currentpos'} = 0;
  $o->{'sem'} = Thread::Semaphore->new();
  $o->{'opened'} = 1;
  $o->{'eof'} = 0;
  $o->{'length'} = 0;
  $o->{'writer_tid'} = undef;
  $o->{'writer_closed'} = undef;
  $o->{'reader_tid'} = undef;
  $o->{'reader_closed'} = undef;

  # Remninder: I should always act as being a blocking handle blocking :-)

  bless $o;
  return $o;
}

sub SYSWRITE {
  my $self = shift; 
  my ($scalar,$length,$offset) = @_;

  $self->{'sem'}->down();
  #print STDERR "SYSWRITE is called with $scalar,$length,$offset\n";
  $self->{'sem'}->up();
  print STDERR "SYSWRITE is called \n";
}

sub WRITE {
  my $self = shift; 
  my ($scalar,$length,$offset) = @_;

  use threads;
  $self->{'sem'}->down();
  print STDERR "WRITE is called with ",length($scalar)," bytes in thread ",threads->tid(),"\n";
  $self->{'sem'}->up();
  #$length,$offset\n";
}

sub PRINT {
  my $self = shift;
  my @args = @_;

  $self->{'sem'}->down();
  print STDERR "Print was called\n";
  use bytes;
  for my $b (@_) {
     $self->{'buffer'}->put_bytes($b);
     $self->{'length'} = $self->{'length'} + length $b;
     print "appending : $b\n";
  }
  $self->{'sem'}->up();
  return 1;
}

sub PRINTF {
  my $self = shift;
  my $format = shift;
  my @args = @_;
  $self->{'sem'}->down();
  print STDERR "printf is called\n";
  $self->{'sem'}->up();
  return 1;
}

sub READ {
  my $self = shift;
  my ($scalar,$length,$offset) = @_;
  my $real_length;
  my $localbuffer= '';
  if (not defined $self->{'reader_tid'}) {
    $self->{'reader_tid'} = threads->tid();
  }
  elsif ($self->{'reader_tid'} ne threads->tid()) {
    croak { message=>"Invalid reader thread in package " . __PACKAGE__ };
  }
  if ($self->{'reader_closed'}) {
   croak { message=>"Handle is closed for reading in package " . __PACKAGE__ };
  }

  print STDERR "Read was called with $length, $offset\n";
  $self->{'sem'}->down();
  if ($length < $self->{'length'}) {
    $real_length = $length;   
  }
  else {
    $real_length = $self->{'length'};
  }
  $_[0] = $self->{'buffer'}->get_bytes($real_length);
  $self->{'currentpos'} = $self->{'currentpos'} + $real_length;
  $self->{'sem'}->up();
  return $real_length;
}

sub READLINE {
  my $self = shift;
  croak { message=>"READLINE not implemented in package " . __PACKAGE__ };
  return "5";
}

sub GETC {
  my $self = shift;
  croak { message=>"GETC not implemented in package " . __PACKAGE__ };
}

sub CLOSE {
  my $self = shift; 
}

sub OPEN {
  my $self = shift;
  my ($filename) = @_;
}

sub BINMODE {
  my $self = shift;
  # I always assume binmode, I do not do any translation
  return 1;
}

sub EOF {
  my $self = shift;
  return 0;
}

sub TELL {
  my $self = shift;
  print STDERR "tell was called\n";
  $self->{'sem'}->down();
  my $r = $self->{'currentpos'};
  $self->{'sem'}->down();
  return $r;
}

sub SEEK {
  my $self = shift;
  my ($offset,$whence) = @_;
  print STDERR "seek was called\n";
  $self->{'sem'}->down();
  if ($whence > 0) {
    if ($offset > $self->{'length'}) {
       $self->{'currentpos'} = $self->{'length'} - 1;
    }
    else {
      $self->{'currentpos'} = $offset;
    }
  }
  elsif ($whence < 0) {
    if ($offset > $self->{'length'}) {
      $self->{'currentpos'} = 0;
    }
    else {
      $self->{'currentpos'} = $self-{'length'} - $offset;
    }
  }
  else {
    if ($offset < 0) {
      $offset = 0;
    }
    $self->{'currentpos'} = $offset;
  }
  $self->{'buffer'}->set_offset($self->{'currentpos'});
  $self->{'sem'}->up();
}

sub DESTROY {
  my $self = shift;
  my $tid = threads->tid();
  print STDERR "destroy was called in $tid\n";
}


1;
