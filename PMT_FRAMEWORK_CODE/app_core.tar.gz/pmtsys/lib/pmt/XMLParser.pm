package XMLParser;

use strict;
use Carp;

use Time::HiRes qw(time);

use PMTUtilities qw(partial loadResource getPMTSysConfig parseURI);

sub new {
  my $package = shift;
  my %args = @_;

  my $o = {};

  $o->{'initialcontext'} = $args{'initialcontext'};
  my $ic = $o->{'initialcontext'};
  my $controller = $ic->{'RUNTIME/SYSTEM/CONTROLLER'};
  $o->{'controller'} = $controller;
  my $group = $ic->{'RUNTIME/EXEC/GROUP'};
  $ic->log(message=>"Creating an XMLParser in group $group",domain=>"system",level=>"info");
  $o->{'xnode'} = $args{'xnode'};
  $o->{'_configured_'} = 0;
  $o->{'_status_'} = undef;

  my $xnode = $o->{'xnode'};
  $ic->log(message=>"Created XMLParser with xnode",data=>"$xnode",level=>"info",domain=>"system");
  
  return bless $o;
}

sub p_configure {
  my $self = shift;
  my $ic = $self->{'initialcontext'};

  if ($self->{'_configured_'}) { return 1; }
  my $xnode = $self->{'xnode'};
  my $controller = $ic->{'RUNTIME/SYSTEM/CONTROLLER'};
 
  use Data::Dumper ;
  my ($saxhandler,$io_in,$io_out);
  eval {
  	$saxhandler = $xnode->xfactory(data=>'./config/saxhandler');
	$ic->log(message=>'In Between',data=>'',domain=>'system',level=>'info');
    $self->{'saxhandler'} = $saxhandler->new(initialcontext=>$ic);
  	$io_in = $xnode->xfactory(data=>'./config/io/in');
  	$io_out = $xnode->xfactory(data=>'./config/io/out');
    $self->{'io_in'} = $io_in;
    $self->{'io_out'} = $io_out;

    my $Init=$xnode->xfind('initparams/param[@name="Init"]');
    my $Final=$xnode->xfind('initparams/param[@name="Final"]');
    my $Start=$xnode->xfind('initparams/param[@name="Start"]');
    my $End=$xnode->xfind('initparams/param[@name="End"]');
    my $Char=$xnode->xfind('initparams/param[@name="Char"]');

    $ic->log(message=>"XMLParser configured with following components",
             data=>{
               saxhandler=>ref $saxhandler,
               io_in=>ref $io_in,
               io_out=>ref $io_out,
		init=>$Init,
		final=>$Final,
		start=>$Start,
		end=>$End,
		char=>$Char
             },
             domain=>"system",
             level=>"info"
            );
    $ic->log(message=>"XMLParser is ready for operation",domain=>"system",level=>"info");
    #use XML::SAX;
    #use XML::LibXML::SAX::Parser;
    #use XML::SAX::ExpatXS;
    use XML::Parser;
    my $parser = XML::Parser->new(
	Style=> 'Stream',
       Handlers=>{
		Init =>$saxhandler->{$Init},
		Final =>$saxhandler->{$Final},
		Start =>$saxhandler->{$Start},
		End 	=>$saxhandler->{$End},
		Char 	=>$saxhandler->{$Char}
	}
    );
    $self->{'parser'} = $parser;
  };
  if ($@) { 
     my $e = $@;
     $ic->log(message=>"An error occurred during run configure step of XMLParser",domain=>"system",level=>"error",data=>$e);
     if (ref $e eq 'HASH') {
       croak $e;
     }
     else {
       croak { message=>$e};
     }
  }
  else {
  	$self->{'_configured_'} = 1;
  }

  return $self->{'_configured_'};

}

sub run {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $xnode = $self->{'xnode'};
  my $controller = $ic->{'RUNTIME/SYSTEM/CONTROLLER'};

  # This should actually go to the constructor
  my $s = $self->p_configure();

  $ic->log(message=>"Doing run in XMLParser",domain=>"system",level=>"info");
  $self->{'_status_'} = 'running';

  my ($saxhandler,$io_in,$io_out);
  eval {
    my $parser = $self->{'parser'};
    $io_in = $self->{'io_in'};
    $io_out = $self->{'io_out'};
    $saxhandler = $self->{'saxhandler'};
    $parser->parse($io_in->getIOHandle());

    if ($xnode->xfind('config/gather_statistics/data()',default=>0)) {
  		if ($saxhandler->can('getProcessStatistics')) {
    		my $data = $saxhandler->getProcessStatistics();
        $ic->log(message=>"Process statistics",data=>$data,level=>"info",domain=>"system");
    		$controller->sendGeneric(type=>'process_data',data=>{ data_type=>'process_statistics', detail=>$data});
  		}
  		else {
    		$controller->sendGeneric(type=>'process_data',data=>{data_type=>'process_statistics',detail=>{}});
  		}
    }
    else  {
      $ic->log(message=>"No process statistics required",domain=>"system",level=>"debug");
    }

    if ($xnode->xfind('config/gather_data_summary',default=>0)) {
  		if ($saxhandler->can('getDataSummary')) {
    		my $data = $saxhandler->getDataSummary();
    		$controller->sendGeneric(type=>'process_data',data=>{ data_type=>'data_summary', detail=>$data});
  		}
  		else {
    		$controller->sendGeneric(type=>'process_data',data=>{data_type=>'data_summary',detail=>{}});
  		}
    }
    else {
      $ic->log(message=>"No data summary required",domain=>"system",level=>"debug");
    }
    if ($xnode->xfind('config/get_results_during_run',default=>0)) {
      $self->getResults();
    }
  };

  if ($@) { 
    my $e = $@; 
    $ic->log(message=>"An error occurred during run of XMLParser",domain=>"system",level=>"error",data=>$e);
    if (ref $e eq 'HASH') {
      croak $e;
    }
    else {
      croak { message=>$e };
    }
  }
}

sub initialize {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  use Time::HiRes qw(time);
  my $start_tm = time();
  $self->{'_status_'} = undef;
  my $wi = $ic->expand('{{WORKLIST/ITEM|default notknown}}');
  my $t = time();
  $ic->log(message=>"Doing initialize in XMLParser for item ",data=>$wi,level=>"system",level=>"info");
  my $s = $self->p_configure();
  my $t = time();
  if ($s) {
    my $saxhandler = $self->{'saxhandler'};
    my $io_in = $self->{'io_in'};
    my $io_out = $self->{'io_out'};

    for my $l ($saxhandler,$io_in,$io_out) {
      if ($l->can('initialize')) {
        $ic->log(domain=>"system",level=>"debug",message=>"Doing initialize in component " . ref $l . "for item ", data=>$wi);
        #print STDERR "doing $$ subcomponent ",ref $l," initialize in ",__PACKAGE__,"for item $wi at $t\n";
        use Data::Dumper;
        eval {
          $l->initialize();
          $ic->log(message=>"Done initializing component " . ref $l . " in XMLParser for item", data=>$wi,domain=>"system",level=>"info");
        };
        if ($@) {
          my $e = $@;
          $ic->log(level=>"error",domain=>"system",data=>$e,message=>"Error occurred in initialization of component " . ref $l . " for item ");
          if (ref $e eq 'HASH') {
            croak $e;
          }
          else {
            croak { message=>$e };
          }
        }
      }
    }
    $saxhandler->setIOSpec(out=>$io_out->getIOHandle());
    $ic->log(message=>"Initialized parser",domain=>"system",level=>"info");
  }
  else {
    # I should actually  croak something here
    croak { message=>"Failed to configure XMLParser for item ",data=>$wi };
  }
}

sub getResults {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $xnode = $self->{'xnode'};
  my $controller = $ic->{'RUNTIME/SYSTEM/CONTROLLER'};
  my $s = 1; # this should be a bunch of checks
  if ($s) {
    my $saxhandler = $self->{'saxhandler'};
    my $io_in = $self->{'io_in'};
    my $io_out = $self->{'io_out'};
    my $final_result = {};
    for my $l ($saxhandler,$io_in,$io_out) {
      if ($l->can('getResults')) {
        my $lr = $l->getResults();
        for my $k (keys %$lr) { $final_result->{$k} = $lr->{$k}; }
      }
    }
    $controller->sendGeneric(type=>'process_data',data=>{ data_type=>'result', detail=>$final_result});
  }
}

1;
