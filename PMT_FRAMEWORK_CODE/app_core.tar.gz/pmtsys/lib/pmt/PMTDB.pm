package PMTDB;

use strict;
use Carp;

sub new {
  my $package = shift;
  my %args = @_;

  my $o = {};
  $o->{'xnode'} = $args{'xnode'};
  my $xnode = $o->{'xnode'};
  $o->{'initialcontext'} = $args{'initialcontext'};
  my $ic = $o->{'initialcontext'};

  $ic->log(message=>"Creating a PMTDB object,xnode = ",domain=>"system",level=>"debug",data=>"$xnode");
  if ($xnode->exists('./config/db_connection')) {
    $o->{'db_connection'} = $xnode->xfind('./config/db_connection/resource_factory()');
  }

  return bless $o;
}

sub ora_get_dbms_output {
   my $dbh = shift;
   my $sth = $dbh->prepare_cached('begin dbms_output.get_line(:line, :status); end;') or return;
   my ($line, $status, @lines);

   # Since 10g r2, Oracle has supported line sizes up to 32767.
   $sth->bind_param_inout(':line', \$line,  32767, { ora_type => 1 });
   $sth->bind_param_inout(':status', \$status, 20, { ora_type => 1 });
   if (!wantarray) {
       $sth->execute or return undef;
       return $line if $status eq '0';
       return undef;
   }
   push @lines, $line while($sth->execute && $status eq '0');
   if (wantarray) {
     return @lines;
   }
   elsif (defined wantarray) {
     return \@lines;
   }
}

sub execStoredProc_default {
  my $self = shift;
  my %args = @_;
  my $ic = $self->{'initialcontext'};
  $ic->log(message=>"Doing execStoredProc_default ... looks like a configuration problem",domain=>"system",level=>"warning");
}

sub sql_oracle {
  my $self = shift;
  my $dbc = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $sql = $args{'sql'};
  my $file = $args{'outfile'};
  my $header = $args{'header'};
  my $separator = $args{'separator'};
  $sql = $ic->expand($sql);
  $ic->log(message=>"Executing Oracle SQL: ",data=>$sql,domain=>"system",level=>"debug");

  my $fh ;
  open ($fh,'>',$file);
  my $statement = $dbc->prepare($sql);
  my $e;
  eval {
    $statement->execute();
  };
  if ($@) {
    $e = $@;
  }
  $statement->finish();
  my $dbms_output_lines = ora_get_dbms_output($dbc);
  if ($dbms_output_lines) {
    $ic->log(message=>"Oracle dbms_output lines: ",data=>$dbms_output_lines,level=>"info",domain=>"system");
  }
  if ($e) {
    $ic->log(message=>"Executing Oracle SQL failed: ",data=>{ sql=>$sql,error=>$e} ,domain=>"system",level=>"error");
    croak { message=>"error occurred during execution of sql",data=>$e };
  }
}

sub query2file_oracle {
  my $self = shift;
  my $dbc = shift;
  my $ic = $self->{'initialcontext'};
  #my $controller = $self->{'controller'};
  my %args = @_;
  my $sql = $args{'sql'};
  print STDERR "sql=",$sql;
  my $file = $args{'outfile'};
  my $header = $args{'header'};
  my $separator = $args{'separator'};
  if (not $separator) { $separator = ','; }
  $sql = $ic->expand($sql);
  $ic->log("Executing query: ",data=>{ sql=>$sql,outfile=>"$file"},domain=>"system",level=>"debug");

  my $fh ;
  open ($fh,'>',$file);
  my $statement = $dbc->prepare($sql);
  $statement->execute();
  if ($header) {
    my $cols = $statement->{'NAME_lc'};
    my $headerline = join($separator,@$cols);
    print $fh "$headerline\n";
  }
  while (my $rec = $statement->fetchrow_arrayref()) {
    my $l = join($separator,@$rec);
    print $fh "$l\n";
  }
  close $fh;
  $statement->finish();
  #$controller->send(type=>'ic_update',data=>{set=>{'WORKLIST/ITEM'=>$file}});
  $ic->{'WORKLIST/ITEM'}=$file;
  #print STDERR "Here with file name $file\n";
}


sub execStoredProc_oracle {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $dbc = shift;
  my %args = @_;
  my $stproc = $args{'procedure'};
  my $params = $args{'parameters'};
  $ic->log(domain=>"system",level=>"info",message=>"Executing stored procedure",data=>{storedproc=>$stproc,params=>$params});
  if (not $params) {
    $params = {};
  }
  my $plist = [];
  for my $k (keys %$params) {
    push @$plist, "$k=>$params->{$k}";
  }
  my $pstring = join(',',@$plist);
  my $sql;
  if (length($pstring)>0) {
     $sql = "begin $stproc($pstring); end;"
  }
  else {
     $sql = "begin $stproc; end; "
  }
  $ic->log(message=>"executing sql",data=>$sql,domain=>"system",level=>"debug");
  my $statement = $dbc->prepare($sql);
  my $e;
  eval {
    $statement->execute();
  };
  if ($@) {
    $e = $@;
  }
  $statement->finish();
  my $dbms_output_lines = ora_get_dbms_output($dbc);
  if ($dbms_output_lines) {
    $ic->log(message=>"Oracle dbms_output lines: ",data=>$dbms_output_lines,level=>"info",domain=>"system");
  }
  if ($e) {
    croak { message=>"error occurred during execution of stored procedure",data=>$e };
  }
  # now we need to know whether it is a package name or a procedure
}

my $methods = {
  execStoredProc_oracle => \&execStoredProc_oracle,
  query2file_oracle => \&query2file_oracle,
  sql_oracle => \&sql_oracle
};

sub query2file {
  my $self = shift;
  my %args = @_;

  my $db_connection; 
  if ( defined $args{'db_connection'} ) {
    $db_connection = $args{'db_connection'};
  }
  elsif ($self->{'db_connection'}) {
    $db_connection = $self->{'db_connection'};
  }
  elsif ($self->{'xnode'}->exists('./config/db_connection')) {
    $db_connection = $self->{'xnode'}->xfind('./config/db_connection');
  }
  else {
    croak { message=>"Could not find a db_connection is call query2file in " . __PACKAGE__ };
  }
  my $dialect = lc $db_connection->getDialect();
  my $m = "query2file_${dialect}";
  if (defined $methods->{$m}) {
    my $mf = $methods->{$m};
    return $mf->($self,$db_connection,@_);
  }
}

sub execStoredProc {
  my $self = shift;
  my %args = @_;

  my $db_connection; 
  if ( defined $args{'db_connection'} ) {
    $db_connection = $args{'db_connection'};
  }
  elsif ($self->{'db_connection'}) {
    $db_connection = $self->{'db_connection'};
  }
  elsif ($self->{'xnode'}->exists('./config/db_connection')) {
    $db_connection = $self->{'xnode'}->xfind('./config/db_connection');
  }
  else {
    croak { message=>"Could not find a db_connection is call execStoredProc in " . __PACKAGE__ };
  }

  my $dialect = lc $db_connection->getDialect();
  my $m = "execStoredProc_${dialect}";
  if (defined $methods->{$m}) {
    my $mf = $methods->{$m};
    return $mf->($self,$db_connection,@_);
  }
}

sub sql {
  my $self = shift;
  my %args = @_;

  my $db_connection; 
  if ( defined $args{'db_connection'} ) {
    $db_connection = $args{'db_connection'};
  }
  elsif ($self->{'db_connection'}) {
    $db_connection = $self->{'db_connection'};
  }
  elsif ($self->{'xnode'}->exists('./config/db_connection')) {
    $db_connection = $self->{'xnode'}->xfind('./config/db_connection');
  }
  else {
    croak { message=>"Could not find a db_connection is call execStoredProc in " . __PACKAGE__ };
  }

  my $dialect = lc $db_connection->getDialect();
  my $m = "sql_${dialect}";
  if (defined $methods->{$m}) {
    my $mf = $methods->{$m};
    return $mf->($self,$db_connection,@_);
  }
}

sub initialize {
  my $self = shift;
  #print STDERR "Doing initialize in " . __PACKAGE__ ."\n";
}

1;
