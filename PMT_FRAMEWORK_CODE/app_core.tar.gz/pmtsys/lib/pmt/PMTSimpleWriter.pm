package PMTSimpleWriter;

use strict;
use Carp;
use File::Spec;

use overload q("") => \&string_overload,
             q{*{}} =>\&file_glob_overload;
sub new {
  my $class = shift;
  my %args = @_;

  my $o = {};
  $o->{'initialcontext'} = $args{'initialcontext'};
  $o->{'xnode'} = $args{'xnode'};
  $o->{'handle'} = undef;
  $o->{'tmpmode'} = 0;

  my $ox = $args{'xnode'};

  my $ic = $o->{'initialcontext'};
  $ic->log(message=>"Creating a PMTSimpleWriter with xnode ",data=>"$ox",domain=>"system",level=>"info");

  return bless $o;
}

sub run {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
}

sub start {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
}

sub end {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
}

sub initialize {
  my $self = shift;
  my $ic = $self->{'initialcontext'};

  if ($self->{'handle'}) {
    $self->{'handle'}->close();
  }
  my $xnode = $self->{'xnode'};
  my ($f,$d);
  if ($xnode->exists('params/directory')) {
    $d=$xnode->xfind('params/directory');
  }
  else { print STDERR "Directory not defined ?\n"; }
  if ($xnode->exists('params/outfile')) {
    $f=$xnode->xfind('params/outfile');
  }
  my $ac = $xnode->xfind('params/directory/@auto_create',default=>0);
  use PMTUtilities qw(evalBoolean);
  $ac = evalBoolean(value=>$ac);
  if (-d $d) {
    # all is well
    #print STDERR __PACKAGE__,"Target Directory allready exists, doing nothing\n";
  }
  else {
    if ($ac) {
      use File::Path qw(make_path);
      $ic->log(message=>"Creating directory $d",domain=>"system",level=>"trace");
      make_path($d);
    }
    else {
      $ic->log(message=>"Looking for directory $d but it does not exist",domain=>"system",level=>"error");
      # This is actually an error
      croak { message=>"Directory $d does not exist " };
    }
  }
  my $ff = File::Spec->catfile($d,$f); 
  $ic->log(message=>"PMTSimpleWriter initialized for file: $ff",domain=>"system",level=>"debug");
  # somme checks should go here, should I create the file, is it file mode or socket mode
  my $filecheck = 1;
  my $createcheck = 1;
  if ($filecheck and $createcheck) {
    use IO::File;
    my $ofile =  IO::File->new($ff,'w');
    $self->{'handle'} = $ofile;
    $self->{'filename'} = $ff;
  }
}

sub finalize {
  my $self = shift;
  my %args = @_;
  my $status = $args{'success'};
  if ($status) { 
  	if ($self->{'tmpmode'}) {
      
  	};
  }
  else { 
  }
}

sub getResults {
  my $self = shift;
  # this is the one that should be take the decision to finalize
  my $xnode = $self->{'xnode'};
  my $rl;
  if ($xnode->exists('params/result_label')) {
    $rl = $xnode->xfind('params/result_label');
  } 
  else {
    $rl = 'outfile';
  }
  return { $rl=>$self->{'filename'}};
}

sub string_overload {
  my $self = shift;
  return "< PMTSimpleWriter instance >";
}

sub getIOHandle {
  my $self = shift;
  return $self->{'handle'};
}

sub file_glob_overload {
  my $self = shift;

  return $self->{'handle'};
}

1;
