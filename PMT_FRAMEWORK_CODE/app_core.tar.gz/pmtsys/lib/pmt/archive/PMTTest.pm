package PMTTest;

use strict;
use Carp;
use Data::Dumper;

sub somefunc {
  my %args = @_;
  print "somefunc got params: \n";
  print Dumper(\%args);
  
  undef;
}

1;
