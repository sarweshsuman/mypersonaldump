package LibXMLMGWPMT01ParserManager;

use strict;
use Carp;

use Data::Dumper;
use File::Spec;
use PMTUtilities qw(serializeTo deserializeFrom getPMTSysConfig);
use Class::Loader;
use JSON;

sub new {
  my $class = shift;

  my $o = {};
  $o->{'config'} = {};
  $o->{'params'} = {};
  $o->{'runid'} = undef;

  bless $o;
 
  return $o;
}

sub setRunID {
  my $self = shift;
  my %args = @_;
  my $runid = $args{'runid'};
  $self->{'runid'} = $runid;
}

sub params {
  my $self = shift;
  $self->{'params'}->{'directory'} = '/opt/PMT/scripts/import';
  $self->{'params'}->{'filepattern'} = '^test\d+_etlexpmx_MGW_20130823113729_1137151.xml$';
  $self->{'params'}->{'outdir'} = '/opt/PMT/outfile';
  $self->{'params'}->{'outfile'} = "MGW_PARSED.".$$.".csv";
}

sub config {
  my $self = shift;
  my %args = @_;
  my $config = $args{'config'};
  for my $key (keys %{$config->{'param'}}) {
    #print "setting config $key to $config->{'param'}->{$key}->{'value'}\n";
    $self->{'config'}->{$key} = $config->{'param'}->{$key}->{'value'};
  }
}

sub run_rpc {
  my $self = shift;
  print "Running in multiprocessing mode\n";
}

sub run_threaded {
  my $self = shift;
  print STDERR "Running in threaded mode\n";
}

sub run_singlethreaded {
  my $self = shift;
  print "running in singlethreaded mode\n";
}

sub run_multiprocess {
  my $self = shift;

  print "Running in MULTIPROCESSING mode\n";

  use Sys::CPU;
  my $number_of_cpus = Sys::CPU::cpu_count();
  print "I got $number_of_cpus cpus\n";

  # Retrive the filenames
  my @filenames = PMTUtilities::getFileList(full_path=>1,directory=>$self->{'config'}->{'directory'},filepattern=>$self->{'config'}->{'filepattern'});
  my $number_of_files = scalar @filenames;
  print "got $number_of_files files\n";

  my $number_of_subprocesses;
  if (defined $self->{'config'}->{'subprocesses'}) {
    $number_of_subprocesses = $self->{'config'}->{'subprocesses'};
  }
  else {
    $number_of_subprocesses = $number_of_files < $number_of_cpus ? $number_of_files : $number_of_cpus;
  }

  print "working with $number_of_subprocesses sub_processes\n";

  print "processing filenames: @filenames\n";

  my $workerpool = { };
  use IPC::Open2;
  use IO::Socket::INET;
  my $workerprocess = $self->{'config'}->{'workerscript'};
  my $io_pid_mapping = {};
  print "using workerprocess: $workerprocess\n";
  
  #$SIG{'CHLD'} = 'IGNORE';

  use IO::Select;
  use POSIX ":sys_wait_h";
  my $selector = IO::Select->new();
  my $do_continue = 1;
  {
    while ($do_continue > 0) {
      # check if there are any dead processes
      for my $pid (keys %$workerpool) {
         my $check = kill 0=>$pid; 
         if (not $check) {
           print "pid $pid is dead\n";
           delete $workerpool->{$pid};
         }
      } 
      my @can_read = $selector->can_read(0.1);
      if (scalar @can_read) {
        print "I have selectors from which I can read\n";
        for my $h (@can_read) {
          my $p = $io_pid_mapping->{$h};
          print "Looks like there's some input on pid $p\n";
          if ($h->connected()) {
            print "and it is connected\n";
            my $data = deserializeFrom(source=>$h,format=>"JSON");
            if (defined $data->{"action"}) {
            }
            elsif (defined $data->{'end'}) {
              # I should wait for it
              print "waiting for pid $p\n";
              my $rc = waitpid($p,WNOHANG);
              print "waited for pid $p\n";
              delete $workerpool->{$p};
              delete $io_pid_mapping->{$h};
              $selector->remove($h);
            }
          }
          else {
            print "But it is not connected\n";
            # means the socket is dead
            delete $workerpool->{$p};
            delete $io_pid_mapping->{$h};
            $selector->remove($h);
          }
        }
      }
      while (scalar @filenames > 0 and scalar keys %$workerpool < $number_of_subprocesses) {
        my $f = shift @filenames;
        print "processing filename: $f\n";
        my $h = { config=>{workerclass=>'LibXMLSAXParser',workerclassparams=>{saxhandler=>'LibXMLMGWSaxParserPMT01D'}}, params=>{runid=>$self->{'runid'},'filename'=>$f} };
        my ($child_writer,$child_reader);
        my $pid = open2($child_reader,$child_writer,$workerprocess);
        use IO::Handle;
        #serializeTo(data=>$h,target=>*STDERR,format=>'JSON');
        serializeTo(data=>$h,target=>IO::Handle->new()->fdopen($child_writer,"w"),format=>'JSON',flush=>1);
        my $handshake = deserializeFrom(source=>IO::Handle->new()->fdopen($child_reader,"r"),format=>"JSON");
        my $socket = IO::Socket::INET->new(
           PeerHost=>$handshake->{'host'},
           PeerPort=>$handshake->{'port'},
           Proto=>'tcp'
        );
        $selector->add($socket);
        $workerpool->{$pid} = { reader=>IO::Handle->new()->fdopen($child_reader,"r"),writer=>IO::Handle->new()->fdopen($child_writer,"w"),status=>'RUNNING',filename=>$f,channel=>$socket};

        $io_pid_mapping->{$socket} = $pid;
        print "I should open a socket to $handshake->{'host'}:$handshake->{'port'}\n";
        
      }
      if (scalar @filenames == 0 and scalar keys %$workerpool == 0) {
        print "I should quit\n";
        $do_continue = 0;
      }
      else {
        #print "still ", scalar @filenames, " to process\n";
        #print "still ", scalar keys %$workerpool, " running processes\n";
      }
      sleep 0.1;
    }
  }
  print "exiting\n";
}


sub run {
  my $self = shift;

  my $run_mode =  uc $self->{'config'}->{'run_mode'};

  if ($run_mode =~ m/^MULTIPROCESSING$/) {
    return $self->run_multiprocess(@_);
  }
  elsif ($run_mode =~ m/^THREADED$/) {
    return $self->run_threaded(@_);
  }
  elsif ($run_mode =~ m/^RPC$/) {
    return $self->run_rpc(@_);
  }
  else {
    print "Unknown mode $run_mode\n";
    return $self->run_singlethreaded(@_);
  }
}

1;
