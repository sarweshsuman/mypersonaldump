package NetDirHandle;

sub new {
  my $package = shift;
  my %args = @_;

  my $directory = $args{'directory'};

  my $o = {};
  bless $o;
  return $o;
}

1;
