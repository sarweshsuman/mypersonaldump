package MGWSaxParserPMT01D;

use strict;
use Carp;

use base qw(XML::SAX::Base);
use PMTUtilities qw(partial getPMTSysConfig);
use DBTie;
use IO::File;

sub new {
  my $class = shift;
  my %params = @_;
  my $o = {};
  $o->{'currentelement'} = [];
  $o->{'path'} = '';
  $o->{'currenttext'} = undef;
  $o->{'texttargets'} = {};
  $o->{'currenttexttarget'} = [];
  $o->{'state'} = {};
	$o->{'io_out'} = IO::File->new('/tmp/parseresult','w');

  $o->{'lookup'} = { dn=>{},measid=>{},measkey=>{},meastype=>{},targetkey=>{}};
  if (defined $params{'lookup'}) {
    my $l = $params{'lookup'};
    print STDERR "lookup is given with key ",keys %$l,"\n";
    for my $k (keys %$l) {
      print STDERR "Registering a lookup $k with val $l->{$k} and tie ",ref tied %{$l->{$k}},"\n";
      $o->{'lookup'}->{$k} = $l->{$k};
    }
  }
  else {
    print STDERR "No lookups defined\n";
  }

  $o->{'elementstarthandlers'} = {
    'OMeS'=>partial(
      $o,
      sub {
        my $self = shift; my $e = shift; 
      }
    ),
    'OMeS.PMSetup'=>partial(
      $o,
      sub { 
        my $self = shift; my $e = shift; 
        # I need the attributes startTime and interval
        my $attributes = $e->{'Attributes'};
        #print STDERR "attributes for pmsetup:",keys %$attributes,"\n";
        $self->{'state'}->{'startTime'} = $attributes->{'{}startTime'}->{'Value'};
        $self->{'state'}->{'interval'} = $attributes->{'{}interval'}->{'Value'};
      }
    ),
    'OMeS.PMSetup.PMMOResult'=> partial(
      $o,
      sub { 
        my $self = shift; my $e = shift; 
        #print STDERR "handling a PMMResult\n"; 
      }
    ),
    'OMeS.PMSetup.PMMOResult.MO'=> partial(
      $o,
      sub { 
        my $self = shift; my $e = shift; 
        #print STDERR "Handling a PMMResult.MO\n"; 
      }
    ),
    'OMeS.PMSetup.PMMOResult.MO.DN'=> partial(
      $o,
      sub { 
        my $self = shift; my $e = shift; 
        $self->{'currenttexttarget'}->[-1]->{'r'} = 1;
        #print STDERR "handling a DN-start\n"; 
      }
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget'=> partial(
      $o,
      sub {
        my $self = shift; my $e = shift; 
        my $attributes = $e->{'Attributes'};
        #print STDERR "attributes",%$attributes,"keys:",keys %{$attributes},"\n";
        #for my $k (keys %$attributes) { print STDERR "$k - "; }
        #print STDERR "\n";
        my $meastype = $attributes->{'{}measurementType'}->{'Value'};
        $self->{'state'}->{'measurementType'} = $meastype;
        $self->{'state'}->{'measurementType_id'} = $self->{'lookup'}->{'meastype'}->{$meastype} = undef;
        #print STDERR "handling a PMTarget with measurementState " .$attributes->{'measurementType'}."\n"; 
      }
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget..*'=> partial(
      $o,
      sub { 
        my $self = shift; my $e = shift; 
        $self->{'currenttexttarget'}->[-1]->{'r'} = 1;
        #print STDERR "handling another element ",$e->{'LocalName'},"\n"; 
      }
    )
  };
  $o->{'elementendhandlers'} = {
    'OMeS'=>partial(
      $o,
      sub {
        my $self = shift; my $e = shift; 
      }
    ),
    'OMeS.PMSetup'=>partial(
      $o,
      sub { 
        my $self = shift; my $e = shift; 
        delete $self->{'state'}->{'startTime'};
        delete $self->{'state'}->{'interval'};
      }
    ),
    'OMeS.PMSetup.PMMOResult'=> partial(
      $o,
      sub { 
        my $self = shift; my $e = shift; 
        #print STDERR "handling a PMMResult\n"; 
      }
    ),
    'OMeS.PMSetup.PMMOResult.MO'=> partial(
      $o,
      sub { 
        my $self = shift; my $e = shift; 
        #print STDERR "Handling a PMMResult.MO\n"; 
      }
    ),
    'OMeS.PMSetup.PMMOResult.MO.DN'=> partial(
      $o,
      sub { 
        my $self = shift; my $e = shift; 
        my $dn = $self->getElementText();
        $self->{'state'}->{'dn'} = $dn;
        $self->{'state'}->{'dn_id'} = $self->{'lookup'}->{'dn'}->{$dn} = undef;
      }
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget'=> partial(
      $o,
      sub {
        my $self = shift; my $e = shift; 
        #print STDERR "handling a PMTarget\n"; 
        delete $self->{'state'}->{'measurementType'};
      }
    ),
    'OMeS.PMSetup.PMMOResult.PMTarget..*'=> partial(
      $o,
      sub { 
        my $self = shift; my $e = shift; 
        my $text = $self->getElementText();
        if ($e->{'LocalName'} eq $self->{'state'}->{'measurementType'}) {
          print STDERR "Element = measurementType, discarding\n";
        }
        else {
          my $localname = $e->{'LocalName'};
          #print STDERR "Processing a measid $localname\n";
          my ($measid,$dummy,$pos) = ($localname =~ /^M(\d+)(\D)(\d*)/);
          my $measkey = $self->{'state'}->{'measurementType'}."_".$measid;
          $self->{'state'}->{'measkey_id'} = $self->{'lookup'}->{'measkey'}->{$measkey} = undef;
          #print STDERR "Registered measkey $measkey\n";
          $self->{'state'}->{'measid_id'} = $self->{'lookup'}->{'measid'}->{$measid} = undef;
          $self->{'state'}->{'pmttarget_id'} = $self->{'lookup'}->{'targetkey'}->{$localname} = undef;
          print STDERR "hend of andling another element ",$e->{'LocalName'}," with text $text and $measkey\n"; 
          $self->write_record(line=>'evert');
        }
      }
    )
  };
  $o->{'currentelementhandler'} = undef;
  $o->{'texthandler'} = undef;


  bless $o;
  return $o;

}
sub write_record {
  $my $self = shift;
  my %args = @_;
  my $line = $args{'line'};
  my $io = $self->{'io_out'};
  $io->write($line);
}

sub start_document {
  my ($self,$doc) = @_;
}

sub getElementStartHandler {
  my $self = shift;
  my $path = $self->{'path'};
  #print STDERR "searching for handler for $path\n";
  for my $k (keys %{$self->{'elementstarthandlers'}}) {
    #print STDERR "checking $k\n";
    if ($path =~ m/^${k}$/) {
      return $self->{'elementstarthandlers'}->{$k};
    }
  }
  return partial($self,sub { print STDERR "dummy function\n"; });
}

sub getElementEndHandler {
  my $self = shift;
  my $path = $self->{'path'};
  #print STDERR "searching for handler for $path\n";
  for my $k (keys %{$self->{'elementendhandlers'}}) {
    #print STDERR "checking $k\n";
    if ($path =~ m/^${k}$/) {
      return $self->{'elementendhandlers'}->{$k};
    }
  }
  return partial($self,sub { print STDERR "dummy function\n"; });
}

sub getCharacterHandler {
}

sub start_element {
  my ($self,$el) = @_;
  my $locname = $el->{'LocalName'};
  if (scalar @{$self->{'currentelement'}} == 0) {
    #print STDERR "Starting document with element $locname\n";
  }
  push @{$self->{'currentelement'}},$locname;
  $self->{'path'} = join ('.',@{$self->{'currentelement'}});
  #print STDERR "Starting element ",$el->{'LocalName'},"\n";

  push @{$self->{'currenttexttarget'}},{'r'=>0,'text'=>undef};
  my $elhandler = $self->getElementStartHandler();
  $elhandler->($el);
}

sub end_element {
  my ($self,$el) = @_;

  eval {
    my $elhandler = $self->getElementEndHandler();
    $elhandler->($el);
  };
  if ($@) {
    print STDERR "An error has occurred\n";
  }

  #print STDERR "popping from texttargets for ",$self->{'path'},"\n";
  my $tt = pop @{$self->{'currenttexttarget'}};
  pop @{$self->{'currentelement'}};
  $self->{'path'} = join ('/',@{$self->{'currentelement'}});
  #print STDERR "Starting element ",$el->{'LocalName'},"\n";
  #print STDERR "Ending element\n";
}

sub setElementText {
  my ($self,$characters) = @_;
}

sub getElementText {
  my $self = shift;
  #print STDERR "retrieving element text for ",$self->{'path'},"\n";
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];
  #print STDERR $currenttexttarget,"\n";
  return $currenttexttarget->{'text'};
}

sub characters {
  my ($self,$characters) = @_;
  my $currenttexttarget = $self->{'currenttexttarget'}->[-1];
 
  if ($currenttexttarget->{'r'} == 1) {
  #print STDERR "characters called with $characters->{'Data'}\n";
  if (not defined $currenttexttarget->{'text'}) { $currenttexttarget->{'text'} = ''; }
  	$currenttexttarget->{'text'} = $currenttexttarget->{'text'} . $characters->{'Data'};
  }
 #print STDERR "Get Characters: $characters->{'Data'} \n";
}

sub comment {
  my ($self,$comment) = @_;
  #print STDERR "Doing Comment\n";
}

sub processing_instruction {
  my ($self,$pi) = @_;
  #print STDERR "Doing $pi\n";
}




1;

