package PerlSAXParser;

use strict;
use Carp;

use PMTUtilities qw(getPMTSysConfig);

sub new {
  my $package = shift;
  my %args = @_;

  my $o = {};

  if (defined $args{'saxhandler'}) {
    $o->{'saxhandler'} = $args{'saxhandler'};
  }
  else {
    $o->{'saxhandler'} = undef;
  }

  bless $o;

  return $o;
  
}

sub run {
  my $self = shift;
  my %params = @_;
  my $uri;
  if (defined $params{'filename'}) {
    $uri = $params{'filename'};
  }
  print STDERR "doing the run method in the PerlSaxParser\n";
  if (defined $self->{'saxhandler'}) {
    my $saxhandler = $self->{'saxhandler'};
    print STDERR "Using SAXHandler: $saxhandler\n";

    # Make the database abstraction
    use DBTie;
    use DBI;
    use DBD::Oracle;
    my $dbconfig = getPMTSysConfig(section=>'db');
    use Data::Dumper;
    print STDERR "DB Config:\n"; print STDERR Dumper($dbconfig);
    my $dbh = DBI->connect("DBI:Oracle:$dbconfig->{'ora_sid'}",$dbconfig->{'ora_user'},$dbconfig->{'ora_passwd'},{RaiseError=>1,PrintError=>1}) or die "Failed to open connection to DB";
    our %db_dn;
    my %db_measid;
    my %db_measkey;
    my %db_meastype;
    my %db_targetkey;

    tie %db_dn,'DBTie',(dbconn=>$dbh,
                        target_table=>'t_pmt_dn',
                        key_col=>'dn',
                        id_col=>'id',
                        sequence=>'seq_pmt_dn_id',
                        store_name=>'DN',
                        auto_insert=>1,
                        verbose=>0
    );  
    tie %db_measid,'DBTie',(dbconn=>$dbh,
                         target_table=>'t_pmt_measid',
                         key_col=>'measid',
                         id_col=>'id',
                         sequence=>'seq_pmt_measid_id',
                         store_name=>'MEASID',
                        auto_insert=>1,
                         verbose=>0
    );  
    tie %db_measkey,'DBTie',(dbconn=>$dbh,
                         target_table=>'t_pmt_measkey',
                         key_col=>'measkey',
                         id_col=>'id',
                         sequence=>'seq_pmt_measkey_id',
                         store_name=>'MEASKEY',
                         auto_insert=>1,
                         verbose=>0
    );  
    tie %db_meastype,'DBTie',(dbconn=>$dbh,
                         target_table=>'t_pmt_meastype',
                         key_col=>'meastype',
                         id_col=>'id',
                         sequence=>'seq_pmt_meastype_id',
                         store_name=>'MEASTYPE',
                         auto_insert=>1,
                         verbose=>0
    );  
    tie %db_targetkey ,'DBTie',(dbconn=>$dbh,
                         target_table=>'t_pmt_pmttargetkey',
                         key_col=>'pmttargetkey',
                         id_col=>'id',
                         sequence=>'seq_pmt_pmttargetkey_id',
                         store_name=>'TARGETKEY',
                         auto_insert=>1,
                         verbose=>0
    );  

    my $keystores = {};
    $keystores->{'dn'} = \%db_dn;
    $keystores->{'measid'} = \%db_measid;
    $keystores->{'measkey'} = \%db_measkey;
    $keystores->{'meastype'} = \%db_meastype;
    $keystores->{'targetkey'} = \%db_targetkey;

    print STDERR "creating a saxhandler\n";
    my $sh = PMTUtilities::loadClass(module=>$saxhandler,args=>['lookup',$keystores]);
    print STDERR "start got an XML handler\n";
    use XML::SAX;
    my $parser = XML::SAX::ParserFactory->parser(
       Handler=>$sh
    );
    $parser->set_feature('http://xmlns.perl.org/sax/join-character-data', 1);
    my $starttime = time();
    print STDERR "Starting parse now\n";
    eval {
      $parser->parse_uri($uri);
    };
    if ($@) {
      print STDERR "An error occurred during parsing: $@\n";
    }
    my $parsetime = time() - $starttime;
    print STDERR "End of parse now (took $parsetime seconds)\n";
  }
  else {
    print STDERR "saxhandler is not defined\n";
  }
  
  print STDERR "end of doing run method in PerlSAXParser\n";
}

1;
