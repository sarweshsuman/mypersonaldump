package XMLWrapper;

use strict;
use Carp;
use XML::LibXML;

# Purpose of this element is mainly memory management.
# As soon as nothing points to this object, it is automatically cleaned

my $xmlpath = undef;

sub new {
  my $package = shift;
  my $o = {};

  my %args = @_;

  if (defined $args{'document'}) {
    $o->{'document'} = $args{'document'};
  }
  elsif (defined $args{'uri'}) {
    use IO::File;
    use XML::DOM;
    my $handle = IO::File->new($args{"uri"},"r");
    my $parser = XML::LibXML->new();
    $o->{'document'} = $parser->load_xml(IO=>$handle);
  }
  else {
    croak { message=>"Invalid parameters to ",__PACKAGE__," constructor"};
  }

  if (not defined $xmlpath) {
    use XML::XPath;
    $xmlpath = XML::XPath->new();
  }
  bless $o;
  return $o;
}
sub xcloneNode() {
  my $self = shift;
  my %args = @_;
  my $path = $args{'xpath'};
}
sub node {
  my $self = shift;
  return $self->{'document'};
}
sub xfind {
  my $self = shift;
  my %args = @_;
  my $path = $args{'xpath'};
  return $xmlpath->find($path,$self->{'document'});
}
sub xfindnodes {
  my $self = shift;
  my $path = shift;
  my %args = @_;
  my $path = $args{'xpath'};
  return $xmlpath->findnodes($path,$self->{'document'});
}
sub xfindvalue {
  my $self = shift;
  my %args = @_;
  my $xpath = $args{'xpath'};
  my $context = $args{'context'};
  if (defined $context) {
    return $context->findvalue($xpath);
  }
  else {
    return $self->{'document'}->findvalue($xpath,$self->{'document'});
  }
}
sub xexists {
  my $self = shift;
  my %args = @_;
  my $path = $args{'xpath'};
  my $context = $args{'context'};
  if (defined $context) {
  return $xmlpath->exists($path,$self->{'document'});
  }
}
sub xgetnodetext {
  my $self = shift;
  my %args = @_;
  my $path = $args{'xpath'};
}
sub AUTOLOAD {
  my $self = shift;
  our $AUTOLOAD;
  my $method = (split(/::/,$AUTOLOAD))[1];
  return $self->{'document'}->$method(@_);
}
sub DESTROY {
  print STDERR "Calling destructor in XML wrapper\n";
  my $self = shift;
  my $d = $self->{'document'};
  $self->{'document'} = undef;
  eval {
  # $d->dispose();
  };
  if ($@) {
    print STDERR "something went wrong in constructor: $@\n";
  }
  else {
  print STDERR "Cleaned up document allright\n";
  }
}
1;
