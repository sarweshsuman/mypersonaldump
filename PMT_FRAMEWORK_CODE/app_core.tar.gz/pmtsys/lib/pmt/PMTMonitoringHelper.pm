package LocalDbConnection;

use strict;
use Carp;

sub new {
  my $package = shift;
  my %args = @_;

  my $c = $args{'connection'};
 
  my $o = {};
  $o->{'connection'} = $c;

  return bless $o;
}

sub AUTOLOAD {
  my $self = shift;
  our $AUTOLOAD;
  my @methodcomps = split('::',$AUTOLOAD);
  my $method = pop(@methodcomps);
  my $dbh = $self->{'connection'};
  return $dbh->$method(@_);
}


sub DESTROY {
  my $self = shift;
}

1;


# ##########################################################################
# MODULENAME          : PMTMonitoringHelper
# DESCRIPTION         : PMT Helper Class: Monitoring
# AUTHOR              : Evert Carton
# INPUTS              : NONE
# OUTPUTS             : NONE
# DEPENDENCY          : NONE
# REMARKS             : NONE
# VERSION             : 1.0
# REVISION HISTORY    : Initial Version
# ##########################################################################

# ==========================================================================
#
# Package Declaration
#
# ==========================================================================

package PMTMonitoringHelper;

# ==========================================================================
#
# Use Declarations
#
# ==========================================================================

use strict;
use Carp;

use PMTHelperBase;

our @ISA = qw(PMTHelperBase);
use Data::Dumper;

use PMTUtilities qw(expand icdefined);

# ==========================================================================
#
# Local Variables
#
# Please note that the PMTLogHelper is conceived as a class
# These module variables are NOT instance variables
# ==========================================================================


# ==========================================================================
#
# 2. Constructor
#
# ==========================================================================

sub new {
  my $class = shift;
  my %args = @_;
  my $context = $args{'initialcontext'};
  my $obj = {};
  $obj->{'initialcontext'} = $context;
  $obj->{'LOGHANDLE'} = undef;
  $obj->{'FILENAME'} = undef;
  $obj->{'ARCHIVE_ON_END'} = 1;
  $obj->{'_CHILDPROCESS_'} = 0;
  $obj->{'STARTED'} = 0;
  $obj->{'_HELD_'} = 0;
  $obj->{'_HELDLINES_'} = [];
  $obj->{'_initialized_'} = 0;
  bless $obj;
  return $obj;
}

# ==========================================================================
#
# System Methods
#
# ==========================================================================


# ==========================================================================
# 
# Public Methods
#
# ==========================================================================

sub initialize {
  my $self = shift;
  if ($self->{'_initialized_'} eq 1 ) { return 1; }
  $self->{'_initialized_'} = 1;
}

sub doInherit {
  return 1;
}


sub MDBStartJob {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $irc  = $self->initialize();
  my $ic = $self->{'initialcontext'};
  my $flowcd = $ic->{'SYSTEM/RUN/FLOWCD'};
  my $role = $ic->{'SYSTEM/RUN/ROLE'};
  my $runseq = $ic->{'SYSTEM/RUN/RUNSEQ'};

  my $dbh = $self->localgetdbconnection();

  my $sql = q{
    insert into t_app_monitoring(flowcd,
                                 group_name,
                                 role_name,
                                 starttime,
                                 run_sequence)
    values('{{SYSTEM/RUN/FLOWCD}}',
           '_JOB_',
           '{{SYSTEM/RUN/ROLE}}',
           sysdate,
           {{SYSTEM/RUN/RUNSEQ}})
  };
  $sql = $ic->expand($sql);
  $sql = $ic->expand($sql);
  my $statement = $dbh->prepare($sql);
  $statement->execute();
  $dbh->commit();
  $statement->finish();
}

sub localgetdbconnection {
  my $self = shift;
  my $ic = $self->{'initialcontext'};

  if (defined $self->{'dbh'}) {
    return $self->{'dbh'};
  }

  my $username = $ic->expand('{{CONFIG/monitoring/db.username}}');
  my $password = $ic->expand('{{CONFIG/monitoring/db.password}}');
  my $service = $ic->expand('{{CONFIG/monitoring/db.service}}');

  use DBI;
  use DBD::Oracle;

  my $dbh = DBI->connect("DBI:Oracle:$service",$username,$password,{AutoCommit=>0,RaiseError=>1,PrintError=>1});
  $dbh->func( 1000000, 'dbms_output_enable' );

  $self->{'dbh'} = $dbh;
  return $dbh;
}

sub MDBEndJob {
  my $self = shift;
  my $irc  = $self->initialize();
  my $ic = $self->{'initialcontext'};

  my $dbh = $self->localgetdbconnection();
  
  my $sql = q{
    update t_app_monitoring
    set endtime = sysdate
    where flowcd = '{{SYSTEM/RUN/FLOWCD}}'
        and group_name =  '_JOB_'
        and role_name   = '{{SYSTEM/RUN/ROLE}}'
        and run_sequence =  {{SYSTEM/RUN/RUNSEQ}}
  };
  $sql = $ic->expand($sql);
  my $statement = $dbh->prepare($sql);
  $statement->execute();
  $dbh->commit();
  $statement->finish();

  $sql = "insert into t_app_messaging(
      flowcd,
      group_name,
      message_type,
      message_value,
      run_sequence,
      ts_upload
    )
    values(
      '{{SYSTEM/RUN/FLOWCD}}',
      '_JOB_',
      'SUCCESS',
      '1',
      {{SYSTEM/RUN/RUNSEQ}},
      SYSDATE
  )";
  $sql=$ic->expand($sql);
  $statement = $dbh->prepare($sql);
  $statement->execute();
  $dbh->commit();
  $statement->finish();
}

sub MDBStartGroup {
  my $self = shift;
  my %args = @_;
  my $irc  = $self->initialize();
  my $ic = $self->{'initialcontext'};

  my $group = $args{'group'};

  my $dbh = $self->localgetdbconnection();

  my $sql = q{
    insert into t_app_monitoring(flowcd,
                                 group_name,
                                 role_name,
                                 starttime,
                                 run_sequence)
    values('{{SYSTEM/RUN/FLOWCD}}',
           ?,
           '{{SYSTEM/RUN/ROLE}}',
           sysdate,
           {{SYSTEM/RUN/RUNSEQ}})
  };

  $sql = $ic->expand($sql);
  $sql = $ic->expand($sql);
  my $statement = $dbh->prepare($sql);
  $statement->bind_param(1,$group);
  $statement->execute();
  $dbh->commit();
  $statement->finish();
}

sub MDBEndGroup {
  my $self = shift;
  my %args = @_;
  my $irc  = $self->initialize();
  my $ic = $self->{'initialcontext'};
  my $group = $args{'group'};

  my $dbh = $self->localgetdbconnection();
  
  my $sql = q{
    update t_app_monitoring
    set endtime = sysdate
    where flowcd = '{{SYSTEM/RUN/FLOWCD}}'
        and group_name =  ?
        and role_name   = '{{SYSTEM/RUN/ROLE}}'
        and run_sequence =  {{SYSTEM/RUN/RUNSEQ}}
  };
  $sql = $ic->expand($sql);
  my $statement = $dbh->prepare($sql);
  $statement->bind_param(1,$group);
  $statement->execute();
  $dbh->commit();
  $statement->finish();

  $sql = "insert into t_app_messaging(
      flowcd,
      group_name,
      message_type,
      message_value,
      run_sequence,
      ts_upload
    )
    values(
      '{{SYSTEM/RUN/FLOWCD}}',
      '$group',
      'SUCCESS',
      '1',
      {{SYSTEM/RUN/RUNSEQ}},
      SYSDATE
  )";
  $sql = $ic->expand($sql);
  $statement = $dbh->prepare($sql);
  $statement->execute();
  $dbh->commit();
  $statement->finish();
}

sub MDBMessage {
  my $self = shift;
  my %args = @_;
  my $irc  = $self->initialize();
  my $ic = $self->{'initialcontext'};
  my $data = $args{'data'};
  my $group = $args{'group'};
  if (not defined $group) { $group = '_JOB_'};
  my $msg_type;
  my $msg ;
  $ic->log(message=>"MDBMessage called with",data=>\%args,domain=>"system",level=>"debug");
  if (defined $data) {
    if (ref $data eq 'ARRAY') { 
      # do nothing
    }
    else {
      $data = [$data];
    }
  }
  else {
    $msg_type = $args{'message_type'};
    $msg = $args{'message'};
    if (ref $msg eq 'ARRAY') {
      # do nothing
    }
    else {
      $msg = [$msg];
    }
    $data = [ { message_type=>$msg_type,message=>$msg } ];
  }

  my $base_sql = "
    insert into t_app_messaging(
      flowcd,
      group_name,
      message_type,
      message_value,
      run_sequence,
      ts_upload
    )
    values(
      '{{SYSTEM/RUN/FLOWCD}}',
      '$group',
      ?,
      ?,
      {{SYSTEM/RUN/RUNSEQ}},
      SYSDATE
    )
  ";
  my $dbh = $self->localgetdbconnection();
  $base_sql = $ic->expand($base_sql);
  my $statement = $dbh->prepare($base_sql);

  for my $m (@$data) {
    $ic->log(message=>"Logging one message: ",data=>$m, domain=>"info",level=>"trace");
    my $m_type = $m->{'message_type'};
    my $m_m = $m->{'message'};
    if (ref $m_m eq 'ARRAY') {} else { $m_m = [$m_m]; }
    for my $sm (@$m_m) {
      $ic->log(message=>"Monitoring message: $m_type/$sm",domain=>"system",level=>"trace");
      $statement->execute($m_type,$sm);
    }
  }
  $dbh->commit();
  $statement->finish();
}

# ==========================================================================
#
# 4. Destructor
#
# ==========================================================================

sub DESTROY {
  my $self = shift;

  # Does this one need to do anything ? I don't think so  ... 
  # Maybe turn down the 
 
}

1;

__END__

# ==========================================================================
#
# POD DOCUMENTATION
#
# ==========================================================================

=pod


=cut
