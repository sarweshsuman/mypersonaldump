package PMTFifoSentinel;

use strict;
use Carp;
use File::Temp;
use POSIX;

sub new {
  my $package = shift;
  my %args = @_;
  my $owner_thread = $args{'owner_thread'};
  my $owner_pid = $args{'owner_pid'};
  my $o = {};
  if (not defined $owner_thread and not defined $o->{'owner_thread'}) {
    use threads;
    print "setting owner to threads-tid:",threads->tid(),"\n";
    $owner_thread = threads->tid();
  }
  elsif (defined $o->{'owner_thread'}) {
    print "owner allready set in ",threads->tid(),"\n";
  }

  $o->{'name'} = tmpnam();
  POSIX::mkfifo($o->{'name'},0666);
  $o->{'owner_thread'} = $owner_thread;
  $o->{'owner_pid'} = $$;

  return bless $o;
  
}

sub getFileName {
  my $self = shift;
  return $self->{'name'};
}
sub DESTROY {
  my $self = shift;
  
  use threads;
  print "destructor called in ",threads->tid(),"\n";
  if (threads->tid() == $self->{'owner_thread'} and $$ == $self->{'owner_pid'}) {
    unlink $self->{'name'};
  }
  else {
    print "doing nothing\n";
  }
}
1;
