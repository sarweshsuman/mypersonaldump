package PMTCommonSteps;

use strict;
use Carp;


sub new {
  my $package = shift;
  my %args = @_;

  my $o = {};
  $o->{'initialcontext'} = $args{'initialcontext'};
  $o->{'xnode'} = $args{'xnode'};
  return bless $o;
}

sub deleteFile {
  my $self = shift;
  my %args = @_;
  my $filename = $args{'file'};
  if (ref $filename eq 'ARRAY') {} else { $filename = [$filename]; }
  for my $f (@$filename) {
    my $rc = `rm -f $f`;
  }
}

sub runCommand {
  my $self = shift;
  my %args = @_;
  my $command = $args{'command'};
  use PMTUtilities qw(runSysCmd);
  my $result = runSysCmd(command=>$command);
  my $ic = $self->{'initialcontext'};
  $ic->log(message=>"executed command:",data=>{command=>$command,result=>$result},level=>"info",domain=>"system");
  my $rc = $result->{'rc'};
  if ($rc) {
    croak { message=>"execution of command failed. See log for details" };
  }
}

sub moveFile {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  use Data::Dumper;
  my $filename = $args{'file'};
  if (ref $filename eq 'ARRAY') {} else { $filename = [$filename]; }
  my $directory = $args{'directory'};
  my $dirchange = 0;
  if ( -d $directory ) {
    # all is well
  }
  else {
    $directory = $ic->expand('{{ENV/PMTROOT}}/tmp');
    $dirchange = 1;
  }

  # check if the directory does actually exist ...
  use File::Basename qw(basename);
  use File::Spec;

  for my $f (@$filename) {
  	my $rc = `mv $f $directory `;
    if ($args{'compress'}) {
      my $basefile = basename $f;
      my $targetfile = File::Spec->catfile($directory,$basefile);
      my $rc = "gzip $targetfile\n";
    }
  }
  if ($dirchange) {
    my $origdirectory = $args{'directory'};
    $ic->log(message=>"Moved files to $directory instead of $origdirectory since $origdirectory does not exist",level=>"error",domain=>"system");
    croak { message=>"Directory $origdirectory does not exist" };
  }
}

sub moveOraFiles {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  use Data::Dumper;
  my $dir_source = $ic->expand($args{'dir_source'});
  my $dir_target = $ic->expand($args{'dir_target'});
  #if (ref $filename eq 'ARRAY') {} else { $filename = [$filename]; }
  #my $directory = $args{'directory'};
  #my $dirchange = 0;
  #if ( -d $directory ) {
  #  # all is well
  #}
  #else {
  #  $directory = $ic->expand('{{ENV/PMTROOT}}/tmp');
  #  $dirchange = 1;
  #}
  # check if the directory does actually exist ...
 
  unless (-d $dir_source ) { croak { message=>"Directory $dir_source does not exist" }; return;}
  unless ( -d $dir_target ) { croak { message=>"Directory $dir_target does not exist" }; return ;}

  opendir ( my $dh,$dir_source );
  while ( my $fn = readdir($dh)){
	unless( $fn eq '.' and $fn eq '..'){
		my $rc=`mv $dir_source/$fn $dir_target`;
	}
  }
  closedir($dh);
}
sub sendMail {
 my $self= shift;
 my $ic = $self->{'initialcontext'};
 my %args = @_;
 my $from = 'PMT';
 unless( defined $args{'to'} ){
	croak { message=>"Parameter TO not defined "};
	return;
 }
 my $to = $ic->expand($args{'to'});
 unless(defined $args{'subject'}){
	croak { message=>"Parameter SUBJECT not defined "};
	return;
 }
 my $subject = $ic->expand($args{'subject'});
 my $type1 = 'multipart/mixed';
 my $type2 = 'TEXT';
 my $text;
 if(not defined $args{'text'}){
	$text='';
 }
 else {
 	$text = $ic->expand($args{'text'});
 }
 use MIME::Lite;
 if( defined $args{'file'} ) {
 	my $file = $ic->expand($args{'file'});
	my $file_option;
	if(defined $args{'file_option'} ){
 		$file_option = $ic->expand($args{'file_option'});
	}
	else {
		$file_option='NOTDEFINED';
	}
	my $file_attach_format;
	if(defined $args{'attachment_format'}){
		$file_attach_format = $ic->expand($args{'attachment_format'});
	}
	else {
		$file_attach_format='TEXT';
	}
	unless ( -e $file ){
		croak { message=>"File $file does not exists" };
		return;
	}	
	if ( $file_option =~ /^ATTACH$/i ){
        	my $msg=MIME::Lite->new(
        	From => "$from",
        	To   => "$to",
        	Subject => "$subject",
        	Type    => "$type1", );

        	$msg->attach(
        	Type    => "$type2",
        	Data    => "$text",);

		$msg->attach(
		Type 	=> "$file_attach_format",
		Path 	=> "$file",);

        	$msg->send();
	}
	elsif( $file_option =~ /^DISPLAY$/i){
        	my $msg=MIME::Lite->new(
        	From => "$from",
        	To   => "$to",
        	Subject => "$subject",
        	Type    => "$type1", );
		open READ,"<$file";
		my @arr=<READ>;
		close READ;
		my $str=join " ",@arr;
        	$msg->attach(
        	Type    => "$type2",
        	Data    => "$text\n$str",);
		
        	$msg->send();
	}
	else {
		croak { message=>" option $file_option not defined " };
		return;
	}
 }
 elsif(defined $text ) {
	my $msg=MIME::Lite->new(
	From => "$from",
	To   => "$to",
	Subject => "$subject",
	Type 	=> "$type1", );

	$msg->attach(
	Type	=> "$type2",
	Data 	=> "$text",);
	$msg->send();
 }
 else {
	croak { message=>"Incorrect configuration" };
 }
}
sub pushFileToRemote {
 my $self= shift;
 my $ic = $self->{'initialcontext'};
 my %args = @_;
 my $remote_server = $ic->expand($args{'remote_server'});
 my $username = $ic->expand($args{'username'});
 my $password= $ic->expand($args{'password'});
 my $remote_path = $ic->expand($args{'remote_path'});
 my $source_path = $ic->expand($args{'source_path'});
 my $source_file_name = $ic->expand($args{'source_file_name'});
 #print STDERR "$source_file_name\n";
 my $protocol = $ic->expand($args{'protocol'});
 unless ( -e $source_path.'/'.$source_file_name ) {
	croak { message=>"Source File $source_path/$source_file_name not found!" };
	return;
 }
 if ( $protocol eq 'ftp' or $protocol eq 'FTP' ){
	use Net::FTP;
	my $ftp = Net::FTP->new($remote_server);
	my $res;
	if ( not defined $ftp ) {
		 croak { message=>"FTP to $remote_server connection unsuccessful $@"};
		return;
	}
	$res=$ftp->login($username,$password);
	if( not defined $res ) {
		croak { message=>"Unable to login into $remote_server with $username or  password ".$ftp->message};
		return;
	}
	undef $res;
	$ftp->binary();
	$res=$ftp->cwd($remote_path);
	if ( not defined $res){
		croak { message=>"Unable to change dir to $remote_path on $remote_server ".$ftp->message};
		return;
	}
	undef $res;
	$res=$ftp->put($source_path.'/'.$source_file_name);
	if ( not defined $res ) {
		croak { message=>"Unable to put the file on remote $remote_server at $source_path/$source_file_name ".$ftp->message };
		return;
	}
	
 }
 elsif ( $protocol eq 'sftp' or $protocol eq 'SFTP' ){
	use Net::OpenSSH;
	my $ssh_options = {};
  if (defined $username) {
    $ssh_options->{'user'} = $username;
  }
  if (defined $password) {
    $ssh_options->{'password'} = $password;
  }
  if (defined $args{'private_key'}) {
    $ssh_options->{'key_path'} = $ic->expand($args{'private_key'});
  }
	my $ssh = Net::OpenSSH->new($remote_server,%$ssh_options);
	my $sftp= $ssh->sftp();
	my $copyoptions = { atomic=>1,overwrite=>1,copy_time=>1,cleanup=>0};
	$sftp->put($source_path.'/'.$source_file_name,$remote_path.'/'.$source_file_name,%$copyoptions);
    	if ($sftp->error) {
      		croak { message=>"SFTP Failed: ". $sftp->error };
	}
 }
 else {
     croak { message=>"Protocol $protocol not supported " };
 } 
 $ic->{'WORKLIST/ITEM'}=$source_path.'/'.$source_file_name;
}
sub copyFiles_sftp_step2 {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_; 
  my $source_file = $args{'sourcefile'};
  if (scalar @$source_file == 0) { return ; }
  my $target_directory = $args{'target_directory'};
  my $remove_original = $args{'remove_source'};
  my $history_file = $args{'history_file'};
  my $remote=$args{'remote_mode'};
  my $atomic = $args{'atomic'};
  my $queue = $args{'queue'};
  my $cred = $args{'credentials'};
  my $host = $args{'host'};
  my $username = $args{'username'};
  use PMTUtilities qw(evalBoolean);
  my $compress = evalBoolean(value=>$args{'compress'});
  if (defined $atomic) {
    $atomic = evalBoolean(value=>$atomic);
  }
  else {
    $atomic = 1;
  }
  $remove_original = evalBoolean(value=>$remove_original);
  print STDERR "Copying using sftp step 2\n";
  use Net::OpenSSH;
  my $ssh_options = {};
  if (defined $cred->{'username'}) {
    $ssh_options->{'user'} = $cred->{'username'};
  }
  if (defined $cred->{'password'}) {
    $ssh_options->{'password'} = $cred->{'password'};
  }
  if (defined $cred->{'private_key'}) {
    $ssh_options->{'key_path'} = $cred->{'private_key'};
  }
  print "host=$host\n";
  my $ssh = Net::OpenSSH->new($host,%$ssh_options);
  my $sftp = $ssh->sftp();
  use File::Spec;
  use File::Basename qw(basename);
  my $copyoptions = { atomic=>1,overwrite=>1,copy_time=>1,cleanup=>1};
  my @successfiles = ();
  for my $f (@$source_file) {
    my $localname = File::Spec->catfile($target_directory,basename $f->{'path'});
    my $basename = basename $f->{'path'};
    #print STDERR "Retrieving file: $f->{'orig_uri'} to $localname\n";
    if ($compress) {
      my $ll = "${localname}.gz";
      use IO::File;
      my $iof = new IO::File($ll,"w");
      binmode $iof, ":gzip";
      $sftp->get($f->{'path'},$iof,%$copyoptions);
      $iof->close();
    }
    else {
      $sftp->get($f->{'path'},$localname,%$copyoptions);
      push @successfiles,basename $localname;
    }
    if ($sftp->error) {
      croak { message=>"SFTP Failed: ". $sftp->error };
    }
    

    if ($remove_original) {
      my %o;
      $sftp->remove($f->{'path'},%o);
    }
    
    if ($history_file) {
    	my $st = $sftp->stat($f->{'path'});
      print $history_file "$basename;$st->{'mtime'};$st->{'size'}\n";
    }
    if ($args{'monitoring'}) {
      $ic->MDBMessage(group=>$args{'monitoring_group'},message_type=>'FILE_COPIED',message=>\@successfiles);
    }
  }
  print STDERR "so far so good\n";
}

sub copyFiles_sftp_step1 {
  my $self = shift;
  my %args = @_;
  my $source_file = $args{'sourcefile'};
  if (scalar @$source_file == 0) { return ; }
  my $target_directory = $args{'target_directory'};
  my $remove_original = $args{'remove_source'};
  my $history_file = $args{'history_file'};
  my $remote=$args{'remote_mode'};
  my $atomic = $args{'atomic'};
  my $queue = $args{'queue'};
  print STDERR "Copying using sftp step 1\n";
  # get all the host/username combinations, and split up the transfer by those
  my $host_usernames = {};
  for my $u (@$source_file) {
    if (not defined $host_usernames->{$u->{'host'}}) {
      $host_usernames->{$u->{'host'}} = {};
    }
    if (not defined $host_usernames->{$u->{'host'}}->{$u->{'username'}}) {
      $host_usernames->{$u->{'host'}}->{$u->{'username'}} = []; 
    }
    push @{$host_usernames->{$u->{'host'}}->{$u->{'username'}}},$u;
  }
  for my $h (keys %$host_usernames) {
    for my $u (keys %{$host_usernames->{$h}}) {
      # pull the first one of the list
      my $fu = $host_usernames->{$h}->{$u}->[0];
      my $fuo = $fu->{'corrected_uri'};
      use PMTUtilities qw(getCredentials);
      my $cred = getCredentials(uri=>$fuo);
      $self->copyFiles_sftp_step2(
         target_directory=>$target_directory,
         remove_source=>$remove_original,
         remote_mode=>$remote,
         atomic=>$atomic,
         queue=>$queue,
         history_file=>$history_file,
         sourcefile=>$host_usernames->{$h}->{$u},
         credentials=>$cred,
         host=>$h,
         username=>$u,
         monitoring=>$args{'monitoring'},monitoring_group=>$args{'monitoring_group'},
         compresss=>$args{'compress'}
      );
    }
  }
}

sub copyFiles_ftp_step2 {
  my $self = shift;
  my %args = @_;
  my $source_file = $args{'sourcefile'};
  if (scalar @$source_file == 0) { return ; }
  my $target_directory = $args{'target_directory'};
  my $remove_original = $args{'remove_source'};
  my $history_file = $args{'history_file'};
  my $remote=$args{'remote_mode'};
  my $atomic = $args{'atomic'};
  my $queue = $args{'queue'};
  my $cred = $args{'credentials'};
  my $host = $args{'host'};
  my $username = $args{'username'};
  use PMTUtilities qw(evalBoolean);
  my $compress = evalBoolean(value=>$args{'compress'});
  if (not defined $atomic) {
    $atomic = 1;
  }
  else {
  $atomic = evalBoolean(value=>$atomic);
  }
  $remove_original = evalBoolean(value=>$remove_original);
  print STDERR "Copying using ftp step 2\n";
  use Net::FTP;
  my $ftp = Net::FTP->new($host);
  $ftp->login($cred->{'username'},$cred->{'password'});
  $ftp->binary();
  use File::Spec;
  use File::Basename qw(basename);
  my $copyoptions = { atomic=>1,overwrite=>1,copy_time=>1,cleanup=>1};
  for my $f (@$source_file) {
    my $localname = File::Spec->catfile($target_directory,basename $f->{'path'});
    my $basename = basename $f->{'path'};
    #print STDERR "Retrieving file: $f->{'orig_uri'} to $localname\n";
    my $res;
    if ($compress) {
      my $ll = "${localname}.gz";
      use IO::File;
      my $iof = new IO::File($ll,"w");
      binmode $iof, ":gzip";
      $res = $ftp->get($f->{'path'},$iof);
      $iof->close();
    }
    else {
      $res = $ftp->get($f->{'path'},$localname);
    }
    if (not defined $res) {
      croak { message=>"FTP Failed: ". $ftp->message };
    }

    if ($remove_original) {
      print STDERR "I should be removing $f->{'path'} ...";
      my $rd ;
      eval {$rd = $ftp->delete($f->{'path'}); }; if ($@) { print STDERR "Delete operation failed: $@\n"; }
      print STDERR "$rd ...\n";
      
    }
    
    if ($history_file) {
      my $m = $ftp->mdtm($f->{'path'});
      my $s = $ftp->size($f->{'path'});
      print $history_file "$basename;$m;$s\n";
    }
    #print STDERR "Retrieving file with $st->
  }
  print STDERR "so far so good\n";
}
sub copyFiles_ftp_step1 {
  my $self = shift;
  my %args = @_;
  my $source_file = $args{'sourcefile'};
  if (scalar @$source_file == 0) { return ; }
  my $target_directory = $args{'target_directory'};
  my $remove_original = $args{'remove_source'};
  my $history_file = $args{'history_file'};
  my $remote=$args{'remote_mode'};
  my $atomic = $args{'atomic'};
  my $queue = $args{'queue'};
  print STDERR "Copying using sftp step 1\n";

  # get all the host/username combinations, and split up the transfer by those
  my $host_usernames = {};
  for my $u (@$source_file) {
    if (not defined $host_usernames->{$u->{'host'}}) {
      $host_usernames->{$u->{'host'}} = {};
    }
    if (not defined $host_usernames->{$u->{'host'}}->{$u->{'username'}}) {
      $host_usernames->{$u->{'host'}}->{$u->{'username'}} = []; 
    }
    push @{$host_usernames->{$u->{'host'}}->{$u->{'username'}}},$u;
  }
  for my $h (keys %$host_usernames) {
    for my $u (keys %{$host_usernames->{$h}}) {
      # pull the first one of the list
      my $fu = $host_usernames->{$h}->{$u}->[0];
      my $fuo = $fu->{'corrected_uri'};
      use PMTUtilities qw(getCredentials);
      my $cred = getCredentials(uri=>$fuo);
      $self->copyFiles_ftp_step2(
         target_directory=>$target_directory,
         remove_source=>$remove_original,
         remote_mode=>$remote,
         atomic=>$atomic,
         queue=>$queue,
         history_file=>$history_file,
         sourcefile=>$host_usernames->{$h}->{$u},
         credentials=>$cred,
         host=>$h,
         username=>$u,
         monitoring=>$args{'monitoring'},monitoring_group=>$args{'monitoring_group'},
         compress=>$args{'compress'}
      );
    }
  }
}


sub copyFiles_scp {
}

sub copyFiles_file {
  my $self = shift;
  my %args = @_;
  my $source_file = $args{'sourcefile'};
  if (scalar @$source_file == 0) { return ; }
  my $target_directory = $args{'target_directory'};
  my $remove_original = $args{'remove_source'};
  my $history_file = $args{'history_file'};
  my $remote=$args{'remote_mode'};
  my $atomic = $args{'atomic'};
  my $queue = $args{'queue'};

  use File::Basename qw(basename);
  use File::Spec;

  FILELOOP:
  for my $f (@$source_file) {

    my $b = basename $f->{'path'};
    if (File::Spec->catfile($target_directory,$b) eq $f->{'path'}) {
      print STDERR "Cannot copy file $f->{'path'} onto itself\n";
      next FILELOOP;
    }
    
    my $rc = `cp $f->{'path'} $target_directory`;

    if ($remove_original) {
      $rc = `rm -f $f->{'path'}`;
    }

    if ($history_file) {
    	my @st = stat($f->{'path'});
      my $s = $st[7]; my $m = $st[9];
      print $history_file "$b;$m;$s\n";
    }
  }
}

sub copyFiles {
  my $self = shift;
  my %args = @_;
  my $source_file = $args{'sourcefile'};
  print STDERR "Got sourcefile : $source_file\n";
  if (ref $source_file eq 'ARRAY') {
  }
  else {
    $source_file = [ $source_file ];
  }
  my $target_directory = $args{'target_directory'};
  my $remove_original = $args{'remove_source'};
  my $history_file = $args{'history_file'};
  my $remote=$args{'remote_mode'};
  my $atomic = $args{'atomic'};
  my $monitoring = $args{'monitoring'}; if (not defined $monitoring) { $monitoring = 0; }
  my $monitoring_group = $args{'monitoring_group'};
  my $queue = $args{'queue'};
  use PMTUtilities qw(parseURI);
  my @source_uris = map { parseURI(uri=>$_,resolve_credentials=>1) } @$source_file;
  # see what schemes we have
  use Data::Dumper;
  print STDERR "Uris are now:\n",Dumper(\@source_uris),"\n";
  my $schemes = {};
  for my $u (@source_uris) {
    if (not defined $schemes->{$u->{'scheme'}}) {
      $schemes->{$u->{'scheme'}} = [];
    }
    push @{$schemes->{$u->{'scheme'}}},$u;
  }
  my $history_file_handle;
  if ($history_file) {
    open ($history_file_handle,">>",$history_file);
  }
  for my $s (keys %$schemes) {
    if ($s =~ m/SFTP/i) {
       print STDERR "Copying using SFTP\n";
       $self->copyFiles_sftp_step1 (
         target_directory=>$target_directory,
         remove_source=>$remove_original,
         remote_mode=>$remote,
         atomic=>$atomic,
         queue=>$queue,
         history_file=>$history_file_handle,
         sourcefile=>$schemes->{$s},
         monitoring=>$monitoring, monitoring_group=>$monitoring_group,
         compress=>$args{'compress'}
       );
    }
    elsif ($s =~ m/SCP|SSH/i) {
       print STDERR "Copying using SCP\n";
    }
    elsif ($s =~  m/FTP/i) {
       $self->copyFiles_ftp_step1 (
         target_directory=>$target_directory,
         remove_source=>$remove_original,
         remote_mode=>$remote,
         atomic=>$atomic,
         queue=>$queue,
         history_file=>$history_file_handle,
         sourcefile=>$schemes->{$s},
         monitoring=>$monitoring, monitoring_group=>$monitoring_group,
         compress=>$args{'compress'}
       );
    }
    elsif ($s =~ m/FILE/i) {
       #print STDERR "Localcopy\n";
       $self->copyFiles_file(
         target_directory=>$target_directory,
         remove_source=>$remove_original,
         remote_mode=>$remote,
         atomic=>$atomic,
         queue=>$queue,
         history_file=>$history_file_handle,
         monitoring=>$monitoring, monitoring_group=>$monitoring_group,
         sourcefile=>$schemes->{$s}
       );
    }
  }
}
1;
