package DBTie;

use DBI;
require Tie::Hash;

use strict;
use Carp;

our @ISA = qw(Tie::Hash);

sub TIEHASH {
  my $class = shift;
  my %args = @_;

  my $o = {};
  my $oo = [$o];
  $o->{'keys'} = [];
  $o->{'system'} ={}; 
  $o->{'dict'} = {};
  $o->{'xnode'} = $args{'xnode'};
  $o->{'system'}->{'initialcontext'} = $args{'initialcontext'};
  my $ic = $args{'initialcontext'};
  $o->{'system'}->{'dbconn'} = $args{'dbconn'};
  #$o->{'system'}->{'fetch_sql'} = $ic->expand($args{'fetch_sql'});
  $o->{'system'}->{'target_table'} = $ic->expand($args{'target_table'});
  $o->{'system'}->{'key_col'} = $ic->expand($args{'key_col'});
  $o->{'system'}->{'id_col'} = $ic->expand($args{'id_col'});
  $o->{'system'}->{'sequence'} = $ic->expand($args{'id_generator_name'});
  $o->{'system'}->{'id_generator_type'} = $ic->expand($args{'id_generator_type'});
  $o->{'system'}->{'id_generator_dialect'} = $ic->expand($args{'id_generator_dialect'});

  $o->{'use_locking'} = $ic->expand('{{SYSTEM/SETTINGS/DBLOOKUP/LOAD|default 1}}');

  $ic->log(message=>"Creating a DBTie object",domain=>"system",level=>"debug");

  if (defined $args{'verbose'}) {
    $o->{'system'}->{'verbose'} = $ic->expand($args{'verbose'});
  }
  else {
    $o->{'system'}->{'verbose'} = 0;
  }
  if (defined $args{'store_name'}) {
    $o->{'system'}->{'store_name'} = $ic->expand($args{'store_name'});
  }
  else {
    $o->{'system'}->{'store_name'} = 'DBKeyStore';
  }
  if (defined $args{'auto_insert'}) {
    $o->{'system'}->{'auto_insert'} = $ic->expand($args{'auto_insert'});
  }
  else {
    $o->{'system'}->{'auto_insert'} = 0;
  }
  my $ic = $o->{'system'}->{'initialcontext'};

  # the following is basically a hash containing the keycol,idcol target_table,and a sequence
  # in other words: { keycol=>key_col,id_col=>'idcol',target_table=>'target_table',sequence=>'sequencename'}
  $o->{'store_sql'} = $args{'store_sql'};

  # do the initial load
  my $sql = '
    select '.$o->{'system'}->{'key_col'}.','.$o->{'system'}->{'id_col'}.' from '.$o->{'system'}->{'target_table'}.' order by '.$o->{'system'}->{'key_col'} ;
  if ($o->{'system'}->{'verbose'}) {
    $ic->log(message=>"Doing sql for initialload: $sql",domain=>"system",level=>"info");
    #print STDERR "Using sql:\n$sql\n for initial load\n";
  }
  my $dbh = $o->{'system'}->{'dbconn'};
  my $statement = $dbh->prepare($sql);
  $statement->execute();
  my $rows = $statement->fetchall_arrayref();
  $ic->log(message=>"Got ". scalar @$rows. " rows from db in ".$o->{'system'}->{'store_name'},domain=>"system",level=>"info");
  for my $r (@$rows) {
    $o->{'dict'}->{$r->[0]} = $r->[1];
    push @{$o->{'keys'}},$r->[0];
  }
  
  $ic->log(message=>"End of constructor in DBTie",level=>"debug",domain=>"system");

  bless $oo;

  return $oo;
} 

sub STORE {
  my $S = shift; my $self = $S->[0];
  my ($key,$value) = @_;
  my $store_value;
  my $ic = $self->{'system'}->{'initialcontext'};

  #print STDERR "HASH says: Trying to store a value\n";
  # check whether it exists in the database
  if ($self->{'system'}->{'verbose'}) {
    #
  }
  if (exists $self->{'dict'}->{$key}) {
    return $self->{'dict'}->{$key};
  }

  my $sql;
  if (not defined $value or $value == 0) {
  use PMTUtilities qw(evalBoolean);
  my $do_locking = evalBoolean(value=>$self->{'use_locking'});
  if ($do_locking) {
    $sql = '
declare
idn number;

function finsert(vkey in varchar2) return number is
  cursor c1 is select * from '.$self->{'system'}->{'target_table'}.' for update;
  rval number;
begin
  open c1;
  begin
  select x.'.$self->{'system'}->{'id_col'}.' into rval from '.$self->{'system'}->{'target_table'}.' x where x.'.$self->{'system'}->{'key_col'}.' = finsert.vkey;
  if c1%isopen
  then
    close c1;
  end if;
  return rval;
  exception 
    when NO_DATA_FOUND then null;
    when others then raise;
  end;
  
  insert into '.$self->{'system'}->{'target_table'}.'('.$self->{'system'}->{'id_col'}.','.$self->{'system'}->{'key_col'}.') values
('.$self->{'system'}->{'sequence'}.'.nextval,finsert.vkey) returning '.$self->{'system'}->{'id_col'}.' into rval;
  commit;

  if c1%isopen
  then
    close c1;
  end if;

  return rval;
end;

begin
  null;
  ? := finsert(?);
end;

';
}
else {
$sql = '
declare
idn number;

function finsert(vkey in varchar2) return number is
  -- cursor c1 is select * from '.$self->{'system'}->{'target_table'}.' for update;
  rval number;
begin
  -- open c1;
  -- begin
  -- select x.'.$self->{'system'}->{'id_col'}.' into rval from '.$self->{'system'}->{'target_table'}.' x where x.'.$self->{'system'}->{'key_col'}.' = finsert.vkey;
  -- if c1%isopen
  -- then
  --  close c1;
  -- end if;
  -- return rval;
  -- exception 
  --   when NO_DATA_FOUND then null;
  --  when others then raise;
  --end;
  
  insert into '.$self->{'system'}->{'target_table'}.'('.$self->{'system'}->{'id_col'}.','.$self->{'system'}->{'key_col'}.') values
('.$self->{'system'}->{'sequence'}.'.nextval,finsert.vkey) returning '.$self->{'system'}->{'id_col'}.' into rval;
  commit;

  -- if c1%isopen
  -- then
  --  close c1;
  -- end if;
  exception
  when DUP_VAL_ON_INDEX then
    select x.'.$self->{'system'}->{'id_col'}.' into rval from '.$self->{'system'}->{'target_table'}.' x where x.'.$self->{'system'}->{'key_col'}.' = finsert.vkey;
    commit;

  when others then raise;

  return rval;
end;

begin
  null;
  ? := finsert(?);
end;
';
}
      
    my $e;
    #print STDERR "using sql for insert:\n$sql\n";
    my $dbh = $self->{'system'}->{'dbconn'};
    my $statement;
    eval {
      $statement = $dbh->prepare($sql);
      my $rval;
      $statement->bind_param(2,$key);
      $statement->bind_param_inout(1,\$rval,50);
      $statement->execute();
      $store_value = $rval;
      $self->{'dict'}->{$key} = $store_value;
      push @{$self->{'keys'}},$key;
      return $store_value;
    };
    if ($@) {
      $e = $@;
      if ($self->{'system'}->{'verbose'}) {
        print STDERR "Got an error while storing value: $@\n";
      };
      eval {
        $statement->finish();
      };
      if (defined $e) {
        croak { message=>$e };
      }
    }
  }
}

sub UNTIE {
  print STDERR "Object is Untied";
}

sub FETCH {
  my $S = shift; my $self = $S->[0];
  my $key = shift;
  my $store_value;
  my $ic = $self->{'system'}->{'initialcontext'};
  use PMTUtilities qw(icdefined);

  if (defined $key and not icdefined $key) {
    $ic->log(message=>"Getting $key in FETCH",domain=>"system",level=>"trace");
  }
  if (defined $self->{'dict'}->{$key}) {
    return $self->{'dict'}->{$key};
  }
  my $sql;

  if ($self->{'system'}->{'auto_insert'}) {
  use PMTUtilities qw(evalBoolean);
  my $do_locking = evalBoolean(value=>$self->{'use_locking'});
		if ($do_locking) {
			$sql = '
	declare
	idn number;

	function finsert(vkey in varchar2) return number is
		cursor c1 is select * from '.$self->{'system'}->{'target_table'}.' for update;
		rval number;
	begin
		open c1;
		begin
		select x.'.$self->{'system'}->{'id_col'}.' into rval from '.$self->{'system'}->{'target_table'}.' x where x.'.$self->{'system'}->{'key_col'}.' = finsert.vkey;
		if c1%isopen
		then
			close c1;
		end if;
		return rval;
		exception 
			when NO_DATA_FOUND then null;
			when others then raise;
		end;
		
		insert into '.$self->{'system'}->{'target_table'}.'('.$self->{'system'}->{'id_col'}.','.$self->{'system'}->{'key_col'}.') values
	('.$self->{'system'}->{'sequence'}.'.nextval,finsert.vkey) returning '.$self->{'system'}->{'id_col'}.' into rval;
		commit;

		if c1%isopen
		then
			close c1;
		end if;

		return rval;
	end;

	begin
		null;
		? := finsert(?);
	end;

	';
		} 
		else {
$sql = '
declare
idn number;

function finsert(vkey in varchar2) return number is
  -- cursor c1 is select * from '.$self->{'system'}->{'target_table'}.' for update;
  rval number;
begin
  -- open c1;
  -- begin
  -- select x.'.$self->{'system'}->{'id_col'}.' into rval from '.$self->{'system'}->{'target_table'}.' x where x.'.$self->{'system'}->{'key_col'}.' = finsert.vkey;
  -- if c1%isopen
  -- then
  --  close c1;
  -- end if;
  -- return rval;
  -- exception 
  --   when NO_DATA_FOUND then null;
  --  when others then raise;
  --end;
  
  insert into '.$self->{'system'}->{'target_table'}.'('.$self->{'system'}->{'id_col'}.','.$self->{'system'}->{'key_col'}.') values
('.$self->{'system'}->{'sequence'}.'.nextval,finsert.vkey) returning '.$self->{'system'}->{'id_col'}.' into rval;
  commit;

  -- if c1%isopen
  -- then
  --  close c1;
  -- end if;
  exception
  when DUP_VAL_ON_INDEX then
    select x.'.$self->{'system'}->{'id_col'}.' into rval from '.$self->{'system'}->{'target_table'}.' x where x.'.$self->{'system'}->{'key_col'}.' = finsert.vkey;
    commit;

  when others then raise;

  return rval;
end;

begin
  null;
  ? := finsert(?);
end;
';
		}
  }
  else {
  
    $sql = '
declare
idn number;

function finsert(vkey in varchar2) return number is
  cursor c1 is select * from '.$self->{'system'}->{'target_table'}.' for update;
  rval number;
begin
  open c1;
  begin
  select x.'.$self->{'system'}->{'id_col'}.' into rval from '.$self->{'system'}->{'target_table'}.' x where x.'.$self->{'system'}->{'key_col'}.' = finsert.vkey;
  if c1%isopen
  then
    close c1;
  end if;
  return rval;
  exception 
    when NO_DATA_FOUND then rval := null;
    when others then raise;
  end;
  
  if c1%isopen
  then
    close c1;
  end if;

  return rval;
end;

begin
  null;
  ? := finsert(?);
end;

 ';
  } 

  my $dbh = $self->{'system'}->{'dbconn'};
  my $statement = $dbh->prepare($sql);
  my $rval;
  $statement->bind_param(2,$key);
  $statement->bind_param_inout(1,\$rval,50);
  $statement->execute();
  $statement->finish();
  $store_value = $rval;
  if ($rval) {
    $self->{'dict'}->{$key} = $rval;
    push @{$self->{'keys'}},$key;
  }
  #print STDERR "in DBTIE returning value: $rval for key $key\n"; 
  return $rval;
}
  # Check the database to see whether it exists there

sub FIRSTKEY {
  my $S = shift; my $self = $S->[0];
  my $ic = $self->{'system'}->{'initialcontext'};

  if (scalar @{$self->{'keys'}}) {
    return $self->{'keys'}->[0];
  }
  return undef;
}

sub NEXTKEY {
  my $S = shift; my $self = $S->[0];
  my $lastkey = shift;
  my $ic = $self->{'system'}->{'initialcontext'};

  my @list = grep {$_ gt $lastkey } sort @{$self->{'keys'}};
  if (scalar @list) {
    return $list[0];
  }
  return undef;
}

sub EXISTS {
  my $S = shift; my $self = $S->[0];
  my $key = shift;
  my $ic = $self->{'system'}->{'initialcontext'};

  if (exists $self->{'dict'}->{$key}) {
    return 1;
  }
  my $sql = '
declare
idn number;

function finsert(vkey in varchar2) return number is
  cursor c1 is select * from '.$self->{'system'}->{'target_table'}.' for update;
  rval number;
begin
  open c1;
  begin
  select x.'.$self->{'system'}->{'id_col'}.' into rval from '.$self->{'system'}->{'target_table'}.' x where x.'.$self->{'system'}->{'key_col'}.' = finsert.vkey;
  if c1%isopen
  then
    close c1;
  end if;
  return rval;
  exception 
    when NO_DATA_FOUND then rval := null;
    when others then raise;
  end;
  
  if c1%isopen
  then
    close c1;
  end if;

  return rval;
end;

begin
  null;
  ? := finsert(?);
end;

 ';

  my $dbh = $self->{'system'}->{'dbconn'};
  my $statement = $dbh->prepare($sql);
  my $rval;
  $statement->bind_param(2,$key);
  $statement->bind_param_inout(1,\$rval,50);
  $statement->execute();
  $statement->finish();
  if (defined $rval) {
    $self->{'dict'}->{$key} = $rval;
    push @{$self->{'keys'}},$key;
    return 1;
  }
  return 0;
  # it may not exist here but it may exist in the database
}

sub DELETE {
  my $S = shift; my $self = $S->[0];
  my $key = shift;
  #my $ic = $self->{'system'}->{'initialcontext'};

  return delete $self->{'dict'}->{$key};

  # should it also delete from the database ? I don't think so
}

sub CLEAR {
  my $S = shift; my $self = $S->[0];
  #my $ic = $self->{'system'}->{'initialcontext'};

  #return clear %{$self->{'dict'}};

  # should it return from the database
}

sub SCALAR {
  my $S = shift; my $self = $S->[0];
  #my $ic = $self->{'system'}->{'initialcontext'};

  return scalar %{$self->{'dict'}};
}

1;
