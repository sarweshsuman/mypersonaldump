# ##########################################################################
# MODULENAME          : PMTLogHelper
# DESCRIPTION         : PMT Helper Class: Logging
# AUTHOR              : Evert Carton
# INPUTS              : NONE
# OUTPUTS             : NONE
# DEPENDENCY          : NONE
# REMARKS             : NONE
# VERSION             : 1.0
# REVISION HISTORY    : Initial Version
# ##########################################################################

# ==========================================================================
#
# Package Declaration
#
# ==========================================================================

package PMTPLHelperLogHelper;

# ==========================================================================
#
# Use Declarations
#
# ==========================================================================

use strict;
use Carp;

use PMTHelperBase;

our @ISA = qw(PMTHelperBase);
use Data::Dumper;

use PMTUtilities qw(expand icdefined);

# ==========================================================================
#
# Local Variables
#
# Please note that the PMTLogHelper is conceived as a class
# These module variables are NOT instance variables
# ==========================================================================

my $loglevels = {
  DEBUG=>0,
  TRACE=>1,
  DEVNOTE=>9,
  VERBOSE=>2,
  INFO=>3,
  WARNING=>4,
  ERROR=>5
};

my $default_logline_pattern = '{{_NOW_|::formatDateTime "%Y-%m-%d %H:%M:%S"}} {{LEVEL|::default UNKNOWN|::substring 8|::rpad 8}} {{DOMAIN|::default UNKNOWN |::substring 8|::rpad 8}} {{CALLER|::default UNKNOWN|::substring 30|::rpad 30}} {{?PAYLOAD}}';

my $default_logfilename_pattern = '{{JOB_ID}}.scriptlog.{{_START_TM_|::formatDateTime %Y%m%d%H%M%S}}';
my $default_threshold = 'INFO';
my $default_level = 'INFO';
my $default_domain = 'SYSTEM';

my $default_domains = ['LIFECYCLE','MODEL','HELPERS','DEVNOTE','SYSTEM'];


# ==========================================================================
#
# 2. Constructor
#
# ==========================================================================

sub new {
  my $class = shift;
  my %args = @_;
  my $context = $args{'initialcontext'};
  my $obj = {};
  $obj->{'context'} = $context;
  $obj->{'LOGHANDLE'} = undef;
  $obj->{'FILENAME'} = undef;
  $obj->{'THRESHOLD'} = $loglevels->{'INFO'};
  $obj->{'ARCHIVE_ON_END'} = 1;
  $obj->{'_CHILDPROCESS_'} = 0;
  $obj->{'STARTED'} = 0;
  $obj->{'DEFAULT_LOGLEVEL'} = 'INFO';
  $obj->{'DEFAULT_LOGDOMAIN'} = 'SYSTEM';
  $obj->{'_HELD_'} = 0;
  $obj->{'_HELDLINES_'} = [];
  bless $obj;
  return $obj;
}

# ==========================================================================
#
# System Methods
#
# ==========================================================================

sub setChildProcess {
  my $self = shift;
  $self->{'_CHILDPROCESS_'} = 1;
  autoflush STDERR 1;
}

sub startHelper {
  my $self = shift;
  my $context = $self->{'context'};
  my $jobid = $context->{'JOB_ID'};
  # Opening the logfile
  my $logfilename = undef;
  my $filenamefromoptions = $context->getJobOption('LOGFILE');
  if (defined $filenamefromoptions) {
    $self->{'ARCHIVE_ON_END'} = 0;
    if ($filenamefromoptions eq '-') {
      $logfilename = undef;
      $self->{'ARCHIVE_ON_END'} = 0;
    }
    else {
      if ($filenamefromoptions =~ m/^\.\.?\//) {
        # a relative path has been given ... 
        $logfilename = File::Spec->rel2abs($filenamefromoptions);
        $self->{'ARCHIVE_ON_END'} = 0;
      }
      elsif ($filenamefromoptions =~ m/\//) {
        # an absolute path has been given
        $logfilename = $filenamefromoptions;
      }
      else {
        # simply put it in the current directory
        $logfilename = File::Spec->rel2abs($filenamefromoptions);
      }
    }
  }
  else {
    my $logfilenamepattern;
    
    $logfilenamepattern = $context->getConfigParameter('PMTLOGHELPER_LOGFILENAME_PATTERN');
    if (not defined $logfilenamepattern) {
    	$logfilenamepattern = $default_logfilename_pattern;
    }
    my $jobfilename;
    if (defined $logfilenamepattern) {
      $logfilename = PMTUtilities::expand(src=>$logfilenamepattern,evalcontext=>[$context,\%ENV]);
      $logfilename = File::Spec->catfile($ENV{'LOGS'},$logfilename);
    }
    else {
      #print STDERR "Could not find logfilenamepattern\n";
    }
  }
  if (defined $logfilename) {
    print STDERR "Setting up logging for jobid $jobid (scenario $context->{SCENARIO}) using logfile: $logfilename\n";
    my $HANDLE;
    eval {
      open($HANDLE,">",$logfilename);
      autoflush $HANDLE 1;
      $self->{'LOGHANDLE'} = $HANDLE;
      $self->{'FILENAME'} = $logfilename;
    };
    if ($@) {
      print STDERR "Failed to open $logfilename:$@\n";
      print STDERR "Logging to STDERR instead\n";
    }
  }
  if (not defined $logfilename) {
    $self->log(message=>"Logging for jobid $jobid to STDERR",call_level=>-2);
  }

  my $threshold = $context->getJobOption('LOGTHRESHOLD');
  my $icthreshold = undef;
  if (defined $threshold) {
    # do something;
  }
  else {
    $threshold = $context->getConfigParameter('LOGHELPER_LOGTHRESHOLD');
    $icthreshold = $context->{'CONFIG/SYSTEM/LOG/LOGTHRESHOLD'};
  }
  if (icdefined $icthreshold) {
    $threshold = $context->resolve('CONFIG/SYSTEM/LOG/LOGTHRESHOLD');
  }
  if (defined $threshold) {
    if ($threshold =~ m/\d+/) {
      # do nothing
    }
    else {
      $threshold = uc $threshold;
      if (defined $loglevels->{$threshold}) {
        $threshold = $loglevels->{$threshold};
      }
      else {
        $threshold = $self->{'THRESHOLD'};
      }
    }
  }
  else {
    $threshold = $self->{'THRESHOLD'};
  }
  $self->{'THRESHOLD'} = $threshold;

  # Get the domains ...
  my $configureddomains = $context->getConfigParameter('LOGHELPER_LOGDOMAINS');
  if (defined $configureddomains) {
    $self->{'DOMAINS'} = $configureddomains;
  }
  else {
    $self->{'DOMAINS'} =  $default_domains;
  }
  # setting line pattern
  my $loglinepattern = $context->getConfigParameter('PMTLOGHELPER_LOGLINE_PATTERN');
  if (defined $loglinepattern) {
    $self->{'LINEPATTERN'} = $loglinepattern;
  }
  else {
    $self->{'LINEPATTERN'} = $default_logline_pattern;
  }
  # get the default level
  my $deflevel = $context->getConfigParameter('LOGHELPER_DEFAULTLOGLEVEL');
  if (defined $deflevel) {
  	$self->{'DEFAULT_LOGLEVEL'} = uc $deflevel;
  }
  my $defdomain = $context->getConfigParameter('LOGHELPER_DEFAULTLOGDOMAIN');
  if (defined $defdomain) {
  	$self->{'DEFAULT_LOGDOMAIN'} = uc $defdomain;
  }


  $self->{'STARTED'} = 1;
}

# ==========================================================================
#
# 'Private' methods
#
# ==========================================================================
sub disableLogArchiving {
  my $self = shift;
  $self->{'ARCHIVE_ON_END'} = 0;
}

sub hold{
  my $self = shift;
  my %args=@_;

  $self->{'_HELD_'} = 1;
}

sub release {
  my $self = shift;
  my %args = @_;


  my $heldlines = $self->{'_HELDLINES_'};
  my $handle = $self->{'LOGHANDLE'};
  if (defined $args{'beginmarker'}) {
    unshift @$heldlines,$args{'beginmarker'};
  }
  if (defined $args{'endmarker'}) {
    push @$heldlines,$args{'endmarker'};
  } 
  my $str = join("\n",@$heldlines);

  print $handle "$str\n";

  $self->{'_HELD_'} = 0;

} 

sub writelogline {
  my $self = shift;
  my %args = @_;
  #print "writelogline called\n";
  
  my $context = $self->{'context'};

  my $LOGTARGET;
  if (defined $args{'target'}) {
    $LOGTARGET = $args{'target'};
  }
  else {
    if (defined $self->{'LOGHANDLE'}) {
      $LOGTARGET = $self->{'LOGHANDLE'};
    }
    else {
      $LOGTARGET = *STDERR;
    }
  }

  if (defined $args{'linespec'}) {

    my $loglinepattern = $self->{'LINEPATTERN'};
    my $linespec = $args{'linespec'};
    my $payload = $linespec->{'PAYLOAD'};
    
    my $realpayload;
    if (ref $payload eq 'ARRAY') {
      if (scalar @$payload > 1) {
        my @payloadlines = @$payload;
        @payloadlines = map { "   >>> $_"; } @payloadlines;
        $realpayload = "\n".join ("\n",@payloadlines);
      }
      else {
        $realpayload = $payload->[0];
      }
    }
    else {
      $realpayload = $payload;
    }
    if (defined $linespec->{'DETAIL'}) {
      my $detail = $linespec->{'DETAIL'};
      $realpayload = "$realpayload\n   >>> -- DETAIL --";
      my $detailline;
      if (ref $detail eq 'ARRAY') {
         my @detaillines = @$detail;
         @detaillines = map { "      >> $_";} @detaillines;
         $detailline = join("\n",@detaillines);
      }
      else {
        $detailline = "      >> $detail";
      }
      $realpayload = "$realpayload\n$detailline";
      $realpayload = "$realpayload\n   >>> -- END OF DETAIL --";
    }
    if (defined $linespec->{'OUTPUT'}) {
      my $output = $linespec->{'OUTPUT'};
      $realpayload = "$realpayload\n   >>> -- OUTPUT --";
      my $outputline;
      if (ref $output eq 'ARRAY') {
      my $dumper = new Data::Dumper([$output]);
      $dumper->Purity(1)->Useperl(1);
      my $dumped = $dumper->Dump();
         #my @outputlines = @$output;
         my @outputlines = split(/\n/,$dumped);
         @outputlines = map { chomp; "      >> $_";} @outputlines;
         $outputline = join("\n",@outputlines);
      }
      else {
        $outputline = "      >> $output";
      }
      $realpayload = "$realpayload\n$outputline";
      $realpayload = "$realpayload\n   >>> -- END OF OUTPUT --";
    }

    if (defined $linespec->{'DATA'}) {
      my $data = $linespec->{'DATA'};
      if (ref $data eq 'HASH') {
        $realpayload = "$realpayload\n   >>> -- DATA --";
	      my $newdata = {};
	      for my $k (keys %$data) {
	        if ($k eq 'initialcontext') {
	          $newdata->{$k} = '<INITIALCONTEXT>';
	        }
	        else {
	          $newdata->{$k} = $data->{$k};
	        }
	      }

			  my $dumper = new Data::Dumper([$newdata]);
			  $dumper->Purity(1)->Useperl(1);
			  my $dumped = $dumper->Dump();
			  #my @outputlines = @$output;
			  my @outputlines = split(/\n/,$dumped);

			  my @datalines = map { "      >> $_ ";} @outputlines;
			  my $dataline = join("\n",@datalines);
			  $realpayload = "$realpayload\n$dataline\n   >>> -- END OF DATA --";
      }
      elsif (ref $data eq 'ARRAY') {
        my $dumper = new Data::Dumper([$data]);
        $dumper->Purity(1)->Useperl(1);
        my $dumped = $dumper->Dump();
        #my @outputlines = @$output;
        my @outputlines = split(/\n/,$dumped);

        $realpayload = "$realpayload\n   >>> -- DATA --";
        my @datalines = map { "      >> $_ ";} @outputlines;
        my $dataline = join("\n",@datalines);
        $realpayload = "$realpayload\n$dataline\n   >>> -- END OF DATA --";
      }
      elsif (defined $data and not ref $data) {
         $realpayload = "$realpayload\n   >>> -- DATA --";
         $realpayload = "$realpayload\n$data\n   >>> -- END OF DATA --";
      }
    }
    if (defined $linespec->{'FILENAME'}) {
      my $filenames = $linespec->{'FILENAME'};
      if (ref $filenames eq 'ARRAY') {}
      else {
        $filenames = [$filenames];
      }
      for my $filename (@$filenames) {
        if ( -e $filename) {
          $realpayload = "$realpayload\n   >>> -- CONTENTS OF FILE: $filename --";
          my $FHANDLE;
          open ($FHANDLE,'<',$filename);
          my @lines = <$FHANDLE>;
          close $FHANDLE;
          @lines = map { chomp; $_; } @lines;
          @lines = map { "      >> $_"; } @lines;
          my $fileline = join("\n",@lines);
          $realpayload = "$realpayload\n$fileline";
          $realpayload = "$realpayload\n   >>> -- END OF FILE: $filename --";
        }
      }
    }
    if (ref $payload eq 'ARRAY' or defined $linespec->{'DATA'} or defined $linespec->{'FILENAME'}) {
       $realpayload = "$realpayload\n   >>> --- END OF MULTILINE MESSAGE --- <<<";
    }
    #    push @payloadlines,"   >>> --- END OF MULTILINE MESSAGE --- <<<";
    
    my $linetowrite = expand(src=>$loglinepattern,evalcontext=>[{PAYLOAD=>$realpayload},$linespec,$context],recursive=>0);
  
    
    if ($self->{'_HELD_'} == 1) {
      my $heldlines = $self->{'_HELDLINES_'};
      push @$heldlines,$linetowrite;
    }
    else {
      #print $LOGTARGET "$linetowrite\n";
      print STDERR "$linetowrite\n";
    }
  }
  elsif (defined $args{'line'}) {
    my $line = $args{'line'};
    if (ref $line eq 'ARRAY') {
      my @lines = @$line;
      @lines = map { chomp; $_; } @lines;
      $line = join("\n",@lines);
      $line = "\n$line";
    }
    else {
      chomp $line;
    }
    if (defined $args{'heading'}) {
      my $heading = $args{'heading'};
      if ($self->{'_HELD_'} == 1) {
        my $heldlines = $self->{'_HELDLINES_'};
        push @$heldlines,"$heading $line";
      }
      else {
        print STDERR "$heading $line\n";
      }
    }
  }
}

# ==========================================================================
# 
# Public Methods
#
# ==========================================================================

sub getLogHandle {
  my $self = shift;
  return $self->{'LOGHANDLE'} if defined $self->{'LOGHANDLE'};
  return undef;
}

sub getLogFileName {
  my $self = shift;
  return $self->{'FILENAME'} if defined $self->{'FILENAME'};
  return undef;
}

sub newlog {
  my %self = shift;
  my %args = @_;
  my $message = $args{'message'};
  chomp $message;
  print STDERR "LOG: $message\n";
}

sub log {
  # Needs support for evalcontext";
  my $self = shift;
  my %args = @_;
  my @whocalledme;
  my $linespec = {};
  my $context = $self->{'context'};
  my $stack_level = 4;
  if (defined $args{'call_level'}) {
    $stack_level = $stack_level - $args{'call_level'};
  }
  if (defined $args{'_CALL_LEVEL_'}) {
    $stack_level = $stack_level - $args{'_CALL_LEVEL_'};
  }
  if (defined $args{'caller'}) {
    @whocalledme = @{$args{'caller'}};
  }
  else {
    @whocalledme = (caller($stack_level));
  }
  my $logline;
  my $nowtime = PMTUtilities::filter_formatdatetime('%Y-%m-%d %H:%M:%S',time());
  #my $nowtime = time();
  my $level=$self->{'DEFAULT_LOGLEVEL'};
  my $domain=$self->{'DEFAULT_LOGDOMAIN'};
  if (defined $args{'level'}) {
     $level=uc $args{'level'};
  }
  my $numlevel;
  if (defined $loglevels->{$level}) {
    $numlevel = $loglevels->{$level};
  }
  else {
    $numlevel = 9;
  }
  if ($numlevel < $self->{'THRESHOLD'}) {
    return;
  }
  if (defined $args{'domain'}) {
     $domain=uc $args{'domain'};
  } 
  # now verify whether we should log this
  # self->{'DOMAINS'} contains a series of regular expressions
  my $dolog = 0;
  my $domains = $self->{'DOMAINS'};
  for my $dom (@$domains) {
    my $exp = "^$dom\$";
    if ($domain =~ m/$exp/) {
      $dolog = 1;
    }
  }
  $dolog = 1;
  if ($dolog == 0) {
    return;
  }
  if (defined $args{'data'}) {
    $linespec->{'DATA'} = $args{'data'};
  }
  if (defined $args{'sortkeys'}) {
    $linespec->{'SORTKEYS'} = $args{'sortkeys'};
  }
  if (defined $args{'filename'}) {
    $linespec->{'FILENAME'} = $args{'filename'};
  }
  if (defined $args{'detail'}) {
    $linespec->{'DETAIL'} = $args{'detail'};
  }
  if (defined $args{'output'}) {
    $linespec->{'OUTPUT'} = $args{'output'};
  }

  my $clr = $whocalledme[3];
  if (not defined $clr) {
    $clr = "UNKNOWN";
  }
  $linespec->{'DOMAIN'} = $domain;
  $linespec->{'LEVEL'}  = $level;
  $linespec->{'CALLER'} = $clr;
  $linespec->{'LINE'} = $whocalledme[4];
  $linespec->{'CALLMOD'} = $whocalledme[0];



  $domain = PMTUtilities::filter_rpad(" ",10,uc $domain);
  $clr = PMTUtilities::filter_substring(30,PMTUtilities::filter_rpad(" ",30,$clr));


  if (not defined $level) {
    #print STDERR "Level missing level in loghelper\n";
  }
  if (not defined $domain) {
    #print STDERR "Level missing domain in loghelper\n";
  }
  if (not defined $clr) {
    #print STDERR "Level missing clr in loghelper\n";
  }
  my $heading = "$level : $domain $clr";
  
  if (defined $args{'message'}) {
    $logline = $args{'message'};
  }

  if (defined $logline) {
    if (exists $args{'evalcontext'}) {
      if (ref $logline eq 'ARRAY') {
        for (my $c=0; $c < scalar @$logline; $c++) {
          $logline->[$c] = expand(src=>$logline->[$c],
                                  evalcontext=>$args{'evalcontext'},
                                  filters=>$args{'filters'},
                                  filterchains=>$args{'filterchains'},
                                  filterlib=>$args{'filterlib'}
                           );
        };
      }
      else {
        $logline = PMTUtilities::expand(src=>$logline,evalcontext=>$args{'evalcontext'});
      };
    }
    $linespec->{'PAYLOAD'} = $logline;
    if ($self->{'STARTED'}) {
      $self->writelogline(linespec=>$linespec,target=>$args{'target'});
    }
    else {
      $self->writelogline(heading=>$heading,line=>$logline,target=>$args{'target'});
    }
  }
}


# ==========================================================================
#
# 4. Destructor
#
# ==========================================================================

sub DESTROY {
  my $self = shift;

  #eval {
  #  if ($self->{'_CHILDPROCESS_'} == 0) {
  #
  #    if (defined $self->{'LOGHANDLE'}) {
  #      $self->log(domain=>"lifecycle",level=>"info",message=>"Closing logfile $self->{FILENAME}");
  #      my $h = $self->{'LOGHANDLE'};
  #      close $h;
  #      $self->{'LOGHANDLE'} = undef;
  #    }
  #  }
  #};
}

1;

__END__

# ==========================================================================
#
# POD DOCUMENTATION
#
# ==========================================================================

=pod

=head1 NAME

  PMTLogHelper

=head1 SYNOPSIS

  PMT Helper Class: Logging

=head1 DESCRIPTION

  This is the standard implementation for a PMTLogger Class

=head1 METHODS

=over

=head2 getLogHandle

=over

=item Usage

  getLogHandle()
  
=item Synopsis

  get a HANDLE to the currently opened logfile
  
=item Description

    get a HANDLE to the currently opened logfile

=item Returns

   A HANDLE to the currently opended logfile
   
=back

=back

=over

=head2 getLogFileName

=over

=item Usage

  getLogFileName()
  
=item Synopsis

  Get the full path to the current logfile
  
=item Description

  Get the fullpath of the current logfile
  
=item Returns

  The name of the current logfile or undef if not defined
  
=back

=back

=over

=head2 log

=over

=item Usage

  log(...);
  The following keyword parameters are understood
    domain
    level
    message
    detail
    data
    sortkeys
    filename
    output
    evalcontext
    call_level

=item Synopsis

  Writes a logging message and/or other data to the logfile

=item Description

  Writes messages and/or other data to the logfile
  
  Messages are logged to a given domain, and a given level, specified
  with the corresponding keywords.
  Eg: to log a message to the domain 'model', under level 'info', one
  uses the following statement:
  
   $ic->log(domain=>'model',level=>'info',message=>'some message');
  
  In addition to a regular message, one can also specify additional
  information that you want to be included in the log:
  
   $ic->log(domain=>'model',
            level=>'info',
            message=>'these are the contents of file '/tmp/testfile',
            filename=>'/tmp/testfile');
            
   This will log the specified message, along with the contents of 
   the specified filename.
   
   Other keywords allow one to specify other data to be logged:
   
   detail: allows one to log specific details for a message:
   
   Eg:
     my $command = "rm -f /tmp/filename";
     $ic->log(domain=>"model",
              level=>"info",
              message=>"removing files with command",
              detail=>$command
             );
             
   data
     Makes for a dump of the specified data structure.
     Eg:
     
     my $h = {key1=>'value1',key2=>'value2');
     $ic->log(domain=>'model',
              level=>'info',
              message=>'please find below a dump of the data',
              data=>$h
             );
             
     if the data is a HASH, the logger will also look for 
     an additional keyword parameter, sortkeys, to determine
     whether the keys in the has should be sorted alphabetically.
     
  output
    Can be used to log the output of eg a script
    
    my $command = "rm -f /tmp/filename";
    my $HANDLE;
    open($HANDLE,"$command |");
    my @lines = <$HANDLE>;
    close $HANDLE;
    
    $ic->log(domain=>"model",
             level=>"trace",
             message=>"please find the output of the command",
             detail=>$command,
             output=>\@lines
            );       
            
    The logger is template-engine aware; if you specify an evalcontext,
    the logger will attempt to expand the message (other items, such 
    as data, output ..., however are not submitted to the template engine.)
    
    $ic->log(
      domain=>"model",
      level=>"info",
      message=>"Starting at {{_START_TM_||::formatDateTime %H:%M:%S}}",
      evalcontext=>undef
    );
    
    This works, since _START_TM_ is added to the evalcontext by default.
    The other traditional keywords (filters,filterchains, filterlib) can also
    be specified; please see the documentation about expand in the 
    PMTUtilities module.

    The logger tries really hard to determine where the call to log came from,
    in other words, it tries to determine the module and the calling subroutine.
    It does so by analyzing the current call stack (see perldoc -f caller
    for details)
    However, one one calls log from within an eval block, or an
    otherwise indirect call, the system can be very confused. In some
    cases one can correct the problem with the optional call_level keyword
    parameter; which indicates the additional levels in call-stack to look for
    the name of the calling subroutine.
         
=item LOG DOMAINS

  One writes messages to a given domain, a domain can be seen as 
  a category.
  In order for the message to be written to the log, you need to 
  configure the logger to accept the domain you're logging to.
  This can be handled through the configuration directive 
  LOGHELPER_LOGDOMAINS, which should contain a comma-separated list
  of domains you want to include in the log. 
  Each entry in this list is considered as a regular expression, and
  the domain you specify should obviously be matched by one of these
  regular expressions to be included in the log.
  
  If the LOGHELPER_LOGDOMAINS configuration entry is not specified in
  the configuration logfile, the default list is used. The default list
  of domains to be included in the log file = 
    LIFECYCLE,MODEL,HELPERS,DEVNOTE,SYSTEM
  
  You are free to "invent" new domains at will; all it takes for 
  domains to be "accepted", is that they should be configured through the 
  LOGHELPER_LOGDOMAINS configuration entry.  
  
  Names of domains are interpreted in a case insensitive way, but the 
  values in the configuration file need to be in uppercase.
  
  If no domain is specified in the call to log, a default domain of 
  SYSTEM is assumed, unless configured otherwise through the
  LOGHELPER_DEFAULTLOGDOMAIN directive in the PMTConfiguration file.
     
=item LOG LEVELS

  Items are logged at a certain level, and one can configure which messages
  actually make it through to the logfile.
  As opposed to the DOMAINS, you are not free to invent new levels.
  The following levels are understood:
  
    DEBUG = 0
    TRACE = 1
    DEVNOTE = 9
    VERBOSE = 2
    INFO = 3
    WARNING = 4
    ERROR = 5
  
  The value of DEVNOTE is delibarely chosen to be very high.
  
  Through the configuration file, one can specify a log threshold.
  All messages logged at a level "lower" than the specified threshold
  will be discarded.
  To configure the loglevel, please use the LOGHELPER_LOGTHRESHOLD
  configuration directive in the configuration file:
  Eg: LOGHELPER_LOGTHRESHOLD=TRACE
  
  If LOGHELPER_THRESHOLD is not defined in the configuration file,
  the default INFO is assumed.
  If the level is not specified in the call to log, a default level of 'INFO'
  is assumed , unless configured otherwise through the
  LOGHELPER_DEFAULTLOGLEVEL directive in the PMT configuration file.

=item Log destination
 
  By default the logger will attempt to write to a file. 
  The filename to be used will be found in a directory set by the environment
  variable LOGS.
  
  By default name of the logfile will be determined by the
  PMTLOGHELPER_LOGFILE_PATTERN in the configuration file, or the default value
  {{JOB_ID}}.scriptlog.{{_START_TM_|::formatDateTime %Y%m%d%H%M%S}}
  
  One can override that value with the logfile joboption (-o logfile=...)
  and either specify an absolute or a relative path.
  
  One can also specify -o logfile=-; In that case, the logger will write
  to STDERR.
   
=item Returns

  This method does not return any value.

=back

=back

=head1 CONFIGURATION

  The PMTLogHelper uses the following directives in the
  configuration file.
  
  Optional: LOGHELPER_DEFAULTLOGLEVEL
    The loglevel to use when not specified in the call to the log method
    Eg: LOGHELPER_DEFAULTLOGLEVEL=INFO
    
  Optional: LOGHELPER_DEFAULTLOGDOMAIN
    The domain to use when not specified in the call to the log method
    Eg: LOGHELPER_DEFAULTLOGDOMAIN=SYSTEM
    
  Optional: LOGHELPER_LOGTHRESHOLD
    The logging threshold
    Eg: LOGHELPER_LOGTHRESHOLD=TRACE
    
  Optional: LOGHELPER_LOGDOMAINS
    The domains to retain in the logfile. 
    Eg:LOGHELPER_LOGDOMAINS=DEVNOTE,SYSTEM,MODEL,HELPERS,CUSTOM.*
    
  Optional: PMTLOGHELPER_LOGFILENAME_PATTERN
    The pattern to use when constructing the logfile.
    Eg: PMTLOGHELPER_LOGFILENAME_PATTERN={{JOB_ID}}.scriptlog.{{_START_TM_|::formatDateTime %Y%m%d%H%M%S}}
    Please note that this is resolved very early in the lifecycle in the process,
    before the scenario etc is determined.
    The pattern is expanded using the initialcontext at that time and the 
    environment.
    Default: {{JOB_ID}}.scriptlog.{{_START_TM_|::formatDateTime %Y%m%d%H%M%S}}
  Optional: PMTLOGHELPER_LOGLINE_PATTERN
      A pattern for loglines in the logfile;
      The following keywords are understood
         LEVEL: The loglevel for the current message
         DOMAIN: The domain for the current message
         CALLER: Name of the subroutine from where call was issued
         LINE:  Line where call was issued
         CALLMOD: Module (Perl package where call was issued)
         PAYLOAD: Expanded message (excluding data, file contents, ...)
           
    Eg: PMTLOGHELPER_LOGLINE_PATTERN ={{_NOW_|::formatDateTime "%Y-%m-%d %H:%M:%S"}} {{LEVEL|::default UNKNOWN|::substring 8|::rpad 8}} {{DOMAIN|::default UNKNOWN |::substring 8|::rpad 8}} {{CALLER|::default UNKNOWN|::substring 30|::rpad 30}} {{?PAYLOAD}}
        This pattern is expanded for every line, using the initialcontext as it
        is at that point in time, augmented with the variables mentioned above.
        Default: {{_NOW_|::formatDateTime "%Y-%m-%d %H:%M:%S"}} {{?PAYLOAD}}
        
=head1 AUTHOR

  Evert Carton

=cut
