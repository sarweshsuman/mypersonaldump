package PMTCounterIterator;

use PMTIteratorBase;
our @ISA = qw(PMTIteratorBase);

use strict;
use Carp;
use overload q{<>} => \&iterator_overload,
             'bool'=> \&bool_overload,
             '!' => \&neg_overload,
             q{""} => sub { return "<" . __PACKAGE__ ." instance>"; };


sub new {
  my $package = shift;
  my %args = @_;
  use Data::Dumper;
  my $initparams = $args{'initparams'};
  my $list = [];
  my $start_el = undef;
  my $end_el = undef;
  if (defined $initparams->{'start'}) {
    $start_el = $initparams->{'start'};
  }
  if (not defined $start_el) { $start_el = 0; }
  if (defined $initparams->{'end'}) {
    $end_el = $initparams->{'end'};
  }
  if (not defined $end_el) { $end_el = 1; }
  my $o = {};
  $o->{'start'} = $start_el;
  $o->{'_list_'} = [];
  $o->{'end'} = $end_el;
  $o->{'current'} = $start_el;
  $o->{'_empty_'} = 0;
  $o->{'initialcontext'} = $args{'initialcontext'};
  $o->{'xnode'} = $args{'xnode'};
  if (defined $initparams->{'config'}->{'batchsize'}) {
    $o->{'batchsize'} = $initparams->{'config'}->{'batchsize'};
  }
  else {
    $o->{'batchsize'} = 1;
  }
  print "Created a " . __PACKAGE__ ." with batchsize = $o->{'batchsize'}, start $start_el, end $end_el\n";
  $o->{'force_array'} = 0;
  $o->{'seq'} = 0;
  return bless $o;
}

sub iterator_overload {
  my $self = shift;
  return $self->next(); 
}

sub neg_overload {
  my $self = shift;
  my $self = shift;
  if ($self->{'recycle'}) {
  	if (scalar @{$self->{'_list_'}} + scalar @{$self->{'recyclelist'}} > 0) { return 0; } else { return 1; }
  }
  if (scalar @{$self->{'_list_'}} > 0) { return 0; } else { return 1; }
}

sub bool_overload {
  my $self = shift;
  if ($self->{'current'} le $self->{'end'} ) { return 1; } else { return 0; }
}

sub next {
  my $self = shift;
  my $batchsize = $self->{'batchsize'};
  if (wantarray) {
    print STDERR "TODO: PMTFileIterator listcontext is buggy \n";
    if ($self->{'_empty_'}) {
      # this does basically imply that is recyclable and that it was called when empty,
      # so we have returned one empty value
      push @{$self->{'_list_'}},@{$self->{'recyclelist'}};
      $self->{'recyclelist'} = [];
      $self->{'_empty_'} = 0;
      return $self->next();
    }
    else {
			my @l = ();
			while (scalar @{$self->{'_list_'}}) {
				push @l, shift @{$self->{'_list_'}};
			} 
			if ($self->{'config'}->{'recycle'}) {
				push @{$self->{'recyclelist'}},@l;
			}
			if (not scalar @l) {
				$self->{'_empty_'} = 1;
			}
			return @l;
    }
  }
  elsif (defined wantarray) {
    # we gotta do stuff with the batchsize here
    # if batchsize = -1 -> return all the elements
    # else return the number of elements in the batchsize
  	# should this one even have the concept of a parent ? I don't think so :-)
    if ($self->{'_empty_'}) {
      # this does basically imply that is recyclable and that it was called when empty,
      # so we have returned one empty value
      push @{$self->{'_list_'}},@{$self->{'recyclelist'}};
      $self->{'recyclelist'} = [];
      $self->{'_empty_'} = 0;
      return $self->next();
    }
    else { # it is not empty
      #print "it is not flagged as empty\n";
      if ($batchsize == -1) {
      	my @vals = ();
				while ($self->{'current'} le $self->{'end'}) {
					#print "it appears to have items\n";
          push @vals,$self->{'current'};
          $self->{'current'} = $self->{'current'} + 1;
				}
        use Data::Dumper;
        print STDERR "PMTFileIterator returning ",Dumper(\@vals),"\n";
				return \@vals;
      }
      elsif ($batchsize > 1)  { 
        my @vals = ();
        while ($self->{'current'} le $self->{'end'} and scalar @vals < $batchsize) {
          push @vals,$self->{'current'};
          $self->{'current'} = $self->{'current'} + 1;
        }
        return \@vals;
      }
      else { # batchsize = 1
        if ($self->{'current'} gt $self->{'end'}) { if ($self->{'force_array'}) { return [];} else { print STDERR "PMYCounterIterator returning undef\n"; return undef; } }
        else { 
          my $item_to_add = $self->{'current'}; $self->{'current'} = $self->{'current'} + 1;
          print STDERR "In PMTCounterIterator: item to return = $item_to_add\n";
          if ($self->{'force_array'}) { return [$item_to_add]; } else { return $item_to_add; }
        }
      }
		}
  }
	else { # wantarray is not even defined
    if ($self->{'_empty_'}) {
      # this does basically imply that is recyclable and that it was called when empty,
      # so we have returned one empty value
      push @{$self->{'_list_'}},@{$self->{'recyclelist'}};
      $self->{'recyclelist'} = [];
      $self->{'_empty_'} = 0;
      return $self->next();
    }
    else {
			if (scalar @{$self->{'_list_'}} > 0) {
				my $val = shift @{$self->{'_list_'}}; 
      	if ($self->{'config'}->{'recycle'}) {
        	push @{$self->{'recyclelist'}},$val;
      	}
      	return undef;
			}	
    	return undef;
    }
	} # end of not even defined wantarray
}

sub reset {
  #print STDERR "resetting ",__PACKAGE__,"\n";
  my $self = shift;
  while (scalar @{$self->{'recyclelist'}}) {
    push @{$self->{'_list_'}}, shift @{$self->{'recyclelist'}};
  }
  $self->{'finished'} = 0;
  $self->{'_empty_'} = 0;
}

DESTROY {
  my $self = shift;
  # if a parent is defined, and the parent has recycle mode we should return all the elements on the parent too
  # kinda tricky, to be implemented later
}

1;

