package PMTXPathInterceptor;

use strict;
use Carp;

use PMTInterceptorBase;
use PMTHelperBase;
use PMTUtilities qw(icdefined getPMTSysConfig);

our @ISA = qw(PMTInterceptorBase PMTHelperBase);

use XML::XPath;
use XML::XPath::XMLParser;
use XML::LibXML qw(:libxml);
use Scalar::Util qw(looks_like_number);

sub new {
  my $p = shift;
  my %args = @_;
  my $initparams = defined $args{'initparams'} ? $args{'initparams'} : {};

  use Data::Dumper;
  #print STDERR "Creating a n PMTXPathInterceptor with initparams;",Dumper($initparams),"\n";

  my $ic = $args{'initialcontext'};
  my $mod = {};

	$mod->{'initialcontext'} = $ic;
  $mod->{'name'} = $initparams->{'mode'};
  $mod->{'_debug_'} = 0;

  if (uc $initparams->{'mode'} eq 'JOBDEF') {
    #print STDERR "Making an interceptor in JOBDEF mode\n";
  
    $mod->{'mode'} = 'JOBDEF';
		$mod->{'mountpoint'} = 'JOBDEF';
		$mod->{'_initialized_'} = 0;
		$mod->{'_src_'} = undef;
		if ($initparams->{'xml_source'}) { $mod->{'_src_'} = $initparams->{'xml_source'}}
		elsif ($initparams->{'xml_source_file'}) { 
			## not implemented yet
		}
		$mod->{'_xctx_'} = undef;
		
		if ($mod->{'_src_'}) {
			my $parser = XML::LibXML->new();
			$parser->set_option('no_blanks',1);
			$parser->set_option('no_cdata',1);
			my $doc = $parser->load_xml(string=>$mod->{'_src_'});
			$doc = $doc->documentElement();
			$mod->{'_xctx_'} = $doc;
			#print STDERR "XPATHINTERCEPTOR working with document: $doc\n";
			$mod->{'_initialized_'} = 1;
		}
  }
  elsif (uc $initparams->{'mode'} eq 'JLOG') {
    #print STDERR "Making an interceptor in JLOG mode\n";
    $mod->{'mode'} = 'JLOG';
		$mod->{'mountpoint'} = 'JLOG';
		$mod->{'_initialized_'} = 1;
		$mod->{'_src_'} = undef;
    if ($initparams->{'debug'}) {
      $mod->{'_debug_'} = 1;
    }

    if ($initparams->{'_xctx_'}) {
      $mod->{'_xctx_'} = $initparams->{'_xctx_'};
    }
    elsif ($initparams->{'from_file'}) {
      my $fname = $initparams->{'from_file'};
      # this is assuming that the filename does exist
      my $parser = XML::LibXML->new();
			$parser->set_option('no_blanks',1);
			$parser->set_option('no_cdata',1);
      open my $fh, '<', $fname;
      binmode $fh; # drop all PerlIO layers possibly created by a use open pragma
      my $doc = XML::LibXML->load_xml(IO => $fh);
      close $fh;
			$doc = $doc->documentElement();
			$mod->{'_xctx_'} = $doc;
			#print STDERR "XPATHINTERCEPTOR working with document: $doc\n";
			$mod->{'_initialized_'} = 1;
    }
    else {
    	my $d = new XML::LibXML::Document();
			my $root_element = new XML::LibXML::Element('jlog');
			$d->setDocumentElement($root_element);
			$mod->{'_xctx_'} = $d->documentElement();
    }

		$mod->{'_initialized_'} = 1;
  }
	$mod->{'path'} = '^'.$mod->{'mountpoint'}.'/.+$';

  bless $mod;
  return $mod;
}

sub isCloneable {
  my $self = shift;
  my $mode = $self->{'mode'};
  if ($mode eq 'JOBDEF') {
    return 1;
  }
  else {
    return 1;
  }
}

sub getCloneData {
  my $self = shift;
  if ($self->{'mode'} eq 'JOBDEF') {
 	  return { mode=>'JOBDEF',name=>'JOBDEF',mountpoint=>'JOBDEF',xml_source=>$self->{'_src_'} };
  }
  elsif ($self->{'mode'} eq 'JLOG') {
    return { _xctx_=>$self->{'_xctx_'},debug=>$self->{'_debug_'}, mode=>'JLOG',name=>'JLOG',mountpount=>'JLOG'};
  }
}

sub noRemoteClone {
  my $self = shift;
  if ($self->{'mode'} eq 'JLOG') {
    return 1;
  }
  return 0;
}
 
sub clone {
  my $self = shift;
  my %args = @_;
  my $nic = $args{'initialcontext'};

  if ($self->{'mode'} eq 'JOBDEF') {
  	return new(__PACKAGE__,initialcontext=>$nic,initparams=>$self->getCloneData());
  }
  else { 
    #print STDERR "Cloning PMTXPathInterceptor in mode $self->{'mode'}\n" ;
  	return new(__PACKAGE__,initialcontext=>$nic,initparams=>$self->getCloneData());
  }

}

sub cloneToChildren {
  my $self = shift;
  my $mode = $self->{'mode'};
  if ($mode eq 'JOBDEF') {
    return 1;
  }
  else {
    return 0;
  }
}



sub getPaths {
  my $self = shift;
  return [ $self->{'path'} ];
}

sub nodePath2PluginPath {
  my $self = shift;
  my %args = @_;
  my $path = $args{'path'};
  $path =~ s:^/[^/]+:$self->{'mountpoint'}:;
  return $path;
}

# 

use PMTUtilities qw(partial);
my $evaluators = {
                   asis=>sub { my $self = shift; my %args = @_; my $ic=$self->{'initialcontext'}; 
                               my $ae = $ic->expand('{{SYSTEM/SETTINGS/XML/AUTO_EXPAND|default 1}}'); 
                               if ($ae) { return $ic->expand($args{'data'}->textContent()); } else { return $args{'data'}->textContent(); }},
                   factory=>sub { my $self = shift; my %args = @_; return $self->factory(data=>$args{'data'}); },
                   xnode=>sub { my $self = shift; my %args = @_; return $self->fn_xnode(data=>$args{'data'}); },
                   bool=> sub { my $self = shift; my $ic = $self->{'initialcontext'}; use PMTUtilities qw{evalBoolean}; my %args = @_; my $p = $args{'data'}; return evalBoolean(value=>$ic->expand($p->textContent))} 
                 };

sub initialize {
  my $self = shift;
  
  if (not $self->{'_initialized_'}) {
  	#print "Initializing the PMTXPathInterceptor\n";
    #$self->{'_xctx_'} = XML::XPath->new(filename=>'/opt/PMT/etc/dbresources.xml');
  	#print "Initialized the PMTXPathInterceptor\n";
    my $parser = XML::LibXML->new();
    $parser->set_option('no_blanks',1);
    $parser->set_option('no_cdata',1);
    use if (not $self->{'_initialized_'}), "PMTFlowRepo" ;
    my $ic = $self->{'initialcontext'};
    my $flowcd = $ic->{'SYSTEM/RUN/FLOWCD'};
    my $role = $ic->{'SYSTEM/RUN/ROLE'};
    my $doc_src = PMTFlowRepo::getJobConfig(flowcd=>$flowcd,role=>$role);
    #my $doc = $parser->load_xml(location=>'/opt/PMT/etc/mgw.xml');
    my $doc = $parser->load_xml(string=>$doc_src);
    $doc = $doc->documentElement();
    $self->{'_src_'}= $doc_src;
    $self->{'_xctx_'} = $doc;
    #print STDERR "XPATHINTERCEPTOR working with document: $doc\n";
  }
  $self->{'_initialized_'} = 1;
}

sub getParserPath {
  my $self = shift;
}

sub fn_data {
  my $self = shift;
  my %args = @_;
  my $inv = $args{'data'};
  my $initialcontext = $args{'initialcontext'};
  my $ae = $initialcontext->expand('{{SYSTEM/SETTINGS/XML/AUTO_EXPAND|default 1}}');
  # in can be either a node, nodeset or an array
  if (ref $inv eq 'ARRAY') {
    my @tmpresults;
    for my $k (@$inv) {
      push @tmpresults,fn_data($k);
    }
    return \@tmpresults;
  }
  elsif ($inv->isa('XML::LibXML::NodeList')) {  # nodeset
    my @n = $inv->get_nodelist();
    return fn_data(\@n); 
  }
  elsif ($inv->isa('XML::LibXML::Node')) { # node
    my $nt = $inv->nodeType;
    if ($nt eq XML_ELEMENT_NODE) {
      if ($ae) { return  $initialcontext->expand($inv->textContent); } else { return $inv->textContent; }
    }
    elsif ($nt eq XML_ATTRIBUTE_NODE) {
      if ($ae) { return  $initialcontext->expand($inv->nodeValue) } else { return $inv->nodeValue(); }
    }
    else {
      croak { message=>"Invalid node type for function fn_data"};
    }
  }
  else {
    croak { message=>"Invalid input type to function fn_data" };
  }
}

sub fn_xnode {
  my $self = shift;
  my %args = @_;
  my $n = $args{'data'};
  my $ic = $self->{'initialcontext'};
  #print STDERR "in fn_xnode, ic = $ic\n";
  #print "rootparser = $rp\n";
  #print "initialcontext = $ic\n";
  use PMTXMLNodeWrapper;
  my $w = PMTXMLNodeWrapper->new(rootparser=>$self,node=>$n,initialcontext=>$ic);
  return $w;
}

sub fn_node {
  my $self = shift;
  # I want the raw node itself
  my %args = @_;
  my $n = $args{'data'};
  return $n;
}

sub fn_count {
  my $self = shift;
  my %args = @_;
  my $n = $args{'data'};
}

sub fn_filterchain {
  my $self = shift;
  my %args = @_;
  my $inv = $args{'data'};
  my $ic = $self->{'initialcontext'};
  my $fc = $args{'filterchain'};
  my $ae = $ic->expand('{{SYSTEM/SETTINGS/XML/AUTO_EXPAND|default 1}}');
  if (ref $inv eq 'ARRAY') {
    my @tmpresults;
    for my $k (@$inv) {
      push @tmpresults,fn_filterchain(filterchain=>$fc,data=>$k,initialcontext=>$ic);
    }
    return \@tmpresults;
  }
  elsif (not ref $inv) {
    return applyFilterChain(value=>$inv,filterchain=>$fc);
  }
  elsif ($inv->isa('XML::LibXML::NodeList')) {  # nodeset
    my @n = $inv->get_nodelist();
    return fn_filterchain(data=>\@n,initialcontext=>$ic,filterchain=>$fc); 
  }
  elsif ($inv->isa('XML::LibXML::Node')) { # node
		use PMTUtilities qw(applyFilterChain);
    my $nt = $inv->nodeType;
    if ($nt eq XML_ELEMENT_NODE) {
      my $txt ; 
      if ($ae) { $txt = $ic->expand($inv->textContent); } else { $txt = $inv->textContent }
      print STDERR "running filterchain $fc on $txt\n";
      return applyFilterChain(value=>$txt,filterchain=>$fc);
    }
    elsif ($nt eq XML_ATTRIBUTE_NODE) {
      my $txt; if ($ae) { $txt = $ic->expand($inv->nodeValue); } else { $txt = $inv->nodeValue; }
      print STDERR "running filterchain $fc on $txt\n";
      return applyFilterChain(value=>$txt,filterchain=>$fc);
    }
    else {
      croak { message=>"Invalid node type for function fn_data"};
    }
  }
  else {
    croak { message=>"Invalid input type to function fn_data" };
  }
}

sub fn_string {
  my $self = shift;
  my %args = @_;
  my $inv = $args{'data'};
	my $ic = $args{'initialcontext'};
  my $ae = $ic->expand('{{SYSTEM/SETTINGS/XML/AUTO_EXPAND|default 1}}');
  # in can be either a node, nodeset or an array
  if (ref $inv eq 'ARRAY') {
    my @tmpresults;
    for my $k (@$inv) {
      push @tmpresults,fn_string(data=>$k);
    }
    return \@tmpresults;
  }
  elsif (not ref $inv) { return $inv; }
  elsif ($inv->isa('XML::LibXML::NodeList')) {  # nodeset
    my @n = $inv->get_nodelist();
    return fn_string(data=>\@n); 
  }
  elsif ($inv->isa('XML::LibXML::Node')) { # node
    my $n; if ($ae) { return $ic->expand($inv->toString()); } else { return $inv->toString(); }
    return $n;
  }
  else {
    croak { message=>"Invalid input type to function fn_name" };
  }
}

sub fn_prettystring {
  my $self = shift;
  my %args = @_;
  my $inv = $args{'data'};
	my $ic = $self->{'initialcontext'};
  my $ae = $ic->expand('{{SYSTEM/SETTINGS/XML/AUTO_EXPAND|default 1}}');
  # in can be either a node, nodeset or an array
  if (ref $inv eq 'ARRAY') {
    my @tmpresults;
    for my $k (@$inv) {
      push @tmpresults,fn_prettystring(initialcontext=>$ic,data=>$k);
    }
    return \@tmpresults;
  }
  elsif (not ref $inv) { return $inv; }
  elsif ($inv->isa('XML::LibXML::NodeList')) {  # nodeset
    my @n = $inv->get_nodelist();
    return fn_prettystring(data=>\@n); 
  }
  elsif ($inv->isa('XML::LibXML::Node')) { # node
    if ($ae) { return $ic->expand($inv->toString(1)); } else { return $inv->toString(1); }
  }
  else {
    croak { message=>"Invalid input type to function fn_name" };
  }
}

sub fn_nodepath {
  my $self = shift;
  my %args = @_;
  my $inv = $args{'data'};
  if (ref $inv eq 'ARRAY') {
    my @tmpresults;
    for my $k (@$inv) {
      push @tmpresults,fn_nodepath(data=>$k);
    }
    return \@tmpresults;
  }
  elsif ($inv->isa('XML::LibXML::NodeList')) {  # nodeset
    my @n = $inv->get_nodelist();
    return fn_nodepath(data=>\@n); 
  }
  elsif ($inv->isa('XML::LibXML::Node')) { # node
    my $n = $inv->nodePath();
    return $n;
  }
  else {
    croak { message=>"Invalid input type to function fn_nodepath" };
  }
}

sub fn_xnodepath {
  my $self = shift;
  my %args = @_;
  my $inv = $args{'data'};
  if (ref $inv eq 'ARRAY') {
    my @tmpresults;
    for my $k (@$inv) {
      push @tmpresults,fn_nodepath(data=>$k);
    }
    return \@tmpresults;
  }
  elsif ($inv->isa('XML::LibXML::NodeList')) {  # nodeset
    my @n = $inv->get_nodelist();
    return fn_nodepath(data=>\@n); 
  }
  elsif ($inv->isa('XML::LibXML::Node')) { # node
    my $n = $inv->nodePath();
    $n = $self->nodePath2PluginPath(path=>$n);
    return $n;
  }
  elsif ($inv->can('xnodePath')) {
    return $inv->xnodePath();
  }
  else {
    croak { message=>"Invalid input type to function fn_nodepath" };
  }
}

sub fn_name {
  my $self = shift;
  my %args = @_;
  my $inv = $args{'data'};
	my $ic = $self->{'initialcontext'};
  # in can be either a node, nodeset or an array
  if (ref $inv eq 'ARRAY') {
    my @tmpresults;
    for my $k (@$inv) {
      push @tmpresults,$self->fn_name(data=>$k);
    }
    return \@tmpresults;
  }
  elsif ($inv->isa('XML::LibXML::NodeList')) {  # nodeset
    my @n = $inv->get_nodelist();
    return $self->fn_name(data=>\@n); 
  }
  elsif ($inv->isa('XML::LibXML::Node')) { # node
    my $n = $inv->nodeName;
    return $n;
  }
  else {
    croak { message=>"Invalid input type to function fn_name" };
  }
}

sub resource_factory {
  my $self = shift;
  my %args = @_;
  my $n = $args{'data'};
  my $ic = $self->{'initialcontext'};

 	use PMTXMLNodeWrapper;
 	my $xnode = PMTXMLNodeWrapper->new(rootparser=>$self,node=>$n,initialcontext=>$ic);

  my $rn;
  if ($n->hasAttribute('resource_name')) {
    $rn = $n->getAttribute('resource_name');
  }
  elsif ($n->hasAttribute('name')) {
    $rn = $n->getAttribute('name');
  }
  else {
    $rn = undef;
  }

  my $t = $n->getAttribute('resource_type');
  if (not $t) {
    croak { message=>"Invalid node, no attribute 'resource_type' in resource_factory" };
  }
  #print "doing a resource factory for $n\n";
  # Factories are under JOBDEF/system/factories/factory[@type="..."]/class
  my $factory_ref = $ic->{"JOBDEF/system//factory[\@type=\"$t\"]/callable/data(.)"};
  #print "using factory: $factory_ref\n";
  my $nodeparser_ref = $ic->{"$self->{'mountpoint'}/system//factory[\@type=\"$t\"]/nodeparser/data(.)"};
  use PMTUtilities qw(getSubRefFromName);
  my $facspec;
  if (icdefined $nodeparser_ref) {
    #print "using nodeparser: $nodeparser_ref\n";
    my $nodeparser = getSubRefFromName(name=>$nodeparser_ref);
    $ic->log(message=>"TODO: Fix the hack with nodeparsser in PMTXPathInterceptor::resource_factory",domain=>"system",level=>"warning");
    $facspec = $nodeparser->($self,data=>$n,initialcontext=>$ic);
  }
  else {
    #print "nodeparser is not defined\n";
  	use PMTXMLNodeWrapper;
  	my $w = PMTXMLNodeWrapper->new(rootparser=>$self,node=>$n,initialcontext=>$ic);
    $facspec = $w;
  }
  #print "facspec is now $facspec\n";
  my $fac = getSubRefFromName(name=>$factory_ref);
  #print "fac is $fac\n";
  my $resource = $fac->(name=>$rn,data=>$facspec,initialcontext=>$ic,xnode=>$xnode);
  return $resource;
}

sub factory {
  my $self = shift;
  my %args = @_;
  my $n = $args{'data'};
  my $ic = $self->{'initialcontext'};
  my $verbose = $ic->expand('{{SETTINGS/FACTORY/VERBOSE|default 0}}');
  if ($verbose) {
  	print "Doing factory for ",$n->toString(1),"\n";
  }

  # Do I have a class
 	use PMTXMLNodeWrapper;
 	my $xnode = PMTXMLNodeWrapper->new(rootparser=>$self,node=>$n,initialcontext=>$ic);
  my $driverclass_nl = $n->find('class');
  my $callable_nl = $n->find('callable');
  if (not $driverclass_nl->size() and not $callable_nl->size()) {
    if ($n->hasAttribute('resource_type')) {
      return $self->resource_factory(data=>$n);
    }
    else {
      croak { message=>"Invalid structure for factory: no 'class' element found" };
    }
  }
  # this gives a nodeset
  if ($driverclass_nl->size()) {
		my @driverclass_list = $driverclass_nl->get_nodelist;
		my $driverclass_node = $driverclass_list[0];
		my $driverclass = $ic->expand($driverclass_node->textContent);
		my $initparams2 = {};
		my $initparams = {};
		#print "I should find a class $driverclass\n";
		if ($n->exists('initparams')) {
			if ($verbose) { print "and it has initparams\n"; }
			my $nl = $n->find('initparams');
			#if ($verbose) {print "Did find initparams: ",$nl->toString(1),"\n"; }
			my @nlist = $nl->get_nodelist();
			if ($verbose) { print "Got initparams in factory",@nlist,"\n";}
			$initparams = $self->parseParamset(data=>$nlist[0]);
		}
		else { 
		 # print "In factory no initparams found for node",$n->toString(1),"\n";
		}
		$initparams2->{'initialcontext'} = $ic;
		$initparams2->{'xnode'} = $xnode;
		$initparams2->{'initparams'} = $initparams;
		use PMTUtilities qw(loadClass);
		my $cl = loadClass(module=>$driverclass,args=>$initparams2);
		return $cl;
  }
  elsif ($callable_nl->size()) {
    my @callable_list = $callable_nl->get_nodelist();
    my $callable_node = $callable_list[0]; 
    my $callable_name = $ic->expand($callable_node->textContent);

		my $initparams2 = {};
		my $initparams = {};
		#print "I should find a class $driverclass\n";
		if ($n->exists('initparams')) {
			if ($verbose) { print "and it has initparams\n"; }
			my $nl = $n->find('initparams');
			#if ($verbose) {print "Did find initparams: ",$nl->toString(1),"\n"; }
			my @nlist = $nl->get_nodelist();
			if ($verbose) { print "Got initparams in factory",@nlist,"\n";}
			$initparams = $self->parseParamset(data=>$nlist[0]);
		}
		else { 
		 # print "In factory no initparams found for node",$n->toString(1),"\n";
		}
    use PMTUtilities qw(h2a partial);
		$initparams2->{'initialcontext'} = $ic;
		$initparams2->{'xnode'} = $xnode;
    my @i2 = h2a(hash=>$initparams2);
    my @i1 = h2a(hash=>$initparams);
    push @i2,@i1;
		#$initparams2->{'initparams'} = $initparams;
		my $cl = partial($callable_name,@i2);
		return $cl;
  }
}

my $postproc_funcs = {
  name=>\&fn_name,
  node=>\&fn_node,
  xnode=>\&fn_xnode,
  data=>\&fn_data,
  prettystring=>\&fn_prettystring,
  string=>\&fn_string,
  parseParamset=>\&parseParamset,
  factory=>\&factory,
  filterchain=>\&fn_filterchain,
  resource_factory=>\&resource_factory,
  parseParam=>\&parseParam,
  nodePath=>\&fn_nodepath,
  xnodePath=>\&fn_xnodepath,
  'local-name'=>\&fn_name
};

sub parseParamset {
  my $self = shift;
  my %args = @_;
  my $n = $args{'data'};
  my $ic = $self->{'initialcontext'};
	my $result = {};
	my $force_array = 0;
	if ($n->hasAttribute('cardinality') and $n->getAttribute('cardinality') eq 'force_array') { $force_array = 1; }
	my @paramnodes = $n->getChildrenByTagName('param');
	for my $pn (@paramnodes) {
		my $k = $pn->getAttribute('name');
    $result->{$k} = $self->parseParam(data=>$pn,force_array=>$force_array);
	}
	return $result;
}

sub parseParam {
  my $self = shift;
  my %args = @_;
  my $n = $args{'data'};
  my $ic=$args{'initialcontext'};
  if ($n->hasAttribute('dataclass') and $n->getAttribute('dataclass') eq 'paramset') {
    return $self->parseParamset(data=>$n);
  }
  my $force_array;
  if (exists $args{'force_array'}) { $force_array = $args{'force_array'}; }
  else {
		my $cp = $n->parentNode;
		if ($cp->hasAttribute('cardinality') and $cp->getAttribute('cardinality') eq 'force_array') { $force_array = 1; }
  }
  my $datatype;
  my $dataspec;
  my $evaluator;
  use PMTUtilities qw(partial);
  if ($n->hasAttribute('data_type')) {
    $datatype = $n->getAttribute('data_type');
    if (defined $evaluators->{$datatype}) {
      if ($n->hasAttribute('data_spec')) {
        $dataspec = $n->getAttribute('data_spec');
      }
      else { $dataspec = undef; }
      $evaluator = partial($evaluators->{$datatype},$self,data_spec=>$dataspec);
    }
    else {
      $evaluator = partial($evaluators->{'asis'},$self,data_spec=>undef);
    }
  }
  else {
    $evaluator = partial($evaluators->{'asis'},$self,data_spec=>undef);
  }
	my @vnodes = $n->getChildrenByTagName('value');
	if (scalar @vnodes) {
		my $result = [];
		for my $vn (@vnodes) {
			push @$result, $evaluator->(data=>$vn);
		}
		return $result;
	}
	else {
		#print "Adding a value to result:",$n->textContent,"\n";
		if ($force_array) {
			return [ $evaluator->(data=>$n)];
		}
		else {
			return  $evaluator->(data=>$n);
		}
	}
}

sub parseNode {
  my $self = shift;
  my %args = @_;
  my $n = $args{'data'};
  my $ic = $self->{'initialcontext'};
  my $ae = $ic->expand('{{SYSTEM/SETTINGS/XML/AUTO_EXPAND|default 1}}');
  my $value = $args{'value'};
  my $ppchain = $args{'ppchain'};
  if (not defined $ppchain) { $ppchain = []; }
	my $nt = $n->nodeType;
  #print STDERR "Parsing node: ",$n->toString(1),"\n";
	
  if ($nt == XML_ELEMENT_NODE and $n->hasAttribute('is_referral') and $n->getAttribute('is_referral') eq 'yes') {
    #print "It is a referral\n";
    my $nnode = $n->cloneNode(1);
    #print "nnode is now ",ref $nnode,"\n";
    my $nodename = $nnode->nodeName;
    $nnode->removeAttribute('is_referral');
    # find the referal
    my $referral = $nnode->findvalue('referral');
    if ($ae) { $referral = $ic->expand($referral); }
    #print "it is a referral to $referral\n";
    my @matchattributes;
    if ($n->hasAttribute('referral_match')) {
      @matchattributes = split(',',$nnode->getAttribute('referral_match'));
      $nnode->removeAttribute('referral_match');
    }
    else {
      @matchattributes = ('name');
    }
    my @matches = map {"\@".$_."=\"".$n->getAttribute($_)."\""} @matchattributes;
    my $matchstring = join(' and ',@matches);
    #print "looking for matchstring: $matchstring\n";
    my $full_url = "JOBDEF$referral/$nodename\[$matchstring\]/node()";
    #print "looking for full url: $full_url\n";
    my $referred_to = $ic->{$full_url};
    #print "referred_to = $referred_to\n";
    # delete all the childelements from $nnode;
    my @childnodes = $nnode->findnodes('referral');
    for my $cn (@childnodes) { $nnode->removeChild($cn); };
    for my $cn ($referred_to->findnodes('*')) {
      $nnode->appendChild($cn->cloneNode(1));
    }
    for my $cn ($referred_to->findnodes('@*')) {
      if ($nnode->hasAttribute($cn->nodeName)) {} else {
       $nnode->setAttribute($cn->nodeName,$cn->nodeValue);
      }
      #$nnode->appendChild($cn->cloneNode(1));
    }
    #and at last copy the attributes from the referred_to
    #print "nnode is now a ",ref $nnode,"\n";
    return $self->parseNode(data=>$nnode,ppchain=>$ppchain);
  }
	#print "parsing node node is now: $n, $nt\n";
	if ($nt == XML_ATTRIBUTE_NODE) {
		 my $v = $n->nodeValue();
		 #print "It is an attribute with value $v\n";
		 return $v;
	}
	elsif ($nt == XML_ELEMENT_NODE) {
		#print "It is an element\n";
    if (scalar @$ppchain) {
      my $f = $ppchain->[0];
      return $f->(data=>$n);
    }
		if ($n->can('hasAttribute') and $n->hasAttribute('dataclass') and  $n->getAttribute('dataclass') eq 'paramset') {
			#print "it is a paramset element\n";
      return $self->parseParamset(data=>$n);
		}
		# It may be parameter in a paramset
		my $cp = $n->parentNode; my $pt = $cp->nodeType;
    #print STDERR "parent has nodeType $pt\n";
		if ($cp->can('hasAttribute') and $cp->hasAttribute('dataclass') and $cp->getAttribute('dataclass') eq 'paramset') {
			my $force_array = 0;
			if ($cp->hasAttribute('cardinality') and $cp->getAttribute('cardinality') eq 'force_array') { $force_array = 1; }
      return $self->parseParam(data=>$n,force_array=>$force_array);
		}
		if ($n->hasChildNodes() )  {
			my @childnodes = $n->childNodes();
			my $c_elementnodes = 0;
			my @c_textnodes = ();
			for my $cn (@childnodes) {
				if ($cn->nodeType == XML_ELEMENT_NODE) {
					$c_elementnodes++;
				}
				elsif ($cn->nodeType == XML_TEXT_NODE or $cn->nodeType == XML_CDATA_SECTION_NODE) {
					push @c_textnodes,$cn;
				}
			}
			if ($c_elementnodes) {
        # I don't know how to parse this, but, if there's a function ...
        if (scalar @$ppchain) {
          my $f = $ppchain->[0];
          return $f->(data=>$n);
        }
        else { 
          my $default_out = $ic->expand('{{SYSTEM/SETTINGS/XML/DEFAULT_OUT|default xnode}}');
          use Data::Dumper;
          #print STDERR "Default policy: converting to ",Dumper($default_out),": ",ref $n,"\n"; 
					return $self->$default_out(data=>$n);
        }
				croak { message => 'Invalid node for inclusion in ic: element has childElements' };
			}
			if (scalar @c_textnodes > 0) { 
				my $lcn = $c_textnodes[0];
        if ($ae) { return $ic->expand($lcn->data); } else { return $lcn->data; }
			} 
			# we can only accept if the only child is text
			return undef;
		}
	}
	elsif ($nt == XML_TEXT_NODE or $nt == XML_CDATA_SECTION_NODE) {
    if ($ae) { return $ic->expand($nt->data); } else { return $nt->data; }
	}
}

sub preRead {
  use PMTUtilities qw(icdefined);
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $key = $args{'key'};
  my $val = $args{'value'};
  my $p = $args{'_path_'};
  my $kk = $args{'_ckey_'};
  my $default = $args{'default'};
  my $iface = $args{'iface'};
  my $return_raw = 0;
  if (defined $iface and $iface =~ m/raw/i) {
    $return_raw = 1;
  }
  #print STDERR "return_raw is now $return_raw\n";
  #print STDERR "doing preread in PMTXPathInterceptor looking for key $key\n";
  $self->initialize();

  # the _path_, $p is actually the most interesting one
  #print "PMTXPathInterceptor: path: $key\n";
  # A small extension here to support somewhat XPath2 like functions 
  my $postprocfunc; 
  my $postprocchain = [];
  if ($key =~ m!/([_A-Za-z-:]+?)\(([^)]*)\)$!) {
    my $fref = $1;
    #print STDERR "in preRead Looking for function $fref\n";
    my $pargs = $2;
    #print "a function has been specified with pargs $pargs\n";
    if ($fref =~ m/::/) {
      use PMTUtilities qw(getSubRefFromName);
      $postprocfunc = getSubRefFromName(name=>$fref);
    }
    elsif (defined $postproc_funcs->{$fref}) {
    	$postprocfunc = $postproc_funcs->{$fref};
    }
    else {
      croak { message=>"Unknown function reference : $fref in Xpath expression" };
    }
    if ($pargs =~ m/^\s*\.\s*$/) { $pargs = ""; }
    my @parguments = eval "($pargs)";
    push @parguments, (_rootparser_=>$self,initialcontext=>$ic);
    use PMTUtilities qw(partial);
    $postprocfunc = partial($postprocfunc,$self,@parguments);
    #print "parguments = @parguments\n";
    push @$postprocchain, $postprocfunc;
    $key =~ s!/([_A-Za-z-:]+?)\(([^)]*)\)$!!;
    #print STDERR "Adapted key = $key\n";
    #print "The key takes a function , $postprocfunc, at the end, we need to treat this specially\n";
  } 
  else {
    #if ($self->{'mode'} eq 'JLOG') {print "It does not match a function\n"; }
  }
  my $xp;
  if (defined $args{'rootnode'}) {
    $xp = $args{'rootnode'};
  }
  else {
  	$xp = $self->{'_xctx_'};
  }
  #if ($self->{'mode'} eq 'JLOG') { print STDERR "Actually looking for key $key in JLOG\n"; }
  my $rs;
  eval {$rs = $xp->find($key);}; if ($@) { my $e = $@; $ic->log(message=>"Error in JLOG query",data=>$e,level=>"error",domain=>"system");  croak { message=>"XPATH query error\n"}; }
  #print STDERR "result of xp->find is (",ref $rs,"),"; print $rs; print "\n";
  if ($rs->isa('XML::LibXML::Number')) {
     #return { value=>$rs->value()};
     if ($return_raw) { return $rs->{'value'}; } else { return { value=>$rs->{'value'}}; }
  }
  elsif ($rs->isa('XML::LibXML::Literal')) {
    return $rs->value();
     if ($return_raw) { return $rs->{'value'}; } else { return { value=>$rs->{'value'}}; }
    #return { value=> $rs->value() };
  }
  elsif ($rs->isa('XML::LibXML::Boolean')) {
    #return {value => $rs->value() };
     if ($return_raw) { return $rs->{'value'}; } else { return { value=>$rs->{'value'}}; }
    return $rs->value();
  }
  elsif ($rs->size() eq 0 and icdefined $default) {
    #print STDERR "Got an empty resultset with default specified\n";
    if (ref $default eq 'ARRAY') {
      my @results = ();
      for my $v (@$default) {
        my $n = new XML::LibXML::Element('default_value');
        $n->appendText($v);
        push @results,$self->parseNode(data=>$n,initialcontext=>$ic,ppchain=>$postprocchain);
      }
      use Data::Dumper;
      if ($self->{'mode'} eq 'JLOG') { 
        #print STDERR "JLOG returning an array (case 1):" ,Dumper(\@results),"\n"; 
     }
     if ($return_raw) { return \@results; } else { return { value=>\@results}; }
      #return \@results;
    }
    else {
    	my $n = new XML::LibXML::Element('default_value');
    	$n->appendText($default);
      my $rc = $self->parseNode(data=>$n,initialcontext=>$ic,ppchain=>$postprocchain);
      #if ($self->{'mode'} eq 'JLOG') { use Data::Dumper; print STDERR "JLOG returning rc: ",Dumper($rc),"\n"; }
     if ($return_raw) { return $rc; } else { return { value=>$rc}; }
    }
  }
  else { 
    #print STDERR "I do actually get a result in preRead\n";
    #print STDERR "result = a nodeset: ", ref $rs, "size:",$rs->size(),"\n";
    my $s = $rs->size();
    #print "resuilt is a nodeset with size $s\n";
    if ($s == 0) {
      
      #if ($self->{'mode'} eq 'JLOG') { use Data::Dumper; print STDERR "JLOG returning undef: empty resultset\n"; }
     	if ($return_raw) { return undef; } else { return { value=>undef}; }
    }
    if ($s == 1) {
      my $n = $rs->[0];
      my $rc = $self->parseNode(data=>$n,initialcontext=>$ic,ppchain=>$postprocchain);
      #if ($self->{'mode'} eq 'JLOG') { use Data::Dumper; print STDERR "JLOG returning rc: ",Dumper($rc),"\n"; }
     if ($return_raw) { return $rc; } else { return { value=>$rc}; }
      #return $rc ;
    } # end of nodelist size 1
    else { # nodesize > 1
      my @results;
      my @nodelist = $rs->get_nodelist();
      for my $n (@nodelist) {
        push @results,$self->parseNode(data=>$n,initialcontext=>$ic,ppchain=>$postprocchain);
      }
      use Data::Dumper;
      #if ($self->{'mode'} eq 'JLOG') { print STDERR "JLOG returning an array \n@results\n when searching for key $key\n" ,Dumper(\@results),"\n"; }
     if ($return_raw) { return \@results; } else { return { value=>\@results}; }
      #return \@results;
    }
  } # end of is nodelist
  #if (1) { use Data::Dumper; print STDERR "JLOG returning undef as final result\n"; }
     	if ($return_raw) { return undef; } else { return { value=>undef}; }
  return undef;
}

sub xfactory {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $data = $args{'data'};
  # for now this is basically just a wrapper around factory, don't know if we will need more later ?
  if (not ref $data) {
    $data = "$data/node()";
    $data = $ic->resolve($data);
  }
  return $self->factory(data=>$data);
  #return $self->factory(data=>$data);
}

sub xnode {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $data = $args{'data'};
  if (not ref $data) {
    $data = "$data/node()";
    $data = $ic->resolve($data);
  }
  return $self->fn_xnode(data=>$data);
  #return $self->factory(data=>$data);
}

sub preSet { 
  my $self = shift;
  croak { message=>"Initialcontext preSet handler at $self->{'mountpoint'} is readonly" };
}

sub postSet {
  my $self = shift;
  croak { message=>"Initialcontext postSet handler at $self->{'mountpoint'} is readonly" };
}

# Specify this is you want the ic not to parse the URL but just hand it as raw to the interceptor
sub needRaw {
  return 1;
}

sub getHelperMethods {
  my $self = shift;
  return ['xfactory'];
}

sub pluginHasHelperMethod {
  my $self = shift;
  my %args = @_;
  my $m = $args{'method'};
  if ($m eq 'xfactory' or $m eq 'xnode' or $m eq 'getResource') { return 1; } else { return 0; }
}

sub getResource {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $rname = $args{'name'};
  my $t = $args{'resource_type'};
  my $res;
  $ic->addParameterStack();
  eval {
  	#print STDERR "mmm looking for resource $rname\n";
    $ic->{'_LOCAL_/RESOURCENAME'} = $rname;
    my $lstring ;
    if ($t) {
       $ic->{'_LOCAL_/RESOURCETYPE'} = $t;
       $lstring = 'JOBDEF/resources/resource[@name="{{_LOCAL_/RESOURCENAME}}" and @resource_type="{{_LOCAL_/RESOURCETYPE}}"]/xnode()';
    }
    else {
      $lstring = 'JOBDEF/resources/resource[@name="{{_LOCAL_/RESOURCENAME}}"]/xnode()';
    }
    $ic->log(message=>"Looking for resourcestring: $lstring",domain=>"system",level=>"trace");
    use Data::Dumper;
    eval { $res = $ic->resolve($lstring); }; if ($@) { print STDERR "Error occurred while resolving resourcestring:",Dumper($@),"\n"; }
    $res = $ic->resolve($lstring);
    if (not icdefined $res) {
      if ($t) {
        croak { message=>"Could not find resource definition for $rname and type $t" };
      }
      else {
        croak { message=>"Could not find resource definition for $rname " };
      }
    }
    #my $res = $ic->resolve('JOBDEF/resources/resource/prettystring()');
    if (ref $res eq 'ARRAY') {
       # prolly two different types ...
       my $types = $ic->resolve('JOBDEF/resources/resource[@name="{{_LOCAL_/RESOURCENAME}}"]/@resource_type/data()');
       croak { message=>"More than one resource with the same name $rname",data=>$types};
    }
    if ($t) {
      $lstring = 'JOBDEF/resources/resource[@name="{{_LOCAL_/RESOURCENAME}}" and @resource_type="{{_LOCAL_/RESOURCETYPE}}"]/node()';
    }
    else {
      $lstring = 'JOBDEF/resources/resource[@name="{{_LOCAL_/RESOURCENAME}}"]/node()';
    }
    #print STDERR "Final Step: Looking for lstring: $lstring\n";
    $res = $ic->resolve($lstring);
    #print STDERR "Still alive after final step in getResource ? ll\n";
    $res = $self->resource_factory(data=>$res);
    #use Data::Dumper;
    #print STDERR "Resourcedef = ",Dumper($res),"\n";
  };
  if ($@) {
    my $e = $@;
    $ic->log(message=>"An error occurred while looking for resource in PMTXPathInterceptor",domain=>"system",level=>"error",data=>$e);
    $ic->popParameterStack();
    croak $e;
  }
  $ic->popParameterStack();
  return $res;
}

sub ihash_to_xml {
  my $self = shift;
  my $nspec = shift;
  my ($gelname,$gnameattr);
  if (ref $nspec eq 'ARRAY') {
    ($gelname,$gnameattr) = @$nspec;
  }
  else {
    $gelname = $nspec; $gnameattr = undef;
  }
  my $h = shift;
  my $flat = shift;
  if ($flat) { }
  use XML::LibXML;
  my $gnel = new XML::LibXML::Element($gelname);
  if ($gnameattr) { $gnel->setAttribute('name',$gnameattr); }
  if ($flat) {} else {$gnel->setAttribute('dataclass','paramset');}
  for my $k (sort keys %$h) {
    my $v = $h->{$k};
    if (ref $v eq 'HASH') {
      my ($elname,$nameattr); if ($flat) { $elname = $k; $nameattr=undef; } else { $elname = 'param'; $nameattr=$k; }
      my $sh = $self->ihash_to_xml([$elname,$nameattr],$h->{$k},$flat); 
      $gnel->addChild($sh);
    }
    elsif (ref $v eq 'ARRAY') {
      my $elname; if ($flat) { $elname = $k; } else { $elname = 'param'; }
    	my $p = new XML::LibXML::Element($elname);
      if ($flat) {} else { $p->setAttribute('name',$k); }
      for my $vv (@$v) {
        if (ref $vv eq 'HASH') {
          my $nel = $self->ihash_to_xml('value',$vv,$flat);
          $p->addChild($nel);
        }
        else {
          my $val = new XML::LibXML::Element('value');
          $val->appendText($vv);
          $p->addChild($val); 
        }
      }
      $gnel->addChild($p);
    }
    else {
    	my $p;
      if ($flat) {
        $p = new XML::LibXML::Element($k);
      }
      else {
        $p = new XML::LibXML::Element('param');
        $p->setAttribute('name',$k);
      }
      
      $p->appendText($v);
      $gnel->addChild($p);
    }
  }
  return $gnel; 
}

sub itemdata_to_itemnode {
  # the idea is to find the item_node for a given $item-item
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $ins = shift; my @itemnodes = @{$ins};
  my $item = shift;

  my $new_item_detail;
  # in order to compare, we first need to make something of this item
  if (ref $item eq 'HASH') {
    $new_item_detail = $self->ihash_to_xml('detail',$item,1); 
  }
  else {
    $new_item_detail = new XML::LibXML::Element('detail'); 
    $new_item_detail->appendText($item);
  }
  my $new_item_string = $new_item_detail->toString();
  #print STDERR "Looking for item ",$new_item_detail->toString(),"\n";

  #print "looking in itemnodes @itemnodes\n";
  for my $i (@itemnodes) {
    my @ides= $i->findnodes('detail');
    my $ide = $ides[0];
    if ($ide and $ide->toString() eq $new_item_string) {
      return $i;
    }
  }
  $ic->log(message=>"Could not find item to attach to",domain=>"system",level=>"warning");
  return undef;
}

sub appendJLOG_event_step_start {
  my $self = shift;
  my $ctx = $self->{'_xctx_'};
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $data = $args{'data'}; my $directives = $args{'directives'};
  use Data::Dumper;
  #$ic->log(message=>"handling event_step_start",data=>\%args,level=>"trace",domain=>"system");
  my $grp_name = $directives->{'context'}->{'group'};
  my $mtime = $directives->{'mtime'};
  my $items = $directives->{'context'}->{'item'}; if (not ref $items) { $items = [$items]; }
  for my $item (@$items) {
		my $stepname = $directives->{'context'}->{'step'};
		my @item_nodes = $ctx->findnodes("group[\@name=\"$grp_name\"]/items/item");
		my $targetnode = $self->itemdata_to_itemnode(\@item_nodes,$item);
		if ($targetnode) {
			# I need to find the steps
			my @ses = $targetnode->findnodes('steps'); my $stepsnode = $ses[0];
			#$ic->log(message=>"Adding a step $stepname to steps: ",data=>$stepsnode,domain=>"system",level=>"trace");
			use XML::LibXML;
			my $stepel = new XML::LibXML::Element($stepname);
			my $status = new XML::LibXML::Element('status');
			my $start = new XML::LibXML::Element('start');
			$start->appendText($mtime);
			$status->addChild($start);
			$stepel->addChild($status);
			$stepsnode->addChild($stepel);
			my $envel = $self->ihash_to_xml('environment',$directives->{'env'},1);
			$stepel->addChild($envel);
		}
  }
}

sub appendJLOG_event_step_end {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $ctx = $self->{'_xctx_'};
  my %args = @_;
  my $data = $args{'data'}; my $directives = $args{'directives'};
  use Data::Dumper;
  
  my $grp_name = $directives->{'context'}->{'group'};
  my $mtime = $directives->{'mtime'};
  my $items = $directives->{'context'}->{'item'}; if (not ref $items) { $items = [$items]; }
  for my $item (@$items) {
		my $stepname = $directives->{'context'}->{'step'};
		my @item_nodes = $ctx->findnodes("group[\@name=\"$grp_name\"]/items/item");
		my $rcs = $data->{'detail'}->{'status'};
		my $targetnode = $self->itemdata_to_itemnode(\@item_nodes,$item);
		if ($targetnode) {
			# I need to find the steps
			my @ses = $targetnode->findnodes("steps/$stepname/status"); my $stepsnode = $ses[0];
			#print STDERR "Adding a step_end $stepname to steps: $stepsnode\n";
			use XML::LibXML;
			#my $stepel = new XML::LibXML::Element($stepname);
			#my $status = new XML::LibXML::Element('status');
			my $end = new XML::LibXML::Element('end');
			my $error = new XML::LibXML::Element('error');
			my $success = new XML::LibXML::Element('success');
			if ($rcs =~ m/success/i) {
				$error->appendText('0');
				$success->appendText('1');
			}
			else {
				$error->appendText('1');
				$success->appendText('0');
			}
			$end->appendText($mtime);
			#$status->addChild($start);
			#$stepel->addChild($status);
			$stepsnode->addChild($end);
			$stepsnode->addChild($error);
			$stepsnode->addChild($success);
			#print STDERR "stepsnode is now ",$stepsnode->toString(),"\n";
		}
		else {
      $ic->log(message=>"Could not find node to connect step_end event to",domain=>"system",level=>"warning");
		}
  }
}
sub appendJLOG_process_data_all {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $ctx = $self->{'_xctx_'};
  my %args = @_;
  my $data = $args{'data'}; my $directives = $args{'directives'};
  use Data::Dumper;
  $ic->log(message=>"handling process_data_statistics",data=>\%args,domain=>"system",level=>"debug");
  my $grp_name = $directives->{'context'}->{'group'};
  my $mtime = $directives->{'mtime'};
  my $items = $directives->{'context'}->{'item'}; if (not ref $items) { $items = [$items]; }
	for my $item (@$items) {
		my $stepname = $directives->{'context'}->{'step'};
		my @item_nodes = $ctx->findnodes("group[\@name=\"$grp_name\"]/items/item");
		my $targetnode = $self->itemdata_to_itemnode(\@item_nodes,$item);
		if ($targetnode) {
			my $data_type = $data->{'data_type'};
			# I need to find the steps
			my @ses = $targetnode->findnodes("steps/$stepname"); my $stepsnode = $ses[0];
			my $statsdata;
			eval {
			$statsdata= $self->ihash_to_xml($data_type,$data->{'detail'},1);
			$stepsnode->addChild($statsdata);
			};
			if ($@) { my $e = $@; $ic->log(message=>"Failed to create statsdata:", data=>$e, domain=>"system",level=>"error"); }
			#print STDERR "Adding a step_end $stepname to steps: $stepsnode\n";
			#use XML::LibXML;
			##my $stepel = new XML::LibXML::Element($stepname);
			#my $status = new XML::LibXML::Element('status');
			#my $end = new XML::LibXML::Element('end');
			#$end->appendText($mtime);
			##$status->addChild($start);
			#$stepel->addChild($status);
			#$stepsnode->addChild($end);
		}
		else {
      $ic->log(message=>"Could not find node to connect process_data to",level=>"error",domain=>"system",data=>\%args);
		}
  }
}

sub appendJLOG_process_data_process_statistics {
  my $self = shift;
  return $self->appendJLOG_process_data_all(@_);
}

sub appendJLOG_event_item_end {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $data = $args{'data'}; my $directives = $args{'directives'};
  my $grp_name = $directives->{'context'}->{'group'};
  my $mtime = $directives->{'mtime'};
  my $items = $directives->{'context'}->{'item'}; if (not ref $items) { $items = [$items]; }
	for my $item (@$items) {
		my $ctx = $self->{'_xctx_'};
		my @item_nodes = $ctx->findnodes("group[\@name=\"$grp_name\"]/items/item");
		my $targetnode = $self->itemdata_to_itemnode(\@item_nodes,$item);
		if ($targetnode) {
			# I need to find the status
			 my @snodes = $targetnode->findnodes('status');
			 my $snode = $snodes[0];
			 if ($snode) {
				 use XML::LibXML;
				 my $e = new XML::LibXML::Element('end');
				 $e->appendText($mtime);
				 $snode->addChild($e);
				#print STDERR "Added item_end event for $item to $targetnode\n";
			 }
		}
		else {
			print STDERR "What went wrong here: could not find an item ?\n";
		}
  }
}
sub appendJLOG_event_new_item {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $data = $args{'data'}; my $directives = $args{'directives'};
  my $ctx = $self->{'_xctx_'};
  my $items = $data->{'detail'}->{'item'}; if (not ref $items) { $items = [$items]; }
	for my $item (@$items) {
		my $group = $directives->{'context'}->{'group'};
		my $mtime = $directives->{'mtime'};
		my @targetnodes = $ctx->findnodes("group[\@name=\"$group\"]/items");
		my $targetnode = $targetnodes[0];
		if ($targetnode) {
			#print STDERR "Adding new item event for $group and item $item to $targetnode\n";
      use Data::Dumper;
      eval {
      $ic->log(message=>"new item even for $group, item=",data=>$item,domain=>"system",level=>"info");
      };
      if ($@) {
        print STDERR "ERROR WHILE LOGGING:",Dumper($@),"\n";
      }
			use XML::LibXML;
			my $item_element = new XML::LibXML::Element('item');
			my $item_status = new XML::LibXML::Element('status'); $item_element->addChild($item_status);
			my $item_start = new XML::LibXML::Element('start'); $item_start->appendText($mtime);
			$item_status->addChild($item_start);
			my $item_steps = new XML::LibXML::Element('steps');   $item_element->addChild($item_steps);
			if (ref $item eq 'HASH') {
				my $item_detail = $self->ihash_to_xml('detail',$item,1); $item_element->addChild($item_detail);
			}
			else {
				my $item_detail = new XML::LibXML::Element('detail'); $item_element->addChild($item_detail);
				$item_detail->appendText($item);
			}
			$targetnode->addChild($item_element);

			#print STDERR "jlog is now ",$ctx->toString(1),"\n";
		}
  }
  
}

sub appendJLOG_event_process_group_create {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  use Data::Dumper;
  #print STDERR "appendJLOG_event_process_group_create processing event_data:",Dumper(\%args),"\n";
  my $directives = $args{'directives'}; my $data = $args{'data'};
  my $group_name = $directives->{'context'}->{'group'};
  use Data::Dumper;
  #print STDERR "handling event of type procsss_group_create for group $group_name\n";
  my $ctx = $self->{'_xctx_'};
  #print STDERR "I should be appending a node to $ctx\n";
  use XML::LibXML;
  my $n = new XML::LibXML::Element('group');
  $n->setAttribute('name',$group_name);
  $ctx->addChild($n);
  my $st = new XML::LibXML::Element('status');
  my $its = new XML::LibXML::Element('items');
  $n->addChild($st);
  $n->addChild($its);
  my $cr = new XML::LibXML::Element('create');
  $cr->appendText($directives->{'mtime'});
  $st->addChild($cr);
  
}

sub appendJLOG_event_process_group_end {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $data = $args{'data'}; my $directives=$args{'directives'};
  my $ic = $self->{'initialcontext'};
  my $ctx = $self->{'_xctx_'};
  my $group_name = $directives->{'context'}->{'group'};
  my $mtime = $directives->{'mtime'};
  use Data::Dumper;
  # I need to find the status node in ...
  my @target_nodes;
  eval { @target_nodes = $ctx->findnodes("group[\@name=\"$group_name\"]/status"); }; 
  #if ($@) { print STDERR "Error occurred while getting target_node: $@\n"; }
  my $target_node = $target_nodes[0];
  #print "found a target node: $target_node\n";
  if ($target_node) {
    use XML::LibXML;
    my $el = new XML::LibXML::Element('end');
    $el->appendText($mtime);
    $target_node->addChild($el);
  }
  #print STDERR "Added process_group_end: ",$ctx,"\n";
}
sub appendJLOG_event_process_group_start {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $data = $args{'data'}; my $directives=$args{'directives'};
  my $ic = $self->{'initialcontext'};
  my $ctx = $self->{'_xctx_'};
  my $group_name = $directives->{'context'}->{'group'};
  my $mtime = $directives->{'mtime'};
  use Data::Dumper;
  # I need to find the status node in ...
  my @target_nodes;
  eval { @target_nodes = $ctx->findnodes("group[\@name=\"$group_name\"]/status"); }; 
  if ($@) { print STDERR "Error occurred while getting target_node: $@\n"; }
  my $target_node = $target_nodes[0];
  #print "fiund a target node: $target_node\n";
  if ($target_node) {
    use XML::LibXML;
    my $el = new XML::LibXML::Element('start');
    $el->appendText($mtime);
    $target_node->addChild($el);
  }
  #print STDERR "Added process_group_start: ",$ctx,"\n";
}


sub appendJLOG_event {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  use Data::Dumper;
  #print STDERR "appendJLOG processing an EVENT:",Dumper(\%args),"\n";
  my $data = $args{'data'};
  my $event_type = $data->{'event_type'};
  my $method_to_look_for = "appendJLOG_event_".$event_type;
  if ($self->can($method_to_look_for)) {
    $self->can($method_to_look_for)->($self,@_);
  }
  else {
    #$ic->log(message=>"appendJLOG cannot find an appropriate handler for event type $event_type ... I have no choice but to ignore it",level=>"warning",domain=>"system");
  }
}


sub appendJLOG_process_data {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  use Data::Dumper;
  #print STDERR "appendJLOG processing an EVENT:",Dumper(\%args),"\n";
  return $self->appendJLOG_process_data_all(@_);
  #my $data = $args{'data'};
  #my $data_type = $data->{'data_type'};
  #my $method_to_look_for = "appendJLOG_process_data_".$data_type;
  #if ($self->can($method_to_look_for)) {
  #  $self->can($method_to_look_for)->($self,@_);
  #}
  #else {
  #  print STDERR "appendJLOG cannot find an appropriate handler for process_data type $data_type ... I have no choice but to ignore it\n";
  #}
}

sub appendJLOG {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  # I should have at least a directives and a data
  my $data = $args{'data'};
  my $directives=$args{'directives'};
  # This should get the event as a hash

  my $message_type = $directives->{'type'};
  my $method_to_look_for = "appendJLOG_".$message_type;
  if ($self->can($method_to_look_for)) {
    $self->can($method_to_look_for)->($self,@_);
  }
  else {
    #$ic->log(message=>"appendJLOG cannot find an appropriate handler for message type $message_type ... I have no choice but to ignore it",domain=>"system",level=>"warning");
  }
  if ($self->{'_debug_'}) {
    my $filename = $ic->expand('/tmp/{{SYSTEM/RUN/FLOWCD}}.{{SYSTEM/RUN/ROLE}}.JLOG');
    my $FH;
    open($FH,'>',$filename);
    my $ctx = $self->{'_xctx_'};
    print $FH $ctx->toString(1);
    close $FH;
  }
  
  
  
  # and now the very tedious task of converting this data to XML and fitting it in the three
  
  
}

sub setJLOG {
  my $self = shift;
  my %args = @_;
}

sub setJLOGFilename {
  my $self = shift;
  my %args = @_;
  my $fname = $args{'filename'};
  # this is assuming that the filename does exist
  my $parser = XML::LibXML->new();
	$parser->set_option('no_blanks',1);
	$parser->set_option('no_cdata',1);
  open my $fh, '<', $fname;
  binmode $fh; # drop all PerlIO layers possibly created by a use open pragma
  my $doc = XML::LibXML->load_xml(IO => $fh);
  close $fh;
	$doc = $doc->documentElement();
	$self->{'_xctx_'} = $doc;
  # This will only be used in the PMTConfigViewer, so I print to STDERR instead of logging
  print STDERR "Loaded Filename $fname\n";
}

sub dumpJLOG {
  my $self = shift;
  my %args = shift;
  my $ctx = $self->{'_xctx_'};
  if (defined wantarray) {
    return $ctx->toString(1);
  }
  my $filename = $args{'filename'};

  my $jld;
  use IO::File;
  use IO::Handle;
  if ($filename) {
  	$jld = IO::File->new($filename,"w");
  }
  else {
    $jld = new IO::Handle;
    $jld->fdopen(\*STDERR,'w');
  }
  print STDERR "Dumping JLOG\n";
  print $jld $ctx->toString(1);
  print STDERR "\n";
  $jld->close();
  print STDERR "Done dumping JLOG\n\n";
}
sub dumpJOBDEF {
  my $self = shift;
  my %args = shift;
  $self->initialize();
  my $ctx = $self->{'_xctx_'};
  if (defined wantarray) {
    return $ctx->toString(1);
  }

  my $filename = $args{'filename'};

  my $jld;
  use IO::File;
  use IO::Handle;
  if ($filename) {
  	$jld = IO::File->new($filename,"w");
  }
  else {
    $jld = new IO::Handle;
    $jld->fdopen(\*STDERR,'w');
  }
  print STDERR "Dumping JOBDEF\n";
  print $jld $ctx->toString(1);
  print STDERR "\n\n";
  $jld->close();
  print STDERR "Done dumping JOBDEF\n\n";
}

sub pluginHasHelperMethod {
  my $self = shift;
  my %args = @_;
  my $m = $args{'method'};
  my $mode = $self->{'mode'};
  if (uc $mode eq 'JOBDEF') {
  	if ($m eq 'xfactory' or $m eq 'xnode' or $m eq 'getResource' or $m eq 'dumpJOBDEF') { return 1; } else { return 0; }
  }
  else {
  	if ($m eq 'appendJLOG' or $m eq 'dumpJLOG' or $m eq 'setJLOG') { return 1; } else { return 0; }
  }
  return 0;
}

1;
