#!/opt/PMT/bin/perl
#
#		General Aggregator Script to Call L2 sql
#		Author : Sarwesh Suman
#
BEGIN{
	push(@INC,"/opt/PMT/pmtsys/scripts/");
}
use Aggregation_ReadConfig;
use Getopt::Long;
use POSIX;
use Time::Local;
use DBI;


my $xml;

my %options=(
				"xml=s" => \$xml,
			);

&GetOptions(%options);

exit 1 if(not defined $xml);

unless(-e $xml){
	exit 1;
}

my $cfg=Aggregation_ReadConfig->new($xml);

my $dbh=DBI->connect("DBI:Oracle:PMT01D","PMT_CDR","PMT_CDR_DEV") or die;

my @jobs=$cfg->getJobs();
print "Got @jobs\n";
foreach my $j (@jobs){
	print "processing $j\n";
	my $script=$cfg->getJobScript($j);
	my $date_num=$cfg->getJobDate($j);
	my $dateformat=$cfg->getJobDateFormat($j);
	print "script $script \n date_num $date_num \n dateformat $dateformat\n\n"; 
	next unless(-e $script);
	my $date=getDate($date_num,$dateformat);
	print "running with date $date\n";

print `sqlplus PMT_CDR/PMT_CDR_PROD\@PMT01P <<EOF 
\@$script $date;
exit; 
EOF`;

	#open ( SQL,"<$script");
	#my @lines=<SQL>;
	#close SQL;
	#my $sql_script=join " ",@lines;
	#$sql_script =~ s/DATEISO/$date/g;
	#my $sth=$dbh->prepare($sql_script) or die;
	#$sth->execute();
}


sub getDate{
        my $days_to_go_back;
        my $format = "%Y%m%d";
        if($#_ == 0){
                $days_to_go_back=shift;
        }
        elsif( $#_ == 1){
                $days_to_go_back=shift;
                $format=shift;
        }
        else {
                $days_to_go_back=0;
        }
        my $epoctime = time + (24*60*60*$days_to_go_back);
        my $date=POSIX::strftime("$format",localtime($epoctime));
        return $date;
}
