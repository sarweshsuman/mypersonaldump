package Aggregation_ReadConfig;

use Data::Dumper;
use XML::Simple;

my $xmlO;
my $ref;

sub new{
	my $class=shift;
	my $xml_file=shift;
	my $xmlO=new XML::Simple(KeepRoot=>1);
	unless(-e $xml_file){
		return undef;
	}
	$ref=$xmlO->XMLin($xml_file);
	print Dumper $ref;
	bless $ref,__PACKAGE__;
	return $class;
}
sub getJobs{
	my $self=shift;
	my @jobs=();
	if(defined $ref->{'jobs'}->{'job'}->{'name'} and $ref->{'jobs'}->{'job'}->{'enabled'} =~ m/(?:YES|y)/i){
		push(@jobs,$ref->{'jobs'}->{'job'}->{'name'});
	}
	elsif(defined $ref->{'jobs'}->{'job'}){
		foreach my $key (keys %{$ref->{'jobs'}->{'job'}}){
			if($ref->{'jobs'}->{'job'}->{$key}->{'enabled'} =~ m/(?:YES|y)/i){
				$jobs[$ref->{'jobs'}->{'job'}->{$key}->{'sequence'}-1]=$key;
			}
		}
	}
	else{
		return ();
	}
	return @jobs;
}
sub getJobScript
{
	my $self=shift;
	my $jobname=shift;
	if(defined $ref->{'jobs'}->{'job'}->{'name'} and $ref->{'jobs'}->{'job'}->{'name'} =~ /$jobname/i){
		if($ref->{'jobs'}->{'job'}->{'script'}){
			return $ref->{'jobs'}->{'job'}->{'script'};
		}
		else {
			return undef;
		}
	}
	elsif(defined $ref->{'jobs'}->{'job'}->{$jobname} and defined $ref->{'jobs'}->{'job'}->{$jobname}->{'script'}){
		return $ref->{'jobs'}->{'job'}->{$jobname}->{'script'};
	}
	else{
		return undef;
	}
}
sub getJobDate
{
	my $self=shift;
	my $jobname=shift;
	if(defined $ref->{'jobs'}->{'job'}->{'name'} and $ref->{'jobs'}->{'job'}->{'name'} =~ /$jobname/i){
		if($ref->{'jobs'}->{'job'}->{'date'}){
			return $ref->{'jobs'}->{'job'}->{'date'};
		}
		else {
			return undef;
		}
	}
	elsif(defined $ref->{'jobs'}->{'job'}->{$jobname} and defined $ref->{'jobs'}->{'job'}->{$jobname}->{'date'}){
		return $ref->{'jobs'}->{'job'}->{$jobname}->{'date'};
	}
	else{
		return undef;
	}
}
sub getJobDateFormat
{
	my $self=shift;
	my $jobname=shift;
	if(defined $ref->{'jobs'}->{'job'}->{'name'} and $ref->{'jobs'}->{'job'}->{'name'} =~ /$jobname/i){
		if($ref->{'jobs'}->{'job'}->{'dateformat'}){
			return $ref->{'jobs'}->{'job'}->{'dateformat'};
		}
		else {
			return undef;
		}
	}
	elsif(defined $ref->{'jobs'}->{'job'}->{$jobname} and defined $ref->{'jobs'}->{'job'}->{$jobname}->{'dateformat'}){
		return $ref->{'jobs'}->{'job'}->{$jobname}->{'dateformat'};
	}
	else{
		return undef;
	}
}
1;
