#!/usr/bin/env perl

use strict;


$|=1;
my $remote_dir='/data1/CDR_archive/spgwcdr/SPGW_CDR';

use Net::OpenSSH();
my $o = {};
$o->{'user'} = 'cdrp';
$o->{'password'} = 'pmt1.?';

my $host = 'zone-azp-p54';
my $ssh =  Net::OpenSSH->new($host,%$o);
my $sftp = $ssh->sftp();

my $copyoptions = {};

my $ls_options = { wanted =>qr/.*MCR201405.*/ };

my $filelist = $sftp->ls('/data1/POC_Data/MSC_CDR_Files',%$ls_options);
my @fs = map { $_->{'filename'}; } @$filelist;

use Data::Dumper;
#print Dumper(\@f);

use File::Spec;
$sftp->setcwd('/data1/POC_Data/MSC_CDR_Files');
for my $f (@fs) {
  my $lf = File::Spec->catfile('/data/POC_Data/MSC_CDR_Files',$f);
  $lf = "$lf.gz";
  if (-e $lf) {
    # do nothing
     print "Ignoring file $f, since allready available\n";
  }
  else {
    my $fh;
    open($fh,">",$lf);
    binmode $fh,":gzip";
    print "Retrieving $f to $lf\n";
    $sftp->get($f,$fh,%$copyoptions); 
    close $fh;
  }
}

