#!/usr/bin/env perl

use strict;

$|=1;
use Net::OpenSSH();
my $o = {};
$o->{'user'} = 'cdrp';
$o->{'password'} = 'pmt1.?';

my $host = 'zone-azp-p54';
my $ssh =  Net::OpenSSH->new($host,%$o);
my $sftp = $ssh->sftp();

my $copyoptions = {};

my $ls_options = { wanted =>qr/.*.eno*/ };

my $filelist = $sftp->ls('/data1/POC_Data/MSC_CDR_Files',%$ls_options);
my @fs = map { $_->{'filename'}; } @$filelist;

use Data::Dumper;
#print Dumper(\@f);


my $backlog_msc_log;
use File::Spec;
$sftp->setcwd('/data1/POC_Data/MSC_CDR_Files');
for my $f (@fs) {
  my $lf = File::Spec->catfile('/data/POC_Data/MSC_CDR_Files',$f);
  $lf = "$lf.gz";
  my $lf2 = File::Spec->catfile('/data/POC_Data/MSC_CDR_Archive',$f);
  $lf2 = "$lf2.gz";
  open ($backlog_msc_log,">>","/opt/PMT/logs/backlog_msc_log_$$.log");
  if (-e $lf or -e $lf2) {
    # do nothing
     print $backlog_msc_log "Ignoring file $f, since allready available\n";
  }
  else {
    my $fh;
    open($fh,">",$lf);
    binmode $fh,":gzip";
    print $backlog_msc_log "Retrieving $f to $lf\n";
    $sftp->get($f,$fh,%$copyoptions); 
    $sftp->die_on_error("Something bad happened");
    close $fh;
  }
}

