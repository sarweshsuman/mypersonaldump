#!/bin/bash

#/opt/PMT/pmtsys/scripts/backlog_msc_cdr.pl
cd /data/POC_Data/all_gerdy
for i in $(ls)
do
touch -d $(echo $i | cut -f 1 -d '.' | cut -f 2 -d '_' ) $i
done
/opt/PMT/pmtsys/scripts/iterload.sh /data/POC_Data/all_gerdy /opt/PMT/work/in/LDS/MSC 1 3 /opt/PMT/pmtsys/scripts/load_msc.sh
