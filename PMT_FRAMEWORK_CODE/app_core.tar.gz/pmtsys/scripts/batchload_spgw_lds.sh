#!/bin/bash

#/opt/PMT/pmtsys/scripts/backlog_msc_cdr.pl
cd /data/POC_Data/SPGW_CDR_FILES
for i in $(ls *eno.gz)
do
touch -t $(echo $i | cut -c 10-23) $i
done
/opt/PMT/pmtsys/scripts/iterload.sh /data/POC_Data/SPGW_CDR_FILES /opt/PMT/work/in/LDS/SPGW 600 250
