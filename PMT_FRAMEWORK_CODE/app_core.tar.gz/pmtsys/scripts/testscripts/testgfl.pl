#!/usr/bin/env perl
#
use strict;
use Carp;

use PMTUtilities qw(getFileList);

my $f = getFileList(directory=>'sftp://adt@10.1.64.100:/data1/ADT_archive/pdmsoss5/MSS_PM/registered/',filepattern=>'.*',maxage=>'1',sortorder=>'age');

use Data::Dumper;


print "FileList:",Dumper($f),"\n";
