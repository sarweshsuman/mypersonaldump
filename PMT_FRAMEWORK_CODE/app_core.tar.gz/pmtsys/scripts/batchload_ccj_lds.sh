#!/bin/bash

/opt/PMT/pmtsys/scripts/iterload.sh /data/POC_Data/CCJRECOV /opt/PMT/work/in/LDS/CCJ 1 50 /opt/PMT/pmtsys/scripts/lds_load_ccj_bl.sh
