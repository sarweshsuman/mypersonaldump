#!/bin/sh

echo "distribute is called" >> /tmp/distribute.log

cd /opt/PMT/work/tmp/spgw
#cp * /opt/PMT/work/in/LDS/SPGW || /bin/true
cp * /data/POC_Data/SPGW_CDR_FILES2 || /bin/true
mv * /data/CDR_archive/SPGW_CDR/in
