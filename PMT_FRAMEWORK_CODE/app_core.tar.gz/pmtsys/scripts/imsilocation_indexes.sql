begin
 for lc in (select index_name, partition_name, status 
               from all_ind_partitions where index_name like  'IDX_IMSI_LOCATION_%' and status ='UNUSABLE')
   loop
     execute immediate 'alter index '||lc.index_name||' rebuild partition '||lc.partition_name;
   end loop;
end;
/
