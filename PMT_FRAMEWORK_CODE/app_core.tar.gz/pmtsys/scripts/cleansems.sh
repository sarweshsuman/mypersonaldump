#!/bin/sh

for i in $(ipcs -s | grep pmtp | cut -f 2 -d  ' ')
do
ipcrm -s $i
done
