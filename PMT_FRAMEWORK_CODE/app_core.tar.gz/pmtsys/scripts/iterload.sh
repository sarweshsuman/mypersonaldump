#/bin/bash

# source directory = $1
# targetdirectory = $2
# script to load = $3
export source_directory=$1
export target_directory=$2
export interval=$3
export batch_size=$4
export script=$5
echo "moving files from $source_directory to $target_directory , batchsize $batch_size and running $script"

export file_count=$(ls $source_directory | wc -l)
echo $file_count

while [ $file_count -gt 0 ]
do
files_to_move=$(ls -t  $source_directory | head -n $batch_size)
  echo "moving files: $files_to_move"
  cd $source_directory && mv $(ls -t | head -n $batch_size) $target_directory && cd -
  if [ -n "$script" ]; then
    $script
  fi
  sleep $interval
  file_count=$(ls $source_directory | wc -l)
done
