#!/bin/bash

cd $(dirname $0)
./PMTRunner -flowcd LMGW --role parser
