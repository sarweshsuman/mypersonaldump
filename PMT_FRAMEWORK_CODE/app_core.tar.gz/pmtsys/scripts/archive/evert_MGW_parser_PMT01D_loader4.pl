#!/opt/PMT/binary/perl/bin/perl

use Carp;
use Data::Dumper;
use XML::Simple;
use DBI;
use JSON;
use Getopt::Long;
#enables passing of non defined options
Getopt::Long::Configure('pass_through');
my %options=();
GetOptions(\%options,'<>' => \&process);

use strict;

my $dbname='PMT01D';
my $user='PMT_SCHEMA';
my $password='PMT_SCHEMA';
my $dbd='Oracle';

# my $dbh=DBI->connect('dbi:Oracle:PMT01D',$user,$password);
my $dbh=DBI->connect('dbi:Oracle:(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(COMMUNITY=TCP.world)(PROTOCOL=TCP)(Host=ip-dora015.bc)(Port=1540)))(CONNECT_DATA=(SID=PMT01D)))',$user,$password);
$dbh->{AutoCommit} = 0;
if (!$dbh) {
  print "Error connecting to database; $DBI::errstr\n";
  exit;
}
#initiate db
DBI->trace(0);

my $sql_insert_pmt_tcpip=$dbh->prepare("insert into t_pmt_tcpip (MEASKEY, DN, MEASID, MEASTYPE, 
                 STARTTIME,INTERVAL, PMTTARGET)
        values (
        ?,?,?,?,
        to_timestamp_tz(?,'YYYY-MM-DD\"T\"HH24:MI:SS.FF6TZH:TZM'),
        ?,?
        )");
        
        
my $sql_insert_pmt_norm=$dbh->prepare(q{ 
          BEGIN
               p_pmt.add_record(?,?,?,?,?,?,?,?);
           END;
           });
$dbh->{FetchHashKeyName} = 'NAME_lc';
           
my $sql_dn_list=$dbh->prepare("select id, dn from t_pmt_dn");
my $sql_dn_extent=$dbh->prepare("insert into t_pmt_dn (id, dn)
         values(seq_pmt_dn_id.nextval,?)");
my $dn_list;
dn_hashlist();
print "dn_list:", scalar keys %$dn_list," keys\n";
         
my $sql_measid_list=$dbh->prepare("select id, measid from t_pmt_measid");
my $sql_measid_extent=$dbh->prepare("insert into t_pmt_measid (id, measid)
             values(seq_pmt_measid_id.nextval, ?)");
my $measid_list;
measid_hashlist();
print "measid_list:", scalar keys %$measid_list," keys\n";
             
my $sql_measkey_list=$dbh->prepare("select id, measkey from t_pmt_measkey");
my $sql_measkey_extent=$dbh->prepare("insert into t_pmt_measkey (id, measkey)
              values(seq_pmt_measkey_id.nextval, ?)");
my $measkey_list;
measkey_hashlist();
print "measkey_list:", scalar keys %$measkey_list," keys\n";
              
              
my $sql_meastype_list=$dbh->prepare("select id, meastype from t_pmt_meastype");
my $sql_meastype_extent=$dbh->prepare("insert into t_pmt_meastype (id, meastype)
               values(seq_pmt_meastype_id.nextval, ?)");
my $meastype_list;
meastype_hashlist();
print "meastype_list:", scalar keys %$meastype_list," keys\n";
               
               
my $sql_pmt_targetkey_list=$dbh->prepare("select id,pmttargetkey from t_pmt_pmttargetkey");
my $sql_pmt_targetkey_extent=$dbh->prepare("insert into t_pmt_pmttargetkey (id, pmttargetkey)
              values(seq_pmt_pmttargetkey_id.nextval, ?)");
my $targetkey_list;
pmt_targetkey_hashlist();
print "targetkey_list:", scalar keys %$targetkey_list," keys\n";
                  

#flush
$| = 1;

my $counter; my @animation = qw( \ | / - );

my $lineseperator = "\n";
my $seperator = "|";
my $cfgfile =  $options{'cfg'}  || "counters.json";

chdir ('/opt/PMT/scripts');
open LOAD_FILE, ">", "./etlexpmx_MGW_input.dat" or die "Could'nt open etlexpmx_MGW_input.dat.";
open (my $ch, '-|','ls /opt/PMT/scripts/import/etlexpmx_MGW_*.xml');
my ($FILE,$ref);
my @contents=<$ch>;
close $ch;
print @contents;

for my $f (@contents) {
  print "I should be processing file $f\n";
}


foreach  $FILE (@contents) 
{

  chomp($FILE);

  #source file
  # my $xml  =  $options{'src'}  || "./import/$FILE";
  my $xml  =  $options{'src'}  || "$FILE";

  print "XML is now $xml\n";

  logr('Ready to roll!');

  #load configfile
  logr("Reading configuration file ($cfgfile)");
  open FILE, "$cfgfile" or die $!;
  my @lines = <FILE>;
  my $cfg = join("\n",@lines);
  close FILE;
  my $meta = decode_json($cfg);

  #output file
  # open OUTFILE, ">$xml.csv" or die $!;

  #read source
  logr("Reading source file ($xml)");
  my $xs   = new XML::Simple( forcearray => 1, keeproot => 1 );
  my $ref  = eval { $xs->XMLin($xml) };

  if ($@){
    die "$0:$@\n";
  }

  logr("Starting loops. Hang on.");

  foreach my $OMeS (@{$ref->{OMeS}}){
   
    foreach my $PMSetup (@{$OMeS->{PMSetup}}){

      my $startTime = $PMSetup->{startTime};
      my $interval = $PMSetup->{interval};
      foreach my $PMMOResult (@{$PMSetup->{PMMOResult}}){
        my $dn =  $PMMOResult->{'MO'}[0]{'DN'}[0];
        #### check dn ####
        my $id_dn_hash;
        my $new_dn=0;
        if ($dn){
          if(defined $dn_list->{$dn} && $dn_list->{$dn}){
            $new_dn=1;
            $id_dn_hash=$dn_list->{$dn}->{id};
          }
        }
        if ($new_dn == 0) {$sql_dn_extent->execute($dn);
          $dbh->commit or die $DBI::errstr;
          $$dn_list{$dn}={};
          dn_hashlist();
          $id_dn_hash=$dn_list->{$dn}->{id};
          #print "Niet gevonden ",$id_dn_hash, "\n";
        }
        $new_dn=0;

        loop:
        foreach my $PMTarget (@{$PMMOResult->{PMTarget}}){
         #get measurement type
          my $measType = $PMTarget->{measurementType};
         
         #array used to cummulated all the counters
                   
          keyloop: 
          foreach my $key (keys %{$PMTarget}){
            print "$animation[$counter++]\b";
             $counter = 0 if $counter == scalar(@animation);
             my @cntArray=();
             next if ($key eq 'measurementType');

             my ($measId,$dummy,$pos) = ($key =~ /^M(\d+)(\D)(\d*)/);
             my $measKey = $measType."_".$measId;
           
             #skip if not in metafile
             #next loop if not defined $meta->{$measKey};
           
             #if the counternumber is not in the range: skip 
             #if($pos >= $meta->{$measKey}{'counters'}){
             # next keyloop;
             #}
             #construct record
             #orginally the record structure contains all measurments in one record,
             #if 100 meas in the source it would result in 100 columns!!! I prefer to have one record per meas.
             #
             #push(@cntArray,$measKey);
             #push(@cntArray,$dn);
             #push(@cntArray,$measId);
             #push(@cntArray,$measType);
             #push(@cntArray,$startTime);
             #push(@cntArray,$interval);
             #push(@cntArray,$PMTarget->{$key}[0]);
             
             my $pmtarget = $PMTarget->{$key}[0];
             # push(@cntArray,$key);
             #my $record = join($seperator,@cntArray);
           
             ### print OUTFILE $record.$lineseperator;
     
             my $startTime=substr($startTime,0,length($startTime)-3);
             # $sql_insert_pmt_tcpip->execute($measKey,$dn,$measId,$measType,$startTime,$interval,$PMTarget->{$key}[0]);
             # $sql_insert_pmt_norm->execute($measKey,$dn,$measId,$measType,$startTime,$interval,$PMTarget->{$key}[0],$key) or die $DBI::errstr;
             # $id_measkey_hash, $id_dn_hash, $id_measid_hash, $id_meastype_hash, $startTime, $interval, $pmtarget, $id_targetkey_hash
           
             #### Checks on all foreign keys. #####

             #### check measid ####
             my $id_measid_hash;
             my $new_measid=0;
             if ($measId){
               if(defined $measid_list->{$measId} && $measid_list->{$measId}){
                 $new_measid=1;
                 $id_measid_hash=$measid_list->{$measId}->{id};
               }
             }
             if ($new_measid == 0) {$sql_measid_extent->execute($measId);
               $dbh->commit or die $DBI::errstr;
               $$measid_list{$measId}={};
               measid_hashlist();
               $id_measid_hash=$measid_list->{$measId}->{id};
             }
             $new_measid=0;
            
            #### check measkey ####
             my $id_measkey_hash;
             my $new_measkey=0;
             if ($measKey){
               if(defined $measkey_list->{$measKey} && $measkey_list->{$measKey}){
                 $new_measkey=1;
                 $id_measkey_hash=$measkey_list->{$measKey}->{id};
               }
             }
             if ($new_measkey == 0) {$sql_measkey_extent->execute($measKey);
               $dbh->commit or die $DBI::errstr;
               $$measkey_list{$measKey}={};
               measkey_hashlist();
               $id_measkey_hash=$measkey_list->{$measKey}->{id};                     
             }
             $new_measkey=0;
            
             #### check meastype ####
             my $id_meastype_hash;
             my $new_meastype=0;
             if ($measType){
               if(defined $meastype_list->{$measType} && $meastype_list->{$measType}){
                 $new_meastype=1;
                 $id_meastype_hash=$meastype_list->{$measType}->{id};
               }
             }
             if ($new_meastype == 0) {$sql_meastype_extent->execute($measType);
               $dbh->commit or die $DBI::errstr;
               $$meastype_list{$measType}={};
               meastype_hashlist();
               $id_meastype_hash=$meastype_list->{$measType}->{id};                      
             }
             $new_meastype=0;
            
             #### check targetkey ####
             my $id_targetkey_hash;
             my $new_targetkey=0;
             if ($key){
               if(defined $targetkey_list->{$key} && $targetkey_list->{$key}){
                 $new_targetkey=1;
                 $id_targetkey_hash=$targetkey_list->{$key}->{id};
               }
             }
             if ($new_targetkey == 0 && $key ne "0") {$sql_pmt_targetkey_extent->execute($key);
               $dbh->commit or die $DBI::errstr;
               $$targetkey_list{$key}={};
               pmt_targetkey_hashlist();
               $id_targetkey_hash=$targetkey_list->{$key}->{id};                     
             }
             $new_targetkey=0;                                              
             #### Ens check on all foreign keys #####
             print LOAD_FILE "$id_measkey_hash, $id_dn_hash, $id_measid_hash, $id_meastype_hash, $startTime, $startTime, $interval, $pmtarget, $id_targetkey_hash\n" 
           
          } # end keyloop
        }#end loop
      }#end PMMOResult
    }#end PMSetup
  }# end OMeS

  $sql_insert_pmt_tcpip->finish;
  $dbh->commit or die $DBI::errstr;
}

### close OUTFILE;
close LOAD_FILE;

#logr('Start loading into database.');
#   system "/opt/PMT/scripts/load_etlexpmx_MGW.sh";
#   my $exit_value  = $? >> 8;
#   my $signal_num  = $? & 127;
#   my $dumped_core = $? & 128;
#   if ($exit_value != 0) {
#       print "exit_value $exit_value :  signal_num $signal_num : dumped_core $dumped_core \n";
#   }

logr('All done, have a nice day');

sub logr{
  my $msg = shift;
  print $msg. "\n";
}

sub process{
  my $a = shift;
  print "Process got parameters $a\n";
  if ( my ($a1,$a2)= $a =~ /^-(\w+)=(.*)$/ ) {
      $options{$a1} = $a2;
    } elsif ( my ($a1,$a2)= $a =~ /^--(\w+)=(.*)$/ ) {
      $options{$a1} = $a2;
    }elsif (my ($a1) = $a=~ /^--(\w+)$/ ) {
      $options{$a1} = 1;
    } elsif (my ($a1) = $a =~ /^-(\w+)$/){
      $options{$a1} = 1;
    }
}

sub dn_hashlist{
   # Load dn table into hasharray @{$dn_list}.
   $sql_dn_list->execute();
   $sql_dn_list->{RaiseError}=1;
   #$dn_list=$sql_dn_list->fetchall_arrayref();
   $dn_list = $sql_dn_list->fetchall_hashref('dn');
  # $$dn_list{'javavavavavav'}={};
  # print Dumper($dn_list);
  # exit;
   }
  
sub measid_hashlist{
   # Load measid table into hasharray @{$measid_list}.
   $sql_measid_list->execute();
   $sql_measid_list->{RaiseError}=1;
   $measid_list=$sql_measid_list->fetchall_hashref('measid');
   # foreach my $r (@{$measid_list}) { print join(", ", @{$r}), "\n";} #@{$r}[1];
   }
  
sub measkey_hashlist{
   # Load measkey table into hasharray @{$measkey_list}.
   $sql_measkey_list->execute();
   $sql_measkey_list->{RaiseError}=1;
   $measkey_list=$sql_measkey_list->fetchall_hashref('measkey');
   # foreach my $r (@{$measkey_list}) { print join(", ", @{$r}), "\n";} #@{$r}[1];
   }

sub meastype_hashlist{
   # Load meastype table into hasharray @{$meastype_list}.
   $sql_meastype_list->execute();
   $sql_meastype_list->{RaiseError}=1;
   $meastype_list=$sql_meastype_list->fetchall_hashref('meastype');
   # foreach my $r (@{$meastype_list}) { print join(", ", @{$r}), "\n";} #@{$r}[1];
   }
   
sub pmt_targetkey_hashlist{
   # Load targetkey table into hasharray @{$targetkey_list}.
   $sql_pmt_targetkey_list->execute();
   $sql_pmt_targetkey_list->{RaiseError}=1;
   $targetkey_list=$sql_pmt_targetkey_list->fetchall_hashref('pmttargetkey');
   # foreach my $r (@{$targetkey_list}) { print join(", ", @{$r}), "\n";} #@{$r}[1];
   }   
