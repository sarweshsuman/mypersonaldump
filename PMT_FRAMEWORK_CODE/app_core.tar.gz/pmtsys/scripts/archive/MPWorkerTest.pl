#!/usr/bin/env perl
#

use strict;
use IPC::Open2;
use JSON;
use PMTUtilities qw(getFileList);

print "This is a worker manager test\n";

my $worker_name = '/opt/PMT/scripts/PMTMPWorker.pl';

my $config = {config => {},params=>{}};
my $json_string = to_json($config);
print $json_string;
print "\n";
my $jlength = length($json_string);
my $packed_length = pack('N',$jlength);

my ($child_reader,$child_writer);

my $child_pid = open2($child_reader,$child_writer,$worker_name);
print $child_writer $packed_length; print $child_writer $json_string;
print "Child started with pid $child_pid\n";
sleep 10;
