#!/bin/bash

gunzip /opt/PMT/work/in/LDS/MSC/*gz # un-gunzip the files in 
PMTRunner --flowcd LDS --param subflow=MSC --role load
gzip -f /data/POC_Data/MSC_CDR_Archive/*[0-9]
PMTRunner --flowcd LDS --param subflow=MSC --role postload
