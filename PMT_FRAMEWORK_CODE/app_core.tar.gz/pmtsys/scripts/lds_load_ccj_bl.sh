#!/bin/bash

#. /home/pmtp/.bash_profile

if [ -f "/opt/PMT/pmtsys/var/locks/LDS/CCJ.lock" ]; then
  echo "lock exists" > /dev/null
else
  echo "lock does not exist" > /dev/null
  touch /opt/PMT/pmtsys/var/locks/LDS/CCJ.lock
  #/opt/PMT/pmtsys/scripts/backlogload.sh /data/POC_Data/CCJ_201407_0102 /opt/PMT/work/in/LDS/CCJ 80 > /dev/null || /bin/true
  #PMTRunner --flowcd LDS --param subflow=CCJ --role collect > /dev/null || /bin/true
  PMTRunner --flowcd LDS --param subflow=CCJ --role load > /dev/null || /bin/true
  gzip -f /opt/PMT/work/archive/LDS/CCJ/*acs > /dev/null || /bin/true
  mv -f /opt/PMT/work/archive/LDS/CCJ/* /data/POC_Data/CCJ_ARCHIVE > /dev/null || /bin/true
  PMTRunner --flowcd LDS --param subflow=CCJ --role postload > /dev/null || /bin/true
  rm -f /opt/PMT/pmtsys/var/locks/LDS/CCJ.lock
fi
#gunzip /opt/PMT/work/in/LDS/MSC/*gz # un-gunzip the files in 
#cd /opt/PMT/work/in/LDS/SPGW
#gunzip *eno.gz
#cd /opt/PMT/work/archive/LDS/SPGW
#gzip -f *eno
#gzip /data/POC_Data/MSC_CDR_Archive/*eno
#PMTRunner --flowcd LDS --param subflow=SPGW --role postload
