package PerlConsole;

$VERSION = '0.4';
