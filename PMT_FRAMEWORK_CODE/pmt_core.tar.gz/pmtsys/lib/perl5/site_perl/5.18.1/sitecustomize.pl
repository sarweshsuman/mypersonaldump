use English;
use Config;
use File::Spec;

my $sitelib = $Config{'sitelib'};
my $archname = $Config{'archname'};
my $siteprefix = $Config{'siteprefix'};
my $prefix = $Config{'prefix'};
my $installstyle = $Config{'installstyle'};
my $version = $Config{'version'};

my $cscript = File::Spec->catfile($sitelib,'sitecustomize.pl');
eval {

	#print "  version = $version\n  prefix=$prefix \n  siteprefix= $siteprefix\n  sitelib = $sitelib\n  archname $archname\n  installstyle = $installstyle\n";
	#for my $e (@INC) {
	#  print "$e\n";
	#}

	# I need to add to check whether the following directories are in the lib
	my $prefix_sitelib = File::Spec->catfile($prefix,$installstyle,'site_perl',$version);
	my $prefix_sitearch = File::Spec->catfile($prefix,$installstyle,'site_perl',$version,$archname);
	#for my $a ($prefix_sitelib,$prefix_sitearch) {
	#  print "Checking for $a\n";
	#}

	my $inc_length = scalar @INC;

	my @new_inc = (); 

	while ($INC[0] && $INC[0] !~ m:^$siteprefix:) {
		push @new_inc, shift @INC;
	}
	unshift @INC,$prefix_sitelib;
	unshift @INC,$prefix_sitearch;

	@new_inc = reverse @new_inc;

	for my $o (@new_inc) {
		unshift @INC, $o; 
	}
	#print STDERR "NOTICE: Perl (processid $$) customized by $cscript\n";
};
if ($@) {
  print STDERR "WARNING: Perl (processid $$) customization by $cscript failed : $@\n";
}

