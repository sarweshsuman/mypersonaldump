#!/opt/pxbigdata/bin/python

import os
import sys
import email
import ConfigParser
import time
from pyhive import hive
from extensions.infrastructure.ConnectionManager import HDFS
from kazoo.client import KazooClient
import json
import datetime
import socket
from StringIO import StringIO
from pyhive import hive

# Acquire a lock but not concurrently
# 

class zklock(object):
  pass 

default_options="""
source_hdfs_path=/osix/in
stage_hdfs_path=/osix/stg
done_hdfs_path=/osix/done
error_hdfs_path=/osix/error
hdfs_node=default
hdfs_port=8020
hdfs_user=lds
hive_user=lds
hive_password=lds
hive_database=testdb
hive_node=localhost
hive_port=10000
hive_stage_script=osix_stage.sql
hive_load_script=osix_load.sql
zkurl=localhost:6666
lockname=/osix_import_lock
notify=evert.carton.ext@proximus.com
maxbatchsize=0"""

def mail_alarm(p_alarm_type):
    if p_alarm_type==1:
        os.system('/hdfsstage/dev_scripts/mail_generic_osix.sh -T "Osix Hive Import: Error Staging" -B "Files were found in /user/lds/P0_STG_OSIX/EDR_STG/ from previous run. Take appropriate action." -M wim.six@proximus.com')
        os.system('/hdfsstage/dev_scripts/mail_generic_osix.sh -T "Osix Hive Import: Error Staging" -B "Files were found in /user/lds/P0_STG_OSIX/EDR_STG/ from previous run. Take appropriate action." -M willem.de.cremer@proximus.com')
        os.system('/hdfsstage/dev_scripts/mail_generic_osix.sh -T "Osix Hive Import: Error Staging" -B "Files were found in /user/lds/P0_STG_OSIX/EDR_STG/ from previous run. Take appropriate action." -M tom.mets@proximus.com')
        os.system('/hdfsstage/dev_scripts/mail_generic_osix.sh -T "Osix Hive Import: Error Staging" -B "Files were found in /user/lds/P0_STG_OSIX/EDR_STG/ from previous run. Take appropriate action." -M evert.carton.ext@proximus.com')
        os.system('/hdfsstage/dev_scripts/mail_generic_osix.sh -T "Osix Hive Import: Error Staging" -B "Files were found in /user/lds/P0_STG_OSIX/EDR_STG/ from previous run. Take appropriate action." -M trinir.kunda.ext@proximus.be')
        os.system('/hdfsstage/dev_scripts/mail_generic_osix.sh -T "Osix Hive Import: Error Staging" -B "Files were found in /user/lds/P0_STG_OSIX/EDR_STG/ from previous run. Take appropriate action." -M praveen.talare.ext@proximus.com')
        os.system('/hdfsstage/dev_scripts/mail_generic_osix.sh -T "Osix Hive Import: Error Staging" -B "Files were found in /user/lds/P0_STG_OSIX/EDR_STG/ from previous run. Take appropriate action." -M DL-000104520@owa.belgacom.be')


ss_defaults = StringIO(default_options)
cfg = dict([(i[0],i[1]) for i in [j.strip().split('=') for j in ss_defaults.readlines() if j.strip()]])

program = sys.argv.pop(0)

loc = os.path.abspath(os.path.dirname(program))

configfilename = 'osix_import.conf'
configfile = os.path.join(loc,configfilename)
#print "using configfile %s" %configfile


cparser = ConfigParser.ConfigParser()
if os.path.exists(configfile):
  cparser.read([configfile])
  cfg.update(dict(cparser.items('osix_import')))

# Zookeeper Stuff: Lo
zkdata = {'timestamp':datetime.datetime.strftime(datetime.datetime.now(),'%Y-%m-%d %H:%M:%S'),'pid':os.getpid(),'host':socket.getfqdn(),'user':os.getlogin()}
zkdata_s = json.dumps(zkdata)
print zkdata_s

# we can really start now
zk = KazooClient(hosts=cfg['zkurl'])
zk.start()

lock = zk.Lock(cfg['lockname'],zkdata_s)
res = lock.acquire(False)


if not res:
  print "Could not acquire the lock, lock is acquired" , lock.contenders()[0]
  sys.exit()

import time
print "%s acquired lock" %(time.asctime(),)
# Get the HDFS: 
h = HDFS(host=cfg['hdfs_node'],port=int(cfg['hdfs_port']),user=cfg['hdfs_user'])

stage_files = h.ll(cfg['stage_hdfs_path'])
if len(stage_files) > 0:
  mail_alarm(1)
  raise RuntimeError('Found files in stage, unexpected, exiting ')

error = False
try:
  stage_files = h.ll(cfg['stage_hdfs_path'])
  if len(stage_files) > 0:
    mail_alarm(1)
    raise RuntimeError('Found files in stage, unexpected, exiting ')

  stg_filename = cfg['hive_stage_script']
  load_filename = cfg['hive_load_script']

  if not os.path.isabs(stg_filename):
     stg_filename = os.path.join(loc,stg_filename)
  if not os.path.isabs(load_filename):
     load_filename = os.path.join(loc,load_filename)

  if not os.path.exists(stg_filename):
    raise RuntimeError('File does not exist: %s' %stg_filename)
  if not os.path.exists(load_filename):
    raise RuntimeError('File does not exist: %s' %load_filename)

  sql_stg = open(stg_filename,'r').read()
  sql_load = open(load_filename,'r').read()
  

  present_files = h.ll(cfg['source_hdfs_path'])
  # temporary condition
  present_files = [ i for i in present_files if i['size'] > 0 ]
  
  import re
  import os.path
  sortkey = lambda x: int(re.sub('\.?txt$','',os.path.basename(x['path'])).split('-')[-1])
  present_files = sorted(present_files,key=sortkey)
  mbs = int(cfg['maxbatchsize'])
  if mbs:
    mbs = min(mbs,len(present_files))
    present_files = present_files[0:mbs]
  process_files = [p['path'] for p in present_files]
  print "files to process",process_files
  
  #print "processing present_files:", process_files, len(process_files)
  #print "moving files from %s to %s" %(cfg['source_hdfs_path'],cfg['stage_hdfs_path'])
  h.mv(process_files,cfg['stage_hdfs_path'])

  h_connect = {'database':cfg['hive_database'],
              'username':cfg['hive_user'],
              'host':cfg['hive_node'],
              'port':int(cfg['hive_port'])}
  hdb = hive.connect(**h_connect)
  c = hdb.cursor()

  #print "executing sql",sql_stg
  #c.execute(sql_stg)
  print "executing sql",sql_load
  c.execute(sql_load)
  print "Executed SQL"
  try:
    c.close()
    hdb.close()
  except:
    print "error occurred when closing database connection"
  print "Closed database connection"
  print "moving files from from %s to %s" %(cfg['stage_hdfs_path'],cfg['done_hdfs_path'])
  #os.system ('/tivp/custom/bin/WPosteMsg.ksh -f /home/lds/WPosteMsg.ini BDP_DWH_MSG4')
  stg_files = h.ll(cfg['stage_hdfs_path'])
  #print "stage files:" ,stg_files
  h.mv([p['path'] for p in h.ll(cfg['stage_hdfs_path'])],cfg['done_hdfs_path'])
  #mv files from stg to done
except Exception as e:
  print "Error occurred", e
  stg_files = h.ll(cfg['stage_hdfs_path'])
  #print "stage files:" ,stg_files
  # move files from stg to error
  error = True
  print "moving files from %s to %s" %(cfg['stage_hdfs_path'],cfg['error_hdfs_path'])
  h.mv([p['path'] for p in h.ll(cfg['stage_hdfs_path'])],cfg['error_hdfs_path'])
finally:
  lock.release()

if error:
  sys.exit(1)
sys.exit()
