insert into table P0_LDS_CDR.T_OSIX_LOCATION_L1 partition (EVENT_DATE)
select 
  interface_type
,process_number
,cast(starttime as timestamp) network_event_ts
,cast(imsi as decimal(16,0)) imsi
,cast(substr(imei, 1, 8) as decimal(8,0)) imei
,cast(lac as int) lac
,cast(rac as int) rac
,cast(tac as int) tac
,cast(cell as bigint) cell
,case when transaction_type = 'UpDataLocation' then 'UpdateLocation'
       when transaction_type = 'ACCT_PDP' then 'ACT_PDP'
       else transaction_type  end as  transaction_type 
 ,transaction_subtype
,transaction_subtype_succ 
 ,errorcode
,split_indicator
,cast(record_accept_ts as timestamp ) record_accept_ts  
 ,substr(starttime, 1, 10) as event_date
from P0_STG_OSIX.T_LDS_OSIX_EDR_STG

