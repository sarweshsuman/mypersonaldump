from pyspark import SparkConf,SparkContext
from pyspark.sql import HiveContext

config=SparkConf().setAppName("InsertIntoTable")
sc=SparkContext(conf=config)
hc=HiveContext(sc)

hc.sql("use p0_stg_osix")

hc.sql("insert into p0_lds_cdr.t_osix_location_l1 select interface_type,process_number,starttime,imsi,imei,lac,rac,tac,cell,transaction_type,transaction_subtype,transaction_subtype_succ,errorcode,split_indicator,record_accept_ts from t_lds_osix_edr_stg limit 10")
