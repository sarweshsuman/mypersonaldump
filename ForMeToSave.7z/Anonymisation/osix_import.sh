#!/bin/bash
set -x
export JAVA_HOME=/etc/alternatives/java_sdk
export PXTOOLKIT_CONFDIR=/opt/pxmodules/etc

echo "======================================" >> /tmp/osix_import.log
date >> /tmp/osix_import.log
osix_import.py 2>&1 >> /tmp/osix_import.$$.log || /bin/true
gzip  /tmp/osix_import.$$.log

