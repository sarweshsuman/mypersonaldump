//-----------------------------------------------------------------------------
// Copyright 2014-2016 Voltage Security LLC
//-----------------------------------------------------------------------------
package com.voltage.securedata.hadoop.crypto;

import java.io.File;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.voltage.securedata.enterprise.FPE;
import com.voltage.securedata.enterprise.LibraryContext;
import com.voltage.securedata.enterprise.VeException;
import com.voltage.securedata.hadoop.config.CryptoAuthMethod;
import com.voltage.securedata.hadoop.config.FormatInfo;
//PROXIMUS
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Local crypto implementation which calls the newer (version 4.0+) Simple API.
 * This class "wraps" the Simple API interface in the standardized Crypto 
 * interface, to provide a common abstraction layer for the crypto operations.
 */
public class LocalCrypto extends BaseCrypto {

	private static final Log LOG = LogFactory.getLog(LocalCrypto.class);

	// Simple API error codes, for auth error trapping
	private static final int ERROR_CODE_AUTH_DENIED = 566;

	// name of Simple API native library, and subdirectory location
	private static final String LOCAL_LIB_NAME = "libvibesimplejava.so";
	private static final String LIB_SUBDIR = "lib";

	// config settings
	private static String policyUrl;
	private static String configPath;

	// static instance, can be shared by multiple instances
	private static LibraryContext libraryContext;

	private FPE fpe;
	
	//change 1
	protected Pattern timestampPattern = Pattern.compile("(\\d\\d\\d\\d)\\-(\\d\\d)\\-(\\d\\d)\\s+(\\d{1,2})\\:(\\d\\d)\\:(\\d\\d)\\.?(\\d{0,3})");

	/** Returns the name of the local crypto service: Local-SimpleAPI */
	@Override
	public String getName() {
		return "Local-SimpleAPI";
	}

	/**
	 * Initializes the local service, for the specified settings.
	 * 
	 * @param policyUrlVal URL of the client policy hosted on the key server.
	 * @param configPathVal  base installation path for the Simple API.  This 
	 * directory must contain the shared object native library 
	 * (libvibesimplejava.so) as well as the trustStore subdirectory with 
	 * the trusted root CA certs.
	 */
	protected static void initService(String policyUrlVal, String configPathVal) {
		LocalCrypto.policyUrl = trim(policyUrlVal);
		LocalCrypto.configPath = trim(configPathVal);
		log("[INIT] LocalCrypto: " + LocalCrypto.policyUrl);
	}

	/** 
	 * Initializes the Simple API, by loading the native library and creating
	 * the shared library context.
	 */
	private static synchronized void initSimpleAPI() {
		if (libraryContext == null) {
			log("ConfigPath: " + configPath);

			try {
				String trustStorePath = getTruststorePath(configPath);
				String libPath = getPath(configPath, LOCAL_LIB_NAME);

				// check if native library exists in base directory; otherwise,
				// look in lib subdirectory
				File libFile = new File(libPath);
				if (!libFile.exists()) {
					String subDir = getPath(configPath, LIB_SUBDIR);
					libPath = getPath(subDir, LOCAL_LIB_NAME);
				}

				log("Loading Simple API library: " + libPath);
				System.load(libPath);

				log("Initializing Simple API library context, with truststore path " + 
						trustStorePath);

				// build SimpleAPI LibraryContext
				libraryContext = new LibraryContext.Builder()
				.setPolicyURL(policyUrl)
				.allowShortFPE(true)
				.setTrustStorePath(trustStorePath)
				.enableMemoryCache(true)
				.build();

				String version = LibraryContext.getVersion();
				log("Initialized Simple API, version: " + version);
			}
			catch (Throwable e) {
				throw new RuntimeException("Failed to initialize Simple API", e);
			}
		}
	}

	/** Logs the specified message at INFO level. */
	private static void log(String msg) {
		LOG.info(msg);
	}

	/** 
	 * Cleans up the underlying Simple API crypto implementation, by destroying
	 * the FPE object.
	 */
	@Override
	public void cleanup() {
		if (this.fpe == null) {
			// nothing to clean up
			return;
		}

		log("Deleting local FPE object, format: " + getFormat());
		this.fpe.delete();
		this.fpe = null;
		log("Deleted local FPE object");
	}

	/** 
	 * Cleans up the underlying Simple API library, by destroying the 
	 * library context object. 
	 */
	public static void cleanupLibrary() {
		if (libraryContext == null) {
			// nothing to clean up
			return;
		}

		log("Deleting local LibraryContext");
		libraryContext.delete();
		libraryContext = null;
		log("Deleted local LibraryContext");
	}

	/** 
	 * Make sure Simple API FPE objects are cleaned up during garbage collection, 
	 * in case user doesn't explicitly call the cleanup() method.
	 */
	@Override
	protected void finalize() throws Throwable {
		try {
			cleanup();
		} 
		finally {
			super.finalize();
		}
	}

	/** 
	 * Builds the local crypto instance for the specified format information.
	 * 
	 * @param formatInfo format info (format name, identity, auth 
	 * credentials, etc.) for which to create this local crypto instance.
	 */
	protected LocalCrypto(FormatInfo formatInfo, boolean ignoreAuthFailureForAccess) {
		super(formatInfo, ignoreAuthFailureForAccess);
		initSimpleAPI();
	}

	/** 
	 * Builds the wrapped Simple API FPE object to perform protect/access
	 * operations.
	 */
	private FPE buildFpe() throws Exception {
		log("Creating local FPE object, for format [" + getFormat() + "]");

		// initialize FPE builder, for specified format name and identity
		FPE.Builder builder = libraryContext.getFPEBuilder(getFormat());
		builder.setIdentity(getIdentity());

		// set auth credentials, based on type (shared secret or 
		// username/password)
		CryptoAuthMethod authMethod = getAuthMethod();
		if (authMethod == CryptoAuthMethod.SharedSecret) {
			builder.setSharedSecret(getSharedSecret());
		}
		else if (authMethod == CryptoAuthMethod.UserPassword) {
			builder.setUsernamePassword(getUsername(), getPassword());
		}
		else {
			throw new IllegalArgumentException("Invalid auth method: " + getAuthMethod());
		}

		return builder.build(); 
	}

	/** Builds/returns the wrapped Simple API FPE object. */
	private FPE getFpe() throws Exception {
		if (this.fpe == null) {
			this.fpe = buildFpe();
		}
		return this.fpe;
	}

	/** 
	 * Wraps the thrown Simple API exception into a standard CrpytoException.
	 * 
	 * @param e Simple API exception to be wrapped.
	 * @return CryptoException instance that wraps the underlying Simple API
	 * exception.
	 */
	@Override
	protected CryptoException buildCryptoException(Exception e) {
		String errorMsg = "Simple API call failed for formatInfo [" + 
				getFormatInfo() + "]: " + e.getMessage();
		return new CryptoException(errorMsg, e);
	}

	@Override
	protected boolean isAuthException(Exception e) {
		if (e instanceof VeException) {
			// check error code for Auth denied 
			VeException veException = (VeException)e;
			return (veException.getErrorCode() == ERROR_CODE_AUTH_DENIED);
		}
		return false;
	}

	@Override
	public String protectFormattedData(String input) throws CryptoException {
		// delegate to wrapped Simple API FPE object
		try {
			FPE fpeFormat = getFpe();
			String processedInput = preProcess(input);

			// base Simple API call
			String output;
			if (isEmpty(processedInput)) {
				// skip empty/null
				output = processedInput;
			}
			else {
				String currentFormat = getFormat();
				if (currentFormat.equals("ProximusDate")){
					output = parseTimestampAndEncrypt(processedInput);
				}
				else{
					output = fpeFormat.protect(processedInput);
				}
			}

			return postProcess(output);
		}
		catch (Exception e) {
			throw buildCryptoException(e);
		}

	}

	@Override
	protected String performAccess(String input) throws Exception {
		// delegate to wrapped Simple API FPE object
		FPE fpeFormat = getFpe();
		String processedInput = preProcess(input);

		// base Simple API call
		String output;
		if (isEmpty(processedInput)) {
			// skip empty/null
			output = processedInput;
		}
		else {
			String currentFormat = getFormat();
			if (currentFormat.equals("ProximusDate")){
				output = parseTimestampAndDecrypt(processedInput);
			}
			else{
				output = fpeFormat.access(processedInput);
			}
		}

		return postProcess(output);
	}

	@Override
	public String[] protectFormattedDataList(String[] input) throws CryptoException {
		// delegate to wrapped Simple API FPE object
		try {
			FPE fpeFormat = getFpe();
			String[] output = new String[input.length];
			// perform FPE operation in loop; Simple API does not have separate
			// explicit "list" API
			String[] processedInput = preProcess(input);
			for (int i=0; i < processedInput.length; i++) {
				// base Simple API call
				if (isEmpty(processedInput[i])) {
					// skip empty/null
					output[i] = processedInput[i];
				}
				else {
					String currentFormat = getFormat();
					if (currentFormat.equals("ProximusDate")){
						output[i] = parseTimestampAndEncrypt(processedInput[i]);
					}
					else{
						output[i] = fpeFormat.protect(processedInput[i]);
					}
				}
			}
			return postProcess(output);
		}
		catch (Exception e) {
			throw buildCryptoException(e);
		}        
	}

	@Override
	public String[] performAccessList(String[] input) throws Exception {
		// delegate to wrapped Simple API FPE object
		FPE fpeFormat = getFpe();
		String[] output = new String[input.length];

		// perform FPE operation in loop; Simple API does not have separate
		// explicit "list" API
		String[] processedInput = preProcess(input);
		for (int i=0; i < processedInput.length; i++) {
			// base Simple API call
			if (isEmpty(processedInput[i])) {
				// skip empty/null
				output[i] = processedInput[i];
			}
			else {
				String currentFormat = getFormat();
				if (currentFormat.equals("ProximusDate")){
					output[i] = parseTimestampAndDecrypt(processedInput[i]);
				}
				else{
					output[i] = fpeFormat.access(processedInput[i]);
				}
			}
		}
		return postProcess(output);
	}    

	/* START PROXIMUS EDITS */


	public String parseTimestampAndEncrypt(String timestamp) throws CryptoException {

		Integer ts_year = 0;
		Integer ts_month = 0;
		Integer ts_day = 0;
		Integer ts_hour = 0;
		Integer ts_min = 0;
		Integer ts_sec = 0;
		Integer ts_ms = 0;

		//change 1
		Matcher m = timestampPattern.matcher(timestamp);

		if (m.find()) {
			ts_year = Integer.parseInt(m.group(1));
			ts_month = Integer.parseInt(m.group(2));
			ts_day = Integer.parseInt(m.group(3));
			ts_hour = Integer.parseInt(m.group(4));
			ts_min = Integer.parseInt(m.group(5));
			ts_sec = Integer.parseInt(m.group(6));
			//change3

			String ts_string = m.group(7);
			if ((ts_string == null) || (ts_string.equalsIgnoreCase(""))){
				ts_ms = 0;
			}
			else{
				int ts_length = ts_string.length();
				ts_ms = Integer.parseInt(m.group(7));
				if (ts_length == 1){
					ts_ms = ts_ms * 100;
				}
				else if (ts_length == 2){
					ts_ms = ts_ms * 10;
				}
			}

			//change2

		} else {
			//      System.out.println("INVALID TIMESTAMP (NEED TO HANDLE HERE)");
		}


		int total_ms = toMs(ts_min, ts_sec, ts_ms);
		int enc_ms = encryptMs(total_ms);
		String new_mn_sc_ms = fromMs(enc_ms);//change to enc version
		String new_ts = String.format("%4d-%02d-%02d %02d:%s",ts_year,ts_month,ts_day,ts_hour,new_mn_sc_ms);

		//out.println("NEW TS: " + new_ts);

		return new_ts;
	}
	public String parseTimestampAndDecrypt(String timestamp) throws CryptoException {

		Integer ts_year = 0;
		Integer ts_month = 0;
		Integer ts_day = 0;
		Integer ts_hour = 0;
		Integer ts_min = 0;
		Integer ts_sec = 0;
		Integer ts_ms = 0;

		//change 1
		Matcher m = timestampPattern.matcher(timestamp);

		if (m.find()) {
			ts_year = Integer.parseInt(m.group(1));
			ts_month = Integer.parseInt(m.group(2));
			ts_day = Integer.parseInt(m.group(3));
			ts_hour = Integer.parseInt(m.group(4));
			ts_min = Integer.parseInt(m.group(5));
			ts_sec = Integer.parseInt(m.group(6));
			//change3

			String ts_string = m.group(7);
			if ((ts_string == null) || (ts_string.equalsIgnoreCase(""))){
				ts_ms = 0;
			}
			else{
				int ts_length = ts_string.length();
				ts_ms = Integer.parseInt(m.group(7));
				if (ts_length == 1){
					ts_ms = ts_ms * 100;
				}
				else if (ts_length == 2){
					ts_ms = ts_ms * 10;
				}
			}
		} else {
			//System.out.println("INVALID TIMESTAMP (NEED TO HANDLE HERE)");
		}


		int total_ms = toMs(ts_min, ts_sec, ts_ms);
		int dec_ms = decryptMs(total_ms);
		String new_mn_sc_ms = fromMs(dec_ms);
		String new_ts = String.format("%4d-%02d-%02d %02d:%s",ts_year,ts_month,ts_day,ts_hour,new_mn_sc_ms);

		//out.println("NEW TS: " + new_ts);

		return new_ts;
	}
	

	public int toMs(int mn, int sc, int ms){

		int total_ms = ms;
		total_ms += (1000 * sc);
		total_ms += (1000 * 60 * mn);
		//out.println("Total MS:  " + total_ms);

		return total_ms;
	}
	public String fromMs(int og_ms){

		Double mn_double = (double)og_ms / (1000 * 60);
		int mn = mn_double.intValue();
		og_ms -= (mn * 1000 * 60);
		Double sc_double = (double)og_ms / (1000);
		int sc=sc_double.intValue();
		og_ms -= (sc * 1000);
		//CHANGE #2:
		String toReturn = String.format("%02d:%02d.%03d", mn,sc,og_ms);	
		//out.println("TO return: " + toReturn);

		return (toReturn);
	}

	public 	int encryptMs(int total_ms) throws CryptoException {
		//		int to_return = 291028;
		// delegate to wrapped Simple API FPE object
		try {
			FPE fpeFormat = getFpe();
			String inputTs =  String.valueOf(total_ms) ;

			// base Simple API call
			String output;
			if (isEmpty(inputTs)) {
				// skip empty/null
				output = inputTs;
			}
			else {
				output = fpeFormat.protect(inputTs);
			}
			return Integer.parseInt(output);
		}
		catch (Exception e) {
			throw buildCryptoException(e);
		}        
	}

	public 	int decryptMs(int total_ms) throws CryptoException {
		//		int to_return = 124160;
		//		return to_return;

		try {
			// delegate to wrapped Simple API FPE object
			FPE fpeFormat = getFpe();
			String inputTs =  String.valueOf(total_ms) ;

			// base Simple API call
			String output;
			if (isEmpty(inputTs)) {
				// skip empty/null
				output = inputTs;
			}
			else {
				output = fpeFormat.access(inputTs);
			}
			return Integer.parseInt(output);
		}
		catch (Exception e) {
			throw buildCryptoException(e);
		}        
	}


}
