from pyspark import SparkContext,SparkConf
from pyspark.sql import HiveContext

conf=SparkConf().setAppName("insertintohive")
ctx=SparkContext(conf=conf)
hc=HiveContext(ctx)

#hc.sql("drop function if EXISTS accessdata");
#hc.sql("drop function if EXISTS protectdata");

#hc.sql("create function accessdata as 'com.voltage.securedata.hadoop.hive.AccessData'");
#hc.sql("create function protectdata as 'com.voltage.securedata.hadoop.hive.ProtectData'");

df=hc.sql("insert into p0_lds_cdr.t_osix_location_l1_encrypted partition(event_date='2016-11-26') select interface_type ,process_number ,default.protectdata(network_event_ts,'NETWORK_EVENTS_TS') as network_event_ts ,default.protectdata(imsi,'IMSI') as imsi,default.protectdata(imei,'IMEI') as imei,default.protectdata(COALESCE(lac,10),'LAC') as lac ,default.protectdata(COALESCE(case when rac=0 then 10 else rac end,10),'RAC') as rac ,default.protectdata(COALESCE(tac,10),'TAC') as tac ,default.protectdata(COALESCE(cell,10),'CELL') as cell ,transaction_type ,transaction_subtype ,transaction_subtype_succ ,errorcode ,split_indicator ,default.protectdata(record_accept_ts ,'NETWORK_EVENTS_TS') as record_accept_ts from p0_lds_cdr.t_osix_location_l1 where event_date='2016-11-26' and imsi>111111111111 and length(cast(network_event_ts as string))>19 and length(cast(record_accept_ts as string))>19")

print df.collect()
