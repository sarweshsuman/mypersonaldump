beeline <<EOF
!connect jdbc:hive2://$1:10001/$2;transportMode=http;httpPath=cliservice
$3
$4
alter table d0_topurl_data.t_radius add if not exists partition(datadate='$5')
EOF
