#!/bin/bash -e
# Read Property files

export file=$1

if [[ $file = '' ]]
then
	echo "No Properties file Found"
	exit;
fi

echo "Using properties file $file"

export comma_sep_list_of_tables=""
#`cat $file | grep 'partitioned.table.to.clean' | cut -d'=' -f2`
export hive_server=`hadoop fs -cat $file | grep hive.server | cut -d'=' -f2`

echo $comma_sep_list_of_tables | tr ',' '\n' | while read table_name
do
	if [[ $table_name = '' ]]
	then
		continue
	fi

	export database=`hadoop fs -cat $file | grep ^$table_name\.database | cut -d'=' -f2`
	export username=`hadoop fs -cat $file | grep ^$table_name\.username | cut -d'=' -f2`
	export password=`hadoop fs -cat $file | grep ^$table_name\.password | cut -d'=' -f2`

	if [[ $database = '' ]]
	then
		export database=`hadoop fs -cat $file | grep ^default\.database | cut -d'=' -f2`
	fi	
	if [[ $username = '' ]] 
	then
		export username=`hadoop fs -cat $file | grep ^default\.username | cut -d'=' -f2`
	fi
	if [[ $password = '' ]]
	then	
		export password=`hadoop fs -cat $file | grep ^default\.password | cut -d'=' -f2`
	fi
	
	export part_name=`hadoop fs -cat $file | grep ^$table_name\.partition\.name | cut -d'=' -f2`

	if [[ $part_name = '' ]]
	then
		echo "Will not process $table_name as part_name not present in properties file"
		continue
	fi
	export older_than=`hadoop fs -cat $file | grep ^$table_name\.drop\.partition\.older\.than\.seconds | cut -d'=' -f2`
	if [[ $older_than = '' ]]
	then
		export older_than=`hadoop fs -cat $file | grep ^default\.drop\.partition\.older\.than\.seconds | cut -d'=' -f2`
	fi
	echo "Dropping partition older than "$older_than" seconds for table $table_name"
	export dt_maxage_epoch=`python -c "import datetime;print int(datetime.datetime.now().strftime('%s'))-$older_than"`
	echo "Getting list of partitions for table $table_name "
#export output=`beeline <<EOF
#!connect jdbc:hive2://$hive_server:10001/$database;transportMode=http;httpPath=cliservice
#$username
#$password
#show partitions $table_name
#EOF`
	export output='3 rows selected (0.102 seconds) Closing: 0: jdbc:hive2://el3207.bc:10001/default;transportMode=http;httpPath=cliservice beeline> !connect jdbc:hive2://el3207.bc:10001/default;transportMode=http;httpPath=cliservice Enter username for jdbc:hive2://el3207.bc:10001/default;transportMode=http;httpPath=                   cliservice: id832037 Enter password for jdbc:hive2://el3207.bc:10001/default;transportMode=http;httpPath=cliservice: AlterRadiusTable.sh cleanup.ini cleanup.sh commons-csv-1.4.ja                   r RadiusAfterLoadOperation.conf RadiusAfterLoadOperation.jar run_spark_sql_TOPURL spark-csv_2.10-1.4.0.jar spark-sql-0.0.1-SNAPSHOT.jar topurl-framework.properties TopUrlRadiusPu                   ll.conf TopUrlSnifferFilePull.conf TopUrlSnifferFilePull.jar 0: jdbc:hive2://el3207.bc:10001/default> show partitions t_radius 0: jdbc:hive2://el3207.bc:10001/default> +---------                   -------------+--+ partition +----------------------+--+ datadate=2016-09-13 datadate=2016-09-14 datadate=2016-09-15 +----------------------+--+ 0: jdbc:hive2://el3207.bc:10001/de                   fault>'
	echo $output | perl -e '$_=<>;@arr=split (/\s+/); foreach my $a (@arr){print $a,"\n";}' | while read line
	do
		echo $line | grep $part_name > /dev/null 2>&1
		if [ $? -eq 0 ];
		then
			dt_from_part=`echo $line | cut -d'=' -f2`
			export epoch_from_part=`python -c "import datetime;print int(datetime.datetime.strptime('$dt_from_part 23:59:59','%Y-%m-%d %H:%M:%S').strftime('%s'))"`
			if [ $epoch_from_part -lt $dt_maxage_epoch ];
			then
				echo "Droping partition $line"
beeline <<EOF
!connect jdbc:hive2://$hive_server:10001/$database;transportMode=http;httpPath=cliservice
$username
$password
alter table $table_name drop partition($part_name='$dt_from_part');
EOF
			fi
		fi
	done;

done;

echo "Now cleaning hdfs"

export comma_sep_list_of_hdfs_to_clean=`hadoop fs -cat $file | grep 'hdfs.dir.to.clean' | cut -d'=' -f2`

echo $comma_sep_list_of_hdfs_to_clean | tr ',' '\n' | while read hdfs_dir
do
	echo "Processing dir $hdfs_dir"
	export older_than=`hadoop fs -cat $file | grep ^$hdfs_dir\.hdfs\.clean\.all\.files\.older\.than\.seconds | cut -d'=' -f2`
	if [[ $older_than = '' ]]
	then 
		 export older_than=`hadoop fs -cat $file | grep ^default\.hdfs\.clean\.all\.files\.older\.than\.seconds | cut -d'=' -f2`
	fi
	export dt_maxage_epoch=`python -c "import datetime;print int(datetime.datetime.now().strftime('%s'))-$older_than"`
	echo "Deleting files older than $dt_maxage_epoch seconds"
	export count=0
	hadoop fs -ls $hdfs_dir | sed -r 's/\s+/\,/g' | cut -d',' -f8 | while read file_name
	do
		if [[ $file_name = '' ]]
		then
			continue
		fi
		export dt_from_file=`hadoop fs -ls $file_name | sed -r 's/\s+/\,/g' | cut -d',' -f6-7`
		export epoch_from_file=`python -c "import datetime;print int(datetime.datetime.strptime('$dt_from_file:00','%Y-%m-%d,%H:%M:%S').strftime('%s'))"`
		if [ $epoch_from_file -lt $dt_maxage_epoch ]
		then
			hadoop fs -rm -skipTrash $file_name > /dev/null 2>&1 
			count=`expr $count + 1`
		else 
			break
		fi
	done;
	echo "Deleted $count files from $hdfs_dir"
done;
exit 0;
