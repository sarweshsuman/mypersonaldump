now=`date +%s`
if [ $now -lt 1476489600 ];
then
        echo "Not executing due to time restriction"
        exit
fi
echo "Ok I will execute "

echo "starting collect at"`date`
java -jar /hdfsstage/dev_scripts/TOPURL/scripts/TopUrlSnifferFilePull.jar collect /hdfsstage/dev_scripts/TOPURL/scripts/TopUrlSnifferFilePull_PreviousHour_OnlyCollect.conf 2>&1
echo "collect complete at"`date`
echo "starting collect at"`date`
java -jar /hdfsstage/dev_scripts/TOPURL/scripts/TopUrlSnifferFilePull.jar collect /hdfsstage/dev_scripts/TOPURL/scripts/TopUrlSnifferFilePull_PreviousHour_SnifferServer2_OnlyCollect.conf 2>&1
echo "collect complete at"`date`
