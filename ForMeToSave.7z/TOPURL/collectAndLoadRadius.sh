now=`date +%s`
if [ $now -lt 1476489600 ];
then
        echo "Not executing due to time restriction"
        exit
fi
echo "Ok I will execute "

echo "invoking collect at "`date`
java -jar /hdfsstage/dev_scripts/TOPURL/scripts/TopUrlSnifferFilePull.jar collect /hdfsstage/dev_scripts/TOPURL/scripts/TopUrlRadiusPull.conf 2>&1 
echo "collect complete at "`date`
sleep 10
echo "invoking load at "`date`
hadoop jar /hdfsstage/dev_scripts/TOPURL/scripts/TopUrlSnifferFilePull.jar load /hdfsstage/dev_scripts/TOPURL/scripts/TopUrlRadiusPull.conf 2>&1
echo "load complete at "`date`
