now=`date +%s`
if [ $now -lt 1476489600 ];
then
	echo "Not executing due to time restriction"
	exit
fi
echo "Ok I will execute "

echo "invoking sniffer 1 collect at "`date`
java -jar /hdfsstage/dev_scripts/TOPURL/scripts/TopUrlSnifferFilePull.jar collect /hdfsstage/dev_scripts/TOPURL/scripts/TopUrlSnifferFilePull_CurrentHour.conf 2>&1 
echo "collect complete at "`date`
echo "invoking collect from sniffer 2 at "`date`
java -jar /hdfsstage/dev_scripts/TOPURL/scripts/TopUrlSnifferFilePull.jar collect /hdfsstage/dev_scripts/TOPURL/scripts/TopUrlSnifferFilePull_CurrentHour_SnifferServer2.conf 2>&1 
echo "collect complete at "`date`
echo "invoking load at "`date`
hadoop jar /hdfsstage/dev_scripts/TOPURL/scripts/TopUrlSnifferFilePull.jar load /hdfsstage/dev_scripts/TOPURL/scripts/TopUrlSnifferFilePull_CurrentHour.conf 2>&1
echo "load complete at "`date`
