import tensorflow as tf

class ImageClassification:
    """
    ImageClassification expects following in initialContext
    it is an operand on which an operator will act

    operand/image_classification/image_height
    operand/image_classification/image_width
    operand/image_classification/num_classes
    operand/image_classification/num_layers
    operand/image_classification/filter_height
    operand/image_classification/filter_width
    operand/image_classification/num_filters_per_layer

    """
    def __init__(self,initialContext):
        self.initialContext=initialContext

        self.session = tf.Session()
        with self.session.as_default():
	        self.image_height=int(initialContext['operand/image_classification/image_height'])
	        self.image_width = int(initialContext['operand/image_classification/image_width'])
	        self.num_classes=int(initialContext['operand/image_classification/num_classes'])

	        self.num_layers = int(initialContext['operand/image_classification/num_layers'])
	        self.filter_heigth = initialContext['operand/image_classification/filter_height']
	        self.filter_width = initialContext['operand/image_classification/filter_width']

	        self.num_filters_per_layer = initialContext['operand/image_classification/num_filters_per_layer']

	        self.num_filters = self.num_filters_per_layer.split(',') # [32,64] if num_of_layers = 2

	        self.x=tf.placeholder(tf.float32,[None,self.image_height * self.image_width])
		#Debugging
	        self.x=tf.Print(self.x,[self.x],message="Input X")

	        self.y_=tf.placeholder(tf.float32,[None,self.num_classes])
		#Debugging
	        self.y_=tf.Print(self.y_,[self.y_],message="Input Y")


	        self.x_image = tf.reshape(self.x,[-1,self.image_height,self.image_width,1]) # Considering channel = 1
	        self.W_conv=[]
	        self.b_conv=[]

	        self.h_conv=[]
	        self.h_pool=[]

	        input_channel = 1
	        output_channel = int(self.num_filters[0])

	        input_=self.x_image

	        for i_layer in range(self.num_layers):
	            W = self.__weight_variable([self.filter_heigth,self.filter_width,input_channel,output_channel])
	            B = self.__bias_variable([output_channel])

	            h = tf.nn.relu(self.__conv2d(input_, W) + B)
	            p = self.__max_pool_2x2(h)

	            input_ = p

	            self.W_conv.append(W)
	            self.b_conv.append(B)
	            input_channel = output_channel
	            if i_layer+1 < len(self.num_filters):
	                output_channel = int(self.num_filters[i_layer+1])
	            else:
	                #end of loop
	                pass

	        # Fully Connected Layer
	        # hard coded
	        W_fc = self.__weight_variable([7 * 7 * output_channel, 1024])
	        b_fc = self.__bias_variable([1024])

	        h_fc = tf.reshape(input_, [-1, 7 * 7 * output_channel])
	        p_fc = tf.nn.relu(tf.matmul(h_fc, W_fc) + b_fc)

	        self.keep_prob = tf.placeholder(tf.float32)
	        h_fc1_drop = tf.nn.dropout(p_fc,self.keep_prob)

	        W_fc2 = self.__weight_variable([1024, self.num_classes])
	        b_fc2 = self.__bias_variable([self.num_classes])

	        self.y_conv = tf.matmul(h_fc1_drop, W_fc2) + b_fc2
	        print(self.y_conv)

	        self.cross_entropy = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(labels=self.y_, logits=self.y_conv))
	        self.train_step = tf.train.AdamOptimizer(1e-4).minimize(self.cross_entropy)
	        self.correct_prediction = tf.equal(tf.argmax(self.y_conv, 1), tf.argmax(self.y_, 1))
	        self.accuracy = tf.reduce_mean(tf.cast(self.correct_prediction, tf.float32))

        self.session.run(tf.global_variables_initializer())

    def __accuracy(self,batch,step_num):
        with self.session.as_default():
        	train_accuracy=self.accuracy.eval(feed_dict={self.x: batch[0], self.y_: batch[1], self.keep_prob: 1.0})
        	print("step %d training accuracy %g" % (step_num,train_accuracy))

    def step(self,batch,step_num):
        with self.session.as_default():
        	self.train_step.run(feed_dict={self.x:batch[0],self.y_:batch[1],self.keep_prob:0.5})
        if step_num % 100 == 0:
            self.__accuracy(batch,step_num)

    def predict(self,x):
        return self.session.run(self.y_conv,feed_dict={self.x:x,self.keep_prob:0.5})

    def __weight_variable(self,shape):
      initial = tf.truncated_normal(shape, stddev=0.1)
      return tf.Variable(initial)

    def __bias_variable(self,shape):
        initial = tf.constant(0.1, shape=shape)
        return tf.Variable(initial)

    def __conv2d(self,x, W):
        return tf.nn.conv2d(x, W, strides=[1, 1, 1, 1], padding='SAME')

    def __max_pool_2x2(self,x):
        return tf.nn.max_pool(x, ksize=[1, 2, 2, 1],strides=[1, 2, 2, 1], padding='SAME')
