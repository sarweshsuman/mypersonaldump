from tensorflow.examples.tutorials.mnist import input_data

class Mnist:
    def __init__(self):
        self.mnist = input_data.read_data_sets('MNIST_data', one_hot=True)
