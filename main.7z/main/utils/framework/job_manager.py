from .job import Job
from .job_runner import JobRunner
from multiprocessing import Process,Pipe

class JobManager:
    def __init__(self,initialContext):
        self.__initialContext = initialContext
        self.__running_jobs={}   # 'JobName':<process object>
        self.__failed_jobs=[]
        self.__completed_jobs=[]
        #self.__jobs_to_start=[]
    # Static method to create jobdef
    def create_jobdef(self,platformMessage):
        jobName=platformMessage.get_app_name()
        eventType=platformMessage.get_event_type()
        jobdef=Job(jobName,eventType)
        components = platformMessage.get_components()
        operator=[]
        operand=[]
        for component in components:
            if components[component]['type'] == 'operator':
                operator.append(components[component])
            else:
                operand.append(components[component])
        for component in operator:
            print(component)
            jobdef.add_operator(component['name'], component)
        for component in operand:
            print(component)
            jobdef.add_operand(component['name'], component)
        print(jobdef)
        return jobdef
    def __start_job(self,jobdef):
        # This method will start the job
        parent_conn , child_conn = Pipe()
        p = Process(target=JobRunner.run_job,args=(jobdef,self.__initialContext,child_conn))
        p.start()
        self.__running_jobs[jobdef.job_name]=p
    def __stop_job(self,jobdef):
        jobName=jobdef.job_name
        if not jobName in self.__running_jobs:
            raise Exception("{} not found in running job queue ".format(jobName))
        else:
            p = self.__running_jobs[jobName]
            p.terminate()
    def __job_status(self,jobdef):
        jobName=jobdef.job_name
        if not jobName in self.__running_jobs:
            raise Exception("{} not found in running job queue ".format(jobName))
        else:
            p = self.__running_jobs[jobName]
            if p.is_alive() == True:
                return "Running"
            else:
                p.name = jobName
                del self.__running_jobs[jobName]
                if p.exitcode != 0:
                    self.__failed_jobs.append(p)
                    return "Failed"
                else:
                    self.__completed_jobs.append(p)
                    return "Success"
    def manage_job(self,jobdef):
        if jobdef.job_event_type == 'START':
            self.__start_job(jobdef)
        elif jobdef.job_event_type == 'STOP':
            self.__stop_job(jobdef)
        elif jobdef.job_event_type == 'STATUS':
            return self.__job_status(jobdef)
        else:
            raise Exception("event type {} not supported ".format(jobdef.job_event_type))
