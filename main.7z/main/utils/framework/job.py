
class Job:
    def __init__(self,jobName,eventType):
        self.__job_name = jobName
        self.__job_event_type = eventType
        self.operator_in_sequence=[]
        self.operator_definition={}

    def add_operator(self,component_name,component):
        index=component['serial_number'] # for sequence of the operators
        self.operator_in_sequence.insert(index,component_name)
        if component_name in self.operator_definition:
            # it already exists ? to train two models may be ?
            # not implemented right now
            pass
        else:
            self.operator_definition[component_name]={}
            self.operator_definition[component_name]['operator_package']=component['operator_package']
            self.operator_definition[component_name]['operator_class'] = component['operator_class']
            self.operator_definition[component_name]['parameters'] = {}
            #for param in component['parameters']:
            #    self.operator_definition[component_name]['parameters'][param]=component['parameters'][param]
            for param in component:
                if param in ('serial_number','operator_package','operator_class'):
                    continue
                else:
                    self.operator_definition[component_name]['parameters'][param] = component[param]
            self.operator_definition[component_name]['parameters']['operand']={}
    def get_operator_package(self,operator_name):
        return self.operator_definition[operator_name]['operator_package']
    def get_operator_class(self,operator_name):
        return self.operator_definition[operator_name]['operator_class']
    def get_operator_as_generator(self):
        for operator in self.operator_in_sequence:
            yield operator
    def get_operator_parameters(self,operator_name):
        return self.operator_definition[operator_name]['parameters']
    def add_operand(self,component_name,component):
        # it is an operand
        operator_name = component['operator']
        if operator_name in self.operator_definition:
            # okay, i already have details about this operator so i will add the operands details now,
            for param in component:
                if param == 'operator':
                    continue
                self.operator_definition[operator_name]['parameters']['operand'][param]=component[param]
        else:
            # operator is not present yet, issue, all operand should be linked with some operator --> automatically.
            raise Exception("Operand Found without any operator")
