import os
import logging

class LogManager:
    logging_filename='mlframework.log'
    def __init__(self,initialContext):
        self.logging_level=initialContext['logging/logging_level']
        self.logging_dir=initialContext['logging/logging_dir']
        if not os.path.exists(self.logging_dir):
            os.mkdir(self.logging_dir)
        elif os.path.isdir(self.logging_dir) == False:
            # logging dir is not directory
            self.logging_dir='/tmp'
        # by default INFO
        logging.basicConfig(filename=os.path.join(self.logging_dir,self.logging_filename), level=self.logging_level,format="%(asctime)s %(name)-12s %(levelname)-8s %(message)s")
        initialContext['framework/logger']=logging

