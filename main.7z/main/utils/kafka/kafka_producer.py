class KafkaProducerPy:
    def __init__(self,initialContext,message):
        self.__initialContext = initialContext
        self.__kafka_topic=self.__initialContext['kafka/topic_name']
		self.__kafka_bootstrapservers=self.__initialContext['kafka/bootstrapservers']
        self.__logger=self.__initialContext['framework/logger'].getLogger(__name__)
        self.__initialContext['framework/kafka/consumer']=self
        self.__logger.info("Initialized")
    def start(self):
        self.__logger.info("Send one message")

        # This is temporary has to be moved to other location
        # We cannot call directly job manager from here

		producer = KafkaProducer(bootstrap_servers=[self.__kafka_bootstrapservers])
		# Asynchronous by default
		future = producer.send(self.__kafka_topic,message)

		# Block for 'synchronous' sends
		try:
			record_metadata = future.get(timeout=10)
		except KafkaError:
			# Decide what to do if produce request failed...
			log.exception()
		pass

		# Successful result returns assigned partition and offset
		print (record_metadata.topic)
		print (record_metadata.partition)
		print (record_metadata.offset)
		
		# block until all async messages are sent
		producer.flush()

        #manager = self.__initialContext['framework/job_manager']
		