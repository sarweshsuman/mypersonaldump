from main.utils.kafka.kafka_consumer import SimpleKafkaConsumer
import os

class Kafka:
    def __init__(self,initContext):
        self.__initialContext = initContext
        self.__consumer = SimpleKafkaConsumer(os.path.join('operand',self.__initialContext[os.path.join('operator','class_name')],self.__class__.__name__),self.__initialContext)
        self.__batch_size = int(self.__initialContext[os.path.join('operand', self.__initialContext[os.path.join('operator', 'class_name')], self.__class__.__name__, 'batch_size')])
        print("Initialized Kafka data source")
        #self.__batch_size = self.__initialContext['']
    def get_generator(self):
        def kafka_batch():
            while True:
                yield self.__consumer.get_n_messages(self.__batch_size)
        return kafka_batch()