class Component(object):

    def __init__(self,componentName=None, inConfiguration={}, inDataFormat={},
                 outConfiguration={}, outDataFormat={}):
        self.__componentName = componentName
        self.__inConfiguration = inConfiguration
        self.__inDataFormat = inDataFormat
        self.__outConfiguration = outConfiguration
        self.__outDataFormat = outDataFormat

    @property
    def componentName(self):
        return self.__componentName or self.defaultComponentName()

    @componentName.setter
    def componentName(self, value):
        self.__componentName = value

    @property
    def inConfiguration(self):
        return self.__inConfiguration

    @inConfiguration.setter
    def inConfiguration(self, value):
        self.__inConfiguration = value

    @property
    def inDataFormat(self):
        return self.__inDataFormat or self.defaultInDataFormat()

    @inConfiguration.setter
    def inDataFormat(self, value):
        self.__inDataFormat = value

    @property
    def outConfiguration(self):
        return self.__outConfiguration or self.defaultOutConfiguration()

    @outConfiguration.setter
    def outConfiguration(self, value):
        self.__outConfiguration = value

    @property
    def outDataFormat(self):
        return self.__outDataFormat or self.defaultOutDataFormat()

    @outDataFormat.setter
    def outDataFormat(self, value):
        self.__outDataFormat = value 
    def __str__(self):
        return "Component Name:{} | InputConfiguration:{} ".format(self.__componentName,self.__inConfiguration)
