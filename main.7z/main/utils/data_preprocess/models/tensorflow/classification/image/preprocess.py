import numpy as np

class PreprocessKafkaMessages:
    x_and_y_separator='|'
    def __init__(self,initialContext):
        self.__initialContext = initialContext
        pass
    def preprocess(self,messages):
        # message being read from kafka topic is generally a list of strings so need to convert them to x and y
        # for specific to Image Classification it has to be converted to x -> 50x784 numpy.ndarray y-> 50x10 numpy.ndarray
        # x and y should be separated by pipe by default, else has to be mentioned in the property
        # once separated as x and y now x has to be converted to numpy.ndarray usually this will be command separated 1x784 message
        x=[]
        y=[]
        for message in messages:
            x1, y1 = message.split(self.x_and_y_separator)
            x1_array_of_pixels = x1.split(',')
            y1_array_of_classes = y1.split(',')
            x1_numpy_array = np.array(x1_array_of_pixels)
            y1_numpy_array = np.array(y1_array_of_classes)
            x.append(x1_numpy_array)
            y.append(y1_numpy_array)
