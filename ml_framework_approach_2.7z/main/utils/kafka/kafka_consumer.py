from main.utils.cdt.platform.message.message import PlatformMessage
from kafka import KafkaConsumer
import os

class SimpleKafkaConsumer:
    def __init__(self,domain,initialContext):
        """
        :param domain: denotes which configuration to pick up from initialContext, for example domain of framework means kafka consumer which will listen to the platform messages
        :param initialContext: dictionary which holds every possible thing going on in the framework.
        """
        self.__domain=domain
        self.__initialContext = initialContext
        print(self.__initialContext)
        self.__logger=self.__initialContext['framework/logger'].getLogger(__name__)

        self.__kafka_topic=self.__initialContext[os.path.join(self.__domain,'topic_name')]
        self.__kafka_bootstrapservers = self.__initialContext[os.path.join(self.__domain,'bootstrap_servers')]

        self.__logger.info("Received following parameters ( kafka_topic:{} , bootstrap_servers:{}  )".format(self.__kafka_topic,self.__kafka_bootstrapservers))

        self.__consumer = KafkaConsumer(bootstrap_servers=self.__kafka_bootstrapservers, auto_offset_reset='earliest')
        self.__consumer.subscribe([self.__kafka_topic])

        self.__logger.info("Subscribed to topic {}".format(self.__kafka_topic))

        self.__initialContext[os.path.join(self.__domain,'kafka/consumer')]=self

    def start(self):
        self.__logger.info("Starting Kafka")
        self.__logger.info("Listening to topic {}".format(self.__kafka_topic))

        manager = self.__initialContext['framework/job_manager']

        for kafka_message in self.__consumer:
            self.__logger.info("Received one message {}".format(kafka_message.value))
            #This message str is for testing kafka dataSource then train
            """
        message_str='''<?xml version="1.0" encoding="UTF-8"?>
<PlatformMessage>
<Message><TopicName>MLFramework</TopicName>
<Sender>Platform</Sender>
<EventType>START</EventType>
<AppName>ObjectClassifier</AppName>
<ComponentName>MLFramework</ComponentName>
<Domain>Aricent</Domain>
<ProcessId>10201010</ProcessId>
<JobType>STREAM</JobType>
</Message>
<ComponentConfig>
<Component><ComponentID>002</ComponentID><ComponentParent>MLFramework</ComponentParent>
<ComponentName>LocalFileReader</ComponentName>
<PropertyConfig><InputConfiguration>
<Property PropertyID="002"><PropertyName>category</PropertyName><PropertyValue>data_sources</PropertyValue></Property>
<Property PropertyID="001"><PropertyName>batch_size</PropertyName><PropertyValue>50</PropertyValue></Property>
<Property PropertyID="001"><PropertyName>file_name</PropertyName><PropertyValue>mnist_data_label.txt</PropertyValue></Property>
</InputConfiguration><InputDataFormat/><OutputConfiguration/><OutputDataFormat/></PropertyConfig></Component>
<Component><ComponentID>002</ComponentID><ComponentParent>MLFramework</ComponentParent>
<ComponentName>PreprocessImageClassification</ComponentName>
<PropertyConfig><InputConfiguration>
<Property PropertyID="002"><PropertyName>category</PropertyName><PropertyValue>data_preprocessing</PropertyValue></Property>
</InputConfiguration><InputDataFormat/><OutputConfiguration/><OutputDataFormat/></PropertyConfig></Component>
<Component><ComponentID>002</ComponentID><ComponentParent>MLFramework</ComponentParent>
<ComponentName>ImageClassification</ComponentName><PropertyConfig><InputConfiguration>
<Property PropertyID=""><PropertyName>category</PropertyName><PropertyValue>action</PropertyValue></Property>
<Property PropertyID=""><PropertyName>action</PropertyName><PropertyValue>Train</PropertyValue></Property>
<Property PropertyID=""><PropertyName>epochs</PropertyName><PropertyValue>120</PropertyValue></Property>
<Property PropertyID=""><PropertyName>image_height</PropertyName><PropertyValue>28</PropertyValue></Property>
<Property PropertyID=""><PropertyName>image_width</PropertyName><PropertyValue>28</PropertyValue></Property>
<Property PropertyID="002"><PropertyName>num_classes</PropertyName><PropertyValue>10</PropertyValue></Property>
<Property PropertyID=""><PropertyName>num_layers</PropertyName><PropertyValue>2</PropertyValue></Property>
<Property PropertyID="002"><PropertyName>filter_height</PropertyName><PropertyValue>5</PropertyValue></Property>
<Property PropertyID="002"><PropertyName>filter_width</PropertyName><PropertyValue>5</PropertyValue></Property>
<Property PropertyID="002"><PropertyName>num_filters_per_layer</PropertyName><PropertyValue>32,64</PropertyValue></Property>
</InputConfiguration><InputDataFormat/><OutputConfiguration/><OutputDataFormat/></PropertyConfig>
</Component></ComponentConfig></PlatformMessage>'''
"""
            message = PlatformMessage()
            message.parse_xml(kafka_message.value)

            # This is temporary has to be moved to other location
            # We cannot call directly job manager from here

            manager.manage_job(message.get_event_type(),message.get_components())
            self.__logger.info("Processed Message")
            self.__logger.info("Waiting for next Message")
    def get_n_messages(self,num_messages):
        print("Trying to get {} messages from kafka queue".format(num_messages))
        count=0
        kafka_messages=[]
        for message in self.__consumer:
            kafka_messages.append(message)
            count += 1
            if count == num_messages:
                break
        return kafka_messages
