import xml.etree.ElementTree as ET
from main.utils.cdt.platform.message.platform_message_component import Component
from main.utils.cdt.platform.message.platform_job_details import JobDetails

class PlatformMessage:
    def __init__(self):
        self.__job_details = JobDetails()

    def get_job_details(self):
        return self.__job_details

    def get_app_name(self):
        return self.__job_details.appName

    def get_event_type(self):
        return self.__job_details.eventType

    def get_components(self):
        components = self.__job_details.componentMap
        final_components={}
        for component in components:
            final_components[component.componentName]={}
            final_components[component.componentName]['name']=component.componentName.split(" ")[1]
            for prop in component.inConfiguration:
                final_components[component.componentName][prop]=component.inConfiguration[prop]
        final_components['jobname']=self.get_app_name()
        print(final_components)
        return final_components

    def parse_xml(self,xmlMessage):
        root = ET.fromstring(xmlMessage)

        #root = tree.getroot()  # This is used when working with ET.parse
        subElement = {}
        for child in root.getchildren():
            subElement[child.tag] = child
        msgElement = subElement.get('Message')
        compElement = subElement.get('ComponentConfig')
        msgConfig = {}
        for child in msgElement :
            msgConfig[child.tag] = child.text

        self.__job_details.topicName = msgElement.find("TopicName").text
        self.__job_details.sender = msgElement.find("Sender").text
        self.__job_details.eventType = msgElement.find("EventType").text
        self.__job_details.appName = msgElement.find("AppName").text
        self.__job_details.componentName = msgElement.find("ComponentName").text
        self.__job_details.domain = msgElement.find("Domain").text
        self.__job_details.processId = msgElement.find("ProcessId").text

        compList = []
        compParams = {}
        for co in compElement:
            compList.append(co)

        # Create a Map <ComponentName, ComponentTree>
        for component in compList:
            compParams[component.find("ComponentName").text] = component

        propMap = {}
        InDataFormatMap = {}
        outConfMap = {}
        outDataFormatMap = {}
        for key in compParams.keys():
            component = compParams.get(key)
            prop = component.find("PropertyConfig")
            config = {}
            inDataFormatConf = {}
            outConf = {}
            outDataFormatConf = {}
            for child in prop:
                for props in child:
                    valueTag = None
                    nameTag = None
                    for value in props.findall('PropertyValue'):
                        valueTag = value.text
                    for name in props.findall('PropertyName'):
                        nameTag = name.text
                    if "InputConfiguration"==str(child.tag):
                        config[nameTag] = valueTag
                    elif "InputDataFormat"==str(child.tag):
                        inDataFormatConf[nameTag] = valueTag
                    elif "OutputConfiguration"==str(child.tag):
                        outConf[nameTag] = valueTag
                    elif "OutputDataFormat"==str(child.tag):
                        outDataFormatConf[nameTag] = valueTag
            propMap[key] = config
            obj = Component()
            obj.componentName = key
            obj.inConfiguration = config;
            obj.inDataFormat = inDataFormatConf;
            obj.outConfiguration = outConf;
            obj.outDataFormat = outDataFormatConf;
            self.__job_details.componentMap.add(obj)
        print(self.__job_details.componentMap)

if __name__ == '__main__':
        message = PlatformMessage()
        message.parse_xml("".join(open('platform_message.xml').readlines()))
        message.get_components()
