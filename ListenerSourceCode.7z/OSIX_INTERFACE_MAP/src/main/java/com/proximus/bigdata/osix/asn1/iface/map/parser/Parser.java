package com.proximus.bigdata.osix.asn1.iface.map.parser;

import java.io.IOException;
import com.proximus.bigdata.osix.BaseParser;

import com.proximus.bigdata.osix.OSIXLDSRecord;

import java.io.InputStream;
import java.util.Properties;

import com.proximus.bigdata.osix.asn1.iface.map.MAP_DATA;
import com.proximus.bigdata.osix.asn1.iface.map.TCAP_PARAM_DATA;
import com.proximus.bigdata.osix.asn1.iface.map.SCCP_DATA;
import com.proximus.bigdata.util.AuxDecoder;

import java.util.Map;

import org.openmuc.jasn1.ber.BerIdentifier;
import org.openmuc.jasn1.ber.BerLength;
import org.openmuc.jasn1.ber.types.*;


public class Parser extends BaseParser {

	@Override
	public void process(InputStream is, Map<String,String> extraparams) throws IOException {
	
		OSIXLDSRecord oix = new OSIXLDSRecord(this.splitrecord);
		oix.SOURCE_IP = this._props.getProperty("source.ip", "0.0.0.0");
		
		oix.INTERFACE_TYPE = this.interface_type;
		
		oix.FIRST_CELL = -1L;
		
		boolean cc = true;
				
		/*
		String r_version = "0.9";
		Long r_id = 0L;
		Long r_xdr_size = 0L;
	    String r_interface_type = this.interface_type;
	    Date r_timestamp = new Date();

		String r_IMSI = null;
		String r_IMEI = null;
		Long r_LAC = null;
		Long r_RAC = null;
		Long r_CELL = null;
		String r_transaction_type = null;
		String r_transaction_subtype = null;
		Date r_attachaccept = null;
		Date r_attachreject = null;
		Boolean r_transaction_subtype_succ = null;
		*/
		
		if (extraparams != null && extraparams.containsKey("process_sequence_number")) {
			String r_process_sequence_number = extraparams.get("process_sequence_number");
			try {
				oix.PROCESS_SEQUENCE_NUMBER = Long.parseLong(r_process_sequence_number);
			}
			catch (Exception e) {
				oix.PROCESS_SEQUENCE_NUMBER = -1L;
			}
		}
		
		BerIdentifier berid = null; 
		try {
			while (cc) {
			  berid = new BerIdentifier();
			  berid.decode(is);
			  if (this.debug) {
				  System.out.println("found a map tagnumber " + berid.tagNumber);
			  }
			  BerLength blen = null; 
			  //new BerLength(); blen.decode(is);
			 // System.out.println("the length = " + blen.val);
			  
			 			  
			 // seizureTime    [0]  Timestamp,
			 // stopTime       [1]  Timestamp,
			 // octetsSent     [2]  INTEGER,
			 // octetsReceived [3]  INTEGER,
			 // msusSent       [4]  INTEGER,
			 // msusReceived   [5]  INTEGER,
			 // status         [6]  ENUMERATED{normal(0), setup(1), timeout(3), abort(4), begin(5)},
			 // mtp3Data       [7]  MTP3-DATA,
			 // sccpData       [8]  SCCP-DATA,
			 // mapData        [9]  MAP-DATA,
			 // linkStatistics [10] Link-Statistics OPTIONAL, 
			 // linkDataList   [11] LinkDataList OPTIONAL

			  
			  switch (berid.tagNumber) {
			  	 case  0: // seizeureTime
			  		 //blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 BerOctetString bs = new BerOctetString();
			  		 bs.decode(is,false);
			  		 oix.STARTTIME = AuxDecoder.decodeDate(bs.octetString);
			  		 break;
			  	 case 1: // stopTime
			  		blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		break;
			  	 case 2: //octetsSent
				  	blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  	break; 
			  	 case 3: // octetsReceived
				  	blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  	break; 
			  	 case 4: // msusSent
				  	blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  	break; 
			  	 case 5: // msusReceived
				  	blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  	break;
			  	 case 6: // status
				  	blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  	break;
			  	 case 7: // mtpdData
				  	blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  	break;
			  	 case 8: // sccpData
				  	//blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				    SCCP_DATA sccp = new SCCP_DATA();
				    sccp.decode(is,false);
				    BerOctetString beo = sccp.origGlobalTitle;
				    
				    oix.FIRST_CELL = Long.parseLong(AuxDecoder.decodeTBCD(beo.octetString));
				  	break;
			  	 case 9: //mapdata
				  	//blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  	MAP_DATA md = new MAP_DATA();
				  	
				  	md.decode(is, false);
				  	TCAP_PARAM_DATA tpd = md.tcapData;
				  	if (tpd.firstOpcode != null) {
				  		switch ((int) tpd.firstOpcode.val) {
				  			case 2:
				  				oix.TRANSACTION_TYPE = "UpDateLocation";
				  				break;
				  			case 3:
				  				oix.TRANSACTION_TYPE = "CancelLocation";
				  				break;
				  			default:
				  				oix.TRANSACTION_TYPE = "UNKNOWN (" + (int) tpd.firstOpcode.val + ")";
				  				break;
				  		}
				  	}
				  	oix.ERROR_CODE = tpd.errorcode != null ? tpd.errorcode.val:null;
				  	
				  	if (md.imsi != null) {
				  		oix.IMSI = AuxDecoder.decodeTBCD(md.imsi.octetString);
				  	}
				  	break;
			  	 default:
			  		blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		break;
			  }
			  		 	
			} // end of loop
		 		
		}// this should be end of try ?
		catch (IOException ee) {
			cc = false;
			
			if (berid.tagNumber == -1) {
				if (this.serializer != null) {
					this.serializer.serialize(oix);
				}
			}
			else {
				System.out.println("got ioexception in parse MAP record: " + ee.getMessage());
				this.errorcount++;
			}
		}	
		finally {
			this.parsecount++;
		}
	}
	
	public Parser (Properties props) {
		super("MAP_V11",props);	
	}
}
