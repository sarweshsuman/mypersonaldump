package com.proximus.bigdata.osix.stormtopology;

import java.io.IOException;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.storm.hdfs.common.rotation.RotationAction;

import java.util.Properties;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.data.Stat;

public class ZookeeperMarkerRotationAction implements RotationAction {

	private Properties _props;
	private boolean _active;
	
	private String zkroot = null;
	
	public ZookeeperMarkerRotationAction() {
		// TODO Auto-generated constructor stub
		this._props = null;
		this._active = false;
	}
	
	public ZookeeperMarkerRotationAction(Properties props) {
		// TODO: To be completed
		this._props  = (Properties) props.clone();
		// the following should only be set if all the required parameters can be found in the properties file
		this.zkroot = this._props.getProperty("hdfs.zookeeper.filerotationmonitor.root", "/osix_kafka/hdfs/files");
		this._active = true;
	}

	@Override
	public void execute(FileSystem arg0, Path arg1) throws IOException {
		// TODO Auto-generated method stub
        System.out.println("ZookeeperMarkerRotationAction has been called for FS " + arg0.toString() + " path " + arg1.toString());
        
        // the first argument is a handle to the filesystem
        // the second argument is the full path to the file that was just closed, and that is ready for processing
        
        // we need to make an entry
        
	}
}
