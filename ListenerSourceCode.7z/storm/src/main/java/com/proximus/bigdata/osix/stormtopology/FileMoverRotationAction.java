package com.proximus.bigdata.osix.stormtopology;

import java.io.IOException;


import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.FileUtil;
import org.apache.storm.hdfs.common.rotation.RotationAction;

import java.util.Properties;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.KeeperException;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.data.Stat;

public class FileMoverRotationAction implements RotationAction {

	private Properties _props;
	private String tgtdir;
	private String builddir;
	private boolean _active;
	
	private String zkroot = null;
	
	public FileMoverRotationAction() {
		// TODO Auto-generated constructor stub
		this._props = null;
		this._active = false;
		this.tgtdir = null;
		this.builddir = null;
	}
	
	public FileMoverRotationAction(Properties props) {
		// TODO: To be completed
		this._props  = (Properties) props.clone();
		
		// the following should only be set if all the required parameters can be found in the properties file
		//this.zkroot = this._props.getProperty("hdfs.zookeeper.filerotationmonitor.root", "/osix_kafka/hdfs/files");
		this._active = true;
		this.builddir = null;
		this.tgtdir = null;
		if (props.containsKey("hdfs.build.path") && props.containsKey("hdfs.save.path")) {
			this.builddir = props.getProperty("hdfs.build.path");
			this.tgtdir = props.getProperty("hdfs.save.path");
		}
		if (this.builddir != null && this.tgtdir != null && this.builddir.equals(this.tgtdir)) {
			this.builddir = null;
			this.tgtdir = null;
		}
	}

	@Override
	public void execute(FileSystem fs, Path pth) throws IOException {
		// TODO Auto-generated method stub
		//System.out.println("FileMoverRotationAction has been called for FS " + fs.toString() + " path " + pth.toString());
		if (this.builddir != null) {
       
          Path newpath = new Path(new Path(this.tgtdir), new Path(pth.getName()));
          //System.out.println("I should be moving file " + pth + " to " + newpath);
          
          fs.rename(pth,newpath);
		}
		else {
			//System.out.println("Nothing to do for FileMoverRotationAction");
		}
        
        // the first argument is a handle to the filesystem
        // the second argument is the full path to the file that was just closed, and that is ready for processing
        
        // we need to make an entry
        
	}
}
