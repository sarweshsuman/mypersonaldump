package com.proximus;

import static org.junit.Assert.*;

        import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.serde2.io.DateWritable;
import org.junit.Before;
        import org.junit.Test;
        import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
        import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;


        import org.apache.hadoop.hive.ql.udf.generic.GenericUDF.DeferredJavaObject;
        import org.apache.hadoop.hive.ql.udf.generic.GenericUDF.DeferredObject;
        import org.apache.hadoop.io.IntWritable;
        import org.apache.hadoop.hive.serde2.io.TimestampWritable;

import java.sql.Date;
import java.sql.Timestamp;

        import org.apache.hadoop.io.Text;

        import com.proximus.*;

public class MapImsiUDTFTest {
    MapImsiUDTF function_test = new MapImsiUDTF();
    org.apache.hadoop.hive.ql.udf.generic.Collector collect;

    @Before
    public void setUp() throws Exception {
        //

    }

    @Test
    public void test() {
        try {
            ObjectInspector strImsi = PrimitiveObjectInspectorFactory.javaIntObjectInspector;
            ObjectInspector strNetworkEventTs = PrimitiveObjectInspectorFactory.javaTimestampObjectInspector;
            ObjectInspector strCell = PrimitiveObjectInspectorFactory.javaIntObjectInspector;
            ObjectInspector strInterfaceType = PrimitiveObjectInspectorFactory.javaStringObjectInspector;
            ObjectInspector strTransactionType = PrimitiveObjectInspectorFactory.javaStringObjectInspector;
            ObjectInspector strTransactionSubtype = PrimitiveObjectInspectorFactory.javaStringObjectInspector;

            ObjectInspector[] args = {strImsi,strNetworkEventTs,strCell,strInterfaceType,strTransactionType,strTransactionSubtype};

            function_test.initialize(args);

            DeferredObject valueObj1 = new DeferredJavaObject(new IntWritable(new Integer("20601")));
            DeferredObject valueObj3 = new DeferredJavaObject(new Text("4025858"));
            DeferredObject valueObj4 = new DeferredJavaObject(new Text("S1_V5"));
            DeferredObject valueObj5 = new DeferredJavaObject(new Text("LU"));
            DeferredObject valueObj6 = new DeferredJavaObject(new Text("NORMAL"));

            Object[] args1 = {101, new Timestamp(114,12,30,0,0,0,3),4025858,"S1_V5","LU","NORMAL"};
            //collect.collect((args1));
            //function_test.process(args1);


            //isEquals("",function_test.process(args1));


        } catch (HiveException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}

