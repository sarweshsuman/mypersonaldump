import sys
from datetime import datetime, date, timedelta
import fileinput

last_imsi=None;
last_tacs=None;
last_start_network_event_ts=None;
last_stop_network_event_ts=None;
last_event_date=None;
last_missing_flag=None;
prv_timestamp=None;
last_tacs_mp_longitude=None;
last_tacs_mp_latitude=None;
last_tacs_mp_postcode=None;
last_flag_record_start=0;
last_flag_record_end=0;

def CalculateTac(tacs,interfacetype):
    """If the interface type is non BE, indicated by start word MAP, the tac is supplied with the keyword ABROAD to indicate non BE country
    Keyword arguments:
    tacs            -- the TACS value
    interfacetype   -- Interface type supplied by OSIX.
    """
    if interfacetype[0:3] == "MAP":
        return "ABROAD"
    else:
        return tacs

def MissingTacFlag(s_tacs,interfacetype):
    """Checks if the TACS value is missing for records which are not from ABOARD. Flag is either 0 (not missing) or 1
    Keyword arguments:
    s_tacs          -- the TACS value
    interfacetype   -- Interface type supplied by OSIX.
    """
    if  s_tacs=='\N' and interfacetype[0:3]<> "MAP":
        return "1"
    else:
        return "0"

def CarryOverRec(p_start_time, p_end_time):
    """Determines by substracting end time from start time if the record is crossing a day. if crossed 1 is returned else 0
    Keyword arguments:
    p_start_time   -- Start time, must start with following format YYYY-MM-DD
    p_end_time     -- End time, must start with following format YYYY-MM-DD
    """
    l_start_dt=datetime.strptime(p_start_time[0:10], '%Y-%m-%d').date()
    l_end_dt=datetime.strptime(p_end_time[0:10], '%Y-%m-%d').date()
    delta = l_end_dt - l_start_dt
    if delta.days > 0:
        return 1
    else:
        return 0

def calc_window(p_imsi, p_network_event_ts,p_tacs,p_tacs_cellref_file, p_event_date, p_interface_type,p_tacs_mp_longitude,p_tacs_mp_latitude,p_tacs_mp_postcode):
    """Creates an aggregatation per imsi per TACS. As long as an IMSI stays on the same TACS only the end date is changed
    Keyword arguments:
    p_imsi                  -- Imsi
    p_network_event_ts      -- Event timestamp when imsi was seen on TACS
    p_tacs                  -- TACS
    p_tacs_cellref_file     -- CI value out of cell ref
    p_event_date            -- Date of the event in format YYYY-MM-DD
    p_interface_type        -- OSIX interface type
    p_tacs_mp_longitude     -- TACS Longitude
    p_tacs_mp_latitude      -- TACS Latitude
    p_tacs_mp_postcode      -- Zip code where TACS is located
    """
    global last_imsi;
    global last_tacs;
    global last_start_network_event_ts;
    global last_stop_network_event_ts;
    global last_event_date;
    global last_missing_flag;
    global prv_timestamp;
    global last_tacs_mp_longitude;
    global last_tacs_mp_latitude;
    global last_tacs_mp_postcode;
    global last_flag_record_start;
    global last_flag_record_end;
    #
    # Switch of imsi. Output previous record and re-initialize records
    #
    if last_imsi and p_imsi!=last_imsi:
        last_flag_record_end=1
        print"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s" % (last_imsi,last_tacs,last_start_network_event_ts,last_stop_network_event_ts, last_event_date,last_missing_flag,last_tacs_mp_longitude,last_tacs_mp_latitude,last_tacs_mp_postcode,last_flag_record_start,last_flag_record_end);
        last_imsi=p_imsi;
        last_event_date=p_event_date;
        last_start_network_event_ts=p_network_event_ts;
        last_stop_network_event_ts=p_network_event_ts;
        last_tacs=CalculateTac(p_tacs,p_interface_type)
        last_missing_flag=MissingTacFlag(p_tacs_cellref_file,p_interface_type);
        prv_timestamp=None;
        last_tacs_mp_longitude=p_tacs_mp_longitude;
        last_tacs_mp_latitude=p_tacs_mp_latitude;
        last_tacs_mp_postcode=p_tacs_mp_postcode;
        last_flag_record_start=1
        last_flag_record_end=0
    else:
        #here imsi is equal or start of new record, so we only need to change stop date
        if CalculateTac(p_tacs,p_interface_type)==last_tacs:
            last_stop_network_event_ts=p_network_event_ts;
            last_imsi=p_imsi;
            last_event_date=p_event_date;
            last_stop_network_event_ts=p_network_event_ts;
            last_tacs=CalculateTac(p_tacs,p_interface_type)
            last_missing_flag=MissingTacFlag(p_tacs_cellref_file,p_interface_type);
            last_tacs_mp_longitude=p_tacs_mp_longitude;
            last_tacs_mp_latitude=p_tacs_mp_latitude;
            last_tacs_mp_postcode=p_tacs_mp_postcode;
        else:
            if last_tacs==None:
                last_imsi=p_imsi;
                last_event_date=p_event_date;
                last_start_network_event_ts=p_network_event_ts;
                last_stop_network_event_ts=p_network_event_ts;
                last_tacs=CalculateTac(p_tacs,p_interface_type);
                last_missing_flag=MissingTacFlag(p_tacs_cellref_file,p_interface_type);
                last_tacs_mp_longitude=p_tacs_mp_longitude;
                last_tacs_mp_latitude=p_tacs_mp_latitude;
                last_tacs_mp_postcode=p_tacs_mp_postcode;
                last_flag_record_start=1
                last_flag_record_end=0
            else:
                print"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s" % (last_imsi,last_tacs,last_start_network_event_ts,last_stop_network_event_ts, last_event_date,last_missing_flag,last_tacs_mp_longitude,last_tacs_mp_latitude,last_tacs_mp_postcode,last_flag_record_start,last_flag_record_end);
                last_imsi=p_imsi;
                last_event_date=p_event_date;
                last_start_network_event_ts=p_network_event_ts;
                last_stop_network_event_ts=p_network_event_ts;
                last_tacs=CalculateTac(p_tacs,p_interface_type);
                last_missing_flag=MissingTacFlag(p_tacs_cellref_file,p_interface_type);
                last_tacs_mp_longitude=p_tacs_mp_longitude;
                last_tacs_mp_latitude=p_tacs_mp_latitude;
                last_tacs_mp_postcode=p_tacs_mp_postcode;
                last_flag_record_start=0
                last_flag_record_end=0

for line in sys.stdin:
   (imsi,network_event_ts,tacs,tacs_cellref_file,event_date,interface_type,tacs_mp_longitude,tacs_mp_latitude,tacs_mp_postcode) = line.strip().split("\t")
   calc_window(imsi,network_event_ts,tacs,tacs_cellref_file,event_date,interface_type,tacs_mp_longitude,tacs_mp_latitude,tacs_mp_postcode);
if last_imsi:
    last_flag_record_end=1
    print"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s" % (last_imsi,last_tacs,last_start_network_event_ts,last_stop_network_event_ts, last_event_date,last_missing_flag,last_tacs_mp_longitude,last_tacs_mp_latitude,last_tacs_mp_postcode,last_flag_record_start,last_flag_record_end);
