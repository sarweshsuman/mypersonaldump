import sys
import hashlib
import time


def HashKey(strImsi):
    """Creates a hashing for a given imsi. First 5 characters of the original string are maintained and added to the hash
    Keyword arguments:
    strImsi     -- the ismi we want to hash. First 5 original chars are mainted
    """
    hash_object = hashlib.sha512(strImsi+time.strftime("%H:%M:%S")).hexdigest()
    return hash_object

def format_oracle_rec(imsi,event_date, tacs,zipcode,event_time_range,country):
    mcc=imsi[0:3]
    mnc=imsi[3:5]
    #modification on 31*3 taken from C code
    if country.upper()=='BE':
        nbr_IMSI_NAT_processed=1
        nbr_IMSI_INAT_processed=0
    else:
        nbr_IMSI_NAT_processed=0
        nbr_IMSI_INAT_processed=1
    print "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s" % (mcc,mnc,imsi[::-1],event_date,tacs,zipcode,event_time_range,country)

for line in sys.stdin:
    (imsi,event_date, tacs,zipcode,event_time_range,country) = line.strip().split("\t")
    format_oracle_rec(imsi,event_date, tacs,zipcode,event_time_range,country)
