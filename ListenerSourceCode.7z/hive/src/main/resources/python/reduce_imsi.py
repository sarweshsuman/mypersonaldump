import sys
from datetime import datetime, date, timedelta
import fileinput
import hashlib

last_imsi=None
last_bucket=0
last_event_date=None
last_tacs=[]
last_event_ts=[]
last_zip=[]


def init_array():
    """ Initialize the different arrays with zero values
    Keyword arguments:
    """
    for i in range(1,97,1):
        #last_celltower.append(0)
        last_tacs.append('')
        last_event_ts.append('')
        last_zip.append('')

def clear_array():
    """Empties the existing arrays. Usually init_array is called afterwards
    Keyword arguments:

    """
    #del last_celltower[:]
    del last_tacs[:]
    del last_zip[:]
    del last_event_ts[:]

def DateParser(input_date):
    """ Checks for a given date string if the nanaseconds are presents. If not standard 000 nanoseconds are added
    Keyword arguments:
    input_date      -- the date in string format
    """
    if input_date.find(".") > 0:
        result = input_date
    else:
        result = input_date + ".000"
    return result

def HashKey(strImsi):
    """Creates a hashing for a given imsi. First 5 characters of the original string are maintained and added to the hash
    Keyword arguments:
    strImsi     -- the ismi we want to hash. First 5 original chars are mainted
    """
    hash_object = hashlib.sha512(strImsi).hexdigest()
    return strImsi[0:5]+hash_object

def FormatZeroValuesForward(pivot_list):
    """ For a given dictionary we scan forward and replace zeros by the previous non zero value. A string starting with 0 is kept with starting zero
    Keyword arguments:
    pivot_list  -- a dictionary list
    """
    for i in range(1, len(pivot_list)):
        if pivot_list[i]=='' and i <> 0:
            pivot_list[i] = pivot_list[i-1]
    return pivot_list

def CalculateTac(tacs,interfacetype):
    """If the interface type is non BE, indicated by start word MAP, the tac is supplied with the keyword ABROAD to indicate non BE country
    Keyword arguments:
    tacs            -- the TACS value
    interfacetype   -- Interface type supplied by OSIX.
    """
    if interfacetype[0:3] == "MAP":
        return "ABROAD"
    else:
        return tacs

def CalculatePostCode(postcode,interfacetype):
    """If the interface type is non BE, indicated by start word MAP, the postcode is supplied with the \N sign to indicate non BE country
	Should be null but because of the FormatZeroValuesForward this would pose an additional problem
    Keyword arguments:
    postcode        -- the postcode value
    interfacetype   -- Interface type supplied by OSIX.
    """
    if interfacetype[0:3] == "MAP":
        return "\N"
    else:
        return postcode        

#Check with business if this is needed. In document is stated that first position can be unknown => Not needed for now
def FormatZeroValuesBackward(celltower_fmt):
    for i in range(len(celltower_fmt)-1,-1,-1):
        #do not process last element as this should always be filled in with the forward
        if celltower_fmt[i]==0 and i <95:
            celltower_fmt[i]=celltower_fmt[i+1]
    return celltower_fmt

def calculate_last(imsi,bucket,event_date_input,interfacetype,tacs,zip):
    """ Pivot the imsi. As long as the same imsi value is streamed no output is done but rather appended to known values of the same imsi. For one imsi date is stored in several
    dictionaries

    Keyword arguments:
    imsi                -- the imsi of a person
    bucket              -- A value indicating in which 15 minute interval of a day the action occurred (max 96 buckets of 15 minutes)
    event_date_input    -- The original event date
    interfacetype       -- The interface type
    tacs                -- The TACS on which the call occurred
    zip                 -- postal code in which the TACS resides
    """
    global last_imsi
    global last_bucket
    global last_event_date
    global last_interfacetype
    global last_tacs
    global last_zip
    event_date=DateParser(event_date_input)
    if last_imsi and imsi!=last_imsi:
            print"%s\t%s\t%s\t%s\t%s" % (last_imsi,last_event_date[0:10], ','.join(FormatZeroValuesForward(last_tacs)),','.join(FormatZeroValuesForward(last_zip)),','.join(FormatZeroValuesForward(last_event_ts)))
            last_imsi= imsi
            last_event_date = event_date
            last_bucket = bucket
            last_interfacetype = interfacetype

            clear_array()
            init_array()
            #last_celltower.pop(int(bucket)-1)
            #last_celltower.insert(int(bucket)-1,celltower)
            last_tacs.pop(int(bucket)-1)
            last_tacs.insert(int(bucket)-1,CalculateTac(tacs,interfacetype))
            last_zip.pop(int(bucket)-1)
            last_zip.insert(int(bucket)-1,CalculatePostCode(zip,interfacetype))
            last_event_ts.pop(int(bucket)-1)
            last_event_ts.insert(int(bucket)-1,last_event_date[11:13]+last_event_date[14:16])
    else:
        #nu zit je in het stuk dat imsi gelijk is. Als de bucket gelijk is dan de hoogste event date nemen van de 2
        if int(bucket)==int(last_bucket):
            time_event_date=datetime.strptime(event_date,'%Y-%m-%d %H:%M:%S.%f')
            if last_event_date == None:
                last_imsi=imsi
                last_event_date=event_date
                #last_celltower.pop(int(bucket)-1)
                #last_celltower.insert(int(bucket)-1,celltower)
                last_tacs.pop(int(bucket)-1)
                last_tacs.insert(int(bucket)-1,CalculateTac(tacs,interfacetype))
                last_zip.pop(int(bucket)-1)
                last_zip.insert(int(bucket)-1,CalculatePostCode(zip,interfacetype))
                last_event_ts.pop(int(bucket)-1)
                last_event_ts.insert(int(bucket)-1,last_event_date[11:16])
                last_bucket = bucket
            else:
                last_time_event_date=datetime.strptime(last_event_date,'%Y-%m-%d %H:%M:%S.%f')
                if time_event_date>last_time_event_date:
                    last_imsi=imsi
                    last_event_date=event_date
                    #last_celltower.pop(int(bucket)-1)
                    #last_celltower.insert(int(bucket)-1,celltower)
                    last_tacs.pop(int(bucket)-1)
                    last_tacs.insert(int(bucket)-1,CalculateTac(tacs,interfacetype))
                    last_zip.pop(int(bucket)-1)
                    last_zip.insert(int(bucket)-1,CalculatePostCode(zip,interfacetype))
                    last_event_ts.pop(int(bucket)-1)
                    last_event_ts.insert(int(bucket)-1,last_event_date[11:13]+last_event_date[14:16])#last_event_ts.insert(int(bucket)-1,last_event_date[11:16])
                    last_bucket = bucket
        else:
            last_imsi=imsi
            last_event_date=event_date
            #last_celltower.pop(int(bucket)-1)
            #last_celltower.insert(int(bucket)-1,celltower)
            last_tacs.pop(int(bucket)-1)
            last_tacs.insert(int(bucket)-1,CalculateTac(tacs,interfacetype))
            last_zip.pop(int(bucket)-1)
            last_zip.insert(int(bucket)-1,CalculatePostCode(zip,interfacetype))
            last_bucket = bucket
            last_event_ts.pop(int(bucket)-1)
            last_event_ts.insert(int(bucket)-1,last_event_date[11:13]+last_event_date[14:16])
init_array()

#if __name__ == "__main__":
#     calculate_last('206018891828867','40','2015-06-26 09:52:56.559','MAP_V7','89STG2','3740');
#     calculate_last('206018891828868','40','2015-06-26 09:52:56.559','S1_V5','89STG2','3740');

for line in sys.stdin:
    (imsi,bucket, event_date,interfacetype,tacs,zipcode) = line.strip().split("\t")
    if tacs=='empty':
        tacs_tmp=''
    else:
        tacs_tmp=tacs
    if zipcode=='empty':
        zip_tmp=''
    else:
        zip_tmp=zipcode
    calculate_last(imsi,bucket, event_date,interfacetype,tacs_tmp,zip_tmp)
if last_imsi:
    #with open ('/tmp/test4.txt', 'a') as f: f.write ('Final if\n')
    print"%s\t%s\t%s\t%s\t%s" % (last_imsi,last_event_date[0:10], ','.join(FormatZeroValuesForward(last_tacs)),','.join(FormatZeroValuesForward(last_zip)),','.join(FormatZeroValuesForward(last_event_ts)))
