--****************************************************************
-- Script name: stg_query_java.sql
-- Creator    : id094223
-- creation_dt: 2015-03-01
-- description: Calculate buckets for network_event_ts
--****************************************************************
--****************************************************************
-- Modification user:
-- Modification dt:
-- Modification reason:
--****************************************************************
set hive.execution.engine=mr;
set yarn.scheduler.minimum-allocation-mb=10240;
set mapreduce.map.java.opts=-Xmx8192m;
add JAR hdfs:///p0_custom/custom/hive/lib/proximus-hive-1.0-SNAPSHOT-standalone.jar;
--****************************************************************
USE p0_stg_tec;
alter table p0_stg_tec.IMSI_BUCKET_CALCULATION drop partition (EVENT_DATE='${DATA_OUTPUT_MASK}');
INSERT INTO TABLE p0_stg_tec.IMSI_BUCKET_CALCULATION partition (EVENT_DATE='${DATA_OUTPUT_MASK}')
SELECT IMSI_TRANSFORMER(imsi,network_event_ts,cell,interface_type) as (imsi,bucket,network_event_ts,cell,interface_type)
FROM p0_lds_cdr.t_osix_location_l1
WHERE event_date='${DATA_OUTPUT_MASK}'
and (transaction_subtype_succ is null or transaction_subtype_succ = 'true');
