--****************************************************************
-- Script name: mllp.sql
-- Creator    : id094223
-- creation_dt: 2015-05-31
-- description: Determine most likely living place
--****************************************************************
--****************************************************************
-- Modification id:
-- Modification dt:
-- Modification reason:
--****************************************************************
set hive.execution.engine=tez;
set hive.vectorized.execution.enabled=false;
--****************************************************************
use p0_lds_cdr;
insert into table p0_lds_cdr.mllp_d_12 PARTITION (EVENT_DATE='${DATA_OUTPUT_MASK}')
SELECT DISTINCT imsi,first_zip,last_zip,first_weight,last_weight,first_days_zip,last_days_zip,total_days_imsi,total_weight_imsi
from(
select imsi,
first_value(zipcode) OVER (PARTITION BY imsi ORDER BY rank_imsi rows between unbounded preceding and unbounded following) as first_zip,
last_value(zipcode) OVER (PARTITION BY  imsi ORDER BY rank_imsi rows between unbounded preceding and unbounded following ) as last_zip,
first_value(sum_Weight) OVER (PARTITION BY imsi ORDER BY rank_imsi rows between unbounded preceding and unbounded following) as first_weight,
last_value(sum_Weight) OVER (PARTITION BY  imsi ORDER BY rank_imsi rows between unbounded preceding and unbounded following ) as last_weight,
first_value(days_by_zip) OVER (PARTITION BY imsi ORDER BY rank_imsi rows between unbounded preceding and unbounded following) as first_days_zip,
last_value(days_by_zip) OVER (PARTITION BY  imsi ORDER BY rank_imsi rows between unbounded preceding and unbounded following ) as last_days_zip,
total_days_imsi,
total_weight_imsi
from(
select imsi,zipcode,sum_Weight,rank_imsi,days_by_zip,total_days_imsi,total_weight_imsi
from(
select 
imsi,
zipcode,
sum_Weight,
rank() over (PARTITION BY imsi order by sum_Weight desc) rank_imsi,
sum(nr_days) over (partition by imsi,zipcode order by sum_Weight desc rows between unbounded preceding and unbounded following) days_by_zip, 
sum(nr_days) over (partition by imsi order by sum_Weight desc rows between unbounded preceding and unbounded following) total_days_imsi,
sum(sum_Weight) over (partition by imsi order by sum_Weight desc rows between unbounded preceding and unbounded following) total_weight_imsi
from(
select
imsi,
zipcode,
count(event_date) as nr_days,
sum(weight) as sum_Weight
from p0_lds_cdr.T_IMSI_MLLOP_D_L2
where event_date between date_sub('${DATA_OUTPUT_MASK}',${DAYS_WINDOWS}) and '${DATA_OUTPUT_MASK}'
and imsi is not null
group by imsi,zipcode
)v
DISTRIBUTE BY imsi SORT BY imsi,sum_Weight desc
) final_q
where rank_imsi <3
DISTRIBUTE BY imsi SORT BY rank_imsi
)y 
)z;
