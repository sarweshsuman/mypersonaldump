--****************************************************************
-- Script name: mllop_weight_1.sql
-- Creator    : id094223
-- creation_dt: 2015-05-15
-- description: Determine the mllop records with weight of 1
--****************************************************************
--****************************************************************
-- Modification id:
-- Modification dt:
-- Modification reason:
--****************************************************************
set hive.execution.engine=tez;
set hive.vectorized.execution.enabled=false;
--****************************************************************
use p0_stg_tec;
truncate table p0_stg_tec.MLLOP_WEIGHT_1_TEMP;
INSERT INTO TABLE p0_stg_tec.MLLOP_WEIGHT_1_TEMP
SELECT DISTINCT 
network_event_ts,
CASE WHEN substr(interface_type,1,3)='MAP' then 'ABROAD' else tacs end tacs,
imsi,
CASE WHEN substr(interface_type,1,3)='MAP' then 0 else zip end as zip,
weight
from (
select 
first_value(network_event_ts) OVER (PARTITION BY imsi ORDER BY network_event_ts DESC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) as network_event_ts,
first_value(v.tacs) OVER (PARTITION BY imsi ORDER BY network_event_ts DESC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) tacs,
first_value(interface_type) OVER (PARTITION BY imsi ORDER BY network_event_ts DESC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) as interface_type,
first_value(zip) OVER (PARTITION BY imsi ORDER BY network_event_ts DESC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) as zip,
imsi,
1 as weight
from
( 
select
network_event_ts,
clr.ci as cell_ci,
clr.TACS_MP_POSTCODE as zip,
interface_type,
imsi,
clr.tacs as tacs,
sic.bucket
from p0_stg_tec.imsi_bucket_calculation sic LEFT OUTER JOIN P0_REF_DATA.CELLREF clr ON (sic.cell=clr.ci)
WHERE sic.event_date = '${DATA_OUTPUT_MASK}'
and sic.bucket < 23 and sic.bucket >= 0
DISTRIBUTE BY imsi SORT BY imsi,network_event_ts desc
)v 
WHERE (v.cell_ci is not null or interface_type like 'MAP%')
) endresult;
