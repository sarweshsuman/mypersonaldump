--****************************************************************
-- Script name: final_query_java.sql.sql
-- Creator    : id094223
-- creation_dt: 2015-03-01
-- description: Imsi aggr for tacs per 15 minutes
--****************************************************************
--****************************************************************
-- Modification id:
-- Modification dt:
-- Modification reason:
--****************************************************************
set hive.execution.engine=tez;
set yarn.scheduler.minimum-allocation-mb=10240;
set mapreduce.map.java.opts=-Xmx10240m;
add file /tmp/reduce_imsi.py;
--****************************************************************
use p0_lds_cdr;
alter table p0_lds_cdr.t_imsi_tacs_pc_15min_l2 drop partition (EVENT_DATE='${DATA_OUTPUT_MASK}');
INSERT INTO TABLE p0_lds_cdr.t_imsi_tacs_pc_15min_l2 PARTITION (EVENT_DATE='${DATA_OUTPUT_MASK}')
SELECT TRANSFORM(cell_calc.imsi,cell_calc.bucket,cell_calc.network_event_ts,cell_calc.interface_type,nvl(cell_calc.tacs,'empty'),nvl(cell_calc.tacs_mp_postcode,'empty')) USING 'python reduce_imsi.py'
as imsi,event_dt,tacs,zipcode,event_ts
FROM (SELECT DISTINCT sic.imsi,sic.bucket,sic.network_event_ts,sic.cell,sic.interface_type,clr.tacs,clr.tacs_mp_postcode
FROM p0_stg_tec.imsi_bucket_calculation sic LEFT OUTER JOIN P0_REF_DATA.CELLREF clr ON (sic.cell=clr.ci)
WHERE sic.event_date='${DATA_OUTPUT_MASK}' DISTRIBUTE  BY imsi SORT BY imsi ASC) cell_calc;
