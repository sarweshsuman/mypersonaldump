--****************************************************************
-- Script name: origin_destination_ph2.sql
-- Creator    : id094223
-- creation_dt: 2015-08-10
-- description: Create staging for origin destination
--****************************************************************
--****************************************************************
-- Modification id:
-- Modification dt:
-- Modification reason:
--****************************************************************
set hive.execution.engine=mr;
add file /tmp/calculate_origin_destination.py;
--
-- The following 3 parameters allow the ORDER BY statement to run in parallel. 
-- The parameter hive.optimize.sampling.orderby.number is the most important one. Can not be too small or too high
--
set hive.optimize.sampling.orderby=true;
set hive.optimize.sampling.orderby.number=10000000;
set hive.optimize.sampling.orderby.percent=0.3f;
--****************************************************************
insert into table p0_stg_tec.ORIGIN_DESTINATION_PHASE_2 PARTITION (EVENT_DATE='${DATA_OUTPUT_MASK}')
select TRANSFORM (imsi, tacs,staying_time_tacs, start_time_tacs, end_time_tacs,tacs_mp_postcode, tacs_mp_longitude, tacs_mp_latitude,unique_id) USING 'python calculate_origin_destination.py' as 
imsi, orig_tacs,orig_last_time,orig_post_code,orig_longitude, orig_latitude, dest_tacs,dest_first_time, dest_post_code,dest_longitude, dest_latitude, gener_id, traject_ind, transit_first_time_tacs
FROM(
select imsi,tacs,staying_time_tacs, start_time_tacs,end_time_tacs,tacs_mp_postcode, tacs_mp_longitude, tacs_mp_latitude, reflect("java.util.UUID", "randomUUID") as unique_id
from p0_lds_cdr.STAYTIME_TACS_AGGR_FINAL
where event_date='${DATA_OUTPUT_MASK}'
ORDER BY imsi,start_time_tacs
)x;
