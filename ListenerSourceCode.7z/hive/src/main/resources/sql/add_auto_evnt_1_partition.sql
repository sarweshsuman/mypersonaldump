--****************************************************************
-- Script name: add_auto_event_1_partition.sql
-- Creator    : id094223
-- creation_dt: 2015-09-01
-- description: Since pig creates the folders, hive needs to be aware of the new partition
--****************************************************************
--****************************************************************
-- Modification id:
-- Modification dt:
-- Modification reason:
--****************************************************************
use p0_stg_tec;
msck repair table auto_event_step1;
