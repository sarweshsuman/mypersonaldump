--****************************************************************
-- Script name: mllop_d_l2.sql
-- Creator    : id094223
-- creation_dt: 2015-06-10
-- description: insert staging into most likely lodging place tbl
--****************************************************************
--****************************************************************
-- Modification id:
-- Modification dt:
-- Modification reason:
--****************************************************************
set hive.execution.engine=tez;
--****************************************************************
use p0_lds_cdr;
alter table p0_lds_cdr.T_IMSI_MLLOP_D_L2 drop partition (EVENT_DATE='${DATA_OUTPUT_MASK}');
insert into table p0_lds_cdr.T_IMSI_MLLOP_D_L2 PARTITION (EVENT_DATE='${DATA_OUTPUT_MASK}')
select 
cell as tacs,
imsi,
zipcode,
weight
from p0_stg_tec.MLLOP_WEIGHT_1_TEMP
union all
select 
cell as tacs,
imsi,
zipcode,
weight
from p0_stg_tec.mllop_weight_x_tmp;
