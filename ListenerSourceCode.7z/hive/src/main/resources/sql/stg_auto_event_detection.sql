--****************************************************************
-- Script name: stg_auto_event_detection.sql
-- Creator    : id094223
-- creation_dt: 2015-09-01
-- description: Calculates whether the hours between start and end are determined or intrapolated
--              Determined at 11 means that the record started at 10 and ended after 11 (cross hour)
--              Intrapolated means the record start and stop is in the same hour or in the coal_2_3H period
--****************************************************************
--****************************************************************
-- Modification id:
-- Modification dt:
-- Modification reason:
--****************************************************************
set hive.execution.engine=tez;
use p0_stg_tec;
--****************************************************************
--
--
alter table p0_stg_tec.AUTO_EVENT_DETECTION drop partition (EVENT_DATE='${DATA_OUTPUT_MASK}');
--
INSERT INTO TABLE p0_stg_tec.AUTO_EVENT_DETECTION PARTITION (EVENT_DATE='${DATA_OUTPUT_MASK}')
SELECT imsi,start_time_tacs,end_time_tacs,coal_1,coal_2,tacs,National_International,Intrapol_date,start_hour,
CASE WHEN time_hour_min between coal_1 and coal_2 then 'determined' else 'intrapolated' END
from(
select distinct imsi,start_time_tacs,end_time_tacs,coal_1,coal_2,coal_2_flag,tacs,National_International,Intrapol_date,z.start_hour,
CAST(CONCAT('${DATA_OUTPUT_MASK} ',CONCAT(z.start_hour,':00:00.0'))as timestamp) as time_hour_min
from(
select 
imsi,start_time_tacs,end_time_tacs,coal_1,coal_2,coal_2_flag,coal_2_3H,tacs,National_International,start_time_tacs_lead,
CASE WHEN start_time_tacs_lead < coal_2_3H and datediff(to_date(coal_2_3H),'${DATA_OUTPUT_MASK}') = 0 THEN start_time_tacs_lead 
WHEN start_time_tacs_lead > coal_2_3H and datediff(to_date(coal_2_3H),'${DATA_OUTPUT_MASK}') = 0 THEN coal_2_3H 
WHEN start_time_tacs_lead < coal_2_3H and datediff(to_date(coal_2_3H),'${DATA_OUTPUT_MASK}') > 0  THEN cast('${DATA_OUTPUT_MASK} 23:59:59' as timestamp)
WHEN datediff(to_date(coal_2_3H),'${DATA_OUTPUT_MASK}') > 0 THEN cast('${DATA_OUTPUT_MASK} 23:59:59' as timestamp) -- possible that start_time_tacs_lead is null
ELSE coal_2_3H
END Intrapol_date
from(
select 
imsi,start_time_tacs,end_time_tacs,coal_1,coal_2,coal_2_flag,tacs,
cast(from_unixtime(unix_timestamp(coal_2)+(3*60*60)) as timestamp) as coal_2_3H,
National_International,start_time_tacs_lead
from(
select imsi,
start_time_tacs,
end_time_tacs,
CASE WHEN datediff(to_date(start_time_tacs),to_date(prv_day_start_ts)) > 0 THEN coalesce(cast('${DATA_OUTPUT_MASK} 00:00:00' as timestamp), start_time_tacs) ELSE coalesce(prv_day_start_ts,start_time_tacs) END coal_1
,CASE WHEN datediff(to_date(next_day_end_ts),to_date(end_time_tacs)) > 0 THEN coalesce(cast('${DATA_OUTPUT_MASK} 23:59:59' as timestamp), end_time_tacs) ELSE coalesce(next_day_end_ts, end_time_tacs) END coal_2
,CASE WHEN datediff(to_date(next_day_end_ts),to_date(end_time_tacs)) > 0 THEN 'Y' ELSE 'N' END coal_2_flag
,tacs
,national_international
,start_time_tacs_lead
from p0_stg_tec.auto_event_step1
where event_date='${DATA_OUTPUT_MASK}'
)w
)x
)y,(select start_hour from p0_ref_data.DAILY_HOURS) z
WHERE (z.start_hour BETWEEN hour(coal_1) and hour(Intrapol_date))
)q;
