--****************************************************************
-- Script name: tacs_staytime_aggr_final_2.sql
-- Creator    : id094223
-- creation_dt: 2015-07-17
-- description: Determine most likely lodging place
--****************************************************************
--****************************************************************
-- Modification id:
-- Modification dt:
-- Modification reason:
--****************************************************************
set hive.execution.engine=tez;
set hive.vectorized.execution.enabled=false;
use p0_lds_cdr;
--
-- create view to determine the next_day_end_ts field. prv_day_start_ts should be taken from tacs_carry_over as it has been calculated on DATA_OUTPUT_MASK_PRV
--
CREATE OR REPLACE VIEW p0_stg_tec.stg_tacs_carry_prv
as
select sta2.imsi,
sta2.tacs,
sta2.start_time_tacs,
sta2.end_time_tacs,
unix_timestamp(sta2.end_time_tacs)-unix_timestamp(sta2.start_time_tacs) as staying_time_tacs ,
sta2.missingcellflag ,
sta2.prv_day_start_ts as prv_day_start_ts,
CASE WHEN sta2.tacs = sta3.tacs AND max(sta2.start_time_tacs) OVER (PARTITION BY sta2.imsi ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) = sta2.start_time_tacs THEN sta3.end_time_tacs else null END next_day_end_ts,
sta2.tacs_mp_longitude ,
sta2.tacs_mp_latitude ,
sta2.tacs_mp_postcode
from (select imsi,tacs,start_time_tacs,end_time_tacs,missingcellflag,tacs_mp_longitude,tacs_mp_latitude,tacs_mp_postcode,prv_day_start_ts
from p0_stg_tec.TACS_CARRY_OVER v where event_date='${DATA_OUTPUT_MASK_PRV}')sta2 LEFT OUTER JOIN (select imsi,tacs,start_time_tacs,end_time_tacs,missingcellflag,tacs_mp_longitude,tacs_mp_latitude,tacs_mp_postcode,flag_record_end,flag_record_start,event_date
from p0_stg_tec.STG_TACS_AGGR v2 where event_date='${DATA_OUTPUT_MASK}' and flag_record_start=1) sta3 ON (sta2.imsi=sta3.imsi);
--
-- insert data from the view into the final table
--
INSERT INTO TABLE p0_lds_cdr.STAYTIME_TACS_AGGR_FINAL PARTITION (EVENT_DATE='${DATA_OUTPUT_MASK_PRV}')
select imsi,
tacs,
start_time_tacs,
end_time_tacs,
staying_time_tacs,
missingcellflag,
next_day_end_ts,
prv_day_start_ts,
tacs_mp_longitude,
tacs_mp_latitude,
tacs_mp_postcode  from p0_stg_tec.stg_tacs_carry_prv;
--
-- create vw which holds the last records of data_output_mask. We calculate the prv_day_start_ts and store it into a temp table
--
CREATE OR REPLACE VIEW p0_stg_tec.stg_tacs_carry_cur
as
select sta3.imsi,
sta3.tacs,
sta3.start_time_tacs,
sta3.end_time_tacs,
unix_timestamp(sta3.end_time_tacs)-unix_timestamp(sta3.start_time_tacs) as staying_time_tacs ,
sta3.missingcellflag ,
CASE WHEN sta2.tacs = sta3.tacs THEN sta2.start_time_tacs else null END prv_day_start_ts,
null as next_day_end_ts,
sta3.tacs_mp_longitude ,
sta3.tacs_mp_latitude ,
sta3.tacs_mp_postcode
from (select imsi,tacs,start_time_tacs,end_time_tacs,missingcellflag,tacs_mp_longitude,tacs_mp_latitude,tacs_mp_postcode,flag_record_end
from p0_stg_tec.STG_TACS_AGGR v where event_date='${DATA_OUTPUT_MASK_PRV}' and flag_record_end = 1)sta2 RIGHT OUTER JOIN (select imsi,tacs,start_time_tacs,end_time_tacs,missingcellflag,tacs_mp_longitude,tacs_mp_latitude,tacs_mp_postcode,flag_record_end,flag_record_start,event_date
from p0_stg_tec.STG_TACS_AGGR v2 where event_date='${DATA_OUTPUT_MASK}' and flag_record_start=1) sta3 ON (sta2.imsi=sta3.imsi);
--
-- Record is stored in the tmp table.
--
INSERT INTO TABLE p0_stg_tec.TACS_CARRY_OVER PARTITION (EVENT_DATE='${DATA_OUTPUT_MASK}')
select imsi,
tacs,
start_time_tacs,
end_time_tacs,
staying_time_tacs,
missingcellflag,
prv_day_start_ts,
next_day_end_ts,
tacs_mp_longitude,
tacs_mp_latitude,
tacs_mp_postcode  from p0_stg_tec.stg_tacs_carry_cur;
--
-- drop the views so that with next run no problems can occur
--
drop view p0_stg_tec.stg_tacs_carry_prv;
drop view p0_stg_tec.stg_tacs_carry_cur;
