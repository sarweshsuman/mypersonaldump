--****************************************************************
-- Script name: tacs_transit_points_ins.sql
-- Creator    : id094223
-- creation_dt: 2015-08-10
-- description: Insert transit points
--****************************************************************
--****************************************************************
-- Modification id: id094223
-- Modification dt: 2015-08-13
-- Modification reason: adding compact statement
--****************************************************************
set hive.execution.engine=tez;
set hive.vectorized.execution.enabled=false;
--****************************************************************
INSERT INTO TABLE p0_lds_cdr.TACS_TRANSIT_POINTS PARTITION (EVENT_DATE='${DATA_OUTPUT_MASK}')
select 
imsi,
orig_tacs as tacs,
transit_first_time_tacs as first_time,
orig_last_time as last_time,
orig_post_code as post_code,
orig_longitude as longitude,
orig_latitude as latitude,
gener_id
from p0_stg_tec.ORIGIN_DESTINATION_PHASE_2
where event_date='${DATA_OUTPUT_MASK}'
and traject_ind='T';
--
alter table p0_lds_cdr.TACS_TRANSIT_POINTS partition (event_date='${DATA_OUTPUT_MASK}') compact 'major';
