--****************************************************************
-- Script name: mllop_weight_x.sql
-- Creator    : id094223
-- creation_dt: 2015-05-15
-- description: Determine the mllop records with weight of x
--****************************************************************
--****************************************************************
-- Modification id:
-- Modification dt:
-- Modification reason:
--****************************************************************
set hive.execution.engine=tez;
set hive.vectorized.execution.enabled=false;
--****************************************************************
use p0_stg_tec;
truncate table p0_stg_tec.mllop_weight_x_tmp;
insert into table p0_stg_tec.mllop_weight_x_tmp
SELECT distinct window_result.network_event_ts,
CASE WHEN substr(window_result.interface_type,1,3)='MAP' then 'ABROAD' else tacs end tacs,
window_result.imsi,
CASE WHEN substr(window_result.interface_type,1,3)='MAP' then 0 else window_result.zip end as zip,
CASE WHEN nvl(window_result.bucket,-1) = -1 then 0 else 1-((window_result.bucket-22)/(96-22)) END as weight
from
(
select tmp_res.network_event_ts,tmp_res.tacs,tmp_res.interface_type,tmp_res.zip,tmp_res.bucket,tmp_res.imsi, tx.imsi as altered_imsi
FROM
(
SELECT distinct
first_value(network_event_ts) OVER (PARTITION BY imsi ORDER BY network_event_ts ASC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) as network_event_ts,
first_value(v.tacs) OVER (PARTITION BY imsi ORDER BY network_event_ts ASC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) tacs,
first_value(interface_type) OVER (PARTITION BY imsi ORDER BY network_event_ts ASC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) as interface_type,
first_value(zip) OVER (PARTITION BY imsi ORDER BY network_event_ts ASC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) as zip,
first_value(bucket) OVER (PARTITION BY imsi ORDER BY network_event_ts ASC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) as bucket,
first_value(imsi) OVER (PARTITION BY imsi ORDER BY network_event_ts ASC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) as imsi
from
( 
select
network_event_ts,
clr.ci as cell_ci,
interface_type,
imsi,
bucket,
clr.TACS_MP_POSTCODE as zip,
clr.tacs as tacs
from p0_stg_tec.imsi_bucket_calculation sic LEFT OUTER JOIN P0_REF_DATA.CELLREF clr ON (sic.cell=clr.ci)
WHERE sic.event_date='${DATA_OUTPUT_MASK}' 
and sic.bucket > 22
DISTRIBUTE BY imsi SORT BY imsi,network_event_ts
)v 
WHERE (v.cell_ci is not null or interface_type like 'MAP%')
) tmp_res LEFT OUTER JOIN p0_stg_tec.MLLOP_WEIGHT_1_TEMP tx ON (tmp_res.imsi=tx.imsi)
)window_result
where window_result.altered_imsi is null;
