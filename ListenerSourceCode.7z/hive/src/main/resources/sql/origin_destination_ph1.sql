set hive.execution.engine=tez;
use p0_lds_cdr;
INSERT INTO TABLE p0_lds_cdr.origin_destination_ph1 PARTITION (EVENT_DATE='${DATA_OUTPUT_MASK}')
select imsi,
tacs as o_tacs,
end_time_tacs as o_last_time,
tacs_mp_longitude as o_longitude,
tacs_mp_latitude as o_latitude,
tacs_mp_postcode as o_postcode,
lead(tacs) OVER (PARTITION BY IMSI ORDER BY start_time_tacs rows between unbounded preceding and unbounded following) as d_tacs,
lead(start_time_tacs) OVER (PARTITION BY IMSI ORDER BY start_time_tacs rows between unbounded preceding and unbounded following) as d_first_time,
lead(tacs_mp_longitude) OVER (PARTITION BY IMSI ORDER BY start_time_tacs rows between unbounded preceding and unbounded following) as d_longitude,
lead(tacs_mp_latitude) OVER (PARTITION BY IMSI ORDER BY start_time_tacs rows between unbounded preceding and unbounded following) as d_latitude,
lead(tacs_mp_postcode) OVER (PARTITION BY IMSI ORDER BY start_time_tacs rows between unbounded preceding and unbounded following) as d_postcode
from(
select 
imsi,tacs,start_time_tacs,end_time_tacs,staying_time_tacs,tacs_mp_longitude,tacs_mp_latitude,tacs_mp_postcode
from p0_lds_cdr.STAYTIME_TACS_AGGR_FINAL stf
where stf.event_date='${DATA_OUTPUT_MASK}'
and stf.staying_time_tacs >= 3600
DISTRIBUTE BY imsi SORT BY start_time_tacs ASC)v;
