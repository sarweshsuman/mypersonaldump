--****************************************************************
-- Script name: export_query_osix_t15.sql
-- Creator    : id094223
-- creation_dt: 2015-05-01
-- description: Anonimyze the IMSI for export to oracle
--****************************************************************
--****************************************************************
-- Modification id: id094223
-- Modification dt: 2015-09-26
-- Modification reason: Table ora_export_record became partitioned
--****************************************************************
set hive.execution.engine=tez;
set hive.vectorized.execution.enabled=false;
add FILE hdfs:///p0_custom/custom/hive/python/osix_oracle_record.py;
--****************************************************************
USE p0_stg_tec;
alter table p0_stg_tec.ora_export_record drop partition (EVENT_DT='${DATA_OUTPUT_MASK}');
INSERT INTO TABLE p0_stg_tec.ora_export_record PARTITION (EVENT_DT='${DATA_OUTPUT_MASK}')
select mcc,mnc,hash_imsi,cast(CONCAT(event_date,' 00:00:00.000') as timestamp) as event_dt,tacs,zipcode,event_time_range,country
from(
select TRANSFORM(tit.imsi,network_event_dt,tacs,zipcode,event_timeranges,ire.country) using 'python osix_oracle_record.py' as mcc,mnc,hash_imsi,event_date,tacs,zipcode,event_time_range,country
from p0_lds_cdr.t_imsi_tacs_pc_15min_l2 tit JOIN p0_ref_data.imsi_ref ire on (ire.ref_date = '${IMSI_REF_MASK}')
where tit.event_date='${DATA_OUTPUT_MASK}'
and tit.imsi between ire.imsi_range_start and imsi_range_stop
and upper(ire.tourist_event_reporting)='TRUE'
)v;
