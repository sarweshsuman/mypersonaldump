--****************************************************************
-- Script name: mcc_mnc_unq_imsi.sql
-- Creator    : id094223
-- creation_dt: 2015-04-01
-- description: Count MCC MNC combinations
--****************************************************************
--****************************************************************
-- Modification id:
-- Modification dt:
-- Modification reason:
--****************************************************************
set hive.execution.engine=tez;
set hive.vectorized.execution.enabled=false;
set yarn.scheduler.minimum-allocation-mb=10240;
set mapreduce.map.java.opts=-Xmx10240m;
--****************************************************************
USE p0_lds_cdr;
alter table p0_lds_cdr.MMC_MNC_UNQ_IMSI drop partition (EVENT_DATE='${DATA_OUTPUT_MASK}');
INSERT INTO TABLE p0_lds_cdr.MMC_MNC_UNQ_IMSI PARTITION (EVENT_DATE='${DATA_OUTPUT_MASK}')
SELECT base_aantal,
       y.unq_imsi_exc_map,
       y.unq_imsi,
       y.mcc,
       y.mnc,
       y.tourist_event_reporting,
       y.country,
       y.network,
       y.event_date
  FROM (SELECT count(distinct(imsi)) as base_aantal,
               SUBSTR(imsi, 1, 3) as mcc,
               SUBSTR(imsi, 4, 2) as mnc
          from p0_lds_cdr.t_osix_location_l1
         where event_date = '${DATA_OUTPUT_MASK}'
         group by SUBSTR(imsi, 1, 3), SUBSTR(imsi, 4, 2)) complete,
       (SELECT Sum(counterexclmap) as unq_imsi_exc_map,
               COUNT(DISTINCT(imsi)) as unq_imsi,
               v.mcc,
               v.mnc,
               v.tourist_event_reporting,
               v.country,
               v.network,
               v.event_date
          FROM (SELECT counterexclmap,
                       imsi,
                       mcc,
                       mnc,
                       event_date,
                       ire.tourist_event_reporting,
                       ire.country,
                       ire.network
                  FROM (SELECT DISTINCT CASE
                                          WHEN interface_type not like 'MAP%' THEN
                                           1
                                          ELSE
                                           0
                                        END as counterexclmap,
                                        SUBSTR(imsi, 1, 3) as mcc,
                                        SUBSTR(imsi, 4, 2) as mnc,
                                        event_date,
                                        imsi
                          FROM p0_stg_tec.imsi_bucket_calculation
                         WHERE event_date = '${DATA_OUTPUT_MASK}') sic
                  JOIN p0_ref_data.imsi_ref ire
                    on (ire.ref_date = '${IMSI_REF_MASK}')
                 WHERE sic.imsi between ire.imsi_range_start and
                       ire.imsi_range_stop) v
         GROUP BY v.mcc,
                  v.mnc,
                  v.tourist_event_reporting,
                  v.country,
                  v.network,
                  v.event_date) y
 where complete.mcc = y.mcc
   and complete.mnc = y.mnc;
