--****************************************************************
-- Script name: tacs_staytime_aggr_stg.sql
-- Creator    : id094223
-- creation_dt: 2015-07-17
-- description: Calculate start and stop time per tacs per imsi
--****************************************************************
--****************************************************************
-- Modification id:
-- Modification dt:
-- Modification reason:
--****************************************************************
set hive.execution.engine=tez;
set hive.vectorized.execution.enabled=false;
add file /tmp/calculate_tacs_window.py;
 --****************************************************************
USE p0_stg_tec;
alter table p0_stg_tec.STG_TACS_AGGR drop partition (EVENT_DATE='${DATA_OUTPUT_MASK}');
INSERT INTO TABLE p0_stg_tec.STG_TACS_AGGR PARTITION (EVENT_DATE='${DATA_OUTPUT_MASK}')
select imsi,tacs_cell,start_time_tac,end_time_tac,missingcell_flag,tacs_mp_longitude,tacs_mp_latitude,tacs_mp_postcode,flag_record_start,flag_record_end
from(
select
TRANSFORM (cellref.imsi,cellref.network_event_ts,cellref.tacs_cell,cellref.tacs,cellref.event_date,cellref.interface_type,tacs_mp_longitude,tacs_mp_latitude,tacs_mp_postcode) USING 'python calculate_tacs_window.py' as
imsi,tacs_cell,start_time_tac,end_time_tac, event_date,missingcell_flag,tacs_mp_longitude,tacs_mp_latitude,tacs_mp_postcode,flag_record_start,flag_record_end
FROM
(
SELECT DISTINCT sic.imsi,sic.network_event_ts,COALESCE(clr.tacs,sic.cell) as tacs_cell,clr.tacs,sic.event_date,interface_type,tacs_mp_longitude,tacs_mp_latitude,tacs_mp_postcode
FROM p0_stg_tec.imsi_bucket_calculation sic LEFT OUTER JOIN P0_REF_DATA.CELLREF clr ON (sic.cell=clr.ci)
WHERE sic.event_date='${DATA_OUTPUT_MASK}'
DISTRIBUTE  BY imsi SORT BY imsi,network_event_ts ASC
) cellref
) final_q;
alter table p0_stg_tec.STG_TACS_AGGR partition (event_date='${DATA_OUTPUT_MASK}') compact 'major';
