--****************************************************************
-- Script name: tacs_staytime_aggr_final_1.sql
-- Creator    : id094223
-- creation_dt: 2015-07-17
-- description: Insert recs into final tbl which are not start or stop recs
--****************************************************************
--****************************************************************
-- Modification id:
-- Modification dt:
-- Modification reason:
--****************************************************************
set hive.execution.engine=tez;
set hive.vectorized.execution.enabled=false;
--****************************************************************
use p0_lds_cdr;
INSERT INTO TABLE p0_lds_cdr.STAYTIME_TACS_AGGR_FINAL PARTITION (EVENT_DATE='${DATA_OUTPUT_MASK}')
select imsi ,
tacs ,
start_time_tacs ,
end_time_tacs ,
unix_timestamp(end_time_tacs)-unix_timestamp(start_time_tacs) as staying_time_tacs ,
missingcellflag ,
null as next_day_end_ts,
null as prv_day_start_ts,
tacs_mp_longitude ,
tacs_mp_latitude ,
tacs_mp_postcode
from p0_stg_tec.STG_TACS_AGGR
where event_date='${DATA_OUTPUT_MASK}'
and flag_record_start=0 and flag_record_end=0;
