--****************************************************************
-- Script name: tacs_staytime_aggr_final_3.sql
-- Creator    : id094223
-- creation_dt: 2015-07-17
-- description: Insert records into tacs_carry_over staging
--****************************************************************
--****************************************************************
-- Modification id:
-- Modification dt:
-- Modification reason:
--****************************************************************
set hive.execution.engine=tez;
set hive.vectorized.execution.enabled=true;
--****************************************************************
use p0_stg_tec;
--
-- Determine the last record of the day but make sure it isn't already inserted. This can happen if a user has only 1 relevant record for a day.
-- This is accomplished by filter imsi_alt is null, which avoids doubles in tacs_carry_over
--
CREATE OR REPLACE VIEW p0_stg_tec.stg_tacs_vw_cur_1
as
select sta3.imsi,
sta3.tacs,
sta3.start_time_tacs,
sta3.end_time_tacs,
unix_timestamp(sta3.end_time_tacs)-unix_timestamp(sta3.start_time_tacs) as staying_time_tacs ,
sta3.missingcellflag ,
null as prv_day_start_ts,
null as next_day_end_ts,
sta3.tacs_mp_longitude ,
sta3.tacs_mp_latitude ,
sta3.tacs_mp_postcode
from (
select stx1.imsi,stx1.tacs,stx1.start_time_tacs,stx1.end_time_tacs,stx1.missingcellflag,stx1.tacs_mp_longitude,stx1.tacs_mp_latitude,stx1.tacs_mp_postcode,stx1.flag_record_end,stx1.flag_record_start,stx1.event_date,stx2.imsi_alt
from(select v2.imsi,v2.tacs,v2.start_time_tacs,v2.end_time_tacs,v2.missingcellflag,v2.tacs_mp_longitude,v2.tacs_mp_latitude,v2.tacs_mp_postcode,v2.flag_record_end,v2.flag_record_start,v2.event_date
from p0_stg_tec.STG_TACS_AGGR v2 where event_date='${DATA_OUTPUT_MASK}' and flag_record_end=1 )stx1 
LEFT OUTER JOIN (SELECT tc.IMSI as imsi_alt, tc.TACS, tc.start_time_tacs from p0_stg_tec.TACS_CARRY_OVER tc where tc.event_date='${DATA_OUTPUT_MASK}')stx2 on(stx1.imsi=stx2.imsi_alt and stx1.tacs=stx2.tacs and stx1.start_time_tacs=stx2.start_time_tacs)
) sta3
WHERE imsi_alt is null;
--
INSERT INTO TABLE p0_stg_tec.TACS_CARRY_OVER PARTITION (EVENT_DATE='${DATA_OUTPUT_MASK}')
select imsi,
tacs,
start_time_tacs,
end_time_tacs,
staying_time_tacs,
missingcellflag,
prv_day_start_ts,
next_day_end_ts,
tacs_mp_longitude,
tacs_mp_latitude,
tacs_mp_postcode from p0_stg_tec.stg_tacs_vw_cur_1;
--
drop view p0_stg_tec.stg_tacs_vw_cur_1;
