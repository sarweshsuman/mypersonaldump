--****************************************************************
-- Script name: mllp_partition_swap.sql
-- Creator    : id094223
-- creation_dt: 2015-05-31
-- description: Move the previous partition to the archive tabel
--****************************************************************
--****************************************************************
-- Modification id:
-- Modification dt:
-- Modification reason:
--****************************************************************
use p0_lds_cdr;
ALTER TABLE p0_lds_cdr.mllp_d_12_archive EXCHANGE PARTITION (EVENT_DATE='${DATA_OUTPUT_MASK}') WITH TABLE p0_lds_cdr.mllp_d_12;
