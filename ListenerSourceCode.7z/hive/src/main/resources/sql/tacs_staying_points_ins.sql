--****************************************************************
-- Script name: tacs_staying_points_ins.sql
-- Creator    : id094223
-- creation_dt: 2015-08-11
-- description: Insert staying points
--****************************************************************
--****************************************************************
-- Modification id: id 094223
-- Modification dt: 2015-08-13
-- Modification reason: add compact statement
--****************************************************************
set hive.execution.engine=tez;
set hive.vectorized.execution.enabled=false;
--****************************************************************
INSERT INTO TABLE p0_lds_cdr.TACS_STAYING_POINTS PARTITION (EVENT_DATE='${DATA_OUTPUT_MASK}')
select 
imsi,
orig_tacs,
orig_last_time,
orig_post_code,
orig_longitude,
orig_latitude,
dest_tacs,
dest_first_time,
dest_post_code,
dest_longitude,
dest_latitude,
gener_id
from p0_stg_tec.ORIGIN_DESTINATION_PHASE_2
where event_date='${DATA_OUTPUT_MASK}'
and traject_ind<>'T';
--
alter table p0_lds_cdr.TACS_STAYING_POINTS partition (event_date='${DATA_OUTPUT_MASK}') compact 'major';
