package com.proximus;

import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.hive.ql.udf.UDFType;
import org.apache.hadoop.io.LongWritable ;

@UDFType(deterministic = false,stateful = true)
public class IncrementId extends UDF {
	private static LongWritable id = new LongWritable();

	public IncrementId(){
		reset();
	}

	public LongWritable evaluate(){
		id.set(id.get()+1);
		return id;
	}

	public void reset(){
		this.id.set(0);
	}
}