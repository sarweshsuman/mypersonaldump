package com.proximus;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.PrimitiveObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.joda.time.DateTime;

public class MapImsiUDTF extends GenericUDTF {
    private PrimitiveObjectInspector strImsi = null;
    private PrimitiveObjectInspector strNetworkEventTs = null;
    private PrimitiveObjectInspector strCellCI = null;
    private PrimitiveObjectInspector strInterfaceType = null;
    private PrimitiveObjectInspector strTransactionType = null;
    private PrimitiveObjectInspector strTransactionSubtype = null;

    /**
     * @param args Standars arguments passed to the function
     */
    @Override
    public StructObjectInspector initialize(ObjectInspector[] args) throws UDFArgumentException {
        if (args.length != 6) {
            throw new UDFArgumentException("MapImsiUDTS() takes exactly 6 arguments");
        }
        strImsi=(PrimitiveObjectInspector) args[0];
        strNetworkEventTs=(PrimitiveObjectInspector) args[1];
        strCellCI=(PrimitiveObjectInspector) args[2];
        strInterfaceType=(PrimitiveObjectInspector) args[3];
        strTransactionType=(PrimitiveObjectInspector) args[4];
        strTransactionSubtype=(PrimitiveObjectInspector) args[5];


        List<String> fieldNames = new ArrayList<String>(6);
        List<ObjectInspector> fieldOIs = new ArrayList<ObjectInspector>(6);
        fieldNames.add("imsi");
        fieldNames.add("bucket");
        fieldNames.add("network_event_ts");
        fieldNames.add("cell");
        fieldNames.add("interface_type");
        fieldNames.add("transaction_type");
        fieldNames.add("transaction_subtype");

        fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
        fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
        fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
        fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
        fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
        fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
        fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
        return ObjectInspectorFactory.getStandardStructObjectInspector(fieldNames, fieldOIs);

    }
    /**
     * Process will calculate the bucket interval for each record. One day is divided in buckets of 15 minutes
     * @param record Object array containing the fields.
     */
    public void process(Object[] record) throws HiveException {
        DateTime dt = new DateTime();
        int year= dt.getYear();
        int month=dt.getMonthOfYear();
        int day=dt.getDayOfMonth();
        int bucket=-1;
        DateTime starttime_15;
        boolean bucket_found=false;

        DateTime starttime=new DateTime(dt.getYear(),dt.getMonthOfYear(),dt.getDayOfMonth(),0,0,0);
        java.sql.Timestamp netwrk_ts = (Timestamp) strNetworkEventTs.getPrimitiveJavaObject(record[1]);

        for (int i=1;i<97 && bucket_found==false;i++){
            starttime_15=starttime.plusMinutes(15);
            //java.sql.Timestamp cannot be cast to java.lang.String

            //System.out.println("Starting the cast of the "+(String) strNetworkEventTs.getPrimitiveJavaObject(record[1]));
            //final String processingtime= (String) strNetworkEventTs.getPrimitiveJavaObject(record[1]);
            DateTime ProcessTs = new DateTime (dt.getYear(),dt.getMonthOfYear(),dt.getDayOfMonth(),netwrk_ts.getHours(),netwrk_ts.getMinutes(),netwrk_ts.getSeconds(), netwrk_ts.getNanos()/1000000);
            if (starttime.getMillis() <= ProcessTs.getMillis() && (ProcessTs.getMillis() <	 starttime_15.getMillis())){
                bucket=i;
                bucket_found=true;

            }
            starttime=starttime.plusMinutes(15);
        }

        forward(new Object[] {strImsi.getPrimitiveJavaObject(record[0]),
        					  new String(Integer.toString(bucket)),
        					  strNetworkEventTs.getPrimitiveJavaObject(record[1]),
        					  strCellCI.getPrimitiveJavaObject(record[2]),
        					  strInterfaceType.getPrimitiveJavaObject(record[3]),
        					  strTransactionType.getPrimitiveJavaObject(record[4]),
        					  strTransactionSubtype.getPrimitiveJavaObject(record[5])
        					  });
    }

    @Override
    public void close() throws HiveException {
        // do nothing
    }
}