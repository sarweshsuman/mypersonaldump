package com.proximus.bigdata.osix.asn1.iface.s1ap.parser;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Map;

import org.openmuc.jasn1.ber.*;
import org.openmuc.jasn1.ber.types.*;

import com.proximus.bigdata.osix.BaseParser;
import com.proximus.bigdata.osix.OSIXLDSRecord;

//import com.proximus.bigdata.osix.asn1.iface.iups.parser.Parser.l_iucommondata;
//import com.proximus.bigdata.osix.asn1.iface.iups.IUPS_XDR_VERSION12;
import com.proximus.bigdata.osix.asn1.iface.s1ap.*;

import java.io.InputStream;
import java.util.Properties;

import com.proximus.bigdata.util.AuxDecoder;

public class Parser extends BaseParser {
	
	@Override
	public void process(InputStream is, Map<String,String> extraparams) throws IOException {
		//System.out.println("Doing the new parse in IUPS parser");
	    //IUPS_XDR_VERSION12 iups_xdr = new IUPS_XDR_VERSION12();
		// explicit or not ?
		// not ... since there does not seem to be a sequence envelope around it
		// we just have the elements
		//iups_xdr.decode(is,false);
		//System.out.println("Did the decide of iups_xdr");
		
		//System.out.println("Got some data: rejectCause" + iups_xdr.commonData.rejectCause);
		
		//return;
		/*
		String r_version = "0.9";
		Long r_id = 0L;
		Long r_xdr_size = 0L;
	    String r_interface_type = this.interface_type;
	    Date r_timestamp = new Date();
		String r_process_sequence_number = null;
		String r_IMSI = null;
		String r_IMEI = null;
		Long r_LAC = 0L;
		Long r_RAC = 0L;
		Long r_CELL = 0L;
		String r_transaction_type = null;
		String r_transaction_subtype = null;
		String r_transaction_subtype_succ = null;
		Date r_attachaccept = null;
		Date r_attachreject = null;
		String r_recordtype = null;
		boolean rb_attachaccept = false;
		boolean rb_attachreject = false;
		String firstTac = null;
		String lastTac = null;
	*/
		
		// we have to loop this until we found no more
		boolean cc = true;
		
		OSIXLDSRecord oix = new OSIXLDSRecord(this.splitrecord);
		oix.SOURCE_IP = this._props.getProperty("source.ip", "0.0.0.0");
		
		oix.INTERFACE_TYPE = this.interface_type;
		
		if (extraparams != null && extraparams.containsKey("process_sequence_number")) {
			String r_process_sequence_number = extraparams.get("process_sequence_number");
			try {
				oix.PROCESS_SEQUENCE_NUMBER = Long.parseLong(r_process_sequence_number);
			}
			catch (Exception e) {
				oix.PROCESS_SEQUENCE_NUMBER = -1L;
			}
		}
		
	
		 
			 //    r_id.toString()
			 //    ,r_interface_type
			 //	 ,r_xdr_size.toString()
			 //	 ,r_version
			 //	 ,r_process_sequence_number
			 //	 ,r_timestamp != null ? r_timestamp.toString():null
			 //	 ,r_IMSI
			 //	 ,r_IMEI
			 //	 ,r_LAC != null ? r_LAC.toString() : null
			 //	 ,r_RAC != null ? r_RAC.toString() : null
			 //	 ,r_CELL != null ? r_CELL.toString(): null
			 //	 ,r_transaction_type
			 //	 ,r_transaction_subtype
			 //	 ,null
			 //	 ,null
	    	 //  ); 
    		 // this.serializer.serialize(sl);
		
		
		BerIdentifier berid = null;
		try {
			while (cc) {
			  berid = new BerIdentifier();
			  berid.decode(is);
			  BerLength blen = null; 
			  //new BerLength(); blen.decode(is);
			 // System.out.println("the length = " + blen.val);
			   			  
			  //  startTime          [0]      Timestamp,
			  //   endTime            [1]      Timestamp,
			  //   recordType         [2]      S1apRecordType,
			  //   ueIdentity         [3]      UE-Identities OPTIONAL,
			  //   allUeTempId        [4]      AllUeTempId OPTIONAL,
			  //   firstCell          [5]      CellId OPTIONAL,
			  //   firstTai           [6]      TAI OPTIONAL,
			  //   taiList            [7]      TAIList OPTIONAL,
			  //   stmsi              [8]      S-TMSI OPTIONAL,
			  //   ueAmbr             [9]      AggregateMaximumBitrate OPTIONAL,
			  //   allPdnInfo         [10]     AllPdnInfo OPTIONAL,
			  //   allErabInfo        [11]     AllErabInfo OPTIONAL,
			  //   allEnbInfo         [12]     AllEnbInfo OPTIONAL,
			  //   mmeInformation     [13]     MmeInformation OPTIONAL,
			  //   attachInfo         [14]     AttachInformation OPTIONAL,
			  //   detachInfo         [15]     DetachInformation OPTIONAL,
			  //   serviceReqInfo     [16]     ServiceRequestInformation OPTIONAL,
			  //   extServReqInfo     [17]     ExtendedServiceRequestInformation OPTIONAL,
			  //   allTauInfo         [18]     AllTauInfo OPTIONAL,
			  //   pagingInfo         [19]     PagingInfo OPTIONAL,
			  //   allAuthInfo        [20]     AllAuthenticationInfo OPTIONAL,
			  //   securityModeInfo   [21]     SecurityModeInfo OPTIONAL,
			  //   incomingHoInfo     [22]     IncomingHoInfo OPTIONAL,
			  //   outgoingHoInfo     [23]     OutgoingHoInfo OPTIONAL,
			  //   allPathSwitchInfo  [24]     AllPathSwitchInfo OPTIONAL,
			  //   allErrorInfo       [25]     AllErrorInfo OPTIONAL,
			  //   allSubProcInfo     [26]     AllSubProcInfo OPTIONAL,
			  //   initCtxtSetupInfo  [27]     InitialContextSetupInfo OPTIONAL,
			  //   ueCtxtRelInfo      [28]     UeContextReleaseInfo OPTIONAL,
			  //   csServiceNot       [29]     Timestamp OPTIONAL,
			  //   timedOut           [30]     BOOLEAN,
			  //   ueCtxtModInfo      [31]     UeContextModificationInfo OPTIONAL, 
			  //   deciphered         [32]     BOOLEAN OPTIONAL
			     
			     
			  switch (berid.tagNumber) {
			  	 case  0: // startTime
			  		 // blen = new BerLength(); blen.decode(is);is.skip(blen.val);
			  		 BerOctetString stoct = new BerOctetString();
			  		 stoct.decode(is, false);
			  		 oix.STARTTIME = AuxDecoder.decodeDate(stoct.octetString);
			  		 break;
			  	 case  1: //endTime
			  		 //blen = new BerLength(); blen.decode(is);is.skip(blen.val);
			  		 BerOctetString etoct = new BerOctetString();
			  		 etoct.decode(is,false);
			  		 oix.ENDTIME = AuxDecoder.decodeDate(etoct.octetString);
			  		 break;
			  	 case  2: //recordType
			  		 //blen = new BerLength(); blen.decode(is);is.skip(blen.val);
			  		 BerInteger rt = new BerInteger();
			  		 rt.decode(is, false);
			  		 
			  		 switch ((int) rt.val) {
			  		   case 1:
			  			   oix.TRANSACTION_TYPE = "ATT";
			  			   break;
			  		   case 2:
			  			   oix.TRANSACTION_TYPE = "PAGING";
			  			   break;
			  		   case 3:
			  			   oix.TRANSACTION_TYPE = "SERV_REQ";
			  			   break;
			  		   case 4:
			  			   oix.TRANSACTION_TYPE = "GUTI_RELOC";
			  			   break;
			  		   case 5:
			  			   oix.TRANSACTION_TYPE = "TAU";
			  			   break;
			  		   case 6:
			  			   oix.TRANSACTION_TYPE = "DET";
			  			   break;
			  		   case 7:
			  			   oix.TRANSACTION_TYPE = "HO";
			  			   break;
			  		   case 8:
			  			   oix.TRANSACTION_TYPE = "PARTIAL";
			  			   break;
			  		   case 9:
			  			   oix.TRANSACTION_TYPE = "ERAB_HANDL";
			  			   break;
			  		   case 10:
			  			   oix.TRANSACTION_TYPE = "EXT_SERV_REQ";
			  			   break;
			  		   case 11:
			  			   oix.TRANSACTION_TYPE = "TAU_COMPL";
			  			   break;
			  		   case 12:
			  			   oix.TRANSACTION_TYPE = "TAU_COMPL";
			  			   break;
			  		   default:
			  			   oix.TRANSACTION_TYPE = "UNKNOWN (" + (int) rt.val + ")";
			  			   break;
			  		 }
			  		 break;
			  	 case  3:  //UEIdentities
			  		 blen = new BerLength(); blen.decode(is);
			  		 
			  		 byte[] cmdd = new byte[blen.val];
			  		 is.read(cmdd, 0, blen.val);
			  		 
			  		 ByteArrayInputStream bis = new ByteArrayInputStream(cmdd);
			  		 BerLength bblen = null;
			  		 
			  		 BerIdentifier lberid = new BerIdentifier();
			  		 
			  		 boolean lcc = true;
			  		 lberid.decode(bis);
			  		 
			  		 while (lcc && lberid.tagNumber != -1) {
			  			 switch (lberid.tagNumber) {
			  			   case 0:
			  				  BerOctetString imsibo = new BerOctetString();
			  				  imsibo.decode(bis,false);
			  				  oix.IMSI = AuxDecoder.decodeTBCD(imsibo.octetString);
			  				  break;
			  			   case 1:
				  			  BerOctetString imeibo = new BerOctetString();
				  			  imeibo.decode(bis,false);
				  			  oix.IMEI = AuxDecoder.decodeTBCD(imeibo.octetString);
			  				  break;
			  			   default:
			  				  //System.out.println("Found a tagnumber " + lberid.tagNumber + " within identitites");
			  				  bblen = new BerLength(); bblen.decode(bis);bis.skip(bblen.val);
			  				  break;
			  			 }
			  			 try {
			  			  lberid.decode(bis);
			  			 } catch (IOException ee) { lcc = false; }
			  		 }
			  		 
			  		 break;
			  	 case  4:  
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case  5:  //FirstCell
			  		 //blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 CellId fc = new CellId();
			  		 fc.decode(is,false);
			  		 // what we get then are two bit strings, enbid and Sector
			  		 if (fc.enbId != null) {
			  			byte[] enbitbytes = fc.enbId.bitString;
			  			byte[] sectorbytes = fc.sector.bitString;
			  			/*String ss= "";
			  			//System.out.println(fc.enbId.bitString.toString());
			  			Long cio = 0L;
			  			for (byte b:enbitbytes) {
			  				cio = cio << 8;
			  				cio = cio + (long) b&0xFF;
			  				 //System.out.print( 0 + b&0xFF); 
			  				ss = ss + Integer.toBinaryString(b&0xFF);
			  			}
			  			System.out.println("ss = " + ss + " cio = " + cio);
			  			//System.out.println();
			  			Long ci = Long.parseLong(ss,2);
			  			System.out.println("ci = " + ci);
			  			*/
			  			oix.FIRST_CELL = (AuxDecoder.decodeLong(enbitbytes) * 256 + AuxDecoder.decodeLong(sectorbytes));
			  			//System.out.println("first cell" + oix.FIRST_CELL);
			  		 }
			  		 break;
			  	 case  6:  //firstTai
			  		 blen = new BerLength(); blen.decode(is);

			  		 byte[] tmdd = new byte[blen.val];
			  		 is.read(tmdd, 0, blen.val);
			  		 
			  		 ByteArrayInputStream tis = new ByteArrayInputStream(tmdd);
			  		 BerLength tblen = null;
			  		 
			  		 BerIdentifier tberid = new BerIdentifier();
			  		 
			  		 boolean tcc = true;
			  		 tberid.decode(tis);
			  		 
			  		 while (tcc && tberid.tagNumber != -1) {
			  			 switch (tberid.tagNumber) {
			  			   case 0:
				  			  tblen = new BerLength(); tblen.decode(tis);tis.skip(tblen.val);
			  				  break;
			  			   case 1:
				  			  BerOctetString imeibo = new BerOctetString();
				  			  imeibo.decode(tis,false);
				  			  oix.FIRST_TAC = AuxDecoder.decodeLong(imeibo.octetString);
			  				  break;
			  			   default:
			  				  //System.out.println("Found a tagnumber " + lberid.tagNumber + " within identitites");
				  			  tblen = new BerLength(); tblen.decode(tis);tis.skip(tblen.val);
			  				  break;
			  			 }
			  			 try {
			  			  tberid.decode(tis);
			  			 } catch (IOException ee) { lcc = false; }
			  		 }			  		 
			  		 break;
			  	 case  7:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case  8:   
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case  9:  
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 10:  
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 11:  
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 12:  
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 13: 
			  		 blen = new BerLength(); blen.decode(is);  is.skip(blen.val);
			  		 break;
			  	 case 14: //AttachInfo 
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 15: 
			  		 blen = new BerLength(); blen.decode(is);  is.skip(blen.val);
			  		 break;
			  	 case 16:  
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 17:  
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 18:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 19:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 20:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 21:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 22:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 23:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 24:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 25:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 26:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 27:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 28:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 29:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 30:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 31:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 32:  //AllTauInfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 default: 
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  } /// end of switch ?
			 // byte[] bb = is.read(blen.val);
			  //is.skip(blen.val);
			} // end of loop
		}// this should be end of try ?
		catch (IOException ee) {
		
			cc = false;
			
			if (berid.tagNumber == -1) {
				if (this.serializer != null) {
					this.serializer.serialize(oix);
				}
			}
			else {
				System.out.println("got ioexception in parse s1ap record: " + ee.getMessage());
				this.errorcount++;
			}
		}	
		finally {
		
			this.parsecount ++;
		}
	}
		
	public Parser (Properties props) {
		
		super("S1_V5",props);
			
	}
	
}
