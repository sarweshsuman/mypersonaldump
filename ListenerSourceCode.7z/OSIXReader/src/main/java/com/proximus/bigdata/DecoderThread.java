package com.proximus.bigdata;

import java.net.Socket;
import java.util.Properties;

public class DecoderThread extends Thread {

	public DecoderThread (Socket s, Properties props) {}
	
	@Override
	public void run() {
		//
	}
}
