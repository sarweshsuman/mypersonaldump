package com.proximus.pig.date;

import org.joda.time.DateTime;
import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.DataType;
import org.apache.pig.data.Tuple;
import org.apache.pig.impl.logicalLayer.schema.Schema;

/**
 * Created by yves on 29/03/2015.
 */
public class AddSecondsToDate extends EvalFunc<DateTime> {
    @Override
    public DateTime exec(Tuple input) throws IOException {
        if (input == null || input.size() < 2) {
            return null;
        }
        if(input.get(1) instanceof Integer){
            return ((DateTime) input.get(0)).plusSeconds((Integer)input.get(1));
        }
        else{
            return (new DateTime(((DateTime)input.get(0)).getMillis() + ((Long) input.get(1) * 1000)));
        }

    }

    @Override
    public Schema outputSchema(Schema input) {
        return new Schema(new Schema.FieldSchema(getSchemaName(this.getClass().getName().toLowerCase(), input), DataType.DATETIME));
    }
}
