package com.proximus.pig.utils;

import org.apache.pig.backend.executionengine.ExecException;
import org.apache.pig.data.DataType;
import org.apache.pig.data.Tuple;
import org.apache.pig.data.TupleFactory;
import org.joda.time.DateTime;
import org.joda.time.LocalTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.ISODateTimeFormat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TupleUtils {

    /**
     * Make the given tuple larger.
     *
     * @param tuple the tuple to enlarge
     * @param size  the amount of fields to add to the tuple
     * @return  a new tuple having oldTuple.size() + 1 fields
     */
    public static Tuple enlarge(Tuple tuple, int size) throws ExecException {
        Tuple result = TupleFactory.getInstance().newTuple(tuple.size() + size);

        // -- copy the values to the result tuple
        int i = 0;
        for (Object fieldValue : tuple) {
            result.set(i++, fieldValue);
        }

        return result;
    }

    public static String string(Tuple tuple, int index) throws ExecException {
        if (tuple == null)
            throw new IllegalArgumentException("The given tuple was null");

        if (tuple.size() <= index)
            throw new IllegalArgumentException("The given index (" + index + ") is larger then the number of fields in the tuple (" + tuple.size() + ")");

        return (tuple.get(index).toString().isEmpty()) ? null : tuple.get(index).toString();
    }

    public static String string(String[] tuple, int index) {
        if (tuple == null)
            throw new IllegalArgumentException("The given tuple was null");

        if (tuple.length <= index)
            throw new IllegalArgumentException("The given index (" + index + ") is larger then the number of fields in the tuple (" + tuple.length + ")");

        return (tuple[index].isEmpty()) ? null : tuple[index];
    }

    public static Integer integer(Tuple tuple, int index) throws ExecException {
        if (tuple == null)
            throw new IllegalArgumentException("The given tuple was null");

        if (tuple.size() <= index)
            throw new IllegalArgumentException("The given index (" + index + ") is larger then the number of fields in the tuple (" + tuple.size() + ")");

        return (tuple.get(index) != null && !tuple.get(index).toString().isEmpty()) ? Integer.parseInt(tuple.get(index).toString()) : null;
    }

    public static Integer integer(String[] tuple, int index) {
        if (tuple == null)
            throw new IllegalArgumentException("The given tuple was null");

        if (tuple.length <= index)
            throw new IllegalArgumentException("The given index (" + index + ") is larger then the number of fields in the tuple (" + tuple.length + ")");


        return (tuple[index] != null && !tuple[index].isEmpty()) ? Integer.parseInt(tuple[index]) : null;
    }

    public static LocalTime time(String[] tuple, int index) {
        if (tuple == null)
            throw new IllegalArgumentException("The given tuple was null");

        if (tuple.length <= index)
            throw new IllegalArgumentException("The given index (" + index + ") is larger then the number of fields in the tuple (" + tuple.length + ")");

        return (tuple[index] != null && !tuple[index].isEmpty()) ? toLocalTime(
                tuple[index]) : null;
    }

    public static Date dateTimeAsDate(String[] tuple, int index) throws ParseException {
        if (tuple == null)
            throw new IllegalArgumentException("The given tuple was null");

        if (tuple.length <= index)
            throw new IllegalArgumentException("The given index (" + index + ") is larger then the number of fields in the tuple (" + tuple.length + ")");

        DateTime dt;
        try {
            dt = DataType.toDateTime(tuple[index]);
        } catch (ExecException e) {
            throw new ParseException(e.getMessage(), 0);
        }
        return (dt == null) ?  null : dt.toDate();
    }

    public static long dateTimeAsLong(String[] tuple, int index) throws ParseException {
        return dateTimeAsDate(tuple, index).getTime();
    }

    public static DateTime dateTime(String[] tuple, int index) throws ParseException {
        return new DateTime(dateTimeAsLong(tuple, index));
    }

    protected static LocalTime toLocalTime(String HHmm) {
        String[] splits = HHmm.split(":");

        if (splits.length != 2)
            throw new IllegalArgumentException("Invalid data '" + HHmm + "' for LocalTime. Expected a HH:mm format");

        return new LocalTime(Integer.parseInt(splits[0]), Integer.parseInt(splits[1]));
    }
}
