package com.proximus.pig.text;

import com.proximus.pig.utils.StringUtils;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.DataType;
import org.apache.pig.data.Tuple;
import org.apache.pig.impl.logicalLayer.schema.Schema;

import java.io.IOException;

/**
 * Created by yves on 29/03/2015.
 */
public class Unquote extends EvalFunc<String> {
    @Override
    public String exec(Tuple input) throws IOException {
        return StringUtils.unquote(DataType.toString(input.get(0)));
    }

    @Override
    public Schema outputSchema(Schema input) {
        return input;
    }
}