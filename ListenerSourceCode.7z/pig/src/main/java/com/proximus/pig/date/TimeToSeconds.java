package com.proximus.pig.date;

import org.apache.pig.EvalFunc;
import org.apache.pig.PigWarning;
import org.apache.pig.data.DataType;
import org.apache.pig.data.Tuple;
import org.joda.time.DateTime;
import org.joda.time.DateTimeFieldType;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.io.IOException;

/**
 * Created by yves on 29/03/2015.
 */
public class TimeToSeconds extends EvalFunc<Integer > {
    @Override
    public Integer exec(Tuple input) throws IOException {
        Integer sod=0;
        if (input == null || input.size() < 1)
            return null;
        try {
            String value = DataType.toString(input.get(0));
            String datemask = DataType.toString(input.get(1));
            final DateTimeFormatter dtf = DateTimeFormat.forPattern(datemask);
            DateTime lt = dtf.parseDateTime(value);
            sod = lt.get(DateTimeFieldType.secondOfDay());
        }catch (NullPointerException e){
            System.out.println(input);
            //warn("class cast exception at "+e.getStackTrace()[0], PigWarning.UDF_WARNING_1);
        }
        return sod;
    }
}
