package com.proximus.pig.text;

import org.apache.pig.EvalFunc;
import org.apache.pig.data.DataByteArray;
import org.apache.pig.data.DataType;
import org.apache.pig.data.Tuple;
import org.apache.pig.data.TupleFactory;
import org.apache.pig.impl.logicalLayer.schema.Schema;

import java.io.IOException;

/**
 * Created by yves on 29/03/2015.
 */
public class NullString2Null extends EvalFunc<Object> {
    private final static TupleFactory tupleFactory = TupleFactory.getInstance();

    @Override
    public Object exec(Tuple input) throws IOException {
        if (input == null || input.size() < 1)
            return new DataByteArray();

        Object inp = input.get(0);

        byte dataType = DataType.findType(inp);

        // if inbound value is null then datatype is 1
        if (dataType == 1)
            return null;

        if (dataType == -1 || dataType != DataType.CHARARRAY)
            throw new IllegalArgumentException("Invalid data type (" + dataType + ") provided");

        return (DataType.toString(inp).equalsIgnoreCase("null")) ? null : inp;
    }

    @Override
    public Schema outputSchema(Schema input) {
        return input;
    }
}
