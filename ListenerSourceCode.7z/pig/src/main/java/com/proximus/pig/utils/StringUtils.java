package com.proximus.pig.utils;

import java.text.Normalizer;

public class StringUtils {
    /**
     * Remove the special characters from the given string.
     *
     * @param input the input string from which to remove the special characters.
     * @return the cleaned string
     */
    public static String removeSpecialCharacters(String input) {
        if (input == null) return null;

        input = Normalizer.normalize(input, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "");
        input = input.toLowerCase();
        input = input.replaceAll("[\\p{M}\\p{S}\\p{Z}\\p{P}]", "");

        return input;
    }

    /**
     * Remove quotes from the beginning and end of the given string, if there are any.
     *
     * @param input the input string from which to remove the quotes
     * @return the cleaned string
     */
    public static String unquote(String input) {
        if (input == null) return null;

        if (input.startsWith("\"") || input.startsWith("'")) input = input.substring(1);
        if (input.endsWith("\"") || input.endsWith("'")) input = input.substring(0, input.length() - 1);

        return input;
    }
}
