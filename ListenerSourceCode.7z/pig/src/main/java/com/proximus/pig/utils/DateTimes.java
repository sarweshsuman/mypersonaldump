package com.proximus.pig.utils;

import org.joda.time.DateTime;

import static org.joda.time.DateTimeZone.UTC;

/**
 * A class that contains utility methods to work with instances of {@link org.joda.time.DateTime}. All methods
 * in this class use the UTC timezone by default.
 *
 */
public final class DateTimes {

    /**
     * Create a new instance of {@link org.joda.time.DateTime} holding the current datetime in UTC.
     *
     * @return The current datetime in UTC;
     */
    public static DateTime current() {
        return new DateTime(UTC);
    }

    /**
     * Creates a new instance of {@link org.joda.time.DateTime} holding the datetime of the begin of the current day in
     * UTC.
     * @return The datetime of the beginning of the current day.
     */
    public static DateTime newBeginOfCurrentDay() {
        return current().withTime(0, 0, 0, 0);
    }

    public static DateTime newEndOfCurrentDay() {
        return current().withTime(23, 59, 59, 999);
    }

    public static DateTime newBeginOfDay(int year, int month, int day) {
        return new DateTime(year, month, day, 0, 0, 0, 0, UTC);
    }

    public static DateTime newEndOfDay(int year, int month, int day) {
        return new DateTime(year, month, day, 23, 59, 59, 999, UTC);
    }
}
