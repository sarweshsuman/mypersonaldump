package com.proximus.pig.date;

import com.proximus.pig.date.AddSecondsToDate;
import org.apache.pig.data.Tuple;
import org.apache.pig.data.TupleFactory;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

/**
 * Created by yves on 29/03/2015.
 */
public class AddSecondsToDateTest {

    private AddSecondsToDate parser;

    @Before
    public void setUp() throws Exception {
        parser = new AddSecondsToDate();
    }

    @Test
    public void TestDateTimeStampConversion() throws Exception {
        DateTimeFormatter fmt = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
        DateTime startdt = fmt.parseDateTime("2013-10-01 00:03:30").withZone(DateTimeZone.UTC);
        int secondstotal = 63;

        Tuple tpl = TupleFactory.getInstance().newTuple(Arrays.asList(startdt, secondstotal));

        DateTime strdateOutput = parser.exec(tpl);

        //System.out.println(strdateOutput);

        Assert.assertEquals("2013-09-30T22:04:33.000Z", strdateOutput.toString());
    }
}
