package com.proximus.pig.date;

import com.proximus.pig.date.TimeToSeconds;
import org.apache.pig.data.DataType;
import org.apache.pig.data.TupleFactory;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.assertEquals;

/**
 * Created by yves on 29/03/2015.
 */
public class TimeToSecondsTest {

    private TimeToSeconds udf;

    @Before
    public void setUp() {
        udf = new TimeToSeconds();
    }

    @Test
    public void testMinutesSeconds() throws Exception {
        assertEquals(DataType.toInteger("2892"), udf.exec(TupleFactory.getInstance().newTuple(Arrays.asList("00:48:12", "HH:mm:ss"))));
    }

    @Test
    public void testHourMinutesSeconds() throws Exception {
        assertEquals(DataType.toInteger("6492"), udf.exec(TupleFactory.getInstance().newTuple(Arrays.asList("01:48:12","HH:mm:ss"))));
    }
}
