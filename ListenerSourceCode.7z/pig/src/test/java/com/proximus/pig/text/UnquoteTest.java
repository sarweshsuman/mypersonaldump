package com.proximus.pig.text;

import com.proximus.pig.text.Unquote;
import org.apache.pig.data.TupleFactory;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.assertEquals;

/**
 * Created by yves on 29/03/2015.
 */
public class UnquoteTest {
    private Unquote udf;

    @Before
    public void setUp() {
        udf = new Unquote();
    }

    @Test
    public void testSingleQuotedString() throws Exception {
        assertEquals("test", udf.exec(TupleFactory.getInstance().newTuple(Arrays.asList("'test'"))));
    }

    @Test
    public void testDoubleQuotedString() throws Exception {
        assertEquals("test", udf.exec(TupleFactory.getInstance().newTuple(Arrays.asList("\"test\""))));
    }

    @Test
    public void testUnQuotedString() throws Exception {
        assertEquals("test", udf.exec(TupleFactory.getInstance().newTuple(Arrays.asList("test"))));
    }

    @Test
    public void testEmptyString() throws Exception {
        assertEquals("", udf.exec(TupleFactory.getInstance().newTuple(Arrays.asList(""))));
    }

    @Test
    public void testSpecialCharacters() throws Exception {
        assertEquals("één", udf.exec(TupleFactory.getInstance().newTuple(Arrays.asList("\"één\""))));
    }
}
