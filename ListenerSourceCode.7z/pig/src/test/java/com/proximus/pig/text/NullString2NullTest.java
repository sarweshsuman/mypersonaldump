package com.proximus.pig.text;
import com.proximus.pig.text.NullString2Null;
import org.apache.pig.data.TupleFactory;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

/**
 * Created by yves on 29/03/2015.
 */
public class NullString2NullTest {
    private NullString2Null udf;

    @Before
    public void setUp() {
        udf = new NullString2Null();
    }

    @Test
    public void testStringNotNull() throws Exception {
        Object result = udf.exec(
                TupleFactory.getInstance().newTuple( Arrays.asList("testing the string"))
        );

        Assert.assertEquals("testing the string", result);
    }

    @Test
    public void testStringNull() throws Exception {
        Object result = udf.exec(
                TupleFactory.getInstance().newTuple( Arrays.asList("null"))
        );

        Assert.assertNull(result);
    }

    @Test
    public void testStringEmpty() throws Exception {
        Object result = udf.exec(
                TupleFactory.getInstance().newTuple( Arrays.asList(""))
        );

        Assert.assertEquals("", result);
    }

}

