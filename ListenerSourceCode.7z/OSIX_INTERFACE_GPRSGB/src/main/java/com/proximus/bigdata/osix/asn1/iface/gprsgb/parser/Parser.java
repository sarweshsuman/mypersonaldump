package com.proximus.bigdata.osix.asn1.iface.gprsgb.parser;

import java.io.IOException;

import com.proximus.bigdata.osix.BaseParser;

import java.util.Map;

import org.openmuc.jasn1.ber.*;
import org.openmuc.jasn1.ber.types.*;

import com.proximus.bigdata.util.AuxDecoder;
import com.proximus.bigdata.osix.OSIXLDSRecord;

//import com.proximus.bigdata.osix.asn1.iface.iups.IUPS_XDR_VERSION12;
import com.proximus.bigdata.osix.asn1.iface.gprsgb.*;

import java.io.InputStream;
import java.util.Properties;

public class Parser extends BaseParser {
		
	@Override
	public void process(InputStream is, Map<String,String> extraparams) throws IOException {

		boolean cc = true;
		 
		OSIXLDSRecord oix = new OSIXLDSRecord(this.splitrecord);
		
		if (extraparams != null && extraparams.containsKey("process_sequence_number")) {
			String r_process_sequence_number = extraparams.get("process_sequence_number");
			try {
				oix.PROCESS_SEQUENCE_NUMBER = Long.parseLong(r_process_sequence_number);
			}
			catch (Exception e) {
				oix.PROCESS_SEQUENCE_NUMBER = -1L;
			}
		}
		
		oix.INTERFACE_TYPE = this.interface_type;
		oix.SOURCE_IP = this._props.getProperty("source.ip", "0.0.0.0");
		
		BerIdentifier berid = null;
		try {
			
			while (cc) {
			  berid = new BerIdentifier();
			  berid.decode(is);
			  BerLength blen = null; 
			  
			  //  
			  // 	recordType                        [0] IupsRecordType,
	  		  // commonData                        [1] IuCommonData,
	  		  //	pTmsi                             [2] TMSI OPTIONAL,
	  		  //	plmnIdentifier                    [4] OCTET STRING OPTIONAL,
	  		  //	chargingId                        [5] INTEGER OPTIONAL,
	  		  //	smsData                           [6] MULTI-SMS OPTIONAL,
	  		  //	rabTrafficClass                   [7] INTEGER OPTIONAL,
	  		  //	attachInfo                        [8] AttachInfo OPTIONAL,
	  		  //	detachInfo                        [9] DetachInfo OPTIONAL,
	  		  //	rauInfo                           [10] RauInfo OPTIONAL,
	  		  //	serviceInfo                       [11] ServiceInfos OPTIONAL,
	  		  //	pdpInfo                           [12] PdpInfo OPTIONAL,
	  		  //	lastOutPut                        [13] BOOLEAN OPTIONAL,
	  		  //	transportLayerAddress             [14] IPAddress OPTIONAL,
	  		  //	srnsContextRequestTime            [15] Timestamp OPTIONAL,
	  		  //	srnsContextResponseTime           [16] Timestamp OPTIONAL,
	  		  //	rabContextList                    [17] RabContextList OPTIONAL,
	  	      //		rabContextFailedToTransferList    [18] RabContextFailedToTransferList OPTIONAL
			  // * 
			  // 
			  
			  // 34 cases
			  switch (berid.tagNumber) {
			  	 case  0: // recordType
			  		 BerInteger rt = new BerInteger();
			  		 rt.decode(is,false);
			  		 if (this.debug) {
			  			 //System.out.println("Processing a recordtype: " + rt.val);
			  		 }
			  		 switch ((int)rt.val) {
			  		 	case 1:
			  		 		oix.TRANSACTION_TYPE = "ATT";
			  		 		break;
			  		 	case 2:
			  		 		oix.TRANSACTION_TYPE = "RAU";
			  		 		break;
			  		 	case 3:
			  		 		oix.TRANSACTION_TYPE = "ACT_PDP";
			  		 		break;
			  		 	case 4:
			  		 		oix.TRANSACTION_TYPE = "DET";
			  		 		break;
			  		 	case 5:
			  		 		oix.TRANSACTION_TYPE = "DEACT_PDP";
			  		 		break;
			  		 	case 6:
			  		 		oix.TRANSACTION_TYPE = "PTMSI_REALLOC";
			  		 		break;
			  		 	case 7:
			  		 		oix.TRANSACTION_TYPE = "PAGING";
			  		 		break;
			  		 	case 8:
			  		 		oix.TRANSACTION_TYPE = "SMS";
			  		 		break;
			  		 	case 9:
			  		 		oix.TRANSACTION_TYPE = "IMSI_DET";
			  		 		break;
			  		 	default:
			  		 		oix.TRANSACTION_TYPE = "UNKNOWN (" + (int) rt.val + ")";
			  		 		break;
			  		 }
			  		 //blen = new BerLength(); blen.decode(is);is.skip(blen.val);
			  		 break;
			  	 case  3: //timeout
			  		 blen = new BerLength(); blen.decode(is);is.skip(blen.val);
			  		 break;
			  	 case  4:  //monitoringinterfaceid
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case  5: // recordopeningtime
			  		 BerOctetString rot = new BerOctetString();
			  		 rot.decode(is, false);
			  		 oix.STARTTIME = AuxDecoder.decodeDate(rot.octetString); 
			  		 break;
			  	 case  6:  // recordopeningclosingtime
			  		 BerOctetString rlt = new BerOctetString();
			  		 rlt.decode(is, false);
			  		 oix.ENDTIME = AuxDecoder.decodeDate(rlt.octetString);
			  		 // blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case  7:  //msidentitities
			  		 
			  		 MS_Identities msi = new MS_Identities();
			  		 msi.decode(is, false);
			  		 oix.IMSI = AuxDecoder.decodeTBCD(msi.imsi.octetString); 
			  		 // blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case  8:  //pdpinfo
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case  9:  //controlvolume
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 10:  //deciphersuccess
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 11:  //firstroutingarea
			  		 AreaInformation arinfo_f = new AreaInformation();
			  		 arinfo_f.decode(is,false);  	
			  		 oix.FIRST_LAC = arinfo_f.lac.val;
			  		 oix.FIRST_RAC = arinfo_f.rac != null ? arinfo_f.rac.val: null; 
			  		 //oix.FIRST_RAC = arinfo_f.rac.val;;
			  		 // blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 12:  //currentroutingarea
			  		 AreaInformation arinfo_c = new AreaInformation();
			  		 arinfo_c.decode(is,false);
			  		 // blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 oix.LAST_LAC = arinfo_c.lac.val;
			  		 oix.LAST_RAC = arinfo_c.rac != null ? arinfo_c.rac.val: null; 
			  		 //oix.LAST_RAC = arinfo_c.rac.val;
			  		 break;
			  	 case 13: //previousroutingarea
			  		 AreaInformation arinfo_p = new AreaInformation();
			  		 arinfo_p.decode(is,false);
			  		 
			  		 //blen = new BerLength(); blen.decode(is);  is.skip(blen.val);
			  		 break;
			  	 case 24: //firstcellid
			  		 BerInteger rfci = new BerInteger();
			  		 rfci.decode(is,false);
			  		 oix.FIRST_CELL = rfci.val;
			  		 //blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 25: // lastcellid
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 // it is wrong for the time being ... so we leave it out for now
			  		 //BerInteger rlci = new BerInteger();
			  		 //rlci.decode(is,false);
			  		 //oix.LAST_CELL = rlci.val;
			  		 break;
			  	 case 30: // rauinfo
			  		 RauInfo ra = new RauInfo();
			  		 ra.decode(is, false);
			  		 if (ra.rauType != null) {
			  		   long rav = ra.rauType.val;
			  		   switch ((int) rav) {
			  		 	  case 0:
			  		 		 oix.TRANSACTION_SUBTYPE = "RAU";
			  		 		 break;
			  		 	  case 1:
			  		 		 oix.TRANSACTION_SUBTYPE = "COMB_RAU";
			  		 		 break;
			  		 	  case 2:
			  		 		 oix.TRANSACTION_SUBTYPE = "COMB_RAU_LAU_ATT";
			  		 		 break;
			  		 	  case 3:
			  		 		 oix.TRANSACTION_SUBTYPE = "PERIODIC";
			  		 		 break;
			  		 	 default:
			  		 		oix.TRANSACTION_SUBTYPE = "UNKNOWN (" + (int) rav + ")";
			  		 		break;
			  		   }
			  		 }
			  		 break;
			  	 case 31: //attachinfo
			  		 AttachInfo ainfo = new AttachInfo();
			  		 ainfo.decode(is, false);
			  		 if (ainfo.attachAccept != null) { oix.TRANSACTION_SUBTYPE_SUCC = true; }
			  		 if (ainfo.attachReject != null) { oix.TRANSACTION_SUBTYPE_SUCC = false; }
			  		 
			  		 break;
			  	 default: // other cases not covered
			  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  } /// end of switch ?
			  
			  
			 // byte[] bb = is.read(blen.val);
			  //is.skip(blen.val);
			} // end of loop
		}// this should be end of try ?
		catch (IOException ee) {

			cc = false;

			if (berid.tagNumber == -1) {
			  if (this.serializer != null ) {
	   		    this.serializer.serialize(oix);
			  }
			}
			else {
				System.out.println("got ioexception in parse GB record: (" + berid.tagNumber + ")" + ee.getMessage());
				this.errorcount++;
			}
		}
		finally {
			this.parsecount++;
		}
	}
	
	public Parser (Properties props) {
		super("GB_V7",props);
	}
}
