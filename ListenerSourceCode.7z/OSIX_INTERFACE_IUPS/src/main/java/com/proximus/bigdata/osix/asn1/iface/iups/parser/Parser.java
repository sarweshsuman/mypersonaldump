package com.proximus.bigdata.osix.asn1.iface.iups.parser;

import java.io.IOException;
import java.util.Map;

import org.openmuc.jasn1.ber.*;
import org.openmuc.jasn1.ber.types.*;

import java.util.Date;
import java.io.ByteArrayInputStream;

import com.proximus.bigdata.osix.OSIXLDSRecord;

import com.proximus.bigdata.osix.BaseParser;

//import com.proximus.bigdata.osix.asn1.iface.iups.IUPS_XDR_VERSION12;
import com.proximus.bigdata.osix.asn1.iface.iups.*;

import java.io.InputStream;

import java.util.Properties;

import com.proximus.bigdata.util.AuxDecoder;

public class Parser extends BaseParser {

		private class l_iucommondata {
		
		//public Long status;
		//public Boolean timeout;
		//public Long monitoringInterfaceId;
		public Date recordOpeningTime;
		public Date recordClosingTime;
		//public MTP3_DATA mttp3_data;
		//public Long firstTimsi;
		//public Long lastTmsi;
		//public AreaInformation firstArea;
		public RanapArea firstRanapArea;
		public RanapArea lastRanapArea;
		public MS_Identities identities;
		//public Integer sccpCause;
		//public Integer ranapCause;
		//public Integer mmCause;
		//public SubProcedures subProcedures;
		//public Integer rejectCause;
		//public Integer cmServiceType;
		//public Boolean cmAborted;
		//public RabMessages rabMessages;
		//public IuMessages iuMessages;
		//public AreaInformation lastArea;
		//public BerOctetString classMark1;
		//public BerOctetString classMark2;
		//public BerOctetString classMark3;
		//public Long ranapCauseType;
		//public Integer firstGlobalRncId;
		//public Integer lastGlobalRncId;
		//public Integer pagingCause;
		//public BerOctetString res;
		//public Long ranapRejectCauseValue;
		
		public String IMSI = null;
		public String IMEI = null;
		public String IMEISV = null;
		public Long firstCell = null;
		public Long lastCell = null;
		
		public Long lastLAC = null;
		public Long firstLAC = null;
		
		public Long firstRAC = null;
		public Long lastRAC = null;
		
		// public 
		
		//  status                [0] Status,
		//  timeout               [1] BOOLEAN,
		//  monitoringInterfaceId [2] InterfaceId,
		//  recordOpeningTime     [3] Timestamp,
		//  recordClosingTime     [4] Timestamp,
		//  mtp3Data              [5] MTP3-DATA,
		//  firstTmsi             [6] TMSI OPTIONAL,
		//  lastTmsi              [7] TMSI OPTIONAL,
		//  firstArea             [8] AreaInformation OPTIONAL,
		//  firstRanapArea        [9] RanapArea OPTIONAL,
		//  lastRanapArea         [10] RanapArea OPTIONAL,
		//  identities            [11] MS-Identities OPTIONAL,
		//  sccpCause             [12] INTEGER OPTIONAL,
		//  ranapCause            [13] INTEGER OPTIONAL,
		//  mmCause               [14] INTEGER OPTIONAL,
		//  subProcedures         [15] SubProcedures OPTIONAL,
		//  rejectCause           [16] INTEGER OPTIONAL,
		//  cmServiceType         [17] INTEGER OPTIONAL,
		//  cmAborted             [18] BOOLEAN,
		//  rabMessages           [19] RabMessages OPTIONAL,
		//  iuMessages            [20] IuMessages OPTIONAL,
		//  lastArea              [21] AreaInformation OPTIONAL,
		//  classMark1            [22] OCTET STRING OPTIONAL,
		//  classMark2            [23] OCTET STRING OPTIONAL, 
		//  classMark3            [24] OCTET STRING OPTIONAL,
		//  ranapCauseType        [25] RanapCauseType OPTIONAL,
		//  firstGlobalRncId      [26] INTEGER OPTIONAL,
		//  lastGlobalRncId       [27] INTEGER OPTIONAL,
		//  pagingCause           [28] INTEGER OPTIONAL,
		//  res                   [29] OCTET STRING OPTIONAL,
		//  ranapRejectCauseValue [30] INTEGER OPTIONAL
		
		
		public l_iucommondata() {
			//
		}
		
		
		
		
		int decode (InputStream is, boolean explicit) throws IOException {
			
			boolean cc = true; 
			BerOctetString aux_bos;
			
			try {
				
				while (cc) {
				  BerIdentifier berid = new BerIdentifier();
				  berid.decode(is);
				  //System.out.println("l_iucommondata: found a tagnumber " + berid.tagNumber);
				  BerLength blen = null; 
				  //new BerLength(); blen.decode(is);
				 // System.out.println("the length = " + blen.val);
				  
				 // IupsRecordType recordType = null;
				  //IuCommonData commonData = null;
				  
					/*
				  status                [0] Status,
				  timeout               [1] BOOLEAN,
				  monitoringInterfaceId [2] InterfaceId,
				  recordOpeningTime     [3] Timestamp,
				  recordClosingTime     [4] Timestamp,
				  mtp3Data              [5] MTP3-DATA,
				  firstTmsi             [6] TMSI OPTIONAL,
				  lastTmsi              [7] TMSI OPTIONAL,
				  firstArea             [8] AreaInformation OPTIONAL,
				  firstRanapArea        [9] RanapArea OPTIONAL,
				  lastRanapArea         [10] RanapArea OPTIONAL,
				  identities            [11] MS-Identities OPTIONAL,
				  sccpCause             [12] INTEGER OPTIONAL,
				  ranapCause            [13] INTEGER OPTIONAL,
				  mmCause               [14] INTEGER OPTIONAL,
				  subProcedures         [15] SubProcedures OPTIONAL,
				  rejectCause           [16] INTEGER OPTIONAL,
				  cmServiceType         [17] INTEGER OPTIONAL,
				  cmAborted             [18] BOOLEAN,
				  rabMessages           [19] RabMessages OPTIONAL,
				  iuMessages            [20] IuMessages OPTIONAL,
				  lastArea              [21] AreaInformation OPTIONAL,
				  classMark1            [22] OCTET STRING OPTIONAL,
				  classMark2            [23] OCTET STRING OPTIONAL, 
				  classMark3            [24] OCTET STRING OPTIONAL,
				  ranapCauseType        [25] RanapCauseType OPTIONAL,
				  firstGlobalRncId      [26] INTEGER OPTIONAL,
				  lastGlobalRncId       [27] INTEGER OPTIONAL,
				  pagingCause           [28] INTEGER OPTIONAL,
				  res                   [29] OCTET STRING OPTIONAL,
				  ranapRejectCauseValue [30] INTEGER OPTIONAL
				*/
				  
				// the switch here below could be ... well much more could be taken care of 
				// in the default, but I chose to keep it explicit, for now
				  
				  switch (berid.tagNumber) {
				  	 case  0: // status
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 //BerInteger srt = new BerInteger();
				  		 //srt.decode(is,false);
				  		 //System.out.println("Parsed a status " + srt.val);
				  		 //this.status = srt.val;
				  		 break;
				  	 case  1: //timeout
				  		 blen = new BerLength(); blen.decode(is);is.skip(blen.val);
				  		 //System.out.println("Skiiped " + blen.val + " bytes in 1 (toString:" + blen.toString() + ")");
				  		 // System.out.println("Decoding san IuCommonData");
				  		 //blen = new BerLength(); blen.decode(is);
				  		 //commonData = new IuCommonData();
				  		 //commonData.decode(is, false);
				  		 //System.out.println("Decoded an IuCommonData");
				  		 break;
				  	 case  2: //monitoringInterfaceId 
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 //BerInteger mrt = new BerInteger(); mrt.decode(is,false);
				  		 //this.monitoringInterfaceId = mrt.val;
				  		 break;
				  	 case  3: //recordOpeningTime;
				  		 //blen = new BerLength(); blen.decode(is);// is.skip(blen.val);
				  		 aux_bos = new BerOctetString(); aux_bos.decode(is,false);
				  		 this.recordOpeningTime = AuxDecoder.decodeDate(aux_bos.octetString);
				  		 break;
				  	 case  4: // recordClosingTime 
				  		 //blen = new BerLength(); blen.decode(is); //is.skip(blen.val);
				  		 aux_bos = new BerOctetString(); aux_bos.decode(is,false);
				  		 this.recordClosingTime = AuxDecoder.decodeDate(aux_bos.octetString);
				  		 break;
				  	 case  5: //mtp3Data 
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case  6:  //firstTmsi
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case  7:  //lastTmsi
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case  8:  //firstArea
				  		 //blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 AreaInformation fr = new AreaInformation();
				  		 fr.decode(is, false);
				  		 this.firstRAC = fr.rac.val;
				  		 break;
				  	 case  9:  //firstRanapArea
				  		 this.firstRanapArea = new RanapArea();
				  		 this.firstRanapArea.decode(is, false);
				  		 //System.out.println("Got first cell:" + this.firstRanapArea.saiArea.sac.val);
				  		 
                         
				  		/* if (this.firstRanapArea.laiArea != null) {
				  		   this.firstCell = this.firstRanapArea.laiArea.sac != null ? this.firstRanapArea.laiArea.sac.val: null;  
				  		   this.firstLAC = this.firstRanapArea.laiArea.lac != null ? this.firstRanapArea.laiArea.lac.val: null;
				  		   this.firstRAC = this.firstRanapArea.laiArea.rac != null ? this.firstRanapArea.laiArea.rac.val: null;
				  		 }
				  		 else */ if (this.firstRanapArea.saiArea != null) {
				  		   this.firstCell = this.firstRanapArea.saiArea.sac != null ? this.firstRanapArea.saiArea.sac.val: null;  
				  		   this.firstLAC = this.firstRanapArea.saiArea.lac != null ? this.firstRanapArea.saiArea.lac.val: null;
				  		   //this.firstRAC = this.firstRanapArea.saiArea.rac != null ? this.firstRanapArea.saiArea.rac.val: null;
				  		 }
				  		 //blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 10:  // lastRanapArea
				  		 this.lastRanapArea = new RanapArea();
				  		 this.lastRanapArea.decode(is,false);
				  		 //System.out.println("Got second cell:" + this.lastRanapArea.saiArea.sac.val);
				  		 //blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 
				  		 /* if (this.lastRanapArea.laiArea != null) {
					  	    this.lastCell = this.lastRanapArea.laiArea.sac != null ? this.lastRanapArea.laiArea.sac.val: null;  
					  		this.lastLAC = this.lastRanapArea.laiArea.lac != null ? this.lastRanapArea.laiArea.lac.val: null;
					  		this.lastRAC = this.lastRanapArea.laiArea.rac != null ? this.lastRanapArea.laiArea.rac.val: null;
					  	 }
				  		 else */ if (this.lastRanapArea.saiArea != null) {
				  		   this.lastCell = this.lastRanapArea.saiArea.sac != null ? this.lastRanapArea.saiArea.sac.val: null;  
				  		   this.lastLAC = this.lastRanapArea.saiArea.lac != null ? this.lastRanapArea.saiArea.lac.val: null;
				  		   // this.lastRAC = this.lastRanapArea.saiArea.rac != null ? this.lastRanapArea.saiArea.rac.val: null;
				  		 }
				  		 //this.lastCell = this.lastRanapArea.saiArea.sac.val;
				  		 //this.lastLAC = this.lastRanapArea.saiArea.lac.val;
				  		 //this.lastRAC = this.lastRanapArea.saiArea.rac.val;
				  		 break;
				  	 case 11:  //identities
				  		 this.identities = new MS_Identities();
				  		 this.identities.decode(is,false);
				  		 this.IMSI =   this.identities.imsi   != null ? AuxDecoder.decodeTBCD(this.identities.imsi.octetString) : null;
				  		 this.IMEI =   this.identities.imei   != null ? AuxDecoder.decodeTBCD(this.identities.imei.octetString) : null;
				  		 this.IMEISV = this.identities.imeisv != null ? AuxDecoder.decodeTBCD(this.identities.imeisv.octetString) : null;
				  		 //System.out.println("Got imsi: " + AuxDecoder.decodeTBCD(this.identities.imsi.octetString));
				  		 //blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 12:  // sccpCause
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 13: // ranapCause
				  		 blen = new BerLength(); blen.decode(is);  is.skip(blen.val);
				  		 break;
				  	 case 14:  // mmCause
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 15: // SubProcedures
				  		 blen = new BerLength(); blen.decode(is);  is.skip(blen.val);
				  		 break;
				  	 case 16:  
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 17:  
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 18:  
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 19: 
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 20: 
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 21:/* lastRac */ 
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 AreaInformation lr = new AreaInformation();
				  		 lr.decode(is, false);
				  		 this.lastRAC = lr.rac.val;
				  		 break;
				  	 case 22: 
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 23: 
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 24: 
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 25: 
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 26: 
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 27: 
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 28: 
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 29: 
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  	 case 30: // ranapRejectCauseValue
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 //BerInteger m_rrcv = new BerInteger();
				  		 //m_rrcv.decode(is, false);
				  		 //this.ranapRejectCauseValue = m_rrcv.val;
				  		 
				  		 break;
				  	 default: 
				  		 blen = new BerLength(); blen.decode(is); is.skip(blen.val);
				  		 break;
				  } /// end of switch ? 
				  
				 // byte[] bb = is.read(blen.val);
				  //is.skip(blen.val);
				} // end of loop
			}// this should be end of try ?
			catch (IOException ee) {
				//System.out.println("got ioexception in parse iocommondata record: " + ee.getMessage());
				cc = false;
			}
			
			return 0;
		}
	}
	
	@Override
	public void process(InputStream is, Map<String,String> extraparams) throws IOException {
		//System.out.println("Doing the new parse in IUPS parser");
	    //IUPS_XDR_VERSION12 iups_xdr = new IUPS_XDR_VERSION12();
		// explicit or not ?
		// not ... since there does not seem to be a sequence envelope around it
		// we just have the elements
		//iups_xdr.decode(is,false);
		//System.out.println("Did the decide of iups_xdr");
		
		//System.out.println("Got some data: rejectCause" + iups_xdr.commonData.rejectCause);
		
		//return;
		
		l_iucommondata commonData = null;
		
		// we have to loop this until we found no more
		boolean cc = true;
		
		OSIXLDSRecord oix = new OSIXLDSRecord(this.splitrecord);
		
		oix.SOURCE_IP = this._props.getProperty("source.ip", "0.0.0.0");
		
		if (extraparams != null && extraparams.containsKey("process_sequence_number")) {
			String r_process_sequence_number = extraparams.get("process_sequence_number");
			try {
				oix.PROCESS_SEQUENCE_NUMBER = Long.parseLong(r_process_sequence_number);
			}
			catch (Exception e) {
				oix.PROCESS_SEQUENCE_NUMBER = -1L;
			}
		}
			
		oix.INTERFACE_TYPE = this.interface_type;
		
		BerIdentifier berid = null;
		try {
			while (cc) {
			 berid = new BerIdentifier();
			  berid.decode(is);
			  //System.out.println("found a tagnumber " + berid.tagNumber);
			  BerLength blen = null; 
			  //new BerLength(); blen.decode(is);
			 // System.out.println("the length = " + blen.val);
			  
			 // IupsRecordType recordType = null;
			  //l_iucommondata commonData = null;
			  
			  //  
			  // 	recordType                        [0] IupsRecordType,
	  		  // commonData                        [1] IuCommonData,
	  		  //	pTmsi                             [2] TMSI OPTIONAL,
	  		  //	plmnIdentifier                    [4] OCTET STRING OPTIONAL,
	  		  //	chargingId                        [5] INTEGER OPTIONAL,
	  		  //	smsData                           [6] MULTI-SMS OPTIONAL,
	  		  //	rabTrafficClass                   [7] INTEGER OPTIONAL,
	  		  //	attachInfo                        [8] AttachInfo OPTIONAL,
	  		  //	detachInfo                        [9] DetachInfo OPTIONAL,
	  		  //	rauInfo                           [10] RauInfo OPTIONAL,
	  		  //	serviceInfo                       [11] ServiceInfos OPTIONAL,
	  		  //	pdpInfo                           [12] PdpInfo OPTIONAL,
	  		  //	lastOutPut                        [13] BOOLEAN OPTIONAL,
	  		  //	transportLayerAddress             [14] IPAddress OPTIONAL,
	  		  //	srnsContextRequestTime            [15] Timestamp OPTIONAL,
	  		  //	srnsContextResponseTime           [16] Timestamp OPTIONAL,
	  		  //	rabContextList                    [17] RabContextList OPTIONAL,
	  	      //		rabContextFailedToTransferList    [18] RabContextFailedToTransferList OPTIONAL
			  // * 
			  // 
			  
			  switch (berid.tagNumber) {
			  	 case  0: // recordType
			  		BerInteger srt = new BerInteger();
			  		srt.decode(is,false);
			  		switch ((int) srt.val) {
			  			case 1: 
			  				oix.TRANSACTION_TYPE = "ATT";
			  				break;
			  			case 2: oix.TRANSACTION_TYPE = "DET";
			  				break;
			  			case 3: oix.TRANSACTION_TYPE = "RAU";
			  				break;
			  			case 4: oix.TRANSACTION_TYPE =  "PTMSI_REALLOC";
			  				break;
			  			case 5: oix.TRANSACTION_TYPE = "ACT_PDP";
			  				break;
			  			case 6: oix.TRANSACTION_TYPE = "DEACT_PDP";
			  				break;
			  			case 7: oix.TRANSACTION_TYPE = "SERV_REQ";
			  				break;
			  			case 8: oix.TRANSACTION_TYPE = "PAGING";
			  				break;
			  		    default: oix.TRANSACTION_TYPE = "UNKNOWN (" + (int) srt.val + ")";
			  		    	break;
			  		}
			  		//	blen = new BerLength(); blen.decode(is);is.skip(blen.val);
			  		//BerInteger rt = new BerInteger();
			  		//rt.decode(is,false);
			  		break;
			  	 case  1:
			  		 // blen = new BerLength(); blen.decode(is);is.skip(blen.val);
			  		 //System.out.println("Decoding san IuCommonData");
			  		 blen = new BerLength(); blen.decode(is);
			  		 //System.out.println("Parsing a commondata with length " + blen.val);
			  		 byte[] cmdd = new byte[blen.val];
			  		 is.read(cmdd, 0, blen.val);
			  		 commonData = new l_iucommondata();
			  		 commonData.decode(new ByteArrayInputStream(cmdd), false);
			  		 oix.IMSI = commonData.IMSI;
			  		 oix.IMEI = commonData.IMEI;
			  		 oix.IMEISV = commonData.IMEISV;
			  		 //Long limeisv = commonData.IMEISV;
			  		 oix.FIRST_CELL = commonData.firstCell;
			  		 oix.LAST_CELL = commonData.lastCell;
			  		 oix.FIRST_LAC = commonData.firstLAC;
			  		 oix.FIRST_RAC = commonData.firstRAC;
			  		 oix.LAST_RAC = commonData.lastRAC;
			  		 oix.LAST_LAC = commonData.lastLAC;
			  		 oix.STARTTIME = commonData.recordOpeningTime;
			  		 oix.ENDTIME = commonData.recordClosingTime;
			  		 
			  		 //Long lcell = commonData.lastCell;
			  		 
			  		 //System.out.println("Got imsi/imei/imeisv" + limsi + "/" + limei + "/" + limeisv);
			  		 //r_IMSI = limsi != null ? limsi.toString() : null;
			  		 
			  		 //System.out.println("Got an imsi from the commondata:" + commonData.);
			  		 //System.out.println("Decoded an IuCommonData");
			  		 break;
			  	 case  2:
			  		blen = new BerLength(); blen.decode(is);is.skip(blen.val);
			  		 // BerOctetString tmsi = new BerOctetString();
			  		 //tmsi.decode(is,false);
			  		 //blen = new BerLength(); blen.decode(is);
			  		 //is.skip(blen.val); 
			  		 break;
			  	 case  3:  blen = new BerLength(); blen.decode(is);is.skip(blen.val);
			  		 break;
			  	 case  4:  blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case  5:  blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case  6:  blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case  7:  blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case  8: // attachInfo  
			  		 //System.out.println("Decoding an attachinfo");
			  		 AttachInfo attinfo = new AttachInfo();
			  		 attinfo.decode(is,false);
			  		 if (attinfo.attachAccept != null) {
			  			 oix.TRANSACTION_SUBTYPE_SUCC = true;
			  			 //r_transaction_subtype_succ = "1";
			  		 }
			  		 if (attinfo.attachReject != null) {
			  			oix.TRANSACTION_SUBTYPE_SUCC = false;
			  		 }
			  		 
			  		 //blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case  9:  blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 10: // rauinfo 
			  		 RauInfo rinfo = new RauInfo();
			  		 rinfo.decode(is, false);
			  		 if (rinfo.rauType != null) {
			  		 switch ((int) rinfo.rauType.val) {
			  		 	case 0:
			  		 		//oix.TRANSACTION_SUBTYPE
			  		 		oix.TRANSACTION_SUBTYPE = "RAU";
			  		 		break;
			  		 	case 1:
			  		 		oix.TRANSACTION_SUBTYPE = "COMB RAU LAU";
			  		 		break;
			  		 	case 2:
			  		 		oix.TRANSACTION_SUBTYPE = "COMB RAU LAU ATT";
			  		 		break;
			  		 	case 3:
			  		 		oix.TRANSACTION_SUBTYPE = "PERIODIC";
			  		 		break;
			  		 	default:
			  		 		oix.TRANSACTION_SUBTYPE = "UNKNOWN (" + (int) rinfo.rauType.val + ")";
			  		 		break;
			  		 }
			  		 }
			  		 //blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 11:  blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 12:  blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 13: blen = new BerLength(); blen.decode(is);  is.skip(blen.val);
			  		 break;
			  	 case 14:  blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 15: blen = new BerLength(); blen.decode(is);  is.skip(blen.val);
			  		 break;
			  	 case 16:  blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 17:  blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 case 18:  blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  	 default: blen = new BerLength(); blen.decode(is); is.skip(blen.val);
			  		 break;
			  } /// end of switch ?
			 // byte[] bb = is.read(blen.val);
			  //is.skip(blen.val);
			} // end of loop
		 
			
			
		}// this should be end of try ?
		catch (IOException ee) {
		
			cc = false;
						
			if (berid.tagNumber == -1) {
				if (this.serializer != null) {
					this.serializer.serialize(oix);
				}
			}
			else {
				System.out.println("got ioexception in parse iups record: " + ee.getMessage());
				this.errorcount++;
			}
		}
		catch (Exception e) {
			System.out.println("other exception in iups parser "); 
			e.printStackTrace(System.err);
		}
		finally {
			this.parsecount++; 
		}
	}
	
	
	public Parser (Properties props) {
		
		super("IUPS_V12",props);
		
	}

	
}
