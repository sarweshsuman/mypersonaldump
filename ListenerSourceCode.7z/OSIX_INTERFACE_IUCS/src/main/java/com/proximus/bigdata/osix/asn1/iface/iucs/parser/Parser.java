package com.proximus.bigdata.osix.asn1.iface.iucs.parser;

import java.io.IOException;

import com.proximus.bigdata.osix.OSIXLDSRecord;
import com.proximus.bigdata.util.AuxDecoder;

import java.util.Map;


//import com.proximus.bigdata.osix.asn1.iface.iups.IUPS_XDR_VERSION12;
import com.proximus.bigdata.osix.asn1.iface.iucs.*;

import java.io.InputStream;
import java.util.Properties;

import com.proximus.bigdata.osix.BaseParser;

public class Parser extends BaseParser {

	
	@Override
	public void process(InputStream is, Map<String,String> extraparams) throws IOException {
		//System.out.println("Doing the new parse in IUPS parser");
		//IUPS_XDR_VERSION12 iups_xdr = new IUPS_XDR_VERSION12();
		// explicit or not ?
		// not ... since there does not seem to be a sequence envelope around it
		// we just have the elements
		//iups_xdr.decode(is,false);
		//System.out.println("Did the decide of iups_xdr");
		
		//System.out.println("Got some data: rejectCause" + iups_xdr.commonData.rejectCause);
		
		//return;
		
		OSIXLDSRecord oix = new OSIXLDSRecord(this.splitrecord);
		oix.SOURCE_IP = this._props.getProperty("source.ip", "0.0.0.0");
		
	/*	String r_version = "0.9";
		Long r_id = 0L;
		Long r_xdr_size = 0L;
	    String r_interface_type = this.interface_type;
	    Date r_timestamp = new Date();
		String r_process_sequence_number = null;
		String r_IMSI = null;
		String r_IMEI = null;
		Long r_LAC = 0L;
		Long r_RAC = 0L;
		Long r_CELL = 0L;
		String r_transaction_type = null;
		String r_transaction_subtype = null;
		Date r_attachaccept = null;
		Date r_attachreject = null;
		*/

		// this is a choice ...
		// implementation should be similar to AIF
		
		if (extraparams != null && extraparams.containsKey("process_sequence_number")) {
			String r_process_sequence_number = extraparams.get("process_sequence_number");
			try {
				oix.PROCESS_SEQUENCE_NUMBER = Long.parseLong(r_process_sequence_number);
			}
			catch (Exception e) {
				oix.PROCESS_SEQUENCE_NUMBER = -1L;
			}
		}
		
		IUCS_XDR_VERSION10 iucs_xdr = new IUCS_XDR_VERSION10();

		int xdr_length = iucs_xdr.decode(is,null);
		oix.XDR_SIZE = new Long(xdr_length);
		
		oix.INTERFACE_TYPE = this.interface_type;

		try {
			// iucs_xdr.
	
			IuCommonData iuc = null;
			SccpConnection sccp = null;
			int ccase = 0;
			
			if (iucs_xdr.mo_call != null ) { 
				oix.TRANSACTION_TYPE = "MOC";
				sccp = iucs_xdr.mo_call; 
				ccase = 1;
			}
			if (iucs_xdr.mt_call != null ) { 
				oix.TRANSACTION_TYPE = "MTC";
				sccp = iucs_xdr.mt_call; 
				ccase = 2;
			}
			if (iucs_xdr.mo_sms != null ) {
				oix.TRANSACTION_TYPE = "SMS_MO";
				sccp = iucs_xdr.mo_sms; 
				ccase = 3;
			}
			if (iucs_xdr.mt_sms != null ) { 
				oix.TRANSACTION_TYPE = "SMS_MT";
				sccp = iucs_xdr.mt_sms; 
				ccase = 4;
			}
			if (iucs_xdr.location_update != null ) { 
				oix.TRANSACTION_TYPE = "LU";
				sccp = iucs_xdr.location_update;
				ccase = 5;
			}
			if (iucs_xdr.handover != null ) {
				oix.TRANSACTION_TYPE = "HO";
				sccp = iucs_xdr.handover; 
				ccase = 6;
			}
			if (iucs_xdr.imsi_detach != null ) {
				oix.TRANSACTION_TYPE = "IMSI_DETACH";
				sccp = iucs_xdr.imsi_detach; 
				ccase = 7;
			}
			if (iucs_xdr.mo_supplementary_service != null ) {
				oix.TRANSACTION_TYPE = "SS_MO";
				sccp = iucs_xdr.mo_supplementary_service; 
				ccase = 8;
			}
			if (iucs_xdr.mt_unknown != null ) {
				oix.TRANSACTION_TYPE = "UNK_MT";
				sccp = iucs_xdr.mt_unknown; 
				ccase = 9;
			}
			if (iucs_xdr.mt_supplementary_service != null ) {
				oix.TRANSACTION_TYPE = "SS_MT";
				sccp = iucs_xdr.mt_supplementary_service;
				ccase = 10;
			}
			if (iucs_xdr.connect_ack != null ) { 
				oix.TRANSACTION_TYPE = "CONN_ACK";
				sccp = iucs_xdr.connect_ack; 
				ccase = 11;
			}
			if (iucs_xdr.paging != null) {
				//System.out.println("It is a paging record");
			}
			
			if (ccase == 0) {/* only to avoid a "ccase not used" warning */}
			
			//System.out.println("handling case: " + ccase);
			
			if (sccp == null) {
				//System.out.println("iuc = null");
				return;
			}
		
			iuc = sccp.common_data;
			
			if (sccp.lut != null) {
				switch ((int) sccp.lut.val) {
					case 0:
						oix.TRANSACTION_SUBTYPE = "NORMAL";
						break;
					case 1:
						oix.TRANSACTION_SUBTYPE = "PERIODIC";
						break;
					case 2:
						oix.TRANSACTION_SUBTYPE = "IMSI_ATT";
						break;
					case 3:
						oix.TRANSACTION_SUBTYPE = "RESERVED";
						break;
					default:
						oix.TRANSACTION_SUBTYPE = "UNKNOWN (" + (int) sccp.lut.val + ")";
						break;
				}
			}
			
			if (sccp.luTimestamps != null) {
				if (sccp.luTimestamps.luAccept != null) {
					oix.TRANSACTION_SUBTYPE_SUCC = true;
				}
				if (sccp.luTimestamps.luReject != null) {
					oix.TRANSACTION_SUBTYPE_SUCC = true;
				}
			}
			
			MS_Identities msi = iuc.identities; 
			// this gives me the imsi and the imei
			
			oix.IMSI = msi.imsi != null ? AuxDecoder.decodeTBCD(msi.imsi.octetString): null;
			oix.IMEI = msi.imei != null ? AuxDecoder.decodeTBCD(msi.imei.octetString): null;
			oix.IMEISV = msi.imeisv != null ? AuxDecoder.decodeTBCD(msi.imeisv.octetString): null;
			oix.STARTTIME = AuxDecoder.decodeDate(iuc.recordOpeningTime.octetString);
			oix.ENDTIME = AuxDecoder.decodeDate(iuc.recordClosingTime.octetString);
			oix.FIRST_CELL = iuc.firstRanapArea.saiArea.sac.val;	
			oix.FIRST_LAC = iuc.firstRanapArea.saiArea.lac.val;	
	        oix.LAST_CELL = iuc.lastRanapArea.saiArea.sac.val;
	        oix.LAST_LAC = iuc.lastRanapArea.saiArea.lac.val;
			// then cell, rac and lac
			
			//AreaInformation ainf = iuc.firstArea;
			oix.STARTTIME = AuxDecoder.decodeDate(iuc.recordOpeningTime.octetString);
			oix.ENDTIME   = AuxDecoder.decodeDate(iuc.recordClosingTime.octetString);
			
			if (this.serializer != null) {
				//System.out.println("calling for serialize in iucs parser");
				this.serializer.serialize(oix);
		    }
			else {
				//System.out.println("not serializing");
			}
		}
		catch (Exception e) {
			this.errorcount++;
		}
		finally {
			this.parsecount++;
		}
	}
	
	
	public Parser (Properties props) {
		
		super("IUCS_V10",props);
		
	}

}
