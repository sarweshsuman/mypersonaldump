package com.proximus.bigdata.osix;

import java.io.IOException;

public interface IThreadMonitor {

	public void success();
	public void success(Long i);
	
	public void failure();
	public void failure(IOException e);
	public void failure(Exception e);
	
	public void reset();
	
}
