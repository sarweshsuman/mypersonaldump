package com.proximus.bigdata.util;

import java.util.Date;

import java.math.BigInteger;

public class AuxDecoder {

	public static Long decodeLong (byte[] ind) {

		String hexstring = "";
		
		for (int i = 0; i < ind.length; i++) {
			byte b = ind[i];
			//System.out.println("Adding :" + Integer.toHexString((int) (b & 0xFF)));
			hexstring = hexstring +  String.format("%02x", (int) (b & 0xFF) );
		}
		//System.out.println("hexstring:Is now hextring : " + hexstring);
		long ll = new BigInteger(hexstring, 16).longValue();
        return new Long(ll);
	}
		
	public static Date decodeDate (byte[] ind) {
		String hexstring = "";
		
		for (int i = 0; i < ind.length; i++) {
			byte b = ind[i];
			hexstring = hexstring +  String.format("%02x", (int) (b & 0xFF) );
		}
		//System.out.println("got hexstring " + hexstring);
		long ll = new BigInteger(hexstring, 16).longValue();
		
		
		Date d = new Date(ll);
		
		//System.out.println("Got a " + ll + " and returning " + d.toString());
		return d;
	}
	
	public static String decodeTBCD(byte[] ind) {
		
	  return TBCDUtil.toTBCD(ind);
	  
	  /*System.out.println("Got a BCD byte string of length " + ind.length + " to decode");
      int lth = ind.length;
	  long result = 0;
	  for (int i = 0; i < lth; i++) {
		int bv = (int) (ind[i] & 0xFF);
		System.out.println("Extracted an int " + bv);
		byte bb = ind[i];
		//int b_1 = (bv & 240) >> 4;
		int b_1 = bb >> 4; // the first 4 bits
		int b_2 = (bb & 15); // the last 4 bits
		System.out.println(" adding b_1 and b_2: " + b_1 + " " + b_2);
		//result = result * 100 + (b_1 * 10) + b_2;
		result = result * 100  + 10 * ((bv & 240) >> 4) + (bv & 15);
	  }
	  System.out.println("Returning a value: "+result);
	  
	  System.out.println("tvcdtuitl would yield: " + TBCDUtil.toTBCD(ind)); 
	  return new Long(result);
	  */
	}
}
