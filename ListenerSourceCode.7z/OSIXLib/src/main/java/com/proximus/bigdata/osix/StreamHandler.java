package com.proximus.bigdata.osix;

import java.io.InputStream;
import java.net.Socket;
import java.util.Properties;

public interface StreamHandler extends Runnable {

	public void initialize(String id, Socket s, Properties p);
	public void initialize(String id, InputStream s, Properties p);

}
