package com.proximus.bigdata.osix.serializers;

import java.io.IOException;
import java.util.Properties;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.proximus.bigdata.osix.IOsixOutRecord;

import java.util.Vector;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;
import kafka.common.FailedToSendMessageException;

import com.proximus.bigdata.osix.IRecordSerializer;

public class SimpleKafkaSerializer implements IRecordSerializer {

	private Properties _props;
	private List<String> _fields;
	private String _fieldsep;
	private String kafkatopic;
	private Producer<String,String> kfkproducer;
	private Long batchsize;
	private Vector<KeyedMessage<String,String>> queue;
	private String brokerlist;
	protected boolean verbose; 
	protected boolean debug;
	protected Integer keyindex;
	private String partitionkey;
	
	public SimpleKafkaSerializer(Properties props, List<String> fields) {
		this._props = props;
		this._fields = fields;
	
		this.keyindex = 0;
		// if only to suppress some silly warning
		if (this._fields != null) {}
		
		String r_verbose = this._props.getProperty("serializer.verbose","not_specified");
		if (r_verbose.equalsIgnoreCase("true")) {
			this.verbose = true;
		}		
		String r_debug = this._props.getProperty("serializer.debug","not_specified");
		if (r_debug.equalsIgnoreCase("true")) {
			this.debug = true;
		}
	}
	
	public SimpleKafkaSerializer(Properties props) {
		this._props = props;
		this._fields = null;
		this.kafkatopic = null;
		this.keyindex = 0;

		if (this._fields != null) {}
		
		String r_verbose = this._props.getProperty("serializer.verbose","not_specified");
		if (r_verbose.equalsIgnoreCase("true")) {
			this.verbose = true;
		}		
		String r_debug = this._props.getProperty("serializer.debug","not_specified");
		if (r_debug.equalsIgnoreCase("true")) {
			this.debug = true;
		}

		
	}
	
	@Override
	public void serialize(IOsixOutRecord ir) throws IOException {
		// TODO Auto-generated method stub

		List<List<String>> sl = ir.get();
		for (List<String> fields:sl) {
			
		  
		  String partitionkey;
		  
		  if (this.keyindex != null) {
			  partitionkey = fields.get(this.keyindex);
		  }
		  else if (this.partitionkey != null) {
			  partitionkey = this.partitionkey;
		  }
		  else {
			  partitionkey = "dummy";
		  }
		  
		  String ss = StringUtils.join(fields,this._fieldsep);
		  //this.os.write(ss.getBytes());	
		
		  //System.out.println("Data to serialize: " + ss);		
          KeyedMessage<String, String> data = new KeyedMessage<String, String>(
                  this.kafkatopic, partitionkey, ss);
          
          //this.kfkproducer.send(data);
          
          //System.out.println("Posted a message");
          
          this.queue.addElement(data);
          if (this.debug) {
            System.out.print(".");
          }
          
          if (this.queue.size() >= this.batchsize) {
        	  try {
        		if (this.debug) {
        		  System.out.println();
        		}
                this.kfkproducer.send(this.queue);
                this.queue.clear();
                if (this.debug) {
                	System.out.println("Posted data to kafka");
                }
        	  }
        	  catch (FailedToSendMessageException e) {
        		  if (this.debug) {
        			 System.out.println("Failed to send data to Kafka " + e.getMessage());
        			 throw new IOException(e); 
        		  }
        	  }
          }
	   }
	}

	@Override
	public void initialize() throws IOException {
		
		if (this.verbose) {
		   System.out.println("Initialize the SimpleKafkaSerializer");
		}
		
		this._fieldsep = this._props.getProperty("simpleserializer.fieldsep", "|");
		this.batchsize = Long.parseLong(this._props.getProperty("kafka.batchsize","100"));
		
		this.queue = new Vector<KeyedMessage<String,String>>();
		
		this.kafkatopic = this._props.getProperty("kafka.topic","osix");

		this.brokerlist = this._props.getProperty("kafka.broker.list","localhost:9092");
		if (this.verbose) {
		   System.out.println("Setting kafkatopic to " + this.kafkatopic 
				              + " batchsize to " + this.batchsize 
				              + " and brokerlist to " + this.brokerlist);
		}
		
		if (this._props.containsKey("kafka.partitionkey.value")) {
			this.partitionkey = this._props.getProperty("kafka.partitionkey.value");
		}
		else if (this._props.containsKey("kafka.partitionkey.index")) {
			String pindex = this._props.getProperty("kafka.partitionkey.index");
			this.keyindex = Integer.parseInt(pindex);
		}
		
	    Properties kafkaprops = new Properties();
        
	    kafkaprops.put("metadata.broker.list", this.brokerlist);
	    kafkaprops.put("serializer.class", "kafka.serializer.StringEncoder");
	    kafkaprops.put("request.required.acks", "0");
			
	    ProducerConfig config = new ProducerConfig(kafkaprops);
		
	    this.kfkproducer =  new Producer<String, String>(config);
	}

	@Override
	public void terminate() throws IOException {
		
	   try {
		  if (this.queue.size() >= 0) {
             this.kfkproducer.send(this.queue);  
          }
       } 
	   catch(Exception ee) {}
	   finally { this.queue.clear(); }
	
	   if (this.verbose) {
	      System.out.println("Terminate the SimpleKafkaSerializer");
	   }
	}
}
