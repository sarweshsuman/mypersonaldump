package com.proximus.bigdata.osix;

import java.io.IOException;
import java.util.Map;

import java.util.Date;

import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;

import com.proximus.bigdata.osix.IByteStreamHandler;
import com.proximus.bigdata.osix.IRecordSerializer;

public abstract class BaseParser implements IByteStreamHandler {

	protected Properties _props;
	protected IRecordSerializer serializer;
	protected String interface_type;
	protected String defaultdateformat = "yyyy-mm-dd HH:mm:ss.SSS";
	protected java.text.SimpleDateFormat dfmat;
	protected boolean splitrecord = true;
	protected boolean verbose;
	protected boolean debug;
	protected boolean zookeeperstats;
	protected Date startdate = null;
	protected Long errorcount = 0L; 
	protected Long parsecount = 0L;
	
	public abstract void process(InputStream is, Map<String,String> extraparams) throws IOException;
	
	
	public final void process(InputStream is) throws IOException {
		// TODO Auto-generated method stub
		if (this.verbose) {
			System.out.println("Warning: you're using the old process in Barser");
		}
        this.process(is,null);
	}
	
	protected BaseParser (String iname, Properties props) {
		this._props = props;
		
		this.interface_type = iname;
		
		String r_verbose = this._props.getProperty("parser.verbose","not_specified");
		if (r_verbose.equalsIgnoreCase("true")) {
			this.verbose = true;
		}
		String r_debug = this._props.getProperty("parser.debug","not_specified");
		if (r_debug.equalsIgnoreCase("true")) {
			this.debug = true;
		}
		String r_split = this._props.getProperty("parser.splitrecords","not_specified");
		if (r_split.equalsIgnoreCase("false")) {
			this.splitrecord = false;
		}
		if (r_split.equalsIgnoreCase("true")) {
			this.splitrecord = true;
		}
		
		if (this.verbose) {
			System.out.println("Constructor for Base Parser");
		}
	}

	public BaseParser (Properties props) {
		this._props = props;
		
		String r_verbose = this._props.getProperty("parser.verbose","not_specified");
		if (r_verbose.equalsIgnoreCase("true")) {
			this.verbose = true;
		}
		String r_debug = this._props.getProperty("parser.debug","not_specified");
		if (r_debug.equalsIgnoreCase("true")) {
			this.debug = true;
		}
		
		if (this._props.containsKey("interface.type")) {
			this.interface_type = this._props.getProperty("interface.type");
		}
		
		if (this.verbose) {
			System.out.println("Constructor for Base Parser");
		}
	}
	
	@SuppressWarnings("all")
	public void initialize() throws IOException {
		// TODO Auto-generated method stub
		this.startdate = new Date();
		
		
		if (this.verbose) {
			System.out.println("Initialize for BaseParser");
		}
		// I should also initialize the serializer
		
		
		String serializer_name = this._props.getProperty("parser.serializer",null);
	    if (serializer_name != null) {
	    	
			Class hh = null;
	          
          try {
              hh = Class.forName(serializer_name);
              try {
            	  this.serializer = (IRecordSerializer) hh.getConstructor(Properties.class).newInstance(this._props);
        			 
              	  //sh.initialize(sc, props);
        	  }
        	  catch (InvocationTargetException e) { System.out.println("Error00 occurred while trying to load class : " + e.getMessage()); this.serializer = null; System.exit(1);}
        		
              catch (InstantiationException e)    { System.out.println("Error01 occurred while trying to load class : " + e.getMessage()); this.serializer = null; System.exit(1);}
        	  catch (IllegalAccessException e)    { System.out.println("Error02 occurred while trying to load class : " + e.getMessage()); this.serializer = null; System.exit(1);}
        	  catch (NoSuchMethodException e)     { System.out.println("Error03 occurred while trying to load class : " + e.getMessage()); this.serializer = null; System.exit(1);}
        	  finally {
        			// what should be here ?
        	  }
              
          }
          catch (ClassNotFoundException e) {
        	  System.out.println("ClassNotFound Exception occurred while trying to load class " + serializer_name + " " + e.getMessage());
        	  System.exit(1); 
          }
	    }
		
	    if (this.serializer != null) {
	    	this.serializer.initialize();
	    }
		
	}

	public void terminate() throws IOException {
		// TODO Auto-generated method stub
		if (this.verbose) {
			System.out.println("Terminate for BaseParser");
		}
		if (this.serializer != null) {
			this.serializer.terminate();
		}
	}
	
	public Long getProcessCount() {
		return this.parsecount;
	}
	
	public Long getErrorCount() {
		return this.errorcount;
	}
}
