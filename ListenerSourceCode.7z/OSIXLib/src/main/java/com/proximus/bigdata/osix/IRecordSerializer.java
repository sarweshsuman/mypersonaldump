package com.proximus.bigdata.osix;

import java.io.IOException;


public interface IRecordSerializer {

	public void initialize() throws IOException;
	public void terminate() throws IOException;
	
	public void serialize(IOsixOutRecord ir) throws IOException;
}
