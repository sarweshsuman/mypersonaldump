package com.proximus.bigdata.osix;

import java.io.IOException;
import java.util.Date;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.text.SimpleDateFormat;
import java.nio.file.*;
import com.google.common.io.ByteStreams; // from Google Guava


public class RawDumper implements IByteStreamHandler {

	private Properties _props;
	//private List<String> _fields;
	private Long thread_id;
	private String _filename;
	private String _fieldsep;
	private String _directory;
	private OutputStream os;
	private String _runningfilename; 	   
	private String _failedfilename; 
	private String _donefilename;
	
	public RawDumper(Properties props) {
	  this._props = props;	
	}
	
	@Override
	public void process(InputStream is) throws IOException {
		// TODO Auto-generated method stub
        this.process(is,null);
	}

	@Override
	public void process(InputStream is, Map<String, String> extraparams)
			throws IOException {
		// TODO Auto-generated method stub
		ByteStreams.copy(is,  this.os);
	}

	@Override
	public void initialize() throws IOException {
		// TODO Auto-generated method stub
		String dirname = this._props.getProperty("rawdumper.directory");
		Date d = new Date();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd.HHmmss");
		String filename = "RAWDUMP.TID" + this._props.getProperty("thread.name") +  "." + df.format(d);
		String runningfilename = filename + ".ACTIVE";
		String donefilename = filename + ".DONE";
		String failedfilename = filename + ".FAILED";
		   
		System.out.println("Using filename " + filename);
		
		// test for the dirname
		// test for the filename
		   
		// does the file exist in the directory ?  that would mean someone else is writing ... which would be somewhat strange
		Path frfpath = Paths.get(dirname,runningfilename);
		  
		System.out.println("Using full filename " + frfpath.toString());
		if (Files.exists(frfpath)) {
		  
		  throw new FileAlreadyExistsException(frfpath.toString());
		}
		   
		//create the runningfilename in the directory
		Path ff = Files.createFile(frfpath);
		// and then open it 
		this.os = Files.newOutputStream(ff);
		this._filename = filename;
		this._runningfilename = runningfilename;	   
		this._failedfilename = failedfilename;
		this._donefilename = donefilename;

	}

	@Override
	public void terminate() throws IOException {
		// TODO Auto-generated method stub
		this.os.close();

	}

	public Long getErrorCount() {
		return 0L;
	}
	
	public Long getProcessCount() {
		return 0L;
	}
	
}
