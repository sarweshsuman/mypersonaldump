package com.proximus.bigdata.osix;

import java.util.Arrays;
import java.util.Date;
import java.util.Calendar;
import java.util.List;

import java.text.SimpleDateFormat;
import java.util.Vector;

public class OSIXLDSRecord implements IOsixOutRecord {

	private boolean splitrecord = true; 
	public Long ID;
	public Long XDR_SIZE;
	public String INTERFACE_TYPE;
	public Long PROCESS_SEQUENCE_NUMBER;
	public Date STARTTIME;
	public Date ENDTIME;
	public String IMSI;
	public String IMEI;
	public String IMEISV;
	public Long FIRST_LAC; public Long LAST_LAC;
	public Long FIRST_RAC; public Long LAST_RAC;
	public Long FIRST_TAC; public Long LAST_TAC;
	public Long FIRST_CELL; public Long LAST_CELL;
	public String TRANSACTION_TYPE;
	public String TRANSACTION_SUBTYPE;
	public Boolean TRANSACTION_SUBTYPE_SUCC;
	public Date ATTACH_ACCEPT;
	public Date ATTACH_REJECT;
	public Long ERROR_CODE;
	public Integer SPLIT_INDICATOR;
	public String SOURCE_IP;
	public Date RECORD_ACCEPT_TIME;
	private String defaultdateformat = "yyyy-MM-dd HH:mm:ss.SSS";
	private SimpleDateFormat dfmat = new SimpleDateFormat(this.defaultdateformat);

	
	public OSIXLDSRecord(int protocol) {
		// TODO Auto-generated constructor stub
		this.splitrecord = false;
	}
	
	public OSIXLDSRecord(boolean split) {
		this.splitrecord = split;
	}
	
	public OSIXLDSRecord() {
		// TODO Auto-generated constructor stub
		this.splitrecord = true;
		this.RECORD_ACCEPT_TIME = new Date();
	}
	

	public List<List<String>> get() {
		
		this.ID = 0L;
		//String r_id = this.ID != null ? this.ID.toString() : null;
		
		//String r_xdr_size = this.XDR_SIZE != null ? this.XDR_SIZE.toString() : null;
		String r_processnumber = this.PROCESS_SEQUENCE_NUMBER != null ? this.PROCESS_SEQUENCE_NUMBER.toString() : null;
		String r_firstcell = this.FIRST_CELL != null ? this.FIRST_CELL.toString():null;
		String r_lastcell = this.LAST_CELL != null ? this.LAST_CELL.toString():null;
		String r_firstrac = this.FIRST_RAC != null ? this.FIRST_RAC.toString(): null;
		String r_lastrac = this.LAST_RAC != null ? this.LAST_RAC.toString(): null;
		String r_firstlac = this.FIRST_LAC != null ? this.FIRST_LAC.toString(): null;
		String r_lastlac = this.LAST_LAC != null ? this.LAST_LAC.toString(): null;
		String r_firsttac = this.FIRST_TAC != null ? this.FIRST_TAC.toString(): null;
		String r_lasttac = this.LAST_TAC != null ? this.LAST_TAC.toString(): null;
		String r_transaction_type = this.TRANSACTION_TYPE;
		String r_transaction_subtype = this.TRANSACTION_SUBTYPE;
		String r_transaction_subtype_succ = this.TRANSACTION_SUBTYPE_SUCC != null ? this.TRANSACTION_SUBTYPE_SUCC.toString(): null;
		String r_attachaccept = this.ATTACH_ACCEPT != null ? dfmat.format(this.ATTACH_ACCEPT):null;  //attachaccept
		String r_attachreject = this.ATTACH_REJECT != null ? dfmat.format(this.ATTACH_REJECT):null; // the attachreject
		String r_starttime = this.STARTTIME != null ? dfmat.format(this.STARTTIME):"SOMESTARTDATE";  //attachaccept
		String r_endtime = this.ENDTIME != null ? dfmat.format(this.ENDTIME):"SOMEENDDATE";  //attachaccept
		String r_imsi = this.IMSI != null ? this.IMSI.toString() : null;
		String r_imeiorimeisv = this.IMEI != null ? this.IMEI : this.IMEISV;
		if (r_imeiorimeisv != null) {
			r_imeiorimeisv = r_imeiorimeisv.substring(0,Math.min(8, r_imeiorimeisv.length()));
		}
		String r_interface_type = this.INTERFACE_TYPE != null ? this.INTERFACE_TYPE: "UNKNOWN";
		String r_imei = r_imeiorimeisv != null ? r_imeiorimeisv.toString() : null;
		String r_errorcode = this.ERROR_CODE != null ? this.ERROR_CODE.toString():null;
		String r_sourceip = this.SOURCE_IP != null ? this.SOURCE_IP.toString(): null;
		//String r_recordtime = 
		if (this.RECORD_ACCEPT_TIME == null) {
			this.RECORD_ACCEPT_TIME = new Date();
		}
		String r_recordaccepttime = this.RECORD_ACCEPT_TIME != null ? dfmat.format(this.RECORD_ACCEPT_TIME):"SOMEENDDATE";  //attachaccept
				
		List<List<String>> nl = new Vector<List<String>>();
		
		//splitrecord is a policy on the one hand, but can also be overridden.
		// it has been decided that whenever startcellid and endcellid are equal within the same minute then don't 
		// split the cell 
		
		boolean drop_second = false;
		
		if (this.splitrecord) {
		  if (this.ENDTIME == null || this.STARTTIME == null || this.FIRST_CELL == null || this.LAST_CELL == null) {
			// do nothing ... keep things as they are
		  }
		  else {
			if (this.FIRST_CELL == this.LAST_CELL) {
			   long difftime = Math.abs(this.ENDTIME.getTime() - this.STARTTIME.getTime());		   
			   if (difftime < 60000) {
				   Calendar c_end = Calendar.getInstance(); Calendar c_start = Calendar.getInstance();
				   c_end.setTime(this.ENDTIME); c_start.setTime(this.STARTTIME);
				   if (c_end.get(Calendar.MINUTE) == c_start.get(Calendar.MINUTE)) {
					   drop_second = true;
				   }
			   }
			}
		  }
		}
		
		if (r_firstcell == null || r_lastcell == null) {
			drop_second = true;
		}
		Integer splitindicator = 0;
		if (this.splitrecord) {			
			
			//System.out.println("Treating this as a splitrecord");
			if (r_firstcell != null && r_imsi != null) {
		      splitindicator++;
			  nl.add(
			    Arrays.asList(
			     r_interface_type
			     ,r_processnumber
			     ,r_starttime
			     ,r_imsi
			     ,r_imei
			     ,r_firstlac
			     ,r_firstrac
			     ,r_firsttac
			     ,r_firstcell
			     ,r_transaction_type
			     ,r_transaction_subtype
			     ,r_transaction_subtype_succ
			     ,r_attachaccept
			     ,r_attachreject
			     ,r_errorcode
			     ,drop_second == true ? "0": splitindicator.toString()
			     ,r_recordaccepttime
			     ,r_sourceip
			  ));
			}
		    //if (r_lastcell != null && r_imsi != null && ((drop_second == false && splitindicator == 1) || (splitindicator == 0)) ) {
			if (r_lastcell != null && r_imsi != null ) {	
		    	splitindicator++;
				nl.add(
			
			    Arrays.asList(
			      r_interface_type
			      ,r_processnumber
			      ,r_endtime
			      ,r_imsi
			      ,r_imei
			      ,r_lastlac
			      ,r_lastrac
			      ,r_lasttac
			      ,r_lastcell
			      ,r_transaction_type
			      ,r_transaction_subtype
			      ,r_transaction_subtype_succ
			      ,r_attachaccept
			      ,r_attachreject
			      ,r_errorcode
			      ,drop_second == true ? "0": splitindicator.toString()
			      ,r_recordaccepttime
			      ,r_sourceip
			  ));
		   } // end of second record is valid
		} // end of do split record = true
		
		else { // do not split record
			//System.out.println("treating this as a non split record");
			
			if (r_imsi != null ) {
				nl.add(Arrays.asList(
				  r_interface_type
				  ,r_processnumber
				  ,r_starttime
				  ,r_endtime
				  ,r_imsi
				  ,r_imei
				  ,r_firstlac
				  ,r_firstrac
				  ,r_firsttac
				  ,r_firstcell
				  ,r_lastlac
				  ,r_lastrac
				  ,r_lasttac
				  ,r_lastcell
				  ,r_transaction_type
				  ,r_transaction_subtype
				  ,r_transaction_subtype_succ
				  ,r_attachaccept
				  ,r_attachreject
				  ,r_errorcode
				  ,splitindicator.toString()
				  ,r_recordaccepttime
				  ,r_sourceip
			));
			}
		} // end of do not split record			
    return nl;
 }
}