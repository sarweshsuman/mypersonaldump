package com.proximus.bigdata.osix;


// this should log to zookeeper !

import java.io.IOException;
import java.util.Properties;
public class SplitterMonitor implements IThreadMonitor {

	public SplitterMonitor(Properties props) {
		// TODO Auto-generated constructor stub
	}
	
	public void success() {}
	public void success(Long i) {}
	
	public void failure(IOException e) {}
	public void failure(Exception e) {}
	public void failure() {}
	
	public void reset() {}

}
