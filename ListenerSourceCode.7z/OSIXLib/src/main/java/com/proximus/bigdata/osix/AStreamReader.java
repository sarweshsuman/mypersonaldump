package com.proximus.bigdata.osix;


import java.net.*;
import java.io.*;

public class AStreamReader {

  private InputStream ins;

  protected int[] getElementTriplet() {
    int[] ret = new int[3];
    // should return [ tagnumber, pc, length ]
    return ret;
  }

  public AStreamReader(InputStream ins) {
     this.ins = ins;
  }

  // byte (public getCdrElement()
}
