package com.proximus.bigdata.osix.serializers;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.List;
import java.io.OutputStream;
//import java.io.InputStream;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.NotDirectoryException;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.commons.lang.StringUtils;

import com.proximus.bigdata.osix.IOsixOutRecord;
//import com.proximus.bigdata.osix.IByteStreamHandler;
import com.proximus.bigdata.osix.IRecordSerializer;

public class SimpleFileSerializer implements IRecordSerializer {

	private Properties _props;
	private List<String> _fields;
	private Long thread_id;
	private String _filename;
	private String _fieldsep;
	private String _directory;
	private OutputStream os;
	private String _runningfilename; 	   
	//private String _failedfilename; 
	private String _donefilename; 
	private boolean verbose;
	private boolean debug;
	
	public SimpleFileSerializer(Properties props, List<String> fields) {
		this._props = props;
		this._fields = fields;
		
		String r_verbose = this._props.getProperty("serializer.verbose","not_specified");
		if (r_verbose.equalsIgnoreCase("true")) {
			this.verbose = true;
		}
		String r_debug = this._props.getProperty("serializer.debug","not_specified");
		if (r_debug.equalsIgnoreCase("true")) {
			this.debug = true;
		}
	}
	
	public SimpleFileSerializer(Properties props) {
		this._props = props;
		this._fields = null;
		
		String r_verbose = this._props.getProperty("serializer.verbose","not_specified");
		if (r_verbose.equalsIgnoreCase("true")) {
			this.verbose = true;
		}
		String r_debug = this._props.getProperty("serializer.debug","not_specified");
		if (r_debug.equalsIgnoreCase("true")) {
			this.debug = true;
		}
		
		if (this.debug) {}
	}
	
	@Override
	public void serialize(IOsixOutRecord ir) throws IOException {
		List <List<String>> sl = ir.get();
		for (List<String> fields: sl) {
			String ss = StringUtils.join(fields,this._fieldsep) + "\n";
			this.os.write(ss.getBytes());	
		}
	}

	@Override
	public void initialize() throws IOException {
		// TODO Auto-generated method stub
		
		if (this.verbose) {
		  System.out.println("Initialize the SimpleFileSerializer");
		}

		// do we need to print the field names
	    if (this._fields != null) {/* avoid warnings */}
	    
		this.thread_id = Thread.currentThread().getId();
		this._filename = "File_" + this.thread_id + ".lst";
		if (this._filename != null) {}
		this._fieldsep = this._props.getProperty("simplefileserializer.fieldsep", "|");
		
		String dirname = this._props.getProperty("simplefileserializer.directory");
		if (this.verbose) {
		  System.out.println("Writing files to " + dirname);
		}
		Path dpath = Paths.get(dirname);
		if (Files.isDirectory(dpath)) {
		  // sofar all is well 
		}
		else if (Files.exists(dpath)) {
			   // it is not a directory
		  throw new NotDirectoryException(dirname);
		}
		else {
			Files.createDirectories(dpath);
		  // create the directory ...
		}
		this._directory = dirname;
		   
		   // does the directory exist ?
		   
		Date d = new Date();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd.HHmmss");
		String filename = "Parser.TID" + this._props.getProperty("thread.name") +  "." + df.format(d);
		String runningfilename = filename + ".ACTIVE";
		String donefilename = filename + ".DONE";
		  
		if (this.verbose) {
		   System.out.println("Using filename " + filename);
		}
		
		// test for the dirname
		// test for the filename
		   
		// does the file exist in the directory ?  that would mean someone else is writing ... which would be somewhat strange
		Path frfpath = Paths.get(dirname,runningfilename);
		  
		if (this.verbose) {
		  System.out.println("Using full filename " + frfpath.toString());
		}
		
		if (Files.exists(frfpath)) {	  
		   throw new FileAlreadyExistsException(frfpath.toString());
		}
		   

		//create the runningfilename in the directory
		Path ff = Files.createFile(frfpath);
		// and then open it 
		this.os = Files.newOutputStream(ff);
		this._filename = filename;
		this._runningfilename = runningfilename;	   
		
		this._donefilename = donefilename;
	}

	@Override
	public void terminate() throws IOException {
		// TODO Auto-generated method stub
		
		if (this.verbose) {
		  
		  String currfilename = Paths.get(this._directory, this._runningfilename).toString();
		  String donefilename = Paths.get(this._directory, this._runningfilename).resolveSibling(this._donefilename).toString();
		  System.out.println("Terminate the SimpleFileSerializer: Moving " + currfilename + " to " + donefilename);
		}
		
		
		Files.move(Paths.get(this._directory, this._runningfilename), Paths.get(this._directory, this._runningfilename).resolveSibling(this._donefilename));	

	}

}
