package com.proximus.bigdata.osix;

import java.io.IOException;

import com.proximus.bigdata.osix.asn1.iface.osixheader.CDR_HEADER;

import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.util.Properties;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.HashMap;

import org.openmuc.jasn1.ber.*;


public class InitialParser implements IByteStreamHandler {

	private Properties _props;
	private IByteStreamHandler dataparser;
	private String parse_length_in_xdr_data; 
	private boolean plixd;
	
	protected boolean debug;
	protected boolean verbose;
	
	public InitialParser(Properties props) {
      this._props = props;	  	

      
		String r_verbose = this._props.getProperty("initialparser.verbose","not_specified");
		if (r_verbose.equalsIgnoreCase("true")) {
			this.verbose = true;
		}
		String r_debug = this._props.getProperty("initialparser.debug","not_specified");
		if (r_debug.equalsIgnoreCase("true")) {
			this.debug = true;
		}
		
		if (this.verbose) {
		      System.out.println("Doing new new constructor of Initialparser");
		}
	}
	
	@Override
	public void process(InputStream is, Map <String,String> extraparams) throws IOException {}
	
	@Override
	public void process(InputStream is) throws IOException {
		CDR_HEADER cdrh = new CDR_HEADER();
		HashMap<String,String> eparams = new HashMap<String,String>();
		
		cdrh.decode(is,null);
		Long psqn = null; 

        byte[] cdrdata = null;
        if (cdrh.headerVersion1 == null) {
            // System.out.println("It is not a version 1");
        } else {
            // System.out.println("It is a version 1");
            cdrdata = cdrh.headerVersion1.cdrData.octetString;
            psqn = null; // it does not have the concept of processequence number,
        }   

        if (cdrh.headerVersion2 == null) {
            // System.out.println("It is not a version 2");
        } else {
            // System.out.println("It is a version 2:" +
            // cdrh.headerVersion2.processSeqNr.val);
            // System.out.println("")
            // System.out.println("I'm am interested in " +
            // cdrh.headerVersion2.cdrData.octetString);
            cdrdata = cdrh.headerVersion2.cdrData.octetString;
    		psqn = cdrh.headerVersion2.processSeqNr.val;
        }
        
        if (cdrdata != null) {
        	// most convenient if we turn this into a stream right away
        	ByteArrayInputStream cdrais = new ByteArrayInputStream(cdrdata);
            // now we need to get the real data out of this one, it
            // contains a few bytes in the beginning:
            // we need to get the identifier octets.
            // We assume that this will just be 1 byte

        	// take out the beridentifier
        	
        	if (psqn != null) {
        		eparams.put("process_sequence_number", psqn.toString());
        	}
        	//System.out.println("Trying to parse identifier in baseparser");
        	BerIdentifier berid = new BerIdentifier();
        	berid.decode(cdrais);
        	//System.out.println("BaseParserTypeA extracted a tagnumber " + berid.tagNumber);
        	
            if (this.plixd) {
            	BerLength blen = new BerLength();
            	blen.decode(cdrais);
            	eparams.put("xdr_size", new Long(blen.val).toString());
            }
            if (this.dataparser != null) {
            	this.dataparser.process(cdrais,eparams);
            }        	
        }

	}

	@Override
	public void initialize() throws IOException {
		// TODO Auto-generated method stub

		if (this.verbose) {
			System.out.println("Doing initialize of Initialparser");
		}
		this.dataparser = null;
		this.plixd = true;
		try {
		  this.parse_length_in_xdr_data = this._props.getProperty("initialparser.extract.length","1");
		  this.plixd = Long.parseLong(this.parse_length_in_xdr_data) > 0 ? true: false;
		}
		catch (Exception e) {
			System.out.println("An error occurred while parsing the parse-date option: " + e.getMessage());
			this.plixd = true;
		}
		String parserclass_name = System.getProperty("initialparser.data.handler", this._props.getProperty("initialparser.data.handler", null));  
	    if (parserclass_name != null) {
	    	
			Class hh = null;
	          
          try {
              hh = Class.forName(parserclass_name);
              try {
            	  this.dataparser = (IByteStreamHandler) hh.getConstructor(Properties.class).newInstance(this._props);
        			 
              	  //sh.initialize(sc, props);
        	  }
        	  catch (InvocationTargetException e) { System.out.println("Error00 occurred while trying to load class : " + e.getMessage()); this.dataparser = null; System.exit(1);}
        		
              catch (InstantiationException e)    { System.out.println("Error01 occurred while trying to load class : " + e.getMessage()); this.dataparser = null; System.exit(1);}
        	  catch (IllegalAccessException e)    { System.out.println("Error02 occurred while trying to load class : " + e.getMessage()); this.dataparser = null; System.exit(1);}
        	  catch (NoSuchMethodException e)     { System.out.println("Error03 occurred while trying to load class : " + e.getMessage()); this.dataparser = null; System.exit(1);}
        	  finally {
        			// what should be here ?
        	  }
              
          }
          catch (ClassNotFoundException e) {
        	  System.out.println("ClassNotFound Exception occurred while trying to load class " + parserclass_name + " " + e.getMessage());
        	  System.exit(1); 
          }
	    }
		
	    if (this.dataparser != null) {
	    	this.dataparser.initialize();
	    }
	}

	@Override
	public void terminate() throws IOException {
		// TODO Auto-generated method stub
		if (this.verbose) {
			System.out.println("Doing terminate of initialParser");
		}
		if (this.dataparser != null) {
			this.dataparser.terminate();
		}
	}
	
	public Long getErrorCount() {
		
		if (this.dataparser != null) {
			return this.dataparser.getErrorCount();
		}
		return 0L;
	}

	public Long getProcessCount() {
		
		if (this.dataparser != null) {
			return this.dataparser.getProcessCount();
		}
		return 0L;
	}
}
 