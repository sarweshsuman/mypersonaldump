package com.proximus.bigdata;


import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.SocketAddress;
import java.net.SocketTimeoutException;
import java.net.Socket;
import java.util.Properties;
import java.util.IdentityHashMap;
import java.util.Set;
import java.util.Iterator;

public class PipeReader {

	/**
	 * @param args
	 */
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		ServerSocket ss = null;
		
		if (args.length == 0) {
			System.out.println("Usage : [program_name] properties_file");
			System.out.println("Please specify a properties file ...");
			System.exit(1);
		}
		String propfile = args[0];
		Properties props = new Properties();
		FileInputStream infle = null;
		try {
          infle = new FileInputStream(propfile);		
          props.load(infle);
          
          // I need two properties:
          // listener.port
          // listener.hostname
          int portNumber = Integer.parseInt(props.getProperty(
					"listener.data.portnumber", "4000"));
          String hostlisten = props.getProperty(
					"listener.data.hostname");
          int queuelength = Integer.parseInt(props.getProperty("listener.queuelength","1"));
          String handler = props.getProperty("listener.data.handler");
          String lname = props.getProperty("listener.name","ANONYMOUS");

          
          Class hh = null;
          
          try {
              hh = Class.forName(handler);
          }
          catch (ClassNotFoundException e) { System.exit(1); }
          
          ss = new ServerSocket(portNumber, queuelength,InetAddress.getByName(hostlisten));
          ss.setSoTimeout(5000);
          
          
          boolean continue_condition = true;
          
          
          Socket sc = null;
          System.out.println("System is ready, listening on "+hostlisten+" port " + portNumber);
          System.out.println("The handler for this stream is " + handler);
          
          IdentityHashMap<Long,Socket> ism = new IdentityHashMap<Long,Socket>();
          IdentityHashMap<Long,Thread> itm = new IdentityHashMap<Long,Thread>();
          
          while (continue_condition == true) {
        	 try {
        		 System.out.println("Waiting for connection ...");
        		 sc = ss.accept();
        		 
        		 SocketAddress sa = sc.getRemoteSocketAddress();
        		 //sa.
        		 //System.out.println("got a connection from " + sa.toString().replace('/','P').replace(':', '_'));
        		 System.out.println("Connected to local: " + sc.getLocalSocketAddress().toString());
        		 String thid = lname + "." + sa.toString().replace('/','P').replace(':', '_');
        		 Thread sh = null;
        		 try {
        			 sh = (Thread) hh.getConstructor(String.class, Socket.class, Properties.class).newInstance(thid,sc,props);
        			 ism.put(sh.getId(),sc);
        			 itm.put(sh.getId(),sh);
        			 sh.start();
              		 //sh.initialize(sc, props);
        		 }
        		 catch (InvocationTargetException e) { sc.close();  sc = null;}
        		 catch (InstantiationException e)    { sc.close();  sc = null; }
        		 catch (IllegalAccessException e)    { sc.close();  sc = null; }
        		 catch (NoSuchMethodException e)     { sc.close();  sc = null; }
        		 finally {
        			// if (sc != null) { sc.close(); }
        		 }
        		 //DecoderThread d = new DecoderThread(sc, props);
        		 //d.start();
        	 }
        	 catch (SocketTimeoutException e) {
        		 // run some checks
        		 System.out.println("Doing some checks");
        		 Set <Long> ks = ism.keySet();
        		 // Loop over the keys 
        		 Iterator<Long> ii = ks.iterator();
        		 
        		 while (ii.hasNext()) {
        			 Long li = ii.next();
        			 
        			 Thread lt = itm.get(li);
        			 //if (lt.)
        			 if (lt.getState() == Thread.State.TERMINATED) {
        				 System.out.println("Found terminated thread " + li);
        				 Long lll = new Long(lt.getId());
        				 long llll = lt.getId();
        				 Socket lss = ism.get(llll);
        				 if (lss != null) {try { lss.close(); } catch (IOException le) {} }
        				 else { System.out.println("When cleaning up i found a socket that is null"); }
        				 
        				 ii.remove(); // if you do it like the commented line below, you'll get a 
        				 //ism.remove(llll);
        				 itm.remove(llll);
        			 }
        			 
        		 }
        		 	 
        	 }
        	 catch (IOException e) {
        		 System.out.println("Error : " + e.getStackTrace());
        		 // wonder what could happen at this point ... 
        	 }
        	 
          }
          
          // now kee
          
          //ss.listen()
		}

		catch(FileNotFoundException e) {
		  System.out.println("The file " + propfile + " does not exist");	
		}
	    catch (IOException e) {
	    	System.out.println("Some IO Exception occurred: " + e.getMessage());
	    }
		finally {
			if (infle !=null) { 
				try {
					infle.close();
				} 
				catch (IOException e) {} 
			}		
		}
		
		// Are we still alive ?	
	}
}
