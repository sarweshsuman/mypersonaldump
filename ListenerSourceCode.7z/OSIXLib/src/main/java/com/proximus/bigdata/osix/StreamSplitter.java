package com.proximus.bigdata.osix;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;


import java.util.Arrays;

import com.proximus.bigdata.osix.IByteStreamHandler;

import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Primitive;


public class StreamSplitter extends Thread {

	private Properties props;
	private InputStream istream;
	private String identifier;
	private IByteStreamHandler bytestream_handler;
	private ASN1InputStream ains;
	private long counter;
	private long maxmessages;
	private long startoffset;
	private IThreadMonitor splitmon = null;
	private IByteStreamHandler errorstream;
	
	private boolean debug;
	private boolean verbose;
	private boolean continue_on_error;
	private Long errorcount;
	private Long maxerrorcount;
	
	
	private void initialize() throws IOException {
		this.bytestream_handler = null;
		this.counter = 0L;
		
		this.maxmessages = 0L;
		this.startoffset = 0L;
		this.errorcount = 0L;
		
		this.continue_on_error = true;
		this.maxerrorcount = -1L;
		
		this.errorstream = null;
		
		this.maxmessages = Long.parseLong(System.getProperty("splitter.max.messages",this.props.getProperty("splitter.max.messages","-1")));
		this.startoffset = Long.parseLong(System.getProperty("splitter.start.offset",this.props.getProperty("splitter.start.offset","0")));
		
		this.ains = new ASN1InputStream(this.istream);
		String parserclass_name = System.getProperty("splitter.data.handler",
				                                     this.props.getProperty("splitter.data.handler", 
				                                                            null
				                                                           )    
				                                    );
		
		String errorhandler_class_name = System.getProperty("splitter.error.handler",
                this.props.getProperty("splitter.error.handler", 
                        null
                       )    
        );
		
		if (parserclass_name != null) {
			
			Class hh = null;
	          
          try {
              hh = Class.forName(parserclass_name);
              try {
            	  this.bytestream_handler = (IByteStreamHandler) hh.getConstructor(Properties.class).newInstance(this.props);
        			 
              	  //sh.initialize(sc, props);
        	  }
        	  catch (InvocationTargetException e) { System.out.println("Error occurred while trying to load class : " + e.getMessage()); this.bytestream_handler = null; System.exit(1);}
        		
              catch (InstantiationException e)    { System.out.println("Error occurred while trying to load class : " + e.getMessage()); this.bytestream_handler = null; System.exit(1);}
        	  catch (IllegalAccessException e)    { System.out.println("Error occurred while trying to load class : " + e.getMessage()); this.bytestream_handler = null; System.exit(1);}
        	  catch (NoSuchMethodException e)     { System.out.println("Error occurred while trying to load class : " + e.getMessage()); this.bytestream_handler = null; System.exit(1);}
        	  finally {
        			// what should be here ?
        	  }
              
          }
          catch (ClassNotFoundException e) {
        	  System.out.println("Error occurred while trying to load class " + parserclass_name+ e.getMessage());
        	  System.exit(1); 
          }
	          
		}
		
         if (errorhandler_class_name != null) {
			
			Class ehh = null;
	          
          try {
              ehh = Class.forName(errorhandler_class_name);
              try {
            	  this.errorstream = (IByteStreamHandler) ehh.getConstructor(Properties.class).newInstance(this.props);
        			 
              	  //sh.initialize(sc, props);
        	  }
        	  catch (InvocationTargetException e) { System.out.println("Error occurred while trying to load class : " + e.getMessage()); this.bytestream_handler = null; System.exit(1);}
        		
              catch (InstantiationException e)    { System.out.println("Error occurred while trying to load class : " + e.getMessage()); this.bytestream_handler = null; System.exit(1);}
        	  catch (IllegalAccessException e)    { System.out.println("Error occurred while trying to load class : " + e.getMessage()); this.bytestream_handler = null; System.exit(1);}
        	  catch (NoSuchMethodException e)     { System.out.println("Error occurred while trying to load class : " + e.getMessage()); this.bytestream_handler = null; System.exit(1);}
        	  finally {
        			// what should be here ?
        	  }
              
          }
          catch (ClassNotFoundException e) {
        	  System.out.println("Error occurred while trying to load class " + errorhandler_class_name + e.getMessage());
        	  System.exit(1); 
          }
	          
		}
		
		if (this.bytestream_handler != null) {
			this.bytestream_handler.initialize();
		}
		
		if (this.errorstream != null) {
			this.errorstream.initialize();
		}
		
		this.splitmon = (IThreadMonitor) new SplitterMonitor(this.props);
		
		if (this.verbose) {
			System.out.println("End of initialization of StreamSplitter");
		}
	}
	
	private void terminate() throws IOException {
		// doing nothing
		if (this.verbose) {
			System.out.println("End of streamsplitter");
			System.out.println("StreamSplitter handled " + this.counter + " messages");
		}
		if (this.bytestream_handler != null) {
			try {
				this.bytestream_handler.terminate();
			}
			catch (IOException e) {}
		}
		if (this.errorstream != null) {
			try {
				this.errorstream.terminate();
			}
			catch (IOException e) {}
		}
		
	}
	
 	public StreamSplitter(String sid, Socket s, Properties p) throws IOException {
		this.props = (Properties) p.clone();
		this.props.put("thread.id", this.getId());
		this.istream = s.getInputStream();
		this.identifier = sid;
		this.initialize();
		
		String r_verbose = this.props.getProperty("splitter.verbose","not_specified");
		if (r_verbose.equalsIgnoreCase("true")) {
			this.verbose = true;
		}
		String r_debug = this.props.getProperty("splitter.debug","not_specified");
		if (r_debug.equalsIgnoreCase("true")) {
			this.debug = true;
		}
		if (this.verbose) {
			System.out.println("Constructor for StreamSplitter with a socket");
		}
		
	} 		
	
	public StreamSplitter(String sid, InputStream s, Properties p) throws IOException {
		this.props = (Properties) p.clone();
		this.props.put("thread.id", this.getId());
		this.istream = s;
		this.identifier = sid;
		this.initialize();
		
		String r_verbose = this.props.getProperty("splitter.verbose","not_specified");
		if (r_verbose.equalsIgnoreCase("true")) {
			this.verbose = true;
		}
		String r_debug = this.props.getProperty("splitter.debug","not_specified");
		if (r_debug.equalsIgnoreCase("true")) {
			this.debug = true;
		}
		if (this.verbose) {
			System.out.println("Constructor for StreamSplitter with an inputstream");
		}
	} 
	
	@Override
	public void run() {
		// noop ?
		boolean cc = true;
		int bdl = 0;
		long ofs = 0;
        
		if (this.startoffset > 0) {
			System.out.println("Skipping " + this.startoffset + " records");
		}
		
		if (this.verbose) {
		  System.out.println("Starting parsing in thread " + this.identifier);
		}
		while (cc) {
			
		  if (this.startoffset > 0 ) {
			  if (ofs < this.startoffset  ) { ofs++; continue; }
		  }
		  
		  if (this.maxmessages != -1 && this.counter >= this.maxmessages) { cc = false; }
		  else { 
			 try {
				 ASN1Primitive asn1prim = this.ains.readObject();
		
				 if (asn1prim != null) {
				  this.counter += 1;
				
				      //System.out.print(".");
				    
				  byte[] encc = asn1prim.getEncoded();
				  //System.out.println("Got a complete message of " + encc.length + " bytes");
				  bdl = bdl + encc.length;
		        
				  ByteArrayInputStream bais = new ByteArrayInputStream(encc);
	
				  if (this.bytestream_handler != null) {
					  
					byte[] bcc = Arrays.copyOf(encc,encc.length);  

					try {
						this.bytestream_handler.process(bais);
						if (this.splitmon != null) {
							this.splitmon.success();
						}
					}
					catch (Exception ee) {
						if (this.verbose) {
						  System.out.println("A parsing error occurred at record " + this.counter + ":" + ee.getMessage());
						}
						if (this.splitmon != null) {
							this.splitmon.failure();
						}
						this.errorcount++;
						if (this.continue_on_error) {			
							if (this.maxerrorcount > 0) {
								if (this.errorcount >= this.maxerrorcount) {
									cc = false;
									System.err.println("Errorcount exceeds max error count. Bailing out");
								}
							}
							else {
								// continue no matter what ... 
							}				
							if (this.errorstream != null) {
							  try { this.errorstream.process(new ByteArrayInputStream(bcc)); } catch (Exception eee) {}
							}							
						}
						else {
							cc = false;
						}
					}
					finally {
						this.counter++;
					}  
				  } 
				}
				else {			
				  cc = false;
				}				
			 }
			 catch (IOException e) {
				// try { this.terminate(); } catch (IOException ee) {}
				if (this.verbose) {
					System.out.println("StreamSplitter handled " + this.counter + " messages");
				}
				System.out.println("IOException occurred in StreamSplitter: " + e.getMessage());
				cc = false;
			 }
		  }
		}
		
		try { this.terminate(); } catch (IOException ee) {}
	}
}
