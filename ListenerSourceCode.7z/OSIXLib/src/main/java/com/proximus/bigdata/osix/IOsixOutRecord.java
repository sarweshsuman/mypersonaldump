package com.proximus.bigdata.osix;

import java.util.List;

public interface IOsixOutRecord {

	List<List<String>> get();
	
}
