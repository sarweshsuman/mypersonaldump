package com.proximus.bigdata.osix;

import java.io.InputStream;
import java.util.Map;
import java.io.IOException;

public interface IByteStreamHandler {
   public void process(InputStream is) throws IOException;
   public void process(InputStream is,Map<String,String> extraparams) throws IOException;
   public void initialize() throws IOException;
   public void terminate() throws IOException;
   public Long getErrorCount();
   public Long getProcessCount();
}
