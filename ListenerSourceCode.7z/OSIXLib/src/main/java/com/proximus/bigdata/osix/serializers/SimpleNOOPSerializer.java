package com.proximus.bigdata.osix.serializers;

import java.io.IOException;
import java.util.Properties;
import java.util.List;

import com.proximus.bigdata.osix.IOsixOutRecord;



import com.proximus.bigdata.osix.IRecordSerializer;

public class SimpleNOOPSerializer implements IRecordSerializer {

	private Properties _props;
	private List<String> _fields;
	
	protected boolean verbose; 
	
	public SimpleNOOPSerializer(Properties props, List<String> fields) {
		this._props = props;
		this._fields = fields;
		
		if (this._props != null && this._fields != null) {}
	
		// if only to suppress some silly warning
	}
	
	public SimpleNOOPSerializer(Properties props) {
		this._props = props;
		this._fields = null;
	}
	
	@Override
	public void serialize(IOsixOutRecord ir) throws IOException {
		
		// this is a noop, so it does nothing 

	}

	@Override
	public void initialize() throws IOException {
		
		if (this.verbose) {
		   System.out.println("Initialize the SimpleNOOPSerializer");
		}
		
	}

	@Override
	public void terminate() throws IOException {
		
	}
}
