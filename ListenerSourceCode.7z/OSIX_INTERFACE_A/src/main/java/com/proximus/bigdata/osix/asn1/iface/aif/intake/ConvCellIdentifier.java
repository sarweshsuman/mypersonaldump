package com.proximus.bigdata.osix.asn1.iface.aif.intake;

import com.proximus.bigdata.osix.asn1.iface.aif.*;
//import com.proximus.bigdata.util.AuxDecoder;

public class ConvCellIdentifier {

	public Long cellid;
	public Long lac;
	public Long sac;
	public Long rac;
	
	public ConvCellIdentifier() {
	
		this.cellid = null;
		this.lac = null;
		this.sac = null;
		this.rac = null;
	}
	
	public ConvCellIdentifier(CellIdentifier ci) {
		
		this.cellid = null;
		this.lac = null;
		this.sac = null;
		this.rac = null;
		
		if (ci.cell != null)                         { this.cellid = ci.cell.val;}  
		if (ci.lac != null)                          { this.lac = ci.lac.val; }   
	}
	
}
