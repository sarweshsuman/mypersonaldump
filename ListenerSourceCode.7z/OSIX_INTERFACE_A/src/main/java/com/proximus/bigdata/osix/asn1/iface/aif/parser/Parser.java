package com.proximus.bigdata.osix.asn1.iface.aif.parser;

import java.io.IOException;
import com.proximus.bigdata.osix.BaseParser;
import com.proximus.bigdata.osix.OSIXLDSRecord;

import java.io.InputStream;
import java.util.Properties;

import com.proximus.bigdata.osix.asn1.iface.aif.A_INTERFACE_CDR_VERSION8;
import com.proximus.bigdata.osix.asn1.iface.aif.intake.ConvCommonData;
import com.proximus.bigdata.osix.asn1.iface.aif.CommonData;

import java.util.Map;

public class Parser extends BaseParser {

	@Override
	public void process(InputStream is, Map<String,String> extraparams) throws IOException {
		
		A_INTERFACE_CDR_VERSION8 aif8 = new A_INTERFACE_CDR_VERSION8();
		
		aif8.decode(is, null);
				
	    /*	
		String r_version = "0.9";
		Long r_id = 0L;
		Long r_xdr_size = 0L;
	    String r_interface_type = this.interface_type;
	    Date r_timestamp = new Date();
		String r_process_sequence_number = null;
		String r_IMSI = null;
		String r_IMEI = null;
		Long r_LAC = null;
		Long r_RAC = null;
		Long r_CELL = null;
		String r_transaction_type = null;
		String r_transaction_subtype = null;
		Date r_attachaccept = null;
		Date r_attachreject = null;
		Boolean r_transaction_subtype_succ = null;
		*/
		
		OSIXLDSRecord oix = new OSIXLDSRecord(this.splitrecord);
		 
		if (extraparams != null && extraparams.containsKey("process_sequence_number")) {
			String r_process_sequence_number = extraparams.get("process_sequence_number");
			try {
				oix.PROCESS_SEQUENCE_NUMBER = Long.parseLong(r_process_sequence_number);
			}
			catch (Exception e) {
				oix.PROCESS_SEQUENCE_NUMBER = -1L;
			}
		}
		
	    oix.SOURCE_IP = this._props.getProperty("source.ip", "0.0.0.0");
		
		
		if (extraparams != null && extraparams.containsKey("xdr_size")) {
			String r_xdr_size = extraparams.get("xdr_size");
			try {
				oix.XDR_SIZE = Long.parseLong(r_xdr_size);
			}
			catch (Exception e) {
				oix.XDR_SIZE = -1L;
			}
		}
		else {
			oix.XDR_SIZE = -1L;
		}

        oix.INTERFACE_TYPE = this.interface_type; // r_interface_type;
        
		// in LDS testing the structure of the target table looks like 
		// The version is added by evert
		/*
		ID                                                 NUMBER
		XDR_SIZE                                           NUMBER
		VERSION											   VARCHAR(6)
		INTERFACE_TYPE                                     VARCHAR2(8)
		PROCESSSEQUENCENUMBER                              NUMBER
		STARTTIME                                          DATE
		ENDTIME                                            DATE
		IMSI                                               VARCHAR2(256)
		IMEI                                               VARCHAR2(256)
		FIRST_LAC                                          NUMBER
		FIRST_RAC                                          NUMBER
		FIRST_CELL                                         NUMBER
		LAST_LAC                                           NUMBER
		LAST_RAC                                           NUMBER
		LAST_CELL                                          NUMBER
		TRANSACTIONTYPE                                    VARCHAR2(32)
		TRANSACTIONSUBTYPE                                 VARCHAR2(32)
		ATTACHACCEPT                                       DATE
		ATTACHREJECT                                       DATE
		*/
		
		CommonData cd = null;
		
        if (aif8.mo_call != null) {
            // System.out.println("It is a mo_call");
            cd = aif8.mo_call.common_data;
            oix.TRANSACTION_TYPE = "MOC";
        }
        if (aif8.mt_call != null) {
          // System.out.println("It is a mt_call");
          cd = aif8.mt_call.common_data;
          oix.TRANSACTION_TYPE = "MTC";
        }
        if (aif8.mo_sms != null) {
          // System.out.println("It is a mo_smsl");
          cd = aif8.mo_sms.common_data;
          oix.TRANSACTION_TYPE = "SMS_MO";
        }
        if (aif8.mt_sms != null) {
          // System.out.println("It is a mt_sms");
          cd = aif8.mt_sms.common_data;
          oix.TRANSACTION_TYPE = "SMS_MT";
        }
        if (aif8.handover != null) {
          // System.out.println("It is a handover");
          cd = aif8.handover.common_data;
          oix.TRANSACTION_TYPE = "HO";
        }
        if (aif8.update_location != null) {
          // System.out.println("It is a update_location");
          // System.out.println("IMSI = " +
          // aif8.update_location.common_data.imsi.getClass());
          cd = aif8.update_location.common_data;
          // System.out.println("imsi = " + imsi);
          // aif8.update_location.common_data.imsi.getClass()
          //ucounter++;
          oix.TRANSACTION_TYPE = "LU";
          long lutype = aif8.update_location.lu_type.val;
          switch ((int) lutype) {
          	case 0:
          		oix.TRANSACTION_SUBTYPE = "NORMAL";
          		break;
          	case 1:
          		oix.TRANSACTION_SUBTYPE = "PERIODIC";
          		break;
          	case 2:
          		oix.TRANSACTION_SUBTYPE = "IMSI_ATT";
          		break;
          	case 3:
          		oix.TRANSACTION_SUBTYPE = "RESERVED";
          		break;
          	default:
          		oix.TRANSACTION_SUBTYPE = "UNKNOWN (" + (int) aif8.update_location.lu_type.val + ")";
          		break;
          }
          if (aif8.update_location.luTimestamps.luAccept != null) {
        	  oix.TRANSACTION_SUBTYPE_SUCC = true;
          }
          if (aif8.update_location.luTimestamps.luReject != null) {
        	  oix.TRANSACTION_SUBTYPE_SUCC = false;
          }
        }
        if (aif8.imsi_detach != null) {
          // System.out.println("It is a imsi_detach");
          // cd = aif8.imsi_detach.common_data;
          // this seems to fuck up the BCD decoding
        }
        if (aif8.mo_supplementary_service != null) {
          // System.out.println("It is a mo_supplementary_service");
          cd = aif8.mo_supplementary_service.common_data;
          oix.TRANSACTION_TYPE = "SS_MO";
        }
        /*
         * if (aif8.paging != null) {
         * System.out.println("It is a paging"); // we can't do
         * anything with this one or so it seems }
         */
        if (aif8.connect_ack != null) {
          // System.out.println("It is a connect_ack");
          cd = aif8.connect_ack.common_data;
          oix.TRANSACTION_TYPE = "CONN_ACK";
        }
        
        /*
         * 		String r_version = "0.9";
		Long r_id = 0L;
		Long r_xdr_size = 0L;
	    String r_interface_type = this.interface_type;
		Long r_process_sequence_number = 0L;
		String r_IMSI = null;
		String r_IMEI = null;
		Long r_LAC = 0L;
		Long r_RAC = 0L;
		Long r_CELL = 0L;
		String r_transaction_type = null;
		String r_transaction_subtype = null;
		Date r_attachaccept = null;
		Date r_attachreject = null;
         */
        
        ConvCommonData ccv = null;
        
        if (cd != null && this.serializer != null) {
          ccv = new ConvCommonData(cd);
               
          oix.STARTTIME = ccv.seizure_time;
          oix.ENDTIME = ccv.end_time;
          
          oix.IMSI = ccv.imsi; // != null ? ccv.imsi : "";         
          oix.IMEI = ccv.imei; // != null ? ccv.imei : "";
            
		  if (ccv.first_cell_identifier != null) {
			  oix.FIRST_CELL = ccv.first_cell_identifier.cellid !=null ? ccv.first_cell_identifier.cellid:null;
			  oix.FIRST_LAC  = ccv.first_cell_identifier.lac != null ? ccv.first_cell_identifier.lac:null;
			  oix.FIRST_RAC  = ccv.first_cell_identifier.rac != null ? ccv.first_cell_identifier.rac:null;
		  }
		  if (ccv.current_cell_identifier != null) {
			  oix.LAST_CELL = ccv.current_cell_identifier.cellid !=null ? ccv.current_cell_identifier.cellid:null;
			  oix.LAST_LAC  = ccv.current_cell_identifier.lac != null ? ccv.current_cell_identifier.lac:null;
			  oix.LAST_RAC  = ccv.current_cell_identifier.rac != null ? ccv.current_cell_identifier.rac:null;
		  }
			  
		  this.serializer.serialize(oix);

        }
	}
	
	public Parser (Properties props) {
		super("AIF_V8",props);
	}

}
