package com.proximus.bigdata.osix.asn1.iface.aif.intake;


import java.util.Date;

import com.proximus.bigdata.osix.asn1.iface.aif.*;
import com.proximus.bigdata.osix.asn1.iface.aif.intake.ConvCellIdentifier;
import com.proximus.bigdata.util.AuxDecoder;

public class ConvCommonData {
	
	public Date seizure_time;
	public Date end_time;
	public Long monitoringInterfaceId;
	public Boolean timeout;
	public Long msc_pc;
	public Long bsc_pc;
	public ConvCellIdentifier first_cell_identifier;
	public ConvCellIdentifier current_cell_identifier;
	public ConvCellIdentifier last_home_cell_identifier;
	public Long cmServiceType;
	public String imsi;
	public byte [] first_tmsi ;
	public byte [] current_tmsi;
	public String imei ;
	public Long bssmap_cause;
	public Boolean cm_aborted;
	public byte[] classMark1;
	public byte[] classMark2;
	public byte[] classMark3;
	public Date assRequestTime;
	public Date assCompleteTime;
	public Date assFailureTime;
	public Date authRequestTime;
	public Date authResponseTime;
	public Date authFailureTime;
	public Date ciphModeCommandTime;
	public Date ciphModeCompleteTime;
	public Date ciphModeRejectTime;
	public Date tmsiReallCommandTime;
	public Date tmsiReallCompleteTime;
	public Date identityRequestTime;
	public Date identityResponseTime;
	public Long typeofidentity;
	public byte[] res; 
	public Long pcm_system_first;
	public Long ts_system_first;
	public Long pcm_system_last;
	public Long ts_system_last;
	public Long cic;
	public Date clearCommandTime;
	public Long bearer_capability;
	public Long chRateAndTypeProposed;
	public Long chosenMode;
	public Long chosenRate;
	public Long speechVersion;
	public byte[] permSpeechVersion;
	public Long transparencyInd ;
	public Long chTypeDataRate;
	public byte[] allowedRifRates;
	public Long assymetryIndication;
	public byte[] priority;
	public Long rr_cause;
	public Long reject_cause;
	public Date clearRequestTime;
	public Long sccpCause;
	
	/*
	  seizure-time            [0]  Timestamp,
	  end-time                [1]  Timestamp,
	  monitoringInterfaceId   [2]  INTEGER,
	  timeout                 [3]  BOOLEAN,
	  msc-pc                  [4]  PointCode,
	  bsc-pc                  [5]  PointCode,
	  first-cell-identifier   [6]  CellIdentifier OPTIONAL,
	  current-cell-identifier [7]  CellIdentifier OPTIONAL,
	  last-home-cell-identifier [8] CellIdentifier OPTIONAL,
	  cmServiceType           [9]  INTEGER OPTIONAL,
	  imsi                    [10] IMSI OPTIONAL,
	  first-tmsi              [11] TMSI OPTIONAL,
	  current-tmsi            [12] TMSI OPTIONAL,
	  imei                    [13] IMEI OPTIONAL,
	  bssmap-cause            [14] INTEGER OPTIONAL,
	  cm-aborted              [15] BOOLEAN,
	  classMark1              [16] OCTET STRING OPTIONAL,
	  classMark2              [17] OCTET STRING OPTIONAL,
	  classMark3              [18] OCTET STRING OPTIONAL,
	  assRequestTime          [19] Timestamp OPTIONAL,
	  assCompleteTime         [20] Timestamp OPTIONAL,
	  assFailureTime          [21] Timestamp OPTIONAL,
	  authRequestTime         [22] Timestamp OPTIONAL,
	  authResponseTime        [23] Timestamp OPTIONAL,
	  authFailureTime         [24] Timestamp OPTIONAL,
	  ciphModeCommandTime     [25] Timestamp OPTIONAL,
	  ciphModeCompleteTime    [26] Timestamp OPTIONAL,
	  ciphModeRejectTime      [27] Timestamp OPTIONAL,
	  tmsiReallCommandTime    [28] Timestamp OPTIONAL,
	  tmsiReallCompleteTime   [29] Timestamp OPTIONAL,
	  identityRequestTime     [30] Timestamp OPTIONAL,
	  identityResponseTime    [31] Timestamp OPTIONAL,
	  typeOfIdentity          [32] INTEGER OPTIONAL,
	  res                     [33] OCTET STRING OPTIONAL,
	  pcm-system-first        [34] INTEGER OPTIONAL,
	  ts-system-first         [35] INTEGER OPTIONAL,
	  pcm-system-last         [36] INTEGER OPTIONAL,
	  ts-system-last          [37] INTEGER OPTIONAL,
	  cic                     [38] INTEGER OPTIONAL,
	  clearCommandTime        [39] Timestamp OPTIONAL,
	  bearer-capability       [40] INTEGER OPTIONAL,
	  chRateAndTypeProposed   [41] INTEGER OPTIONAL,
	  chosenMode              [42] INTEGER OPTIONAL,
	  chosenRate              [43] INTEGER OPTIONAL,
	  speechVersion           [44] INTEGER OPTIONAL,
	  permSpeechVersion       [45] OCTET STRING OPTIONAL,
	  transparencyInd         [46] INTEGER OPTIONAL,
	  chTypeDataRate          [47] INTEGER OPTIONAL,
	  allowedRifRates         [48] OCTET STRING OPTIONAL,
	  assymetryIndication     [49] INTEGER OPTIONAL,
	  priority                [50] OCTET STRING OPTIONAL,
	  rr-cause                [51] INTEGER OPTIONAL,
	  reject-cause            [52] INTEGER OPTIONAL,
	  clearRequestTime        [53] Timestamp OPTIONAL,
	  sccpCause               [54] INTEGER OPTIONAL
	*/
	
	
	public ConvCommonData() {
		//
		this.seizure_time = null;
		this.end_time = null;
		this.monitoringInterfaceId = null;
		this.timeout = null;
		this.msc_pc = null;
		this.bsc_pc = null;
		this.first_cell_identifier = null;
		this.current_cell_identifier = null;
		this.last_home_cell_identifier = null;
		this.cmServiceType = null;
		this.imsi = null;
		this.first_tmsi = null;
		this.current_tmsi = null;
		this.imei = null ;
		this.bssmap_cause = null;
		this.cm_aborted = null;
		this.classMark1 = null;
		this.classMark2 = null;
		this.classMark3 = null;
		this.assRequestTime = null;
		this.assCompleteTime = null;
		this.assFailureTime = null;
		this.authRequestTime = null;
		this.authResponseTime = null;
		this.authFailureTime = null;
		this.ciphModeCommandTime = null;
		this.ciphModeCompleteTime = null;
		this.ciphModeRejectTime = null ;
		this.tmsiReallCommandTime = null;
		this.tmsiReallCompleteTime = null ;
		this.identityRequestTime = null ;
		this.identityResponseTime = null ;
		this.typeofidentity = null;
		this.res = null; 
		this.pcm_system_first = null;
		this.ts_system_first = null;
		this.pcm_system_last = null;
		this.ts_system_last = null;
		this.cic = null;
		this.clearCommandTime = null;
		this.bearer_capability = null;
		this.chRateAndTypeProposed = null;
		this.chosenMode = null;
		this.chosenRate = null;
		this.speechVersion = null;
		this.permSpeechVersion = null;
		this.transparencyInd = null ;
		this.chTypeDataRate = null;
		this.allowedRifRates = null;
		this.assymetryIndication = null;
		this.priority = null;
		this.rr_cause = null;
		this.reject_cause = null;
		this.clearRequestTime = null;
		this.sccpCause = null;
	}
	
	public ConvCommonData(CommonData cd) {
		this.seizure_time = null;
		this.end_time = null;
		this.monitoringInterfaceId = null;
		this.timeout = null;
		this.msc_pc = null;
		this.bsc_pc = null;
		this.first_cell_identifier = null;
		this.current_cell_identifier = null;
		this.last_home_cell_identifier = null;
		this.cmServiceType = null;
		this.imsi = null;
		this.first_tmsi = null;
		this.current_tmsi = null;
		this.imei = null ;
		this.bssmap_cause = null;
		this.cm_aborted = null;
		this.classMark1 = null;
		this.classMark2 = null;
		this.classMark3 = null;
		this.assRequestTime = null;
		this.assCompleteTime = null;
		this.assFailureTime = null;
		this.authRequestTime = null;
		this.authResponseTime = null;
		this.authFailureTime = null;
		this.ciphModeCommandTime = null;
		this.ciphModeCompleteTime = null;
		this.ciphModeRejectTime = null ;
		this.tmsiReallCommandTime = null;
		this.tmsiReallCompleteTime = null ;
		this.identityRequestTime = null ;
		this.identityResponseTime = null ;
		this.typeofidentity = null;
		this.res = null; 
		this.pcm_system_first = null;
		this.ts_system_first = null;
		this.pcm_system_last = null;
		this.ts_system_last = null;
		this.cic = null;
		this.clearCommandTime = null;
		this.bearer_capability = null;
		this.chRateAndTypeProposed = null;
		this.chosenMode = null;
		this.chosenRate = null;
		this.speechVersion = null;
		this.permSpeechVersion = null;
		this.transparencyInd = null ;
		this.chTypeDataRate = null;
		this.allowedRifRates = null;
		this.assymetryIndication = null;
		this.priority = null;
		this.rr_cause = null;
		this.reject_cause = null;
		this.clearRequestTime = null;
		this.sccpCause = null;
		
		if (cd == null) {
			return;
		}
		//return 0;
		
		if (cd.seizure_time != null)                    { this.seizure_time = AuxDecoder.decodeDate(cd.seizure_time.octetString); } //  Timestamp   
		if (cd.end_time  != null)                       { this.end_time = AuxDecoder.decodeDate(cd.end_time.octetString); }         //  Timestamp  
		if (cd.monitoringInterfaceId != null)           { this.monitoringInterfaceId = cd.monitoringInterfaceId.val;}  // INTEGER 
		if (cd.timeout != null)                         { this.timeout = cd.timeout.val; }  // Boolean 
		if (cd.msc_pc != null)                          { this.msc_pc = cd.msc_pc.val;} // POINTCODE =~ INTEGER 
		if (cd.bsc_pc != null)                          { this.bsc_pc = cd.bsc_pc.val; } // Pointcode =~ INTEGER  
		if (cd.first_cell_identifier != null)           { this.first_cell_identifier = new ConvCellIdentifier(cd.first_cell_identifier);} // CellIdentifier 
		if (cd.current_cell_identifier != null)         { this.current_cell_identifier = new ConvCellIdentifier(cd.current_cell_identifier); } // Cellidentifier
		if (cd.last_home_cell_identifier != null)       { this.last_home_cell_identifier = new ConvCellIdentifier(cd.last_home_cell_identifier);} // CellIdentifier 
		if (cd.cmServiceType != null)                   { this.cmServiceType = cd.cmServiceType.val; } // Integer 
		if (cd.imsi != null)                            { this.imsi = AuxDecoder.decodeTBCD(cd.imsi.octetString); } // TBCD 
		if (cd.first_tmsi  != null)                     { this.first_tmsi = cd.first_tmsi.octetString; } // TBCD ?
		if (cd.current_tmsi != null)                    { this.current_tmsi = cd.current_tmsi.octetString; } // TBCD ? 
		if (cd.imei != null)                            { this.imei = AuxDecoder.decodeTBCD(cd.imei.octetString); } // TBCD 
		if (cd.bssmap_cause != null)                    { this.bssmap_cause = cd.bssmap_cause.val;} // INTEGER 
		if (cd.cm_aborted != null)                      { this.cm_aborted = cd.cm_aborted.val;} // Boolean
		if (cd.classMark1 != null)                      { this.classMark1 = cd.classMark1.octetString; } // OCTET STRING 
		if (cd.classMark2 != null)                      { this.classMark2 = cd.classMark2.octetString; } // OCTET STRING 
		if (cd.classMark3 != null)                      { this.classMark3 = cd.classMark3.octetString; } // OCTET STRING 
		if (cd.assRequestTime != null)                  { this.assRequestTime = AuxDecoder.decodeDate(cd.assRequestTime.octetString); }
		if (cd.assCompleteTime != null)                 { this.assCompleteTime = AuxDecoder.decodeDate(cd.assCompleteTime.octetString); }
		if (cd.assFailureTime != null )                 { this.assFailureTime = AuxDecoder.decodeDate(cd.assFailureTime.octetString); }
		if (cd.authRequestTime != null )                { this.authRequestTime =  AuxDecoder.decodeDate(cd.authRequestTime.octetString); }
		if (cd.authResponseTime != null)                { this.authResponseTime = AuxDecoder.decodeDate(cd.authResponseTime.octetString); }
		if (cd.authFailureTime != null)                 { this.authFailureTime =  AuxDecoder.decodeDate(cd.authFailureTime.octetString); }   
		if (cd.ciphModeCommandTime != null)             { this.ciphModeCommandTime =  AuxDecoder.decodeDate(cd.ciphModeCommandTime.octetString); }
		if (cd.ciphModeCompleteTime != null)            { this.ciphModeCompleteTime = AuxDecoder.decodeDate(cd.ciphModeCompleteTime.octetString); }
		if (cd.ciphModeRejectTime != null)              { this.ciphModeRejectTime = AuxDecoder.decodeDate(cd.ciphModeRejectTime.octetString); }
		if (cd.tmsiReallCommandTime != null)            { this.tmsiReallCommandTime = AuxDecoder.decodeDate(cd.tmsiReallCommandTime.octetString ); }
		if (cd.tmsiReallCompleteTime != null)           { this.tmsiReallCompleteTime = AuxDecoder.decodeDate( cd.tmsiReallCompleteTime.octetString); } 
		if (cd.identityRequestTime != null)             { this.identityRequestTime =  AuxDecoder.decodeDate(cd.identityRequestTime.octetString); }
		if (cd.identityResponseTime != null)            { this.identityResponseTime =  AuxDecoder.decodeDate(cd.identityResponseTime.octetString); }
		if (cd.typeOfIdentity != null)                  { this.typeofidentity = cd.typeOfIdentity.val;} // INTEGER 
		if (cd.res != null)                             { this.res = cd.res.octetString; } // OCTET STRING 
		if (cd.pcm_system_first != null)                { this.pcm_system_first = cd.pcm_system_first.val;} // INTEGER 
		if (cd.ts_system_first != null)                 { this.ts_system_first = cd.ts_system_first.val;} // INTEGER 
		if (cd.pcm_system_last != null)                 { this.pcm_system_last = cd.pcm_system_last.val;} // INTEGER 
		if (cd.ts_system_last != null)                  { this.ts_system_last=  cd.ts_system_last.val;} // INTEGER 
		if (cd.cic != null)                             { this.cic = cd.cic.val;} // INTEGER 
		if (cd.clearCommandTime != null)                { this.clearCommandTime =  AuxDecoder.decodeDate(cd.clearCommandTime.octetString ); }  
		if (cd.bearer_capability != null)               { this.bearer_capability = cd.bearer_capability.val;} // INTEGER 
		if (cd.chRateAndTypeProposed != null)           { this.chRateAndTypeProposed =  cd.chRateAndTypeProposed.val;} // INTEGER 
		if (cd.chosenMode != null)                      { this.chosenMode =  cd.chosenMode.val;} // INTEGER 
		if (cd.chosenRate != null)                      { this.chosenRate = cd.chosenRate.val;} // INTEGER 
		if (cd.speechVersion != null)                   { this.speechVersion =  cd.speechVersion.val;} // INTEGER 
		if (cd.permSpeechVersion != null)               { this.permSpeechVersion = cd.permSpeechVersion.octetString; } // OCTET STRING 
		if (cd.transparencyInd != null)                 { this.transparencyInd = cd.transparencyInd.val;} // INTEGER 
		if (cd.chTypeDataRate != null)                  { this.chTypeDataRate = cd.chTypeDataRate.val; } // INTEGER 
		if (cd.allowedRifRates != null)                 { this.allowedRifRates = cd.allowedRifRates.octetString; } // OCTET STRING 
		if (cd.assymetryIndication != null)             { this.assymetryIndication = cd.assymetryIndication.val;} // INTEGER 
		if (cd.priority != null)                        { this.priority = cd.priority.octetString; } // OCTET STRING 
		if (cd.rr_cause != null)                        { this.rr_cause =  cd.rr_cause.val;} // INTEGER 
		if (cd.reject_cause != null)                    { this.reject_cause = cd.reject_cause.val;} // INTEGER 
		if (cd.clearRequestTime != null)                { this.clearRequestTime = AuxDecoder.decodeDate(cd.clearRequestTime.octetString ); }
		if (cd.sccpCause != null)                       { this.sccpCause = cd.sccpCause.val; } // INTEGER 
	}
	
	public int decode(CommonData cd) {
		
		/* instead of initializing everything, we migth do it this with ... =  ? ... : ... ;
		 * 
		 */
		
		// all this stuff should really be in the constructor
		
		//return null;
		
		
		this.seizure_time = null;
		this.end_time = null;
		this.monitoringInterfaceId = null;
		this.timeout = null;
		this.msc_pc = null;
		this.bsc_pc = null;
		this.first_cell_identifier = null;
		this.current_cell_identifier = null;
		this.last_home_cell_identifier = null;
		this.cmServiceType = null;
		this.imsi = null;
		this.first_tmsi = null;
		this.current_tmsi = null;
		this.imei = null ;
		this.bssmap_cause = null;
		this.cm_aborted = null;
		this.classMark1 = null;
		this.classMark2 = null;
		this.classMark3 = null;
		this.assRequestTime = null;
		this.assCompleteTime = null;
		this.assFailureTime = null;
		this.authRequestTime = null;
		this.authResponseTime = null;
		this.authFailureTime = null;
		this.ciphModeCommandTime = null;
		this.ciphModeCompleteTime = null;
		this.ciphModeRejectTime = null ;
		this.tmsiReallCommandTime = null;
		this.tmsiReallCompleteTime = null ;
		this.identityRequestTime = null ;
		this.identityResponseTime = null ;
		this.typeofidentity = null;
		this.res = null; 
		this.pcm_system_first = null;
		this.ts_system_first = null;
		this.pcm_system_last = null;
		this.ts_system_last = null;
		this.cic = null;
		this.clearCommandTime = null;
		this.bearer_capability = null;
		this.chRateAndTypeProposed = null;
		this.chosenMode = null;
		this.chosenRate = null;
		this.speechVersion = null;
		this.permSpeechVersion = null;
		this.transparencyInd = null ;
		this.chTypeDataRate = null;
		this.allowedRifRates = null;
		this.assymetryIndication = null;
		this.priority = null;
		this.rr_cause = null;
		this.reject_cause = null;
		this.clearRequestTime = null;
		this.sccpCause = null;
		
		//return 0;
		
		if (cd.seizure_time != null)                    { this.seizure_time = AuxDecoder.decodeDate(cd.seizure_time.octetString); } //  Timestamp   
		if (cd.end_time  != null)                       { this.end_time = AuxDecoder.decodeDate(cd.end_time.octetString); }         //  Timestamp  
		if (cd.monitoringInterfaceId != null)           { this.monitoringInterfaceId = cd.monitoringInterfaceId.val;}  // INTEGER 
		if (cd.timeout != null)                         { this.timeout = cd.timeout.val; }  // Boolean 
		if (cd.msc_pc != null)                          { this.msc_pc = cd.msc_pc.val;} // POINTCODE =~ INTEGER 
		if (cd.bsc_pc != null)                          { this.bsc_pc = cd.bsc_pc.val; } // Pointcode =~ INTEGER  
		if (cd.first_cell_identifier != null)           { this.first_cell_identifier = null;} // CellIdentifier 
		if (cd.current_cell_identifier != null)         { this.current_cell_identifier = null; } // Cellidentifier
		if (cd.last_home_cell_identifier != null)       { this.last_home_cell_identifier = null;} // CellIdentifier 
		if (cd.cmServiceType != null)                   { this.cmServiceType = cd.cmServiceType.val; } // Integer 
		if (cd.imsi != null)                            { this.imsi = AuxDecoder.decodeTBCD(cd.imsi.octetString); } // TBCD 
		if (cd.first_tmsi  != null)                     { this.first_tmsi = cd.first_tmsi.octetString; } // TBCD ?
		if (cd.current_tmsi != null)                    { this.current_tmsi = cd.current_tmsi.octetString; } // TBCD ? 
		if (cd.imei != null)                            { this.imei = AuxDecoder.decodeTBCD(cd.imei.octetString); } // TBCD 
		if (cd.bssmap_cause != null)                    { this.bssmap_cause = cd.bssmap_cause.val;} // INTEGER 
		if (cd.cm_aborted != null)                      { this.cm_aborted = cd.cm_aborted.val;} // Boolean
		if (cd.classMark1 != null)                      { this.classMark1 = cd.classMark1.octetString; } // OCTET STRING 
		if (cd.classMark2 != null)                      { this.classMark2 = cd.classMark2.octetString; } // OCTET STRING 
		if (cd.classMark3 != null)                      { this.classMark3 = cd.classMark3.octetString; } // OCTET STRING 
		if (cd.assRequestTime != null)                  { this.assRequestTime = AuxDecoder.decodeDate(cd.assRequestTime.octetString); }
		if (cd.assCompleteTime != null)                 { this.assCompleteTime = AuxDecoder.decodeDate(cd.assCompleteTime.octetString); }
		if (cd.assFailureTime != null )                 { this.assFailureTime = AuxDecoder.decodeDate(cd.assFailureTime.octetString); }
		if (cd.authRequestTime != null )                { this.authRequestTime =  AuxDecoder.decodeDate(cd.authRequestTime.octetString); }
		if (cd.authResponseTime != null)                { this.authResponseTime = AuxDecoder.decodeDate(cd.authResponseTime.octetString); }
		if (cd.authFailureTime != null)                 { this.authFailureTime =  AuxDecoder.decodeDate(cd.authFailureTime.octetString); }   
		if (cd.ciphModeCommandTime != null)             { this.ciphModeCommandTime =  AuxDecoder.decodeDate(cd.ciphModeCommandTime.octetString); }
		if (cd.ciphModeCompleteTime != null)            { this.ciphModeCompleteTime = AuxDecoder.decodeDate(cd.ciphModeCompleteTime.octetString); }
		if (cd.ciphModeRejectTime != null)              { this.ciphModeRejectTime = AuxDecoder.decodeDate(cd.ciphModeRejectTime.octetString); }
		if (cd.tmsiReallCommandTime != null)            { this.tmsiReallCommandTime = AuxDecoder.decodeDate(cd.tmsiReallCommandTime.octetString ); }
		if (cd.tmsiReallCompleteTime != null)           { this.tmsiReallCompleteTime = AuxDecoder.decodeDate( cd.tmsiReallCompleteTime.octetString); } 
		if (cd.identityRequestTime != null)             { this.identityRequestTime =  AuxDecoder.decodeDate(cd.identityRequestTime.octetString); }
		if (cd.identityResponseTime != null)            { this.identityResponseTime =  AuxDecoder.decodeDate(cd.identityResponseTime.octetString); }
		if (cd.typeOfIdentity != null)                  { this.typeofidentity = cd.typeOfIdentity.val;} // INTEGER 
		if (cd.res != null)                             { this.res = cd.res.octetString; } // OCTET STRING 
		if (cd.pcm_system_first != null)                { this.pcm_system_first = cd.pcm_system_first.val;} // INTEGER 
		if (cd.ts_system_first != null)                 { this.ts_system_first = cd.ts_system_first.val;} // INTEGER 
		if (cd.pcm_system_last != null)                 { this.pcm_system_last = cd.pcm_system_last.val;} // INTEGER 
		if (cd.ts_system_last != null)                  { this.ts_system_last=  cd.ts_system_last.val;} // INTEGER 
		if (cd.cic != null)                             { this.cic = cd.cic.val;} // INTEGER 
		if (cd.clearCommandTime != null)                { this.clearCommandTime =  AuxDecoder.decodeDate(cd.clearCommandTime.octetString ); }  
		if (cd.bearer_capability != null)               { this.bearer_capability = cd.bearer_capability.val;} // INTEGER 
		if (cd.chRateAndTypeProposed != null)           { this.chRateAndTypeProposed =  cd.chRateAndTypeProposed.val;} // INTEGER 
		if (cd.chosenMode != null)                      { this.chosenMode =  cd.chosenMode.val;} // INTEGER 
		if (cd.chosenRate != null)                      { this.chosenRate = cd.chosenRate.val;} // INTEGER 
		if (cd.speechVersion != null)                   { this.speechVersion =  cd.speechVersion.val;} // INTEGER 
		if (cd.permSpeechVersion != null)               { this.permSpeechVersion = cd.permSpeechVersion.octetString; } // OCTET STRING 
		if (cd.transparencyInd != null)                 { this.transparencyInd = cd.transparencyInd.val;} // INTEGER 
		if (cd.chTypeDataRate != null)                  { this.chTypeDataRate = cd.chTypeDataRate.val; } // INTEGER 
		if (cd.allowedRifRates != null)                 { this.allowedRifRates = cd.allowedRifRates.octetString; } // OCTET STRING 
		if (cd.assymetryIndication != null)             { this.assymetryIndication = cd.assymetryIndication.val;} // INTEGER 
		if (cd.priority != null)                        { this.priority = cd.priority.octetString; } // OCTET STRING 
		if (cd.rr_cause != null)                        { this.rr_cause =  cd.rr_cause.val;} // INTEGER 
		if (cd.reject_cause != null)                    { this.reject_cause = cd.reject_cause.val;} // INTEGER 
		if (cd.clearRequestTime != null)                { this.clearRequestTime = AuxDecoder.decodeDate(cd.clearRequestTime.octetString ); }
		if (cd.sccpCause != null)                       { this.sccpCause = cd.sccpCause.val; } // INTEGER 
		
		//Long testv = cd.assymetryIndication.val;
		return 1;
		
	}
	
}