package com.proximus.bigdata.osix.asn1.iface.aif.intake;

import java.util.Date;
import java.io.Serializable;


public class LocationDataStore implements Serializable {

	/* attributes */
	public String TransactionType;
	public int RecordType;
	public long TransactionID;
	public Date network_event_date;
	public long IMSI;
	public long CellID;
	public long LocationAreaCode;
	public long RoutingAreaCode;
	public int lutype; /* location_update type */
}
