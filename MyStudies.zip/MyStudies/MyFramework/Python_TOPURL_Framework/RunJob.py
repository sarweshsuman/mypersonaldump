# Module Name : RunJob.py
#
#
#
#
######################################################

import argparse
import subprocess
import time
import ConfigParser
import os
import sys
import time
import logging

filename=os.path.basename(__file__)
current_working_directory=os.path.dirname(__file__)
sys.path.append(current_working_directory+"/Default_Plugins")

run_configuration={} #stores all the run context

job=None
job_definition_file=None

args_parser = argparse.ArgumentParser(description="Master Program of the framework")
args_parser.add_argument("--job",help="Job to Start",required=True)
args_parser.add_argument("--properties",help="Job definition properties file",required=True)
args_parser.add_argument("-d","--detach",help="Run in background")

args = vars(args_parser.parse_args())

if args['detach']:
	print "Run in background.."
	subprocess.Popen(["python",__file__,"--job",args['job'],"--properties",args['properties']])
	exit(0)

job=args['job']
job_definition_file=args['properties']

run_configuration['RUNJOB_PID']=os.getpid()
run_configuration['JOBNAME']=job
run_configuration['CURRENTDIR']=current_working_directory
run_configuration['RUN_SEQUENCE']=int(time.time())

if os.path.isfile(job_definition_file) == False:
	print "Job Definition File does not exists, exiting.."
	exit(1)

job_config = ConfigParser.SafeConfigParser()
job_config.read(job_definition_file)

if not 'framework' in job_config.sections():
	exit(1)

import JobSupervisor

# Importing all the Framework Modules
currlyresolver_module=__import__(job_config.get('framework','CURRLYRESOLVER'))
jobbuilder_module=__import__(job_config.get('framework','BUILDJOB'))
run_configuration_manager_module=__import__(job_config.get('framework','RUNCONFIGURATIONMANAGER'))

# Initiating Framework Modules
resolver=currlyresolver_module.CurrlyResolver()
run_configuration['RESOLVER']=resolver
run_configuration['JOB_CONFIG']=job_config

rcm_ip=job_config.get('configuration','run_configuration_manager.server.ip')
rcm_port=job_config.get('configuration','run_configuration_manager.server.port')
run_configuration_manager_obj=run_configuration_manager_module.RunConfigurationManager(rcm_ip,rcm_port,run_configuration)
run_configuration_manager_obj.start()

jobbuilder=jobbuilder_module.JobBuilder(run_configuration_manager_module,rcm_ip,rcm_port)

jb = JobSupervisor.JobSupervisor(run_configuration_manager_module,rcm_ip,rcm_port)
jb._start()

#print "From RunJob"
#print run_configuration
#import re
#for section in job_config.sections():
#	for option in job_config.options(section):
#		string=job_config.get(section,option)
#		string=re.sub(r'FILE:',r'',string)
#		print "String before change "+string
#		print "After resolving "+resolver.resolve(string)

