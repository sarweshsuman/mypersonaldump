import os
import shutil
import smtplib
import time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

class CommonSteps:
	run_configuration=None
	rcm_obj=None
	resolver=None
	def __init__(self):
		print "Initializing Common Steps"
		#print self.run_configuration
	def _initialize(self,rcm_obj):
		self.rcm_obj=rcm_obj
		self.resolver=self.rcm_obj.get('RESOLVER')
	def listdir(self,rcm_obj,statistics,output,args=()):
		self._initialize(rcm_obj)
		stepnumber=args[0]
		dirlist=os.listdir(self.resolver.resolve(self.rcm_obj,'{{FINDSTEPPARAM:'+str(stepnumber)+';dir.to.list}}'))
		self.rcm_obj.set('JOBRUNNER/STEPSRESULT/'+str(stepnumber),dirlist)
		dict={}
		dict['numberoffileslisted']=len(dirlist)
		dict['status']='success'
		statistics.put(dict)
	def deletefile(self,rcm_obj,statistics,output,args=()):
		""" 
			Mandatory field in run_configuration = deletefile 
	    		Type of field = list or string
			Return Type = None 
		"""
		self._initialize(rcm_obj)
		stepnumber=args[0]
		deletefile=self.resolver.resolve(self.rcm_obj,'{{FINDSTEPPARAM:'+str(stepnumber)+';deletefile}}')
		dict={}
		if not deletefile:
			self.rcm_obj.set('JOBRUNNER/STEPSRESULT/'+str(stepnumber),[])
			dict['status']='failed'
			dict['errormsg']='found no('+str(deletefile)+') file'
			statistics.put(dict)
			return
		if isinstance(deletefile,type([])):
			for file in deletefile:
				if os.path.isfile(file):
					os.remove(file)
			self.rcm_obj.set('JOBRUNNER/STEPSRESULT/'+str(stepnumber),deletefile)
			dict['numberoffilesdeleted']=len(deletefile)
			dict['status']='success'
		elif isinstance(deletefile,type('')):
			if os.path.isfile(deletefile):
				os.remove(deletefile)
			self.rcm_obj.set('JOBRUNNER/STEPSRESULT/'+str(stepnumber),[deletefile])
			dict['numberoffilesdeleted']=1
			dict['status']='success'
		statistics.put(dict)
	def runcommand(self,rcm_obj,statistics,output,args=()):
		""" 
			Mandatory field in run_configuration = runcommand
		    	Type of field = string 
			Return Type = None 
		"""
		self._initialize(rcm_obj)
		stepnumber=args[0]
		runcommand=self.resolver.resolve(self.rcm_obj,'{{FINDSTEPPARAM:'+str(stepnumber)+';runcommand}}')
		if not runcommand:
			self.rcm_obj.set('JOBRUNNER/STEPSRESULT/'+str(stepnumber),[])
			return
		commandtolist=runcommand.split(" ")
		subprocess.Popen(commandtolist)
		self.rcm_obj.set('JOBRUNNER/STEPSRESULT/'+str(stepnumber),[])
	def movefile(self,rcm_obj,statistics,output,args=()):
		""" 
			Mandatory field in run_configuration = movefile , fromdir , todir
	 	   	Type of field = string or list
			Return Type = None 
		"""
		#print args
		self._initialize(rcm_obj)
		stepnumber=args[0]
		statusofstep=args[1]
		dict={}
		dict[stepnumber]={}
		
		dict2={}
		#print self.run_configuration
		try:
			movefile=self.resolver.resolve(self.rcm_obj,'{{FINDSTEPPARAM:'+str(stepnumber)+';movefile}}')
			fromdir=self.resolver.resolve(self.rcm_obj,'{{FINDSTEPPARAM:'+str(stepnumber)+';fromdir}}')
			todir=self.resolver.resolve(self.rcm_obj,'{{FINDSTEPPARAM:'+str(stepnumber)+';todir}}')
			filesmoved=[]
			if not movefile or not fromdir or not todir:
				return
			if type([]) == type(movefile):
				for file in movefile:
					shutil.move(fromdir+"/"+file,todir+"/"+file)
					filesmoved.append(fromdir+"/"+file)
			elif type(movefile) == type(" "):
				shutil.move(fromdir+"/"+movefile,todir+"/"+movefile)
				filesmoved.append(fromdir+"/"+movefile)
			dict[stepnumber]['STEPSRUNSTATUS']='success'
			dict[stepnumber]['ERRORREASON']=""
			self.rcm_obj.set('JOBRUNNER/STEPSRESULT/'+str(stepnumber),filesmoved)
			dict2['numberoffilesmoved']=len(filesmoved)
			dict2['status']='success'
		except Exception as e :
			#print "Caught Exception"
			dict[stepnumber]['STEPSRUNSTATUS']='failed'
			dict[stepnumber]['ERRORREASON']=e.__str__()
			self.rcm_obj.set('JOBRUNNER/STEPSRESULT/'+str(stepnumber),[])
			dict2['numberoffilesmoved']=0
			dict2['status']='failed'
		statusofstep.put(dict)
		statistics.put(dict2)
			#print self.run_configuration
	def sendmail(self,rcm_obj,statistics,output,args=()):
		"""
		"""
		self._initialize(rcm_obj)
		stepnumber=args[0]
		statusofstep=args[1]
		dict={}
		dict[stepnumber]={}
		mailfrom=self.resolver.resolve(self.rcm_obj,'{{FINDSTEPPARAM:'+str(stepnumber)+';mail.from}}')
		mailto=self.resolver.resolve(self.rcm_obj,'{{FINDSTEPPARAM:'+str(stepnumber)+';mail.to}}')
		mailsubject=self.resolver.resolve(self.rcm_obj,'{{FINDSTEPPARAM:'+str(stepnumber)+';mail.subject}}')
		part=MIMEText(self.resolver.resolve(self.rcm_obj,'{{FINDSTEPPARAM:'+str(stepnumber)+';mail.text}}'), 'text')
		msg = MIMEMultipart('alternative')
		msg['Subject']=mailsubject
		msg['From']=mailfrom
		msg['To']=mailto
		msg.attach(part)
		s=smtplib.SMTP('localhost')
		s.sendmail(mailfrom,mailto.split(","),msg.as_string())
		s.quit()
		dict[stepnumber]['STEPSRUNSTATUS']='success'
		dict[stepnumber]['ERRORREASON']=""
		statusofstep.put(dict)
		
