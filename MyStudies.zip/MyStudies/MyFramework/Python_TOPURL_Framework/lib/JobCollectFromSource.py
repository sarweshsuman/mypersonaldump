from ftplib import FTP
import re
import os
import BaseSteps

class JobCollectFromSource(BaseSteps.BaseSteps):
	rcm_obj=None
	source_ip=None
	source_username=None
	source_password=None
	source_path=None
	source_filepattern=None
	destination_path=None
	history_file=None
	protocol=None
	
	stepnumber=None
	protocol2function={}
		
	resolver=None
	logger=None

	statistics_queue=None
	steprunstatus=None
	def __init__(self):
		#BaseSteps.BaseSteps.__init__(self)
		self.protocol2function={
					'ftp':self._ftp,
					'sftp':self._sftp,
		}
	def _initialize(self,rcm_obj,statistics_queue,stepnumber,steprunstatus,logger):
		self.rcm_obj=rcm_obj
		self.resolver=self.rcm_obj.get('RESOLVER')
		self.stepnumber=stepnumber
		self.logger=logger
		self.steprunstatus=steprunstatus
		self.statistics_queue=statistics_queue
		
		self.source_ip=self.resolver.resolve(self.rcm_obj,self.rcm_obj.get('JOBRUNNER/STEPSCONFIG/'+str(stepnumber)+'/source.ip'))
		self.source_username=self.resolver.resolve(self.rcm_obj,self.rcm_obj.get('JOBRUNNER/STEPSCONFIG/'+str(stepnumber)+'/source.username'))
		self.source_password=self.resolver.resolve(self.rcm_obj,self.rcm_obj.get('JOBRUNNER/STEPSCONFIG/'+str(stepnumber)+'/source.password'))
		self.source_path=self.resolver.resolve(self.rcm_obj,self.rcm_obj.get('JOBRUNNER/STEPSCONFIG/'+str(stepnumber)+'/source.file.path'))
		self.source_filepattern=self.resolver.resolve(self.rcm_obj,self.rcm_obj.get('JOBRUNNER/STEPSCONFIG/'+str(stepnumber)+'/source.file.pattern'))
		self.protocol=self.resolver.resolve(self.rcm_obj,self.rcm_obj.get('JOBRUNNER/STEPSCONFIG/'+str(stepnumber)+'/protocol'))
		self.destination_path=self.resolver.resolve(self.rcm_obj,self.rcm_obj.get('JOBRUNNER/STEPSCONFIG/'+str(stepnumber)+'/destination.path'))
		self.history_file=self.resolver.resolve(self.rcm_obj,self.rcm_obj.get('JOBRUNNER/STEPSCONFIG/'+str(stepnumber)+'/history.file'))
		
		if not os.path.isfile(self.history_file):
			print "History File not present, creating"
			os.system("touch "+self.history_file)
	def run(self,rcm_obj,statistics_queue,output,args):
		self._initialize(rcm_obj,statistics_queue,args[0],args[1],args[2])
		#dict2={}
		#dict={}
		#dict[self.stepnumber]={}
		try:
			self.protocol2function[self.protocol.lower()]()
			self._steprunstatus("success","")
			#dict[self.stepnumber]['STEPSRUNSTATUS']='success'
			#dict[self.stepnumber]['ERRORREASON']=""
		except Exception as e :
			self._steprunstatus("falied",e.__str__())
			#dict[self.stepnumber]['STEPSRUNSTATUS']='failed'
			#dict[self.stepnumber]['ERRORREASON']=e.__str__()	
		#statistics_queue.put(dict2)
		#steprunstatus.put(dict)
	def _ftp_connect(self):
		self.logger.send(["INFO","Connecting to host"+str(self.source_ip)])
		ftp=FTP(self.source_ip)
		ftp.login(self.source_username,self.source_password)
		return ftp
	def _ftp(self):
		dict={}
		ftp=self._ftp_connect()
		self.logger.send(["INFO","changing working directory "+self.source_path])
		ftp.cwd(self.source_path)
		file_list=ftp.nlst()
		actualdownloadedfiles=[]
		filestodownload=[]
		filesalreadydownloaded=[]

		f=open(self.history_file,'r')
		filesalreadydownloaded=f.readlines()
		f.close()
	
		w=open(self.history_file,'a')
		for f in file_list:
			if re.search(self.source_filepattern,f):
				filestodownload.append(f)
		for f in filestodownload:
			if f+"\n" in filesalreadydownloaded:
				continue	
			file_handle=open(self.destination_path+"/"+f,'wb')
			ftp.retrbinary('RETR '+f,file_handle.write)
			file_handle.close()
			w.write(f)
			w.write("\n")
			actualdownloadedfiles.append(f)
		self.logger.send(["INFO","Number Of Files Downloaded "+str(len(actualdownloadedfiles))])
		w.close()
		ftp.quit()
		self._statistics("numberoffilesdownloaded",len(actualdownloadedfiles))
		self._statistics("status","success")
		self._setoutput(actualdownloadedfiles)
		#self.rcm_obj.set('JOBRUNNER/STEPSRESULT/'+str(self.stepnumber),actualdownloadedfiles)
		return dict
	def _sftp(self):
		pass
