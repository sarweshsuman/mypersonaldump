
class JobResultCollector:
	pass
