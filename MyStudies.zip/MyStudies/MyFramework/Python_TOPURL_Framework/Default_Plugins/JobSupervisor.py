from multiprocessing import *
import time

class JobSupervisor:
	rcm_module=None
	rcm_obj=None
	rcm_ip=None
	rcm_port=None
	job_config=None
	job_runner=None
	job_logger=None

	send_joblogger=None
	recv_joblogger=None

	send_supervisor=None
	recv_supervisor=None
	def __init__(self,run_configuration_manager_module,rcm_ip,rcm_port):
	
		self.rcm_module=run_configuration_manager_module
		self.rcm_ip=rcm_ip
		self.rcm_port=rcm_port
		
		self.rcm_obj=self.rcm_module.RunConfigurationManager.connect(self.rcm_ip,self.rcm_port)
		
		self.rcm_obj.set('JOBSUPERVISOR',{})
		self.rcm_obj.set('JOBSUPERVISOR/JOBS',[])
		#self.run_configuration['JOBSUPERVISOR']={}
		#self.run_configuration['JOBSUPERVISOR']['JOBS']=[]
		
		self.job_config=self.rcm_obj.get('JOB_CONFIG')
		self.recv_joblogger,self.send_joblogger = Pipe()

		#self.rcm_obj.set('JOBSUPERVISOR/SEND_JOBLOGGER',jobrunner)
		#self.rcm_obj.set('JOBSUPERVISOR/RECV_JOBLOGGER',logger)
		#self.run_configuration['JOBSUPERVISOR']['SEND_JOBLOGGER']=jobrunner
		#self.run_configuration['JOBSUPERVISOR']['RECV_JOBLOGGER']=logger
	
		self.recv_supervisor,self.send_supervisor = Pipe()
		
		jobrunner=__import__(self.job_config.get('framework','JOBRUNNER'))
		#self.rcm_obj.set('JOBSUPERVISOR/SEND_JOBSUPERVISOR',child)
		#self.rcm_obj.set('JOBSUPERVISOR/RECV_JOBSUPERVISOR',supervisor)
		self.job_runner=jobrunner.JobRunner(self.rcm_obj,self.send_supervisor,self.send_joblogger)
		#self.rcm_obj.set('JOBSUPERVISOR/JOBRUNNER',jobrunner.JobRunner(self.rcm_ip,self.rcm_port,self.job_config))
		#self.run_configuration['JOBSUPERVISOR']['SEND_JOBSUPERVISOR']=child
		#self.run_configuration['JOBSUPERVISOR']['RECV_JOBSUPERVISOR']=supervisor
		#self.run_configuration['JOBSUPERVISOR']['JOBRUNNER']=jobrunner.JobRunner(self.run_configuration)
		
		joblogger=__import__(self.job_config.get('framework','JOBLOGGER'))
		self.job_logger=joblogger.JobLogger(self.rcm_obj,self.send_supervisor,self.recv_joblogger)
		#self.rcm_obj.set('JOBSUPERVISOR/JOBLOGGER',joblogger.JobLogger(self.rcm_obj))

		#print self.rcm_obj.display()
		#self.run_configuration['JOBSUPERVISOR']['JOBLOGGER']=joblogger.JobLogger(self.run_configuration)
	def _start(self):
		# I will start JobRunner and JobLogger and I will not quit ,  I will monitor those threads
		p2 = Process(target=self.job_logger.run,args=())
		#self.run_configuration['JOBSUPERVISOR']['JOBS'].append(p2)
		p2.start()
	
		self.send_joblogger.send(["DEBUG","JOBSUPERVISOR : Started JobLogger"])	
		self.send_joblogger.send(["DEBUG","JOBSUPERVISOR : Starting JobRunner"])	
		p1 = Process(target=self.job_runner.run,args=())
		#self.run_configuration['JOBSUPERVISOR']['JOBS'].append(p1)
		p1.start()
		self.send_joblogger.send(["DEBUG","JOBSUPERVISOR : Waiting for JobRunner to Complete"])	
		p1.join()
		recv=self.recv_supervisor.recv()
		self.send_joblogger.send(["DEBUG","JOBSUPERVISOR : Received Following Status from JobRunner "+recv])	
		self.send_joblogger.send(["DEBUG","JOBSUPERVISOR : Terminating JobLogger"])	
		#print self.run_configuration
		p2.terminate()
