
class BaseSteps:
	def _steprunstatus(self,runstatus,errorreason):
		dict={}
		if self.steprunstatus and self.stepnumber:
			dict[self.stepnumber]={}
			dict[self.stepnumber]['STEPSRUNSTATUS']=runstatus
			dict[self.stepnumber]['ERRORREASON']=errorreason
			self.steprunstatus.put(dict)
		else:
			raise Exception("steprunstatus queue or stepnumber not found!")	
	def _statistics(self,key,value):
		if self.statistics_queue:
			if self.statistics_queue.qsize() != 0:
				dict=self.statistics_queue.get()
				dict[key]=value
				self.statistics_queue.put(dict)			
			else:
				dict={}
				dict[key]=value
				self.statistics_queue.put(dict)
		else :
			raise Exception("statistics_queue not found")
	def _setoutput(self,output):
		if not type(output) == type([]):
			raise Exception("Only type list is acceptable while setting output for a step")
			return
		if self.rcm_obj and self.stepnumber:
			rv=self.rcm_obj.get('JOBRUNNER/STEPSRESULT/'+str(self.stepnumber))
			if not rv:
				self.rcm_obj.set('JOBRUNNER/STEPSRESULT/'+str(self.stepnumber),output)
			else :
				self.rcm_obj.set('JOBRUNNER/STEPSRESULT/'+str(self.stepnumber),rv+output)	
		else:
			raise Exception("rcm obj not found or stepnumber not found")
