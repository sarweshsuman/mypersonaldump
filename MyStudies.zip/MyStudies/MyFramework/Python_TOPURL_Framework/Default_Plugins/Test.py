import RunConfigurationManager
print "Loaded RunConfiguration"
from time import *
import cPickle as pickle
from multiprocessing import *
import sys
import re

cmnd_line={}

for i in sys.argv:
	if not re.search("=",i):
		continue
	key,value=i.split("=")
	cmnd_line[key]=value

print cmnd_line
exit(1)
class A:
	def abcd(self):
		print "HELLO"

obj1=A()
obj=getattr(obj1,'abcd')

run_configuration={
'JOBRUNNER': 
{
'STEPSRUNSTATUS': {1: 'failed'}, 'ERRORREASON': {1: "[Errno 2] No such file or directory: '/home/pmtd/PMT_NP_TotalQueries_5743_20151203141500.csv'"}, 
'STEPSCONFIG': 
{1: {'movefile': 'PMT_NP_TotalQueries_5743_20151203141500.csv', 'fromdir': '/home/pmtd', 'todir': '/tmp'}, 2: {'mail.text': 'This is test', 'mail.from': 'PMT', 'mail.to': 'id832037@proximus.com', 'mail.subject': 'This is test'}}, 
'STEPS':[obj]
}
}
rcm=RunConfigurationManager.RunConfigurationManager('127.0.0.1',5000,run_configuration)
rcm.start()
#sleep(2)

rcm2=RunConfigurationManager.RunConfigurationManager.connect('127.0.0.1',5000)
#print obj.get('JOBRUNNER/STEPSCONFIG/1/movefile')

#print type(obj1)
rcm2.set('JOBRUNNER/STEPSCONFIG/1/movefile',obj1)
print rcm2.display()['JOBRUNNER']['STEPSCONFIG'][1]['movefile']()
exit(1)

rcm2.set('JOBRUNNER/STEPSCONFIG/1/movefile',obj1)
callme= rcm2.get('JOBRUNNER/STEPSCONFIG/1/movefile')

callme.abcd()

exit(1)
p1=Process(target=obj.set,args=('JOBRUNNER/STEPSCONFIG/1/movefile','sarwesh',1))
p2=Process(target=obj.set,args=('JOBRUNNER/STEPSCONFIG/1/movefile','suman',2))

p1.start()
p2.start()
#print "SLEEPING 1"
#sleep(10)
#obj.set('JOBRUNNER/STEPSCONFIG/1/movefile','sarwesh')
#print "SLEEPING 2"
#sleep(10)
print "waiting for process to finish"
p1.join()
p2.join()
print "Printing from parent"
print obj.get('JOBRUNNER/STEPSCONFIG/1/movefile')

func=obj.get('JOBRUNNER/STEPS')[0]
func()
#send,recv=RunConfigurationManager.RunConfigurationManager.connect('127.0.0.1',5000)
#print send('set JOBRUNNER/STEPSCONFIG/1/movefile=sarwesh')

#send,recv=RunConfigurationManager.RunConfigurationManager.connect('127.0.0.1',5000)
#print send('display')
#print pickle.loads(recv(1024) )
