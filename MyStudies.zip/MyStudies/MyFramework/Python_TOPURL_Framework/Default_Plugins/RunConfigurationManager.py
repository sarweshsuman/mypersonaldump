import socket
from multiprocessing import *
import re
import time
import os
import sys
import copy_reg
import types
#import cPickle as pickle
import pickle

def _pickle_method_(method): 
     func_name = method.im_func.__name__
     obj = method.im_self
     cls =  method.im_class
     return _unpickle_method_, (func_name, obj, cls)

def _unpickle_method_(func_name, obj, cls):
     func = cls.__dict__[func_name]
     return func.__get__(obj, cls)

copy_reg.pickle(types.MethodType, _pickle_method_, _unpickle_method_)

class RunConfigurationServer:
	run_configuation=None
	ip=None
	port=None
	v_socket=None
	methods=None
	client_address=None
	def __init__(self,ip,port,run_configuration):
		self.run_configuration=run_configuration
		self.methods = {
				'get':self._get,
				'display':self._display,
				'set':self._set,
				'addpath':self._addpath,
		}
		self.ip=str(ip)
		self.port=int(port)
		self.v_socket=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
		self.v_socket.bind((self.ip,self.port))
	def _addpath(self,path):
		try:
			sys.path.append(pickle.loads(path))
		except Exception as e:
			print "Exception in _addpath "
	def _start(self):
		while True:
			data,self.client_address=self.v_socket.recvfrom(4096)
			#print "Received Connection from "+str(self.client_address)
			#new_data=re.sub('\s+',' ',data)
			args=data.split('????????')
			if len(args) == 1 :
				args.append(None)
			self.methods[args[0].lower()](args[1])
	def _get(self,args):
		keys=args.split('/')
		tmp_run_configuration=self.run_configuration
		try:
			for k in keys:
				if re.search('^[0-9]+$',k):
					value=tmp_run_configuration[int(k)]
					tmp_run_configuration=value
					continue
				value=tmp_run_configuration[k]
				tmp_run_configuration=value
		except Exception as e:
			print "Exception at RunConfigurationManager:_get " + e.__str__()
			value=None
		data_string=pickle.dumps(value)
		self.v_socket.sendto(data_string,self.client_address)
	def _set(self,args):
		key,valuetoset=args.split('equalsto')
		#print sys.getsizeof(valuetoset)
		keys=key.split('/')
		lastkey=keys.pop()
		tmp_run_configuration=self.run_configuration
		for k in keys:
			if re.search('^[0-9][0-9]*$',k):
				if int(k) in tmp_run_configuration.keys():
					tmp_run_configuration=tmp_run_configuration[int(k)]
				else :
					tmp_run_configuration[int(k)]={}
				continue
			if k in tmp_run_configuration.keys():
				tmp_run_configuration=tmp_run_configuration[k]
			else :
				tmp_run_configuration[k]={}
		try:
			if re.search('^[0-9]+$',lastkey):
				tmp_run_configuration[int(lastkey)]=pickle.loads(valuetoset)
			else:
				tmp_run_configuration[lastkey]=pickle.loads(valuetoset)
		except EOFError as e:
			print "Received EOFError " + e.__str__()
			tmp_run_configuration[lastkey]=valuetoset
		except Exception as e:
			print "Exception at RunConfigurationManager:_set "+key + " " + e.__str__()
			tmp_run_configuration[lastkey]=valuetoset
	def _display(self,args):
		data_string=pickle.dumps(self.run_configuration,-1)
		self.v_socket.sendto(data_string,self.client_address)
# rcm('get JOBRUNNER/STEPSRESULT')
# rcm('set JOBRUNNER/STEPSRESULT/1=[a,b,c])
class RunConfigurationManager:
	runconfigurationserver=None
	server_process=None
	def __init__(self,ip,port,run_configuration):
		self.runconfigurationserver=RunConfigurationServer(ip,port,run_configuration)
		func=getattr(self.runconfigurationserver,'_start')
		self.server_process=Process(target=func,args=())
		self.server_process.daemon=True
	@staticmethod
	def connect(ip,port):
		return RunConfigurationHandler(ip,port)
	def start(self):
		self.server_process.start()
class RunConfigurationHandler:
	server_address=None
	client_socket=None
	def __init__(self,ip,port):
		self.server_address=(ip,int(port))
	def _connect(self):
		self.client_socket=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	def _closeconnection(self):
		self.client_socket.close()
	def get(self,key):
		self._connect()
		self.client_socket.sendto('get????????'+str(key),self.server_address)
		recv_data,address=self.client_socket.recvfrom(4096)
		#print "RunConfig..."
	#	print recv_data
	#	print "RunConfig Ends.."
		data=pickle.loads(recv_data)
		#print data
		self._closeconnection()
		return data
	def set(self,key,value):
		self._connect()
		#print (key,value)
		#print "end"
		self.client_socket.sendto("set????????"+str(key)+"equalsto" + pickle.dumps(value,-1),self.server_address)
		self._closeconnection()
	def display(self):
		self._connect()
		self.client_socket.sendto("display",self.server_address)
		recv_data,address=self.client_socket.recvfrom(4096)
		data=pickle.loads(recv_data)
		self._closeconnection()
		return data
	def addpath(self,path):
		self._connect()
		self.client_socket.sendto("addpath????????"+ pickle.dumps(path,-1),self.server_address)
		self._closeconnection()
	def getandset(self,key,value):
		self._connect()
		self.client_socket.sendto('get????????'+str(key),self.server_address)
		recv_data,address=self.client_socket.recvfrom(4096)
		datatoreturn=pickle.loads(recv_data)
		self.client_socket.sendto("set????????"+str(key)+"equalsto"+pickle.dumps(value,-1),self.server_address)
		self._closeconnection()
		return datatoreturn
