import time
from multiprocessing import *

class JobRunner:
	rcm_obj=None
	logger=None
	resolver=None
	process_completed_inerror=None
	process_completed_successfully=None
	process_running=None
	process_to_run_in_sequence=None

	send_supervisor=None
	def __init__(self,rcm_obj,send_supervisor,send_joblogger):
		self.rcm_obj=rcm_obj
		self.rcm_obj.set('JOBRUNNER/STEPSRUNSTATUS',{})
		self.rcm_obj.set('JOBRUNNER/ERRORREASON',{})
		self.rcm_obj.set('JOBRUNNER/STEPSRESULT',{})
		self.rcm_obj.set('JOBRUNNER/STATISTICS',{})
		#self.run_configuration['JOBRUNNER']['STEPSRUNSTATUS']={}
		#self.run_configuration['JOBRUNNER']['ERRORREASON']={}
		#self.run_configuration['JOBRUNNER']['STEPSRESULT']={}
		#self.run_configuration['JOBRUNNER']['STEPSRESULT_LOCK']={}
		self.resolver=self.rcm_obj.get('RESOLVER')
		self.logger=send_joblogger
		self.send_supervisor=send_supervisor

		self.process_completed_inerror=[]
		self.process_completed_successfully=[]
		self.process_running=[]
	def _appendStepRunStatus(self,steprunstatus):
		while steprunstatus.qsize() != 0:
			lst=steprunstatus.get()
			for stepnum in lst.keys():
				self.rcm_obj.set('JOBRUNNER/STEPSRUNSTATUS/'+str(stepnum),lst[stepnum]['STEPSRUNSTATUS'])
				self.rcm_obj.set('JOBRUNNER/ERRORREASON/'+str(stepnum),lst[stepnum]['ERRORREASON'])
				#self.run_configuration['JOBRUNNER']['STEPSRUNSTATUS'][stepnum]=lst[stepnum]['STEPSRUNSTATUS']
				#self.run_configuration['JOBRUNNER']['ERRORREASON'][stepnum]=lst[stepnum]['ERRORREASON']
	def _isrunconditiontrue(self,counter):
		self.logger.send(["DEBUG","JOBRUNNER : Checking Execute Condition for Step "+str(counter)])
		#self.rcm_obj.get('JOBRUNNER/STEPRUNCONDITION/'+str(counter))
		rc=self.resolver.resolve(self.rcm_obj,self.rcm_obj.get('JOBRUNNER/STEPRUNCONDITION/'+str(counter)))
		if not rc:
			return True
		if rc.upper() == "TRUE" :
			return True
		elif rc.upper() == "FALSE" :
			return False
		else :
			self.logger.send(["DEBUG","JOBRUNNER : Step "+str(counter) + " execute condtion returned unknown value "+str(rc)])
			return False
	def run(self):
		# I have to run the steps here and in parallel if need be
		self.logger.send(["DEBUG","JOBRUNNER : Starting execution of steps"])
		counter=1
		self.process_to_run_in_sequence=self.rcm_obj.get('JOBRUNNER/STEPS')
		self.logger.send(["DEBUG","JOBRUNNER : Steps to run in sequence"])
		self.logger.send(["DEBUG","JOBRUNNER : "+",".join(str(x) for x in self.process_to_run_in_sequence)])
		process_to_wait_for_before_executing_next_step=[]
		tmp_parallel_list=self.rcm_obj.get('JOBRUNNER/PARALLEL')
		for step in self.process_to_run_in_sequence:
			self.logger.send(["DEBUG","JOBRUNNER : Executing Step "+str(counter)])
			steprunstatus=Queue()
			if not self._isrunconditiontrue(counter):
				dict={}
				dict[counter]={}
				dict[counter]['STEPSRUNSTATUS']='skipped'
				dict[counter]['ERRORREASON']=""
				steprunstatus.put(dict)
				#print "Calling append run status"
				#print steprunstatus.qsize()
				self._appendStepRunStatus(steprunstatus)
				counter += 1
				continue
			self.logger.send(["DEBUG","JOBRUNNER : Execute Condition for Step "+str(counter) + " is okay"])
			if counter in self.process_completed_inerror or counter in self.process_completed_successfully or counter in self.process_running:
				self.logger.send(["DEBUG","JOBRUNNER : Process "+str(step)+" counter="+str(counter)+" already ran ( with error or successfully ) hence moving to next process"])
				self.logger.send(["DEBUG","JOBRUNNER : Step Completed with error "+",".join(str(x) for x in self.process_completed_inerror)])
				self.logger.send(["DEBUG","JOBRUNNER : Step Completed successfully "+",".join(str(x) for x in self.process_completed_successfully)])
				counter += 1
				continue
			process_to_wait_for_before_executing_next_step.append(Process(target=step,args=(self.rcm_obj,counter,steprunstatus,self.logger)))
			self.process_running.append(counter)
			self.logger.send(["DEBUG","JOBRUNNER : Step "+str(counter)+" added for execution"])
			if counter in tmp_parallel_list.keys():
				self.logger.send(["DEBUG","JOBRUNNER : Found parallel step with step "+str(counter)])
				for i in tmp_parallel_list[counter]:
					if not self._isrunconditiontrue(i):
						self.logger.send(["DEBUG","JOBRUNNER : Step "+str(i)+" run condition didnot satisfy hence will not be executed in parallel"])
						continue
					process_to_wait_for_before_executing_next_step.append(Process(target=self.process_to_run_in_sequence[i-1],args=(self.rcm_obj,i,steprunstatus,self.logger)))
					self.process_running.append(i)
					self.logger.send(["DEBUG","JOBRUNNER : Step "+str(i)+" added for execution"])
			for p in process_to_wait_for_before_executing_next_step:
				p.start()
			self.logger.send(["DEBUG","JOBRUNNER : steps started "+",".join(str(x) for x in self.process_running)])
			for p in process_to_wait_for_before_executing_next_step:
				p.join()
				self._appendStepRunStatus(steprunstatus)
			self.logger.send(["DEBUG","JOBRUNNER : steps completed "+",".join(str(x) for x in self.process_running)])
			for p in self.process_running:
				self.process_completed_successfully.append(p)
			self.process_running=[]	
			process_to_wait_for_before_executing_next_step=[]
			counter += 1
		self.logger.send(["DEBUG","JOBRUNNER : Signalling JJOBSUPERVISOR , steps completed successfully"])	
		self.send_supervisor.send('JOBRUNNER : Completed Successfull')
		print self.rcm_obj.display()
		#print self.run_configuration['JOBRUNNER']
		#count=1
		#while True:
			#self.run_configuration['JOBSUPERVISOR']['SEND_JOBLOGGER'].send(["CRITICAL"," This is logging test count "+str(count)])
			#time.sleep(5)
			#count += 1
