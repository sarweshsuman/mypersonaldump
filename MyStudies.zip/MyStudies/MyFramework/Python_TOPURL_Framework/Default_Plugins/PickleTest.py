import cPickle as pickle
import copy_reg
import types



def _pickle_method_(method):
     func_name = method.im_func.__name__
     obj = method.im_self
     cls =  method.im_class
     return _unpickle_method_, (func_name, obj, cls)

def _unpickle_method_(func_name, obj, cls):
     func = cls.__dict__[func_name]
     return func.__get__(obj, cls)

copy_reg.pickle(types.MethodType, _pickle_method_, _unpickle_method_)


class A:
	def a(self):
		print "HELLO"
		print "HI"
		return

obj=A()
func=getattr(obj,'a')
#l= func.__class__.mro()
#print l[1].__dict__
f=pickle.dumps(func,-1)
r= pickle.loads(f)
r()
