import logging 
import signal
import sys

# implement using File Handler
class JobLogger:
	rcm_obj=None
	job_config=None
	resolver=None
	

	logginglevel=None
	logdir=None
	filename=None
	displayformat=None
	logging_methods={}
	log=None

	send_supervisor=None
	recv_joblogger=None
	def _exit_gracefully(self,signal,frame):
		self._debug("JOBLOGGER : Received Terminate signal")
		while self.recv_joblogger.poll():
			recv=self.recv_joblogger.recv()
			self.logging_methods[recv[0]](recv[1])
		self._debug("JOBLOGGER : JobLogger Terminating")
		sys.exit(0)
	def __init__(self,rcm_obj,send_supervisor,recv_joblogger):
		self.logging_methods={
				'ERROR':self._error,
				'INFO':self._info,
				'DEBUG':self._debug,
				'WARNING':self._warning,
				'CRITICAL':self._critical,
		}
		self.rcm_obj=rcm_obj
		self.send_supervisort=send_supervisor
		self.recv_joblogger=recv_joblogger
		self.job_config=self.rcm_obj.get('JOB_CONFIG')
		self.resolver=self.rcm_obj.get('RESOLVER')

		if self.job_config.has_section('logging'):
			logginglevel=self.job_config.get('logging','log.level')
			logdir=self.resolver.resolve(self.rcm_obj,self.job_config.get('logging','log.dir'))
			filename=self.resolver.resolve(self.rcm_obj,self.job_config.get('logging','log.filename'))
			displayformat=self.job_config.get('logging','log.format')
			if logginglevel.upper() == 'ERROR':
				logging.basicConfig(filename=logdir+"/"+filename,format=displayformat,level=logging.ERROR)
			elif logginglevel.upper() == 'CRITICAL':
				logging.basicConfig(filename=logdir+"/"+filename,format=displayformat,level=logging.CRITICAL)
			elif logginglevel.upper() == 'DEBUG':
				logging.basicConfig(filename=logdir+"/"+filename,format=displayformat,level=logging.DEBUG)
			elif logginglevel.upper() == 'WARNING':
				logging.basicConfig(filename=logdir+"/"+filename,format=displayformat,level=logging.WARNING)
			elif logginglevel.upper() == 'INFO':
				logging.basicConfig(filename=logdir+"/"+filename,format=displayformat,level=logging.INFO)
		else:
			return None
		signal.signal(signal.SIGTERM,self._exit_gracefully)
	def _critical(self,string):
		logging.critical(string)
	def _warning(self,string):
		logging.warning(string)
	def _error(self,string):
		logging.error(string)
	def _info(self,string):
		logging.info(string)
	def _debug(self,string):
		logging.debug(string)
	def run(self):
		while True:
			recv=self.recv_joblogger.recv()
			self.logging_methods[recv[0]](recv[1])
