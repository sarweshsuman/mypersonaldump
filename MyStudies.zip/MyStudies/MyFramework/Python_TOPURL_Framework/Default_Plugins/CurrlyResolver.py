#Module : CurrlyResolver.py
#
#
#
#
###################################

import re
import string as string2
import os
import json

class CurrlyResolver:
	map_keyword_to_function=None
	#run_configuration = None # To Store properties when initialized by parent
	rcm_obj=None
 	def __init__(self):
		self.map_keyword_to_function = {
			'CONCAT':self._concat,
			'CURRENTDIR':self._currentdir,
			'JOBNAME':self._jobname,
			'FINDSTEPPARAM':self._findstepparam,
			'MKDIR':self._mkdir,
			'ENABLED':self._checkifstepisenabled,
			'STARTIF':self._startif,
			'RUNTIMEDATA':self._runtimedata,
		#	'FILE':_file,
		}
	def _initialize(self,rcm_obj):
		self.rcm_obj=rcm_obj
	def _runtimedata(self,args):
		key=args[0]
		try:
			data=self.rcm_obj.get(key)
			if type(data)==type(""):
				return data
			elif type(data) == type([]):
				return ",".join(data)
			elif type(data) == type({}):
				return json.dumps(data)
			elif str(type(data)) == "<type 'int'>":
				return str(data)
			elif str(type(data)) == "<type 'instance'>" or  str(type(data)) == "<type 'instancemethod'>":
				return str(type(data))
			else:
				return "Unknown Type"
		except Exception as e:
			print "Exception at CurrlyResolver:_runtimedata "+e.__str__()
			return ""
	def _startif(self,args):
		try:
			print "In startif"
			statement=args[0]
			step,condition=statement.split("=")
			stepnum=re.search("STEP(.*)",step.upper())
			if stepnum:
				if self.rcm_obj.get('JOBRUNNER/STEPSRUNSTATUS/'+str(stepnum.group(1))).upper() == condition.upper():
					print "Returning true"
					return "TRUE"
				else:
					print "Returning false"
					return "FALSE"
			else :
				print "Returning false"
				return "FALSE"
		except Exception as e :
			print "Exception at CurrlyResolver:_startif "+e.__str__()
			return "FALSE"
	def _checkifstepisenabled(self,args):
		return args[0].lower()
	def _mkdir(self,args):
		dirname=args[0]
		if not os.path.isdir(dirname):
			os.system('mkdir -p '+dirname)
		return dirname
	def _findstepparam(self,args):
		#if not self.run_configuration['JOBRUNNER']['STEPEXECUTING']:
		#	return None
		stepnumber=int(args[0])
		param=args[1]
		#print "stepnumber="+str(stepnumber)
		#print self.run_configuration['JOBRUNNER']['STEPSCONFIG']
		#print "param="+param
		# No concept of return anyother value than string or boolean etc
		param_value = self.rcm_obj.get('JOBRUNNER/STEPSCONFIG/'+str(stepnumber)+"/"+str(param))
		#if re.search(",",param_value):
		#	list=param_value.split(",")
		#	return list
		#else:
		return param_value
	def _concat(self,list,FIELD=""):
		return FIELD.join(list)
	def _currentdir(self):
		return self.rcm_obj.get('CURRENTDIR')
	def _jobname(self):
		return self.rcm_obj.get('JOBNAME')
	#def _file(self):
	#	return 
	def resolve(self,rcm_obj,string):
		#Primarily concerned with substituting values in a string
		if not string:
			return None
		self._initialize(rcm_obj)
		if re.search("{{",string):
			loop_over_string=len(re.findall("{{",string))
			for counter in range(0,loop_over_string):
				keyword=re.search("{{([A-Z]+)}}",string)
				if keyword:
					keyword_to_value=self.map_keyword_to_function[keyword.group(1)]()
					#print "Before "+string
					string=string2.replace(string,keyword.group(0),keyword_to_value,1)
					#print "After "+string
					#print
				else:
					# Didnt find keyword , Now check if curly brackets contains : and ;
					if re.search(":",string):
						part_within_currly=re.search("{{(.*)}}",string)
						(keyword_and_named_argument,args_string)=part_within_currly.group(1).split(":")
						keyword=None
						named_args={}
						if re.search("/",keyword_and_named_argument):
							# We have named arguments
							(keyword,named_args_separated_by_semicolon)=keyword_and_named_argument.split("/")
							tmp_list=named_args_separated_by_semicolon.split(";")
							for elem in tmp_list:
								(key,value)=elem.split("=")
								named_args[key]=value
						else:
							keyword=keyword_and_named_argument
						args=args_string.split(";")
						keyword_to_value=self.map_keyword_to_function[keyword](args,**named_args)
						string=string2.replace(string,part_within_currly.group(0),keyword_to_value,1)
						#if isinstance(keyword_to_value,type([])):
						#	if loop_over_string != 1 :
						#		# Case Open !!!
						#		# Cannot expect list to be replaced into string or can I do it?? 
						#		return None
						#	return keyword_to_value
						#elif isinstance(keyword_to_value,type('')):
						#	string=string2.replace(string,part_within_currly.group(0),keyword_to_value,1)
						#else:
						#	print "Unknown return type from function _"+keyword
						#	return None
					else:
						return string
			return self.resolve(self.rcm_obj,string)
		else:
			return string
	def resolve2(self,string):
		#Concerned with substitu
		pass
