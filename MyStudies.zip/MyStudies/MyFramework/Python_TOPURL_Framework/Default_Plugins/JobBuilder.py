import re
import os
import sys
import ConfigParser
import Step

class JobBuilder:
	#run_configuration=None
	steps=[]
	configparser=None
	rcm_obj=None
	rcm_module=None
	rcm_ip=None
	rcm_port=None
	
	job_config=None
	job_name=None
	resolver=None
	def __init__(self,run_configuration_manager_module,rcm_ip,rcm_port):
		self.rcm_module=run_configuration_manager_module
		self.rcm_ip=rcm_ip
		self.rcm_port=rcm_port
		
		self.rcm_obj=self.rcm_module.RunConfigurationManager.connect(self.rcm_ip,self.rcm_port)

		self.rcm_obj.set('JOBRUNNER',{})
		self.rcm_obj.set('JOBRUNNER/DELTA',0)
		self.rcm_obj.set('JOBRUNNER/STEPS',[])
		self.rcm_obj.set('JOBRUNNER/STEPSCONFIG',{})
		self.rcm_obj.set('JOBRUNNER/STEPRUNCONDITION',{})
		
		self.job_config=self.rcm_obj.get('JOB_CONFIG')
		self.job_name=self.rcm_obj.get('JOBNAME')
		self.resolver=self.rcm_obj.get('RESOLVER')

		self.configparser=ConfigParser.ConfigParser()
		self._buildsteps()
	def _buildsteps(self):
		
		for option in self.job_config.options(self.job_name):
			stepnumber=re.search("STEP(.*)",option.upper())
			if not stepnumber:
				continue
			value=self.job_config.get(self.job_name,option)
			filetoload_obj=re.search("^FILE:(.*)",value)
			if filetoload_obj:
				# I need to load the file	
				filetoload=self.resolver.resolve(self.rcm_obj,filetoload_obj.group(1))
				if(os.path.isfile(filetoload) == True):
					self.configparser.read(filetoload)
					self._updaterunconfiguration()  # Update run_configuration with settings for each step
					if not self.configparser.has_section('library'):
						print "No library to load"
					else:
						#Add path where the library might exists
						self._addpath()
						#Load and initialize the modules
						self._loadmodule()
				else:
					print "File "+filetoload + " not found"
				# Now Building the steps
				self._addsteps()
				self._checkforparalleloption()
				self._addruncondition()
			else:
				pass
	def _addruncondition(self):
		if self.configparser.has_section('stepruncondition'):
			for opt in self.configparser.options('stepruncondition'):
				stepnumber=re.search('STEP(.*).CONDITION',opt.upper())
				if not stepnumber:
					continue
				self.rcm_obj.set('JOBRUNNER/STEPRUNCONDITION/'+str(stepnumber.group(1)),self.configparser.get('stepruncondition',opt))
	def _checkforparalleloption(self):
		delta=self.rcm_obj.get('JOBRUNNER/DELTA')
		if self.configparser.has_option('steps','parallel'):
			step_list=self.configparser.get('steps','parallel').split(",")
			stepnumber_list=[]
			for step in step_list:
				stepnumber=re.search('STEP(.*)',step.upper())
				stepnumber_list.append(int(stepnumber.group(1))+delta)
			stepnumber_list.sort()
			tmp_parallel_list=self.rcm_obj.get('JOBRUNNER')
			if 'PARALLEL' in tmp_parallel_list.keys():
				self.rcm_obj.set('JOBRUNNER/PARALLEL/'+str(stepnumber_list[0]),stepnumber_list[1:])
			else :
				self.rcm_obj.set('JOBRUNNER/PARALLEL',{})
				self.rcm_obj.set('JOBRUNNER/PARALLEL/'+str(stepnumber_list[0]),stepnumber_list[1:])
		else:
			self.rcm_obj.set('JOBRUNNER/PARALLEL',{})
	def _addsteps(self):
		for step in self.configparser.options('steps'):
			if not re.search('STEP',step.upper()):
				continue	
			stepnumber=re.search('STEP(.*)',step.upper())
			action=self.configparser.get('steps',step)
			if not re.search('^CALL:',action):
				print "Only CALL is supported"
				continue
			COUNT_CALL=len(re.findall('CALL:',action))
			if COUNT_CALL != 1:
				print "Only support one CALL statement per step"
				continue
			moduletocall=re.search('^CALL:(.*)',action)
			if not moduletocall:
				print "No Call statement found"
				continue
			#print "Module to call " + moduletocall.group(1)
			(module,method)=moduletocall.group(1).split('.')
			if not self.rcm_obj.get(module.upper()):
				print "Module "+module+" not found in run_configuration"
				continue
			func=getattr(self.rcm_obj.get(module.upper()),method)
			stp=Step.Step(func,int(stepnumber.group(1)))
			stp_run=getattr(stp,'run')
			tmp_list=self.rcm_obj.get('JOBRUNNER/STEPS')
			tmp_list.append(stp_run)
			self.rcm_obj.set('JOBRUNNER/STEPS',tmp_list)
	def _loadmodule(self):
		modules_to_load = self.configparser.get('library','LOADMODULE')
		run_configuration=self.rcm_obj.display()
		if modules_to_load:
			list_of_modules_to_load=modules_to_load.split(",")
			for completename in list_of_modules_to_load:
				(package,module)=completename.split(".")
				if not module.upper() in run_configuration.keys():
					obj=__import__(package)
					obj_call=getattr(obj,module)
					obj_obj=obj_call()
					self.rcm_obj.set(module.upper(),obj_obj)
				else:
					#print "HERE 3"
					obj=reload(sys.modules[package])
					obj_call=getattr(obj,module)
					self.rcm_obj.set(module.upper(),obj_call())
		#print "HERE 2"
		#print self.rcm_obj.display()
	def _addpath(self):
		add_path=self.configparser.get('library','ADDPATH')
		add_path=self.resolver.resolve(self.rcm_obj,add_path)
		if add_path:
			list_of_add_path=add_path.split(',')
			for p in list_of_add_path:
				sys.path.append(p)
				self.rcm_obj.addpath(p)
	def _updaterunconfiguration(self):
		#self.run_configuration['JOBRUNNER']['STEPSCONFIG']={}
		print "Here Initializing"
		delta=self.rcm_obj.get('JOBRUNNER/DELTA')
		for opt in self.configparser.options('steps'):
			if not re.search('STEP',opt.upper()):
				continue
			if not self.configparser.has_section(opt):
				continue
			stepnumber=re.search('^STEP(.*)',opt.upper())
			if (int(stepnumber.group(1)) in self.rcm_obj.get('JOBRUNNER/STEPSCONFIG').keys()) and delta == 0:
				#print "Yes it exists "
				tmp_list=self.rcm_obj.get('JOBRUNNER/STEPSCONFIG').keys()
				tmp_list.sort()
				delta=int(tmp_list[len(tmp_list)-1])
				self.rcm_obj.set('JOBRUNNER/DELTA',delta)
			self.rcm_obj.set('JOBRUNNER/STEPSCONFIG/'+str(int(stepnumber.group(1))+delta),{})
			for sub_opt in self.configparser.options(opt):
				value=self.configparser.get(opt,sub_opt)
				#self.rcm_obj.set('JOBRUNNER/STEPSCONFIG/'+str(int(stepnumber.group(1))+delta)+"/"+str(sub_opt),self.resolver.resolve(self.rcm_obj,value))
				self.rcm_obj.set('JOBRUNNER/STEPSCONFIG/'+str(int(stepnumber.group(1))+delta)+"/"+str(sub_opt),value)


		
