import re
import time
from multiprocessing import Queue

class Step:
	rcm_obj=None
	functocall=None
	loopoverstepoutput=None
	waitformoreoutput=None
	stepnumber=None
	statistics=None
	statistics_queue=None
	def __init__(self,functocall,stepnumber):
                self.functocall=functocall
                self.stepnumber=stepnumber
	def _initialize(self,rcm_obj):
		self.rcm_obj=rcm_obj
		self.statistics={}
		self.statistics_queue=Queue()
		list_stepconfig=self.rcm_obj.get('JOBRUNNER/STEPSCONFIG')
		if self.stepnumber in list_stepconfig.keys():
			if 'loop.over.step.output' in list_stepconfig[self.stepnumber].keys():
				group=re.search('STEP(.*)',list_stepconfig[self.stepnumber]['loop.over.step.output'].upper())
				if group:
					self.loopoverstepoutput=int(group.group(1))
				# Step is independent of other steps in case of null
			if 'waitformoreoutput' in list_stepconfig[self.stepnumber].keys() and list_stepconfig[self.stepnumber]['waitformoreoutput'].upper() in ('YES','NO'):
					self.waitformoreoutput=list_stepconfig[self.stepnumber]['waitformoreoutput'].upper()
			else :
				self.waitformoreoutput='NO'	
		else:
			print "No Configuration found for step "+str(stepnumber)
	def run(self,rcm_obj,stepnumber,steprunstatus,logger):
		self._initialize(rcm_obj)
		self.statistics['starttime']=time.time()
		try:
			if self.loopoverstepoutput:
				stepsresult=self.rcm_obj.get('JOBRUNNER/STEPSRESULT')
				while not self.loopoverstepoutput in stepsresult.keys():
					print "Output Not seen Yet "+str(stepnumber) + " loopoverstepoutput" +str(self.loopoverstepoutput)
					time.sleep(1)
					stepsresult=self.rcm_obj.get('JOBRUNNER/STEPSRESULT')
					print stepsresult
				print "Found Output"
				stepsresult=self.rcm_obj.getandset('JOBRUNNER/STEPSRESULT/'+str(self.loopoverstepoutput),[])
				if self.waitformoreoutput == 'YES':
					print "Wait for More output set to YES"
					#to be implemented !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
					while True:
						self.functocall(self.rcm_obj,self.statistics_queue,stepsresult,(stepnumber,steprunstatus,logger))
						time.sleep(1)
						stepsresult=self.rcm_obj.get('JOBRUNNER/STEPSRESULT/'+str(self.loopoverstepoutput))
						while len(stepsresult) == 0:
							print "Found 0 length step output"
							time.sleep(2)
							stepsresult=self.rcm_obj.get('JOBRUNNER/STEPSRESULT/'+str(self.loopoverstepoutput))
						stepsresult=self.rcm_obj.getandset('JOBRUNNER/STEPSRESULT/'+str(self.loopoverstepoutput),[])
				else:
					print "Wait for more output set to NO "+str(stepnumber)
					# This means I take the output once and process it and exit
					self.functocall(self.rcm_obj,self.statistics_queue,stepsresult,(stepnumber,steprunstatus,logger))
			else:
				print "loopoverstepoutput not set hence processing as independent stepi "+str(stepnumber)
				self.functocall(self.rcm_obj,self.statistics_queue,None,(stepnumber,steprunstatus,logger))
		except Exception as e:
			self.statistics['status']='failed'
			self.statistics['error']=e.__str__()
		self.statistics['endtime']=time.time()
		self.statistics['timetaken']=self.statistics['endtime']-self.statistics['starttime']
		self._getStatistics()
		self._setStatistics(stepnumber)
        def _getStatistics(self):
		# expected in form of dictonary only
		if self.statistics_queue.qsize()==0:
			return
		dict=self.statistics_queue.get()
		for k in dict.keys():
			self.statistics[k]=dict[k]
	def _setStatistics(self,stepnumber):
		self.rcm_obj.set('JOBRUNNER/STATISTICS/'+str(stepnumber),self.statistics)
