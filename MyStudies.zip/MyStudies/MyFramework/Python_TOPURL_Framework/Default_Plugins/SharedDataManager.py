import socket

class SharedDataManager:
	shareddata={}
	lock={}
	def __init__(self,ip,port):
		pass
	def loadData(self,identification,datatoload)
