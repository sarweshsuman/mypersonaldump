#!/usr/bin/env perl

use strict;
use Carp;

use DBI;
use Getopt::Long;
use PMTDbXmlUtils qw(DBDo);
use PMTUtilities qw(partial);

my $username;
my $password;
my $encryptpw;
my $driver;
my $dbname;
my $service;
my $host;
my $port;
my $connectionname;
my $test;

sub publish {
  my %args = @_;
  my $params = $args{'params'};
  my $replace = $args{'replace'};

  my $queries ;
  if ($replace) {
    print "this is a replacement query\n";
    $queries = [
      {
				statement=>q{
					if (exists (collection('dbxml:/pmtconf')/shared/db_connections/db_connection[@name=$pq_connectionname_in]))
					then 
						(delete nodes collection('dbxml:/pmtconf')/shared/db_connections/db_connection[@name=$pq_connectionname_in],
						insert node element db_connection {
							attribute name { $pq_connectionname_in },
							element driver { $pq_driver_in },
							element service { $pq_service_in },
							element username { $pq_username_in },
							element password { $pq_password_in }
						}
						as last into collection('dbxml:/pmtconf')/shared/db_connections
					 ) 
					else 
						insert node element db_connection {
							attribute name { $pq_connectionname_in },
							element driver { $pq_driver_in },
							element service { $pq_service_in },
							element username { $pq_username_in },
							element password { $pq_password_in }
						}
						as last into collection('dbxml:/pmtconf')/shared/db_connections
				}
      }
    ];
  }
  else {
    print "this is not a replacement query\n";
    $queries = [
      {
				statement=>q{
					if (exists (collection('dbxml:/pmtconf')/shared/db_connections/db_connection[@name=$pq_connectionname_in]))
					then
						()
					else
						insert node element db_connection {
							attribute name { $pq_connectionname_in },
							element driver { $pq_driver_in },
							element service { $pq_service_in },
							element username { $pq_username_in },
							element password { $pq_password_in }
						}
						as last into collection('dbxml:/pmtconf')/shared/db_connections
				}
      }
    ];
  }
  my $context = {
    pq_connectionname_in => $params->{'name'},
    pq_driver_in => $params->{'driver'},
    pq_username_in => $params->{'username'},
    pq_password_in => $params->{'password'},
    pq_service_in => $params->{'service'}
  };
  eval {
  DBDo(queries=>$queries,context=>$context);
  };
  if ($@) {
    if (ref $@ eq 'HASH') {
      print "Error: $@->{'message'}\n";
    }
    else {
      print "Error: $@\n";
    }
    exit(1);
  }
  undef;
}

sub check_connectionname {
}

sub interactive {
  print "Configuring a new database connection\n";
  print "=====================================\n";
  my $connection_ok = 0;
  my $configure_other = 1;
  my $breakloop = 0;
  while (not $breakloop and (not $connection_ok or $configure_other) ) {
    print "Name of the database connection: ";
    my $name_ok = 0;
    my $replace = 0;
    my $lname;
		while (not $name_ok) {
			$lname = <STDIN>;
			chomp $lname; $lname = lc $lname;
			# Test if the name does allready exist;
			my $context = { pq_connectionname_in => $lname };
			my $queries = [
				{
					statement=>q{
						if (exists(collection('dbxml:/pmtconf')/shared/db_connections/db_connection[@name=$pq_connectionname_in]))
						then 1 else 0
					}
				}
			];
			my $outresult = {};
			my $result_parser = partial(sub { my %args = @_; my $results = $args{'results'}; my $out = $args{'out'}; $out->{'exists'} = $results->[0]; }, out=>$outresult);
      eval {
			DBDo(queries=>$queries,context=>$context,result_parser=>$result_parser);
      };
      if ($@) {
        if (ref $@ eq 'HASH') {
          print "Erorr: $@->{'message'}\n";
        }
        else {
          print "Error: $@\n";
        }
        exit(1);
      }
			if ($outresult->{'exists'}) {
				print "Name allready exists\n";
				print "do you want to replace it\n";
        $replace = 1;
			}
			else {
				print "name does not exist yet\n";
				$name_ok = 1;
			}
		}
		print "name is ok\n";

		my $default_driver = "oracle";
		print "Driver (oracle): ";
		my $ldriver = <STDIN>;
		chomp $ldriver; $ldriver = lc $ldriver;
		if (not $ldriver) { $ldriver = $default_driver; }
		print "ServiceName/DatabaseName: ";
		my $lservice = <STDIN>;
		chomp $lservice; $lservice = lc $lservice;
		print "Username: ";
		my $lusername = <STDIN>;
		chomp $lusername; $lusername = lc $lusername;
		print "Password: ";
		my $lpassword = <STDIN>;
		chomp $lpassword; $lpassword = lc $lpassword;
		print "Test the connection (y/n): ";
		my $ltest = <STDIN>; chomp $ltest; $ltest = lc $ltest;
		chomp $ltest;
		if ($ltest =~ m/^y/) {
			print "Testing the connection ....";
			use DBI;
			use DBD::Oracle;
			eval {
				my $dbh = DBI->connect("DBI:Oracle:$lservice",$lusername,$lpassword, { RaiseError=>1 });
			};
			if ($@) {
				print " NOK\n";
				print "Connection test failed. Do you want to use it anyway (y/n) ? ";
				my $lanswer = <STDIN>;
				chomp $lanswer; $lanswer = lc $lanswer;
				if ($lanswer =~ m/^y/) {
					$connection_ok = 1;
				}
				else {
					$connection_ok = 0;
          $breakloop = 1;
				}
			}
			else {
				print " OK\n";
				$connection_ok = 1;
			}
		}
		else {
			$connection_ok = 1;
		}
    # configure the connection
    publish(
      replace=>$replace,
      params=>{
        service=>$lservice,
        username=>$lusername,
        password=>$lpassword,
        name=>$lname,
        driver=>$ldriver
      }
    );
    print "Do you want to configure another connection (y/n) ? ";
    my $lanswer = <STDIN>;
    chomp $lanswer; $lanswer = lc $lanswer;
    if ($lanswer =~ m/^y/) {
      $breakloop = 0;
      $connection_ok = 0;
      print "\n\n";
    }
    else { $breakloop = 1; }
  } 
}

GetOptions(
  'username=s'=>\$username,
  'password=s'=>\$password,
  'driver=s'=>\$driver,
  'dbname=s'=>\$dbname,
  'service'=>\$service,
  'host=s'=>\$host,
  'port=s'=>\$port,
  'name=s'=>\$connectionname,
  'test'=>\$test
);

if (not $connectionname) {
  # switch to interactive mode
  print "switching to interactive mode\n";
  interactive();
}
else {
  # test the other arguments
}
