#!/bin/sh

for i in $(ipcs -s | grep pmt | cut -f 2 -d  ' ')
do
ipcrm -s $i
done
