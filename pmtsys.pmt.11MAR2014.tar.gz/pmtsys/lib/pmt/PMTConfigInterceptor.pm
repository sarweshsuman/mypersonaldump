package PMTConfigInterceptor;

use strict;

use PMTInterceptorBase;
use PMTUtilities qw(icdefined);
use Config::Simple;
use Data::Dumper;
our @ISA = qw(PMTInterceptorBase);

sub new {
  my $p = shift;
  my %args = @_;

  my $ic = $args{'initialcontext'};
  my $mod = {};


  my $initparams = $args{'initparams'};
  my $config_file = $initparams->{'config_file'};
  my $config_data = $initparams->{'config_data'};

  my $config_hash = {};
  $mod->{'initialcontext'} = $ic;
  $mod->{'_config_data_'} = {};

  if (defined $config_file) {
    my %C;
    my $cf = Config::Simple->new($config_file);
    my $v = $cf->vars();
    
    my $config_hash_build = {};
    KEYLOOP:
    for my $k (keys %$v) {
      #print "Analysing the key $k\n";
      # split the key
      my @ks = split(/\./,$k);
      # now this could be of several lengths, two, three ...
      for (my $i = 0; $i < scalar @ks -1 ; $i++) {
        my @p_block_key = @ks[0 .. $i]; my $block_key = join('.',@p_block_key);
        my @p_value_key = @ks[$i+1 .. scalar @ks-1]; my $value_key = join('.',@p_value_key);
        #print "checking for value $value_key in section $block_key\n";
        my $section_params = $cf->param(-block=>$block_key);
        if (defined $section_params->{$value_key}) {
          #print "I found the value: $v->{$k}\n";
          if (not exists $config_hash_build->{$block_key}) { $config_hash_build->{$block_key} = {}; }
          $config_hash_build->{$block_key}->{$value_key} = $v->{$k};
        }
      }
    }
    #print STDERR "Config hash is now ",Dumper($config_hash_build),"\n";
    $config_hash = $config_hash_build;
  }
  elsif (defined $config_data) {
    my %CC = %{$config_data};
    $config_hash  = \%CC;
    use Data::Dumper;
    #print STDERR "Initialized PMTConfigInterceptor with data ",Dumper($config_hash),"\n";
  }

  #$mod->{'_config_data_'} = $config_hash;
  use Data::Dumper;
  use PMTUtilities qw(mergeRecursiveHash);
  mergeRecursiveHash(src=>$config_hash,update=>$mod->{'_config_data_'});
  use Data::Dumper;
  #print STDERR "PMTConfigInterceptor: ",Dumper($mod->{'_config_data_'}),"\n";

  bless $mod;

  #print STDERR "Loaded ".__PACKAGE__."\n";
  return $mod;
}

#sub needRaw { return 1; }

sub getCloneData {
  my $self = shift;
  use Data::Dumper;
  #print STDERR "In getrCloneData of PMTCinfigInterceptor: ",Dumper($self->{'_config_data_'}),"\n";
  return { config_data=>$self->{'_config_data_'}};
}

sub clone {
  my $self = shift;
  my %args = @_;
  my $nic = $args{'initialcontext'};

  return new(__PACKAGE__,initialcontext=>$nic,initparams=>$self->getCloneData());
}

sub isCloneable {
  return 1;
}

sub getPaths {
  my $self = shift;
  return { preRead=>[ '^CONFIG/[^\/]+$' , '^CONFIG/[^\/]+/[^\/]+$' ]};
}

sub preRead {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  #print "getRead invoked with",Dumper(\%args),"\n";
  my %args = @_;
  my $key = $args{'key'};
  my $val = $args{'value'};
  my $p = $args{'_path_'};

  #my $ukey = uc $key;
  #my $url = "SYSTEM/META/PARAM2/CONFIG/$ukey";
  #my $v = $ic->{$url};
  #if (not icdefined $v ) {
  #  # do nothing
  #}
  #else {
  #  if (not ref $v and $v =~ m/,/) {
  #    my @vv = split(/,/,$v);
  #    @vv = map { s/\ $//g; $/^\ //g; } @vv;
  #    return { value => \@vv };
  #  }
  #  return { value=>$v };
  #}
   
  my $cd = $self->{'_config_data_'};
  use Data::Dumper;
  if ($p->[0] eq 'CONFIG' and scalar @$p == 2 and defined $cd->{$p->[1]}) {
    my $pname = $p->[1];
    if (defined $cd->{$pname} ) {
      #print STDERR "$pname = configured in PMTConfigInterceptor (scalar 2 case)\n";
      return { value=>$cd->{$pname} };
    }
  }
  elsif ($p->[0] eq 'CONFIG' and scalar @$p == 3 and defined $cd->{$p->[1]}->{$p->[2]}) {
    #print STDERR "The scalar 3 case in PMTPLHelper\n";
    return { value=>$cd->{$p->[1]}->{$p->[2]}};
  }
  else {
    #print STDERR "The other scalar case in PMTPLHelper\n";
    
    return undef;
  }
  return undef;
}


1;
