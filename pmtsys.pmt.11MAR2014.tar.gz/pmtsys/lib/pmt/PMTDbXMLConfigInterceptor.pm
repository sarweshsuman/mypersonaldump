package PMTDbXMLConfigInterceptor;

use strict;
use Carp;

use PMTInterceptorBase;
use PMTUtilities qw(icdefined getPMTSysConfig);

our @ISA = qw(PMTInterceptorBase);

use Sleepycat::DbXml;

sub new {
  my $p = shift;
  my %args = @_;

  my $ic = $args{'initialcontext'};
  my $mod = {};
  $mod->{'initialcontext'} = $ic;
  $mod->{'mountpoint'} = 'JOBDEF';
  $mod->{'path'} = '^'.$mod->{'mountpoint'}.'/.+$';
  
  # find the containers ...
  my $known_containers = getPMTSysConfig(section=>'dbxml');

  $mod->{'containers'} = {};
  for my $cname (keys %$known_containers) {
    if (lc $cname eq 'default') {
      $mod->{'default_container'} = $known_containers->{$cname};
    }
    else {
      $mod->{'containers'}->{lc $cname} = $known_containers->{$cname};
    }
  }

  bless $mod;
  return $mod;
}

sub getPaths {
  my $self = shift;
  return [ '^JOBDEF/[^\/]+$' ];
}

# 
sub preRead {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $key = $args{'key'};
  my $val = $args{'value'};
  my $p = $args{'_path_'};
  my $kk = $args{'_ckey_'};

  # the _path_, $p is actually the most interesting one
}

sub preSet { 
  my $self = shift;
  croak { message=>"Initialcontext handler at $self->{'mountpoint'} is readonly" };
}

sub postSet {
  my $self = shift;
  croak { message=>"Initialcontext handler at $self->{'mountpoint'} is readonly" };
}

1;
