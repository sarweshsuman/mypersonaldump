package PMTCommonSteps;

use strict;
use Carp;

sub new {
  my $package = shift;

  my $o = {};
  return bless $o;
}

sub deleteFile {
  my $self = shift;
  my %args = @_;
  my $filename = $args{'file'};
  if (ref $filename eq 'ARRAY') {} else { $filename = [$filename]; }
  for my $f (@$filename) {
    my $rc = `rm -f $f`;
  }
}

sub moveFile {
  my $self = shift;
  my %args = @_;
  my $filename = $args{'file'};
  if (ref $filename eq 'ARRAY') {} else { $filename = [$filename]; }
  my $directory = $args{'directory'};

  for my $f (@$filename) {
  	my $rc = `mv $f $directory `;
  }
}

sub copyFiles_sftp_step2 {
  my $self = shift;
  my %args = @_;
  my $source_file = $args{'sourcefile'};
  if (scalar @$source_file == 0) { return ; }
  my $target_directory = $args{'target_directory'};
  my $remove_original = $args{'remove_source'};
  my $history_file = $args{'history_file'};
  my $remote=$args{'remote_mode'};
  my $atomic = $args{'atomic'};
  my $queue = $args{'queue'};
  my $cred = $args{'credentials'};
  my $host = $args{'host'};
  my $username = $args{'username'};
  use PMTUtilities qw(evalBoolean);
  $atomic = evalBoolean(value=>$atomic);
  $remove_original = evalBoolean(value=>$remove_original);
  print STDERR "Copying using sftp step 2\n";
  use Net::OpenSSH;
  my $ssh_options = {};
  if (defined $cred->{'username'}) {
    $ssh_options->{'user'} = $cred->{'username'};
  }
  if (defined $cred->{'password'}) {
    $ssh_options->{'password'} = $cred->{'password'};
  }
  if (defined $cred->{'private_key'}) {
    $ssh_options->{'key_path'} = $cred->{'private_key'};
  }
  my $ssh = Net::OpenSSH->new($host,%$ssh_options);
  my $sftp = $ssh->sftp();
  use File::Spec;
  use File::Basename qw(basename);
  my $copyoptions = { atomic=>1,overwrite=>1,copy_time=>1,cleanup=>1};
  for my $f (@$source_file) {
    my $localname = File::Spec->catfile($target_directory,basename $f->{'path'});
    my $basename = basename $f->{'path'};
    print STDERR "Retrieving file: $f->{'orig_uri'} to $localname\n";
    $sftp->get($f->{'path'},$localname,%$copyoptions);

    if ($remove_original) {
      my %o;
      $sftp->remove($f->{'path'},%o);
    }
    
    if ($history_file) {
    	my $st = $sftp->stat($f->{'path'});
      print $history_file "$basename;$st->{'mtime'};$st->{'size'}\n";
    }
    #print STDERR "Retrieving file with $st->
  }
  print STDERR "so far so good\n";
}

sub copyFiles_sftp_step1 {
  my $self = shift;
  my %args = @_;
  my $source_file = $args{'sourcefile'};
  if (scalar @$source_file == 0) { return ; }
  my $target_directory = $args{'target_directory'};
  my $remove_original = $args{'remove_source'};
  my $history_file = $args{'history_file'};
  my $remote=$args{'remote_mode'};
  my $atomic = $args{'atomic'};
  my $queue = $args{'queue'};
  print STDERR "Copying using sftp step 1\n";

  # get all the host/username combinations, and split up the transfer by those
  my $host_usernames = {};
  for my $u (@$source_file) {
    if (not defined $host_usernames->{$u->{'host'}}) {
      $host_usernames->{$u->{'host'}} = {};
    }
    if (not defined $host_usernames->{$u->{'host'}}->{$u->{'username'}}) {
      $host_usernames->{$u->{'host'}}->{$u->{'username'}} = []; 
    }
    push @{$host_usernames->{$u->{'host'}}->{$u->{'username'}}},$u;
  }
  for my $h (keys %$host_usernames) {
    for my $u (keys %{$host_usernames->{$h}}) {
      # pull the first one of the list
      my $fu = $host_usernames->{$h}->{$u}->[0];
      my $fuo = $fu->{'corrected_uri'};
      use PMTUtilities qw(getCredentials);
      my $cred = getCredentials(uri=>$fuo);
      $self->copyFiles_sftp_step2(
         target_directory=>$target_directory,
         remove_source=>$remove_original,
         remote_mode=>$remote,
         atomic=>$atomic,
         queue=>$queue,
         history_file=>$history_file,
         sourcefile=>$host_usernames->{$h}->{$u},
         credentials=>$cred,
         host=>$h,
         username=>$u,
         
      );
    }
  }
}

sub copyFiles_ftp_step2 {
  my $self = shift;
  my %args = @_;
  my $source_file = $args{'sourcefile'};
  if (scalar @$source_file == 0) { return ; }
  my $target_directory = $args{'target_directory'};
  my $remove_original = $args{'remove_source'};
  my $history_file = $args{'history_file'};
  my $remote=$args{'remote_mode'};
  my $atomic = $args{'atomic'};
  my $queue = $args{'queue'};
  my $cred = $args{'credentials'};
  my $host = $args{'host'};
  my $username = $args{'username'};
  use PMTUtilities qw(evalBoolean);
  $atomic = evalBoolean(value=>$atomic);
  $remove_original = evalBoolean(value=>$remove_original);
  print STDERR "Copying using ftp step 2\n";
  use Net::FTP;
  my $ftp = Net::FTP->new($host);
  $ftp->login($cred->{'username'},$cred->{'password'});
  $ftp->binary();
  use File::Spec;
  use File::Basename qw(basename);
  my $copyoptions = { atomic=>1,overwrite=>1,copy_time=>1,cleanup=>1};
  for my $f (@$source_file) {
    my $localname = File::Spec->catfile($target_directory,basename $f->{'path'});
    my $basename = basename $f->{'path'};
    print STDERR "Retrieving file: $f->{'orig_uri'} to $localname\n";
    $ftp->get($f->{'path'},$localname,%$copyoptions);

    if ($remove_original) {
      print STDERR "I should be removing $f->{'path'} ...";
      my $rd ;
      eval {$rd = $ftp->delete($f->{'path'}); }; if ($@) { print STDERR "Delete operation failed: $@\n"; }
      print STDERR "$rd ...\n";
      
    }
    
    if ($history_file) {
      my $m = $ftp->mdtm($f->{'path'});
      my $s = $ftp->size($f->{'path'});
      print $history_file "$basename;$m;$s\n";
    }
    #print STDERR "Retrieving file with $st->
  }
  print STDERR "so far so good\n";
}
sub copyFiles_ftp_step1 {
  my $self = shift;
  my %args = @_;
  my $source_file = $args{'sourcefile'};
  if (scalar @$source_file == 0) { return ; }
  my $target_directory = $args{'target_directory'};
  my $remove_original = $args{'remove_source'};
  my $history_file = $args{'history_file'};
  my $remote=$args{'remote_mode'};
  my $atomic = $args{'atomic'};
  my $queue = $args{'queue'};
  print STDERR "Copying using sftp step 1\n";

  # get all the host/username combinations, and split up the transfer by those
  my $host_usernames = {};
  for my $u (@$source_file) {
    if (not defined $host_usernames->{$u->{'host'}}) {
      $host_usernames->{$u->{'host'}} = {};
    }
    if (not defined $host_usernames->{$u->{'host'}}->{$u->{'username'}}) {
      $host_usernames->{$u->{'host'}}->{$u->{'username'}} = []; 
    }
    push @{$host_usernames->{$u->{'host'}}->{$u->{'username'}}},$u;
  }
  for my $h (keys %$host_usernames) {
    for my $u (keys %{$host_usernames->{$h}}) {
      # pull the first one of the list
      my $fu = $host_usernames->{$h}->{$u}->[0];
      my $fuo = $fu->{'corrected_uri'};
      use PMTUtilities qw(getCredentials);
      my $cred = getCredentials(uri=>$fuo);
      $self->copyFiles_ftp_step2(
         target_directory=>$target_directory,
         remove_source=>$remove_original,
         remote_mode=>$remote,
         atomic=>$atomic,
         queue=>$queue,
         history_file=>$history_file,
         sourcefile=>$host_usernames->{$h}->{$u},
         credentials=>$cred,
         host=>$h,
         username=>$u,
      );
    }
  }
}


sub copyFiles_scp {
}

sub copyFiles_file {
  my $self = shift;
  my %args = @_;
  my $source_file = $args{'sourcefile'};
  if (scalar @$source_file == 0) { return ; }
  my $target_directory = $args{'target_directory'};
  my $remove_original = $args{'remove_source'};
  my $history_file = $args{'history_file'};
  my $remote=$args{'remote_mode'};
  my $atomic = $args{'atomic'};
  my $queue = $args{'queue'};

  use File::Basename qw(basename);
  use File::Spec;

  FILELOOP:
  for my $f (@$source_file) {

    my $b = basename $f->{'path'};
    if (File::Spec->catfile($target_directory,$b) eq $f->{'path'}) {
      print STDERR "Cannot copy file $f->{'path'} onto itself\n";
      next FILELOOP;
    }
    
    my $rc = `cp $f->{'path'} $target_directory`;

    if ($remove_original) {
      $rc = `rm -f $f->{'path'}`;
    }

    if ($history_file) {
    	my @st = stat($f->{'path'});
      my $s = $st[7]; my $m = $st[9];
      print $history_file "$b;$m;$s\n";
    }
  }
}

sub copyFiles {
  my $self = shift;
  my %args = @_;
  my $source_file = $args{'sourcefile'};
  print STDERR "Got sourcefile : $source_file\n";
  if (ref $source_file eq 'ARRAY') {
  }
  else {
    $source_file = [ $source_file ];
  }
  my $target_directory = $args{'target_directory'};
  my $remove_original = $args{'remove_source'};
  my $history_file = $args{'history_file'};
  my $remote=$args{'remote_mode'};
  my $atomic = $args{'atomic'};
  my $queue = $args{'queue'};
  use PMTUtilities qw(parseURI);
  my @source_uris = map { parseURI(uri=>$_,resolve_credentials=>1) } @$source_file;
  # see what schemes we have
  use Data::Dumper;
  print STDERR "Uris are now:\n",Dumper(\@source_uris),"\n";
  my $schemes = {};
  for my $u (@source_uris) {
    if (not defined $schemes->{$u->{'scheme'}}) {
      $schemes->{$u->{'scheme'}} = [];
    }
    push @{$schemes->{$u->{'scheme'}}},$u;
  }
  my $history_file_handle;
  if ($history_file) {
    open ($history_file_handle,">>",$history_file);
  }
  for my $s (keys %$schemes) {
    if ($s =~ m/SFTP/i) {
       print STDERR "Copying using SFTP\n";
       $self->copyFiles_sftp_step1 (
         target_directory=>$target_directory,
         remove_source=>$remove_original,
         remote_mode=>$remote,
         atomic=>$atomic,
         queue=>$queue,
         history_file=>$history_file_handle,
         sourcefile=>$schemes->{$s}
       );
    }
    elsif ($s =~ m/SCP|SSH/i) {
       print STDERR "Copying using SCP\n";
    }
    elsif ($s =~  m/FTP/i) {
       $self->copyFiles_ftp_step1 (
         target_directory=>$target_directory,
         remove_source=>$remove_original,
         remote_mode=>$remote,
         atomic=>$atomic,
         queue=>$queue,
         history_file=>$history_file_handle,
         sourcefile=>$schemes->{$s}
       );
    }
    elsif ($s =~ m/FILE/i) {
       #print STDERR "Localcopy\n";
       $self->copyFiles_file(
         target_directory=>$target_directory,
         remove_source=>$remove_original,
         remote_mode=>$remote,
         atomic=>$atomic,
         queue=>$queue,
         history_file=>$history_file_handle,
         sourcefile=>$schemes->{$s}
       );
    }
  }
}
1;
