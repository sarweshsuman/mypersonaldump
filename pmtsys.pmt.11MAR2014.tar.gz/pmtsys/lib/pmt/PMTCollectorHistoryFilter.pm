package PMTCollectorHistoryFilter;

use strict;
use Carp;
use File::Touch;
use PMTUtilities qw(partial);

use overload q{&{}} => \&call_overload, 
             q{""}  => sub { return "<". __PACKAGE__ . " instance>"};

sub new {
  my $package = shift;
  my %args = @_;
  my $o = {}; 
  $o->{'initialcontext'} = $args{'initialcontext'};
  $o->{'xnode'} = $args{'xnode'};
  return bless $o; 
}

sub call_overload {
  my $self = shift;
  return partial(\&filter,$self);
}

sub filter {
  my $self = shift;
  my $xnode = $self->{'xnode'};
  my %args = @_;
  my $data = $args{'data'};
  my $ic = $self->{'initialcontext'};
  my $flowcd = $ic->{'SYSTEM/RUN/FLOWCD'};
  my $history_file ;
  if ($xnode->exists('config/history_file')) {
    $history_file = $xnode->xfind('config/history_file');
    #= "/opt/PMT/pmtsys/var/collection_history/${flowcd}.history";
  }
  else {
    $history_file = "/opt/PMT/pmtsys/var/collection_history/${flowcd}.history";
  }
  use File::Basename qw(dirname);
  my $histdir = dirname $history_file;
  use File::Path qw(make_path);
  make_path($histdir);
  print STDERR "Filtering the collection files for flowcd $flowcd using file $history_file \n";
  use File::Touch;
  touch($history_file);
  my @newlist = ();
  my $hfile_handle;
  open ($hfile_handle,"<",$history_file);
  my @lines = <$hfile_handle>;
  my $lines_hash = {};
  close $hfile_handle;
  for my $l (@lines) {
    chomp $l;
    my @lsplit = split(';',$l);
    print STDERR "Found filename $lsplit[0] in history file\n";
    $lines_hash->{$lsplit[0]} = 1;
  }
  for my $d (@$data) {
    if (not defined $lines_hash->{$d->{'filename'}}) {
      print STDERR "including file $d->{'filename'}\n";
      push @newlist,$d;
    }
    else {
      print STDERR "Discarding file $d->{'filename'}\n";
    }
  }
  use Data::Dumper;
  print STDERR "Filter should return: ",Dumper(\@newlist),"\n";
  if (wantarray) { return @newlist; }
  elsif (defined wantarray) { return \@newlist; }
  return undef;
}

1;
