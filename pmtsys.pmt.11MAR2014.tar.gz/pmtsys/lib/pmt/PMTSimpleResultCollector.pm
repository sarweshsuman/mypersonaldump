package PMTSimpleResultCollector;

use strict;
use Carp;

use PMTUtilities qw(partial);

use Time::HiRes qw(time);

use overload q{<>} => \&iterator_overload,
             q{""} => sub { return "<" . __PACKAGE__ ." instance>"; };

sub new {
  my $package = shift;
  my %args = @_;
  my $ic = $args{'initialcontext'};
  my $xn = $args{'xnode'};
  my $list = $args{'list'};
  my $batchsize = $args{'batchsize'};
  if (not $batchsize) { $batchsize = 1; }
  if (not $list) { $list = []; }
  my $o = {};
  $o->{'_list_'} = [];
  for my $i (@$list) {
    push @{$o->{'_list_'}},$i;
  }
  $o->{'xnode'} = $xn;
  $o->{'initialcontext'} = $ic;
  $o->{'ended'} = 0;
  $o->{'batchsize'} = $xn->xfind('config/batchsize',default=>1);
  $o->{'empty'} =  uc $xn->xfind('config/empty_policy',default=>'undef');
  $o->{'force_array'} = $xn->xfind('config/force_array',default=>0);

  print STDERR "Creating collector with batchsize $o->{'batchsize'}\n";
  return bless $o;
}

sub iterator_overload {
  my $self = shift;
  return $self->next();
}

sub next {
  my $self = shift;
  my $ended = $self->{'ended'};
  my $batchsize = $self->{'batchsize'};
  my $force_array = $self->{'force_array'};
  my $qs = scalar @{$self->{'_list_'}};
  use Data::Dumper;
  print STDERR "next called in PMTSimpleResultCollector [$ended][$batchsize][$qs]\n";
  my $item;
  if (scalar @{$self->{'_list_'}}) {
    if ($batchsize == 1) {
			$item = shift @{$self->{'_list_'}};
			if ($force_array) {
				return [$item];
			}
			else {
				return $item;
			}
    }
    else { # batchsize > 1
      if ($ended) {
        print STDERR time()," next:It is ended and my size is currently ",scalar @{$self->{'_list_'}},"\n"; 
      	my @il;
				while (scalar @il < $batchsize and scalar @{$self->{'_list_'}}) {
					push @il,shift @{$self->{'_list_'}};
				}
        print STDERR time()," next:It is ended and I return what I have ",Dumper(\@il),"\n"; 
         
				return \@il;
      }
      else {
        if (scalar @{$self->{'_list_'}} < $batchsize) {
          return undef;
        }
        else {
					my @il;
					while (scalar @il < $batchsize and scalar @{$self->{'_list_'}}) {
            my $i = shift @{$self->{'_list_'}};
						push @il,$i;
					}
          print STDERR "next:It is not ended: ,returning: ",Dumper(\@il),"\n";
					return \@il;
        }
      }
    }
  }
  else {
    if ($ended) {
      print STDERR time()," Returning empty_token\n";
      return bless {},'EMPTY_TOKEN';
    }
    else { 
      return undef;
    }
  }
}

sub append {
  my $self = shift;
  my %args = @_;
  my $item = $args{'item'};
  print STDERR time()," Adding item $item to result collector\n";
  push @{$self->{'_list_'}},$item;
}

sub end {
  my $self = shift;
  print STDERR "METHOD end is called on PMTSimpleResultCollector\n";
  $self->{'ended'} = 1;
}

1;
