package PMTDBConnection;

use strict;
use Carp;

sub new {
  print "creating a new DBConnection\n";
  my $class = shift;
  my $dbh = shift;
  my $o = {};
  $o->{'connection'} = $dbh;
  bless $o;
  return $o;
}

sub AUTOLOAD {
  my $self = shift;
  our $AUTOLOAD;
  my @methodcomps = split('::',$AUTOLOAD);
  my $method = pop(@methodcomps);
  my $dbh = $self->{'connection'};
  return $dbh->$method(@_);
}

sub DESTROY {
  my $self = shift;
  my $dbh = $self->{'connection'};
  print "killing the connection\n";
  $dbh->disconnect();
}

1;
