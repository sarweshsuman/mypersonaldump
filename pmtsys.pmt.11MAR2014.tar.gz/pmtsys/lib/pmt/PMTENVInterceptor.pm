package PMTENVInterceptor;

use strict;

use PMTInterceptorBase;
use PMTUtilities qw(icdefined);

our @ISA = qw(PMTInterceptorBase);

sub new {
  my $p = shift;
  my %args = @_;

  my $ic = $args{'initialcontext'};
  
  my $mod = {};

  $mod->{'initialcontext'} = $ic;

  if (icdefined $ic->{'CONFIG/ENV'}) {
    my $lcdenv = $ic->expand($ic->{'CONFIG/ENV'});

    for my $key (keys %$lcdenv) {
      $ENV{$key} = $lcdenv->{$key};
    }
  }

  bless $mod;

  #print STDERR "Loaded ".__PACKAGE__."\n";
  return $mod;

}

sub getPaths {
  my $self = shift;
  return [ '^ENV/[^\/]+$' ];
}

sub preRead {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $key = $args{'key'};
  my $val = $args{'value'};
  my $p = $args{'_path_'};
  my $kk = $args{'_ckey_'};

  #print __PACKAGE__,"looking for $key";

  if ($p->[0] eq 'ENV' and scalar @$p == 2 and defined $p->[1]) {
    my $pname = $p->[1];
    my $envvar = $ENV{$pname};
    #print STDERR "ENVInterceptor looking for $pname\n";
    if (defined $envvar) {
      return { value=>$envvar };
    }
  }
  return undef;
}

sub postSet {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $key = $args{'key'};
  my $val = $args{'value'};
  my $p = $args{'_path_'};
  my $kk = $args{'_ckey_'};

  if (defined $p->[0] and $p->[0] eq 'ENV' and defined $val and not ref $val) {
    $ENV{$key} = $val;
  }
}

sub getCloneData {
  my %self = shift;
  my %NH = %ENV;
  return { env_data=>\%NH};
}

sub isCloneable {
  return 1;
}
sub clone {
  my $self = shift;
  my %args = @_;
  my $nic = $args{'initialcontext'};

  return new(__PACKAGE__,initialcontext=>$nic,initparams=>$self->getCloneData());
}
1;
