package WorkController;
  
use strict;
use Carp;
use PMTExecContext;
use PMTUtilities qw(partial);
use PMTChannelLocker;

use overload q{&{}} => \&call_overload, 
             q{""}  => sub { return "<". __PACKAGE__ . " instance>"};
sub new {
  my $class = shift;
  my %args = @_;
  my $controller = $args{'controller'};
  my $processmodel = $args{'process_model'};
  my $item = $args{'item'};

  print STDERR "Creating workdcontroller for item $item and process_model $processmodel\n";

  my $o = {};
  $o->{'controller'} = $controller;
  $o->{'process_model'} = $processmodel;
  $o->{'started'} = 0;
  $o->{'initialcontext'} = $controller->{'initialcontext'};
  $o->{'current_step'} = -1;
  $o->{'current_step_node'} = undef;
  $o->{'iswaiting'} = 0;
  $o->{'item'} = $item;
  return bless $o;
}


sub call_overload {
  my $self = shift;
  return partial(\&run,$self);
}

sub isWaiting {
  my $self = shift;
  return $self->{'iswaiting'};
}

sub start {
  my $self = shift;
  my $controller = $self->{'controller'};
  my $ic = $self->{'initialcontext'};
  # this one should do the setup of all the instances, callables, whatever is in the objects node of the steps
  print STDERR "In workcontroller_start Building process for $self->{'process_model'}\n";
  $controller->send(type=>'new_item',data=>{item=>$self->{'item'}});
  $controller->send(type=>'ic_update',data=>{set=>{'WORKLIST/ITEM'=>$self->{'item'}}});
  $ic->{'WORKLIST/ITEM'} = $self->{'item'};
  # the other ones being: RUNTIME/EXEC/GROUP
  #                  and: RUNTIME/EXEC/STEP # this is one we have to set here :-)
  my $pm = $self->{'process_model'};
  if ($pm->exists('objects/object[@lifecycle="item"]')) {
    my @os = ();
    my $sobjects = $pm->xnode(data=>'objects/object[@lifecycle="item"]',force_array=>1);
    for my $sob (@$sobjects) {
      if ($sob->evalPreReqs(condition_type=>'create_condition')) {
        my $npa = $sob->xnodePath();
        push @os,$npa;
      }
    }
    use Data::Dumper;
    print STDERR "I found the following objects I should transmit:\n",Dumper(\@os),"\n";
    $controller->send(data=>\@os,type=>'process_setup');
    #use Data::Dumper;
    #for my $lo (@$os) {
    #  eval {
    #  	my $lof = $ic->xfactory(data=>$lo);
    #    $lof->();
    #  };
    #  if ($@) { print STDERR "Error in invoking xfactory:",Dumper($@),"\n"; }
     
    #}
  }
  
  
  $self->{'started'} = 1;
  #$controller->send(type=>'item_end');
}

sub run {
  my $self = shift;
  my %args = @_;
  print "Doing run in workcontroller\n";
  my $ic = $self->{'initialcontext'};
  my $controller = $self->{'controller'};
  my $pm = $self->{'process_model'};
  my $directives = $args{'directives'};
  my $data = $args{'data'};
  if (not $self->{'started'}) {
  	print "Doing start in workcontroller\n";
    $self->start();
  }
  # end then start the process
  my $cs = $self->{'current_step'};
  print STDERR "Doing process setup\n";
  my $condition_ok = 1; my $no_wait = 1;
  if ($pm->exists("steps/step[\@seq > $cs]")) {
    my $sts = $pm->xnode(data=>"steps/step[\@seq > $cs]",force_array=>1);
    my @sorted_steps = sort { $a->xfind('./@seq') cmp $b->xfind('./@seq') } @$sts;
    use Data::Dumper;
    print STDERR "Looking for suitable stepnode in @sorted_steps\n";

    my $step_to_send;
    # now find the first step that I can send
    my $stepfound = undef;
    use Data::Dumper;
    STEPLOOP:
    for my $stnode (@sorted_steps) {
       my $stepname = $stnode->xfind('./@name');
       eval {
       if ($stnode->evalPreReqs(condition_type=>'create_condition')) {
         # all is well
         print STDERR "create_condition for step $stepname are ok\n";
       }
       else {
         # We can skip this all together
         # and to avoid having to go through this one in the next run
         $self->{'current_step'} = $stnode->xfind('./@seq');
         $self->{'current_step_node'} = $stnode->xfind('./nodePath()');
         next STEPLOOP;
       }
       if ($stnode->evalPreReqs(condition_type=>'wait')) {
         # that's ok too
         print STDERR "wait_condition for step $stepname are ok\n";
       }
       else {
         # OK, we have a wait condition here ... 
         $no_wait = 0;
         $self->{'iswaiting'} = 1;
         last STEPLOOP;
       }
       if ($stnode->evalPreReqs(condition_type=>'condition')) {
         # we're still good
         print STDERR "condition for step $stepname is ok\n";
       }
       else {
         $self->{'current_step'} = $stnode->xfind('./@seq');
         $self->{'current_step_node'} = $stnode->xfind('./nodePath()');
         next STEPLOOP;
       }
       if ($condition_ok and $no_wait) {
         # I can send the node
         $self->{'iswaiting'} = 0;
         $stepfound = $stnode;
         my $stepname = $stnode->xfind('./@name',default=>'_unknown_');
         $self->{'current_step'} = $stnode->xfind('./@seq');
         $self->{'current_step_node'} = $stnode->xfind('./nodePath()');
         my $target = $stnode->xfind('./@target',default=>'helper');
         $ic->{'RUNTIME/EXEC/STEP'} = $stepname;
         if (uc $target eq 'HELPER') {
         	 print STDERR "sending service_request to client for step $stepname\n";
    		 	 my $eh = $controller->createRequestHandle(custom=>{request=>'STEP',stepnode=>$stnode->xfind('./xnodePath()')});
    		 	 $controller->submit(request_handle=>$eh);
         }
         elsif (uc $target eq 'LOCAL') {
           use Data::Dumper;
           eval {
             my $test = $ic->{'RUNTIME/EXEC/GROUP'};
             print "TESTTEST: $test\n";
             $controller->execLocalStep(stepnode=>$stnode);
           }; if ($@) { print STDERR "An error occurred while executing localstep:",Dumper($@),"\n"; }
           $self->run();
         }
         last STEPLOOP;
       }
       };
       if ($@) {
         print STDERR "Error occurred during run in workcontroller: ",Dumper($@),"\n";
       }
    }
    if (not defined $stepfound and $no_wait) {
      print STDERR "No items found that match and nothing is waiting\n";
      $self->{'iswaiting'} = 0;
    	$controller->send(type=>'item_end');
    }
    #else { 
    #  print STDERR "Why did I not send an item_end\nstepfound = $stepfound\n,condition_ok=$condition_ok\n,no_wait=>$no_wait\n";
    #}
  }
  else {
    print STDERR "No more steps: sending item_end\n";
    $self->{'iswaiting'} = 0;
    $controller->send(type=>'item_end');
  }
  print STDERR "End of run in WorkController\n";

  # This is called in case of ask_work or step_end
}

1;

package PMTHelperHelper;

select STDERR;
$|=1;
use strict;
use Carp;

use POSIX ":sys_wait_h";
use IPC::Open2;
use IO::Select;
use IO::Socket::INET;
use PMTUtilities qw(icdefined partial serializeTo deserializeFrom);
use PMTChannelLocker;

use overload '&{}' => \&call_overload, q{""}=>\&as_string;

sub service_request_status_handler {
  my $controller = shift;
  use Data::Dumper;
  my %args = @_;
  my $directives = $args{'directives'};
  my $data = $args{'data'};
  my $request_id = $data->{'request_id'};
  my $status = $data->{'status'};
  my $q = $controller->{'run_queue'};
  my @rh = grep { $_->{'local_id'} eq $request_id } @$q;
  if (@rh) { $rh[0]->{'status'} = $status; }
  print STDERR "Setting service request $request_id to status $status, in ",Dumper(\@rh),"\n";
}

sub service_request_response_handler {
  print STDERR "In service_request_response handler\n";
  my $controller = shift;
  my %args = @_;
  my $directives = $args{'directives'};
  my $data = $args{'data'};
  my $request_id = $data->{'request_id'};
  my $q = $controller->{'run_queue'};
  my @rh = grep { $_->{'local_id'} eq $request_id } @$q;
  if (@rh) {
    $rh[0]->{'status'} = 'FINISHED';
  }
  use Data::Dumper;
  print STDERR  "Got service response data:",Dumper($data),"\n";
}

sub service_request_accept_handler {
  my $controller = shift;
  my %args = @_;
  my $directives = $args{'directives'};
  my $data = $args{'data'};
  my $request_id = $data->{'request_id'};
  my $q = $controller->{'run_queue'};
  my @rh = grep { $_->{'local_id'} eq $request_id } @$q;
  if (@rh) { $rh[0]->{'status'} = 'QUEUED'; }
  print STDERR "In handler for service_request_accept\n";
}

sub child_log_handler {
  my $controller = shift;
  print STDERR "Log handler doing something\n";
}

sub do_status_update { 
  print STDERR "Processing message of type status_update\n";
}
sub do_data_summary { 
  print STDERR "Processing message of type data_summary\n";
}
sub do_process_statistics { 
  my $controller = shift;
  my %args = @_;
  my $data = $args{'data'};
  my $directives = $args{'directives'};
  use Data::Dumper;
  print STDERR "Processing a process_statistics message: ",Dumper(\%args),"\n"; 
}
sub do_new_status {
  print STDERR "Processing message of type new_status\n";
}
sub do_event {
  my $controller = shift;
  my %args = @_;
  my $data = $args{'data'};
  my $directives = $args{'directives'};
  use Data::Dumper;
  print STDERR "Processing an event message: ",Dumper(\%args),"\n"; 
  my $ic = $controller->{'initialcontext'};
  $ic->appendJLOG(data=>$data,directives=>$directives);
}

sub do_process_data {
  my $controller = shift;
  my %args = @_;
  my $data = $args{'data'};
  my $directives = $args{'directives'};
  my $ic = $controller->{'initialcontext'};
  $ic->appendJLOG(data=>$data,directives=>$directives);
}


sub end_ack_handler {
  my $controller = shift;
  print STDERR "End of ack received ... the listener should stop now\n";
  $controller->{'do_continue'} = 0;
  $controller->setFinished();
}

sub ask_work_handler {
  my $controller = shift;

  print STDERR "ask_work_handler called\n";
  my $worklist = $controller->getResource(name=>'worklist');
  my $processmodel = $controller->getProcessModel();
  print STDERR "worklist in ask_work_handler = ",$worklist,"\n";
  my $policy = $controller->{'worklist_policy'}; $policy = uc $policy;
  print STDERR "ask_work_handler called with policy $policy\n";
  if ($policy eq 'UNDEF') {
		my $item = <$worklist>;
		print STDERR "Picked item from worklist: $item\n";
		if (defined $item) {
			print STDERR "I should start building a work list\n";
			my $work_controller = $controller->buildWorkController(item=>$item);
			$work_controller->(@_);
		}
		else {
			# send an end request
			use Data::Dumper;
			my $eh = $controller->createRequestHandle(custom=>{request=>'__end__'});
			print STDERR "I should send an end request in ask_work_handler,",Dumper($eh),"\n";
			$controller->submit(type=>'service_end',request_handle=>$eh);
			 # now make a wait_function;
			#$controller->send(type=>'final_exit');
		}
  }
  elsif ($policy eq 'EMPTY_TOKEN') {
		my $item = <$worklist>;
		print STDERR "Picked item from worklist: $item\n";
		if (defined $item and ref $item eq 'EMPTY_TOKEN') {
      print STDERR "I got an empty token\n";
			use Data::Dumper;
			my $eh = $controller->createRequestHandle(custom=>{request=>'__end__'});
			print STDERR "I should send an end request in ask_work_handler,",Dumper($eh),"\n";
			$controller->submit(type=>'service_end',request_handle=>$eh);
    }
    elsif (defined $item) {
			print STDERR "I should start building a work list\n";
			my $work_controller = $controller->buildWorkController(item=>$item);
			$work_controller->(@_);
		}
		else {
      $controller->send(type=>'wait_work');
		}
  }
  # during development, I will just send an end request
}

sub step_end_handler {
  my $controller = shift;
  my %args = @_;
  print STDERR "step_end_handler called in pmthelperhelper\n";
  my $workcontroller = $controller->getWorkController();
  $workcontroller->(@_);
}

sub helpersetup_handler {
  my $controller = shift;
  my %args = @_;

  my $ic = $controller->{'initialcontext'};
  #print STDERR "ic is now $ic\n";
  my $directives = $args{'directives'};
  my $data = $args{'data'};

  # I should send it everything I have under SYSTEM

  my $sysdata = $ic->{'SYSTEM'};
  #print STDERR "I should send it ",$sysdata,"\n";
  $controller->send(data=>{set=>{SYSTEM=>$sysdata}},type=>'ic_update');
  $controller->send(data=>{set=>{'RUNTIME/EXEC/GROUP'=>$ic->{'RUNTIME/EXEC/GROUP'}}},type=>'ic_update');
  if (icdefined $ic->{'CMDPARAM'}) {
    my $cmddata = $ic->{'CMDDATA'};
    $controller->send(data=>{set=>{CMDDATA=>$cmddata}},type=>'ic_update');
  }

  # And then the plugins
  # I need env, conf, and xpathinterceptor,and log, log is a little tricky for now
  my $env_helper = $ic->getNamedPlugin(name=>'ENV');
  #print STDERR "ENV helper = ",$env_helper,"\n";

  my $interceptors = $ic->getNamedPlugins(type=>'interceptor');
  my $plugins = [];
  for my $ii (@$interceptors) {
    # this is under the assumption that all we have here are cloneable or inheritable plugins
    #print STDERR "Checking for 'remotability' of plugin $ii->{'name'}\n";
    if ($ii->{'plugin'}->can('noRemoteClone') and $ii->{'plugin'}->noRemoteClone()) {
      # do nothing :-)
      #print STDERR "Plugin $ii->{'name'} cannot be remoted\n";
    }
    else {
      #print STDERR "Plugin $ii->{'name'} can be remoted\n";
    	push @{$plugins},{ name=>$ii->{'name'},module=>ref $ii->{'plugin'},initparams=>$ii->{'plugin'}->getCloneData() };
    }
  }
  push @$plugins, { name=>'LOG',module=>'PMTPLHelperLogHelper' };
  #my $plugins = [
  #  { name=>'ENV',module=>'PMTENVInterceptor',initparams=>$ic->getNamedPlugin(name=>'ENV')->getCloneData() },
  #  { name=>'CONFIG',module=>'PMTConfigInterceptor',initparams=>$ic->getNamedPlugin(name=>'CONFIG')->getCloneData() },
  #  { name=>'JOBDEF',module=>'PMTXPathInterceptor',initparams=>$ic->getNamedPlugin(name=>'JOBDEF')->getCloneData() }
  #];

  $controller->send(type=>'ic_setup',data=>{plugins=>$plugins});
  print STDERR "End of helpersetup_handler\n";
  

  # I should basically send it ic_update and ic_setup data
}

use PMTExecContext;

sub new {
  my $package = shift;
  my %args = @_;
  my $o = {};
  $o->{'workerpool'} = {};
  $o->{'io_pid_mapping'} = {};
  $o->{'initialcontext'} = new PMTExecContext($args{'initialcontext'});
  $o->{'code'} = $args{'code'};
  $o->{'callable'} = $args{'callable'};
  $o->{'instance'} = $args{'instance'};
  $o->{'args'} = $args{'args'};
  $o->{'helperscript'} = $args{'helper'};
  if (exists $args{'async'}) { $o->{'async'} = $args{'async'}; } else { $o->{'async'} = -1};
  $o->{'ioselector'} = IO::Select->new();
  $o->{'state'} = undef;
  $o->{'channel'} = undef;
  $o->{'_workitemfinished_'} = 0;
  $o->{'type'}= undef;
  $o->{'run_queue'} = [];
  $o->{'xnode'} = $args{'xnode'};
  $o->{'local_request_counter'} = 0;
  $o->{'process_model'} = undef; #= $args{'process_model'}; # this should be an xnode
  $o->{'worklist'} = $args{'worklist'};
  $o->{'resultcollector'} = $args{'resultcollector'};
  $o->{'state'} = undef;
  $o->{'_finished_'} = 0;
  $o->{'_channellocked_'} = 0;
  $o->{'initial_item'} = $args{'initial_item'};
  $o->{'worklist_policy'} = undef;

  use Data::Dumper;
  my $xnode = $o->{'xnode'};
  $xnode->setIC(initialcontext=>$o->{'initialcontext'});
  my $group = $xnode->xfind('./ancestor::group[1]/@name/data(.)');
  print STDERR "HelperHelper: group $group\n";
  my $ic = $o->{'initialcontext'};
  $ic->{'RUNTIME/EXEC/GROUP'} = $group;
  
  if (not $o->{'args'}) {
    $o->{'args'} = {};
  }
  $o->{resources} = {};

  return bless $o;
}

sub setFinished {
  print STDERR "SetFinished called\n";
  my $self = shift;
  $self->{'_finished_'} = 1;
}

sub setWorkListPolicy {
  my $self = shift;
  my %args = @_;
  my $policy = $args{'policy'};
  $self->{'worklist_policy'} = uc $policy;
  print STDERR "Setting worklist policy to ",uc $policy,"\n";
}

sub isFinished {
  my $self = shift;
  if ($self->{'_finished_'}) {
    print STDERR "Mmmm who set this to finished\n";
    return 1;
  }
  print STDERR "isFinished = called in PMTHelperHelper\n";
  my $cl = new PMTChannelLocker($self);
  #print "ChannelLocker created in isFinished\n";
  print "finished: _finished_ = $self->{'_finished_'}\n";
  if (not $self->{'_finished_'}) {
    # check if its waiting
    my $workcontroller = $self->getWorkController();
    if (not defined $workcontroller) {
      print STDERR "Eeeeh ? forkcontroller is not defined\n";
    }
    else {
      print STDERR "Ah ok  workcontroller is defined\n";
    }
    if (defined $workcontroller and $workcontroller->isWaiting()) { 
      $workcontroller->();
    }
  }
  print STDERR "End of isFinished in PMTHelperHelper\n";
  return $self->{'_finished_'};
}

sub getProcessModel {
  my $self = shift;
  return $self->{'process_model'};
}

sub setResources {
  my $self = shift;
  my %args = @_;
  for my $k (keys %args) {
    $self->{'resources'}->{uc $k} = $args{$k};
  }
}

sub getResource {
  my $self = shift;
  my %args = @_;
  my $resourcename = uc $args{'name'};
  return $self->{'resources'}->{$resourcename};
  
}

sub setProcessModel {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  $self->{'process_model'} = $ic->xnode(data=>$args{'process_model'});
  #$self->{'process_model'} $ic->
  #$self->{'process_model'}->setRootParser(rootparser=>$self->{'xnode'}->{'_rootparser'});
}

sub getProcessModel {
  my $self = shift;
  return $self->{'process_model'};
}

sub send {
  my $self = shift;
  my %args = @_;
  my $waitfor;
  my $channel_writer = $self->{'channel_writer'};
  return $channel_writer->(@_,reader=>partial(\&receive,$self));
}

sub receive {
 my $self = shift;
 # print STDERR "RECEIVE CALLED IN HELPERHEMPER\n";
 my $channel_reader = $self->{'channel_reader'};
 my $rhs = {};
  #print STDERR "CONFIGURING READER handlers\n";
 for my $rh (keys %{$self->{'reader_handlers'}}) {
  #print STDERR "Configuring handler: $rh\n";
  $rhs->{$rh} = partial($self->{'reader_handlers'}->{$rh},$self);
 }
 $channel_reader->(handlers=>$rhs,@_);
}

sub as_string {
  return "PMTHelperHelper Instance";
}

sub call_overload {
  my $self = shift;
  use PMTUtilities qw(partial);
  return partial(\&run,$self);
}

sub setup {
  my $self = shift;
  my %args = @_;
  my $cl = new PMTChannelLocker($self);
  $self->{'code'} = $args{'code'};
  $self->{'callable'} = $args{'callable'};
  $self->{'instance'} = $args{'instance'};
  $self->{'args'} = $args{'args'};
  
  
  my $code = $self->{'code'};
  my $instance = $self->{'instance'};
  my $callable = $self->{'callable'};
  my $args = $self->{'args'};

  my $helper_data = {};
  my $to_execute;
  if ($code) {
    $helper_data->{'code'} = $code;
    $self->{'type'} = 'code';
  }
  elsif (defined $callable) {
    $helper_data->{'callable'} = $callable;
    $self->{'type'} = 'callable';
  }
  elsif (defined $instance) {
    $helper_data->{'instance'} = $instance;
    $self->{'type'} = 'instance';
  }

  $helper_data->{'args'} = $args;

  print STDERR "PMTHelperHelper Waiting for ack for prepare\n";
  $self->send(type=>'setup',wait_for=>'ack',data=>{prepare=>$helper_data});
  print STDERR "PMTHelperHelper got ack\n";
}

sub buildWorkController {
  my $self = shift;
  my %args = @_;
  my $item = $args{'item'};
  $self->{'_workcontroller_'} = new WorkController(item=>$item,controller=>$self,process_model=>$self->{'process_model'});
  return $self->{'_workcontroller_'};
}

sub getWorkController {
  my $self = shift;
  return $self->{'_workcontroller_'};
}

sub createRequestHandle {
  my $self = shift;
  my %args = @_;
  my $custom_request = $args{'custom'};

  my $async = $self->{'async'};
  my $channel = $self->{'channel'};
  
  my $type = $self->{'type'};

  my $request_data = {};

 
  my $returns = $args{'returns'}; if (not icdefined $returns) { $returns = 'ARRAY' };
  if ($custom_request) {
    $request_data->{'request'} = $custom_request->{'request'};
    $request_data->{'data'} = {};
    for my $k (keys %$custom_request) {
      if ($k ne 'request') {
        $request_data->{'data'}->{$k} = $custom_request->{$k};
      }
    }
  }
  else {
		if ($type eq 'instance') {
			if (defined $args{'method'}) { 
				$request_data->{'request'} = 'method';
				$request_data->{'method'} = $args{'method'};
			}
			else {
				$request_data->{'request'} = 'call';
				$request_data->{'method'} = 'overload::call';
			}
			$request_data->{'args'} = $args{'args'};
		}
		elsif ($type eq 'callable') {
			$request_data->{'request'} = 'call';
			$request_data->{'args'} = \%args;
		}
		elsif ($type eq 'code') {
			$request_data->{'request'} = 'call';
			$request_data->{'args'} = \%args;
		}
    if ($returns) {
      $request_data->{'returns'} = uc $returns;
    }
    $request_data->{'calling_convention'} = { initialcontext=>1, controller=>1 };
  }
  
  $self->{'local_request_counter'} = $self->{'local_request_counter'} + 1;
  my $request_handle = { request=>$request_data,status=>'WAITING',id=>undef, local_id => $self->{'local_request_counter'} };

  push @{$self->{'run_queue'}},$request_handle;
  print "Added the new request handle to the queue\n";

  return $request_handle;
}

sub submit {
  my $self = shift;
  my %args = @_;
  my $cl = new PMTChannelLocker($self);

  use Data::Dumper;
  #print STDERR "In submit, reader_handlers = ",Dumper($self->{'reader_handlers'}),"\n";

  my @to_submit;
  if (defined $args{'request_handle'}) {
    @to_submit = ($args{'request_handle'});
  }
  else {
  	my @run_queue = @{$self->{'run_queue'}};
    @to_submit = grep { $_->{'status'} eq 'WAITING' } @run_queue;
  }
  my $type; if (defined $args{'type'}) { $type = $args{'type'}; } else { $type = "service_request"; }
  
  for my $rh (@to_submit) {
    $self->send(type=>$type,data=>{request_id=>$rh->{'local_id'},data=>$rh->{'request'}});
    
    print STDERR "$$ Sent service request to child with type $type\n";
    $rh->{'status'} = 'SUBMITTED';
    $self->{'status'} = 'RUNNING';
  }

 
  return;
}

sub helperSetup {
  my $self = shift;

  my $ic = $self->{'initialcontext'};
  my $xnode = $self->{'xnode'};
  my $processmodel = $self->{'process_model'};

  print STDERR "building processmodel in helpersetup\n";
  # This should do the startup of the helper ... 
  my $args = $self->{'args'};
  my $helperscript = $self->{'helperscript'};
  my $ident = $ic->expand('{{_PROCESSID_}}.{{SYSTEM/RUN/FLOWCD}}.{{SYSTEM/RUN/ROLE}}');
  my $code = $self->{'code'};
  my $callable = $self->{'callable'};
  my $instance = $self->{'instance'};
  my $async = $self->{'async'};
  
  if (not defined $args) { $args = {}; }
  if (not defined $helperscript) { $helperscript = 'PMTPLHelper'; }

  my $do_continue = 1;
  my $workerpool = $self->{'workerpool'};
  my $io_pid_mapping = $self->{'io_pid_mapping'};
  my $selector = $self->{'ioselector'}; 


  my ($child_writer,$child_reader);
  my $pid = open2($child_reader,$child_writer,"$helperscript --ident $ident");

  my $wtr = IO::Handle->new()->fdopen($child_writer,"w");
  my $rdr = IO::Handle->new()->fdopen($child_reader,"r");

  serializeTo(type=>'handshake_request',data=>{request=>'handshake'},io=>$wtr);
  my $response_data = deserializeFrom(io=>$rdr,wait_for=>'handshake_response');
  my $handshake;
  if (defined $response_data->{'response'}->{'handshake'}) {
    $handshake = $response_data->{'response'}->{'handshake'};
    use Data::Dumper;
    #print STDERR "Got handshake data\n",Dumper($handshake),"\n";
  }
  else {
    croak {message=>'Protocol error in communication with child'};
  }
  my $socket = IO::Socket::INET->new(
      PeerHost=>$handshake->{'host'},
      PeerPort=>$handshake->{'port'},
      Proto=>'tcp'
  ) or die "Could not create connection: $!";  
  print STDERR "Created client socket in PMTHelperHelper\n";
  $selector->add($socket);
  $self->{'channel'} = $socket;
  $workerpool->{$pid} = { reader=>IO::Handle->new()->fdopen($child_reader,"r"),
                          writer=>IO::Handle->new()->fdopen($child_writer,"w"),
                          status=>'WAIT',
                          channel=>$socket
                        };

  $io_pid_mapping->{$socket} = $pid;

  $self->{'state'} = 'INITIALIZED';

  #my $prepare_name = '__default__';
  #my $helper_data = {name=>$prepare_name};
  #my $to_execute;
  #if ($code) {
  #  $helper_data->{'code'} = $code;
  #  $self->{'type'} = 'code';
  #}
  #elsif (defined $callable) {
  #  $helper_data->{'callable'} = $callable;
  #  $self->{'type'} = 'callable';
  #}
  #elsif (defined $instance) {
  #  $helper_data->{'instance'} = $instance;
  #  $self->{'type'} = 'instance';
  #}

  #$helper_data->{'args'} = $args;
  # Now prepare the helper


  # Create a few shortcuts ...

  $self->{'reader_handlers'} = {
    service_request_status=>partial(\&service_request_status_handler),
    service_request_accept=>partial(\&service_request_accept_handler),
    ic_update_ack=> sub { },
    end_ack=>partial(\&end_ack_handler),
    ask_work=>partial(\&ask_work_handler),
    step_end=>partial(\&step_end_handler),
    #service_request_response=>sub { print STDERR "In service_request_response handler\n"; }, # partial(\&service_request_response_handler),
    service_request_response=>partial(\&service_request_response_handler),
    log=>partial(\&child_log_handler),
    status_update=>partial(\&do_status_update),
    data_summary=>partial(\&do_data_summary),
    event=>partial(\&do_event),
    process_data=>partial(\&do_process_data),
    process_statistics=>(\&do_process_statistics),
    new_status=>(\&do_new_status)
  };
  my $cr = partial(\&deserializeFrom,io=>$socket);
  my $cw = partial(\&serializeTo,io=>$socket);
  $self->{'channel_writer'} = $cw;
  $self->{'channel_reader'} = $cr;

  #print STDERR "PMTHelper waiting for ack for prepare request in constructor\n";
  #$cw->(type=>'setup',data=>{prepare=>$helper_data},wait_for=>'ack');
  #print STDERR "PMTHelper got ack for prepare request in constructor\n";

}

sub run {
  my $self = shift;
  if (not defined $self->{'state'}) {
    $self->helperSetup();
  }
  $self->helpersetup_handler();
  #print STDERR "Locking channel in PMTHelperHelper::run, current state = $self->{'_channellocked_'}\n";
  $self->send(type=>'lock_channel',wait_for=>'channel_locked');
  #print STDERR "Got channel_locked reply ack from child in PMTHelperHelper::run\n";
  $self->{'_channellocked_'} = 1;
  my $pm = $self->{'process_model'};
  if ($pm->exists('objects/object[@lifecycle != "item"]')) {
    my $sobjects = $pm->xfind('objects/object[@lifecycle != "item"]/xnode()',force_array=>1);
    my @os = ();
    for my $sob (@$sobjects) {
      if ($sob->evalPreReqs(condition_type=>'create_condition')) {
        my $npa = $sob->xnodePath();
        push @os,$npa;
      }
    }
    use Data::Dumper;
    #print STDERR "I found the following objects I should transmit:\n",Dumper(\@os),"\n";
    $self->send(data=>\@os,type=>'initial_process_setup');
    #use Data::Dumper;
    #for my $lo (@$os) {
    #  eval {
    #  	my $lof = $ic->xfactory(data=>$lo);
    #    $lof->();
    #  };
    #  if ($@) { print STDERR "Error in invoking xfactory:",Dumper($@),"\n"; }
     
    #}
  }
  else {
  	$self->send(type=>'helper_start');
  }
  #$self->processQueue();
}


sub run_orig {
  my $self = shift;
  my %args = @_;

  #print STDERR "run is called in PMTHelperHelper\n";



  my $request_handle = $self->createRequestHandle(@_);
  $self->submit(request_handle=>$request_handle);

  if (defined wantarray) { return $request_handle; }
  return;
 
}

sub processQueue {
  my $self = shift;
  my $cl = new PMTChannelLocker($self);
}

sub isWorkItemFinished {
  my $self = shift;
  return $self->{'_workitemfinished_'};
}

sub join {
  my $self = shift;
  my %args = @_;


  if ($args{'_destructor_'}) {
    # check the latest request
    my $queue = $self->{'run_queue'};
    my $last_request = @$queue[-1];
    if ($last_request->{'request'}->{'request'} eq '__end__') {
      # do nothing;
    }
    else { 
  		#my $channellocker =  new PMTChannelLocker($self);
      print STDERR "TODO: Please check the conditions for join method\n";
      # add an end request to the queue
      my $eh = $self->createRequestHandle(custom=>{request=>'__end__'});
      $self->submit(request_handle=>$eh);
      # now make a wait_function;
      my $wf = sub {
        # I get a lot of arguments here but I don't really need them
        my $runqueue = $self->{'run_queue'};
        my @end_item = grep { $_->{'request'}->{'request_id'} eq '__end__'} @$runqueue;
        #if (@end_item and $end_item[0]->{'status'} eq 'FINISHED') { return 1; } else { return 0 };
        return @end_item and $end_item[0]->{'status'} eq 'FINISHED' ? 1 : 0;  
      };
      #$self->receive(wait_for=>$wf);
    	#push @$queue, { id=>undef,status=>'WAITING',request=>{'request'=>'end' }, local_id=>$self->{'local_request_counter'}};
    }
    return $self->join(wait_for=>'end_ack');
  }
  else {

  	my $channellocker =  new PMTChannelLocker($self);

    print STDERR "Doing joining in PMTHelperHelper\n";

		my $join_to = $args{'local_id'};
		if (not $join_to) { $join_to = $self->{'local_request_counter'}; }
		print STDERR "Joining up to $join_to\n";
		# get all the request handles to need to be joined
		my @queue = @{$self->{'run_queue'}};
		print STDERR "In join: Current queue = ",Dumper($self->{'run_queue'}),"\n";
		
		my @process_queue = grep { $_->{'local_id'} le $join_to } @queue;

#- 		for my $rh (@process_queue) {
#- 			print STDERR "Checking item = ",Dumper($rh),"\n";
#- 			if ($rh->{'status'} eq 'FINISHED') {
#- 				if ($rh->{'local_id'} eq $join_to) {
#- 					#return the result
#- 					return;
#- 				}
#- 			}
#- 			elsif ($rh->{'status'} eq 'RUNNING') {
#- 				# wait till it's done
#- 				while ($rh->{'status'} eq 'RUNNING') {
#- 					my ($directives,$response) = $self->receive();
#- 					if ($directives->{'message_role'} eq 'response') {
#- 						$rh->{'status'} = 'FINISHED';
#- 					}
#- 					elsif ($directives->{'message_role'} eq 'log') {
#- 						# I should be logging this
#- 					}
#- 					elsif (not defined $directives->{'message_role'}) {
#- 						$rh->{'status'} = 'FINISHED';
#- 					}
#- 					else {
#- 						# discard it for now
#- 						print STDERR "discarding message type $directives->{'message_role'}\n";
#- 					}
#- 				}
#- 				print STDERR "done with item: ",Dumper($rh),"\n";
#- 			}
#- 			elsif ($rh->{'status'} eq 'SUBMITTED') {
#- 			}
#- 			elsif ($rh->{'status'} eq 'WAITING') {
#- 				# if I get one here with status waiting, I think it implies that I passed the running
#- 			}
#- 		}

# # 		if ($self->{'running'}) {
# # 		my $workerpool = $self->{'workerpool'};
# # 		my $io_pid_mapping = $self->{'io_pid_mapping'};
# # 		my $selector = $self->{'selector'};
# # 
# # 		# get all the request handles to need to be joined
# # 		my @queue = @{$self->{'run_queue'}};
# # 		print STDERR "Current queue = ",Dumper($self->{'run_queue'}),"\n";
# # 
# # 			my $do_continue = 1;
# # 
# # 			while ($do_continue > 0) {
# # 				for my $pid (keys %$workerpool) {
# # 					my $check = kill 0=>$pid; 
# # 					if (not $check) {
# # 						 delete $workerpool->{$pid};
# # 						 $do_continue = 0;
# # 					}   
# # 				}
# # 				my @can_read = $selector->can_read(0.1); 
# # 				if (scalar @can_read) {
# # 					for my $h (@can_read) {
# # 						my $p = $io_pid_mapping->{$h};
# # 						my $data = $self->receive();
# # 						if (defined $data->{'action'}) {
# # 						}
# # 						elsif (defined $data->{'end'}) {
# # 							my $rc = waitpid($p,WNOHANG);
# # 							delete $workerpool->{$p};
# # 							delete $io_pid_mapping->{$h};
# # 							$selector->remove($h);
# # 						}
# # 					}
# # 				}
# # 			}
# # 			$self->{'running'} = 0;
# # 		}

  }
}

####
## A Series of testfunctions ... 
## For UnitTesting or whatever
####

sub test_send_ic_update {
  my $self = shift;
  my %args = @_;
  my $data = $args{'data'};

  my $cl = new PMTChannelLocker($self);
  $self->send(data=>$data,wait_for=>'ic_update_ack',type=>'ic_update');
  print STDERR "Got ack for ic_update\n";
}

sub kill {
  my $self = shift;
  # not clear yet what I have to do here ...
}

sub DESTROY {
  my $self = shift;
  print STDERR "$$ In destructor of PMTHelperHelper;\n";
  use Data::Dumper;
  my $rh = $self->{'reader_handlers'};
  #print STDERR "$$ In destructor, reader_handlers = ",Dumper($rh),"\n";
  if ($self->{'state'} eq 'TERMINATED') { return; }
  $self->join(_destructor_=>1);
  print STDERR "PMTHelperHelper: I am done: I should somehow tell the child I'm exiting\n";
  #undef $self->{'channel_reader'};
  #undef $self->{'channel_writer'};
  $self->send(type=>'final_exit');
  print STDERR "Shutting down channel in helperhelpeer\n";
  $self->{'channel'}->shutdown(2);
  $self->{'channel'}->close();
  # and finally wait for the child
  my $workerpool = $self->{'workerpool'};
  for my $p (keys %$workerpool) {
		my $rc = waitpid($p,WNOHANG);
  }
  undef;
}

sub execLocalStep {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_; 
  my $test = $ic->{'RUNTIME/EXEC/GROUP'};
  print STDERR "TESTTESTTEST: $test\n";
  my $stepnode = $args{'stepnode'};
  my $test2 = $stepnode->texpand('{{RUNTIME/EXEC/GROUP|default groupnotnown}}');
  print STDERR "TESTTOST: $test2\n";
  # what can I find here
  print STDERR "Executing a local step: $stepnode\n";
  my $names = $stepnode->xfind('*[name() != "pre_reqs"]/name(.)',force_array=>1);
  for my $n (@$names) {
    print STDERR "Executing a local step of type: $n\n";
  }
  my $stepelements = $stepnode->xnode(data=>'*[name() != "pre_reqs"]',force_array=>1);
  for my $sel (@$stepelements) {
    my $n = $sel->xfind('./name()');
    if ($n eq 'ic_update') {
      my $ic_update = $sel->xfind('./parseParamset()');
      use PMTUtilities qw(icdefined mergeRecursiveHash);
      if (icdefined $ic_update) {
        mergeRecursiveHash(src=>$ic_update,update=>$ic);
      }   
    }   
    elsif ($n eq 'call') {
      my $object = $sel->xfind('object');
      my $method = $sel->xfind('method');
     
      my $params;
      if ($sel->exists('params')) {
        $params = $sel->xfind('params');
      } else { $params = {};} 
      use Data::Dumper();
      print STDERR "Using parameters ",Dumper($params)," in local step\n";
      my $item = $params->{'item'};
      eval {
        my $exp = $ic->expand($item);
        print STDERR "Expanded item = $item: $exp\n";
      }; 
      if ($@) { print STDERR "Could not expand item: $item: $@\n"; }
      use PMTUtilities qw(h2a);
      my @cp = h2a(hash=>$params);
      eval {
        $object->$method(@cp);
      };
      if ($@) { print STDERR "Error occurred during execution of localstep: $@" };

      # I need a reference to an object
      # the method
      # and the initparams
    }
  }
}

#sub AUTOLOAD {
#  ## dynamic delegation ... 
#  my $self = shift;
#  our $AUTOLOAD;
#  my $method = (split(/::/,$AUTOLOAD))[1];
#  print "Autoloader looking for method $method\n";
#  
#  #return &$self('AUTOLOADER',$method,@_);
#}

1;

