package PMTDBConnectionManager;

use strict;
use Carp;
use DBI;

my $shared_connections;

BEGIN {
  $shared_connections = {};
}

sub getConnection {
  my %args = @_;
  my $ic = $args{'initialcontext'};
  my $cs = $args{'data'};  # cs is short for connection_spec

  my $connection_name;
  if (defined $cs->{'connection_name'}) {
    $connection_name = lc $cs->{'connection_name'};
  }
  elsif (defined $args{'name'}) {
    $connection_name = lc $args{'name'};
  }
  my $shared;
  $shared = $cs->{'shared_connection'};
  if ($shared and not defined $connection_name) {
    # fall back to non shared
    $shared = 0;
  }
  #print "creating connection $connection_name\n";
  if ($shared and defined $shared_connections->{$connection_name}) {
    return $shared_connections->{$connection_name};
  }
  # we're still here
  my $driver = $cs-{'driver'};
  my $service = $cs->{'service'};
  my $username = $cs->{'username'};
  my $password = $cs->{'password'};
  use DBI;
  use DBD::Oracle;
  my $dbh;
  eval {
  	$dbh = DBI->connect("DBI:Oracle:$service",$username,$password,{RaiseError=>1,PrintError=>1});
    print STDERR "PMTDBConnectionManager: Created database connection\n";
  };
  if ($@) {
    my $e = $@;
    print STDERR "PMTDBConnectionManager:Failed to create database connection\n";
    croak { message=>"Failed to connect create database connection $connection_name : $@" };
  }
  if ($shared) {
    $shared_connections->{$connection_name} = $dbh;
    return $dbh;
  }
  use PMTDBConnection;
  return PMTDBConnection->new($dbh);
}

END {
  for my $k (keys %$shared_connections) {
    $shared_connections->{$k}->disconnect;
    delete $shared_connections->{$k};
  }
}

1;

