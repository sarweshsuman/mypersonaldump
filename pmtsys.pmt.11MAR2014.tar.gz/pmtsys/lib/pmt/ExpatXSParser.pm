package ExpatXSParser;

use strict;
use Carp;

use Time::HiRes qw(time);

use PMTUtilities qw(partial loadResource getPMTSysConfig parseURI);

sub new {
  my $package = shift;
  my %args = @_;

  my $o = {};

  $o->{'initialcontext'} = $args{'initialcontext'};
  my $ic = $o->{'initialcontext'};
  my $controller = $ic->{'RUNTIME/SYSTEM/CONTROLLER'};
  $o->{'controller'} = $controller;
  my $group = $ic->{'RUNTIME/EXEC/GROUP'};
  print STDERR "The ExpatXSParser is running in group: $group\n";
  print STDERR "The ExpatXSParser found a controller: ",ref $controller,"\n";
  #print STDERR "In EXPATXSPARSER: @_\n";
  $o->{'xnode'} = $args{'xnode'};
  $o->{'_configured_'} = 0;
  $o->{'_status_'} = undef;

  my $xnode = $o->{'xnode'};
  print STDERR "Created ExpatXSParser with $xnode\n";
  
  return bless $o;
}

sub p_configure {
  my $self = shift;
  my $ic = $self->{'initialcontext'};

  if ($self->{'_configured_'}) { return 1; }
  my $xnode = $self->{'xnode'};
  my $controller = $ic->{'RUNTIME/SYSTEM/CONTROLLER'};
 
  use Data::Dumper;
  my ($saxhandler,$io_in,$io_out);
  eval {
  	$saxhandler = $xnode->xfactory(data=>'./config/saxhandler');
    $self->{'saxhandler'} = $saxhandler;
  	$io_in = $xnode->xfactory(data=>'./config/io/in');
  	$io_out = $xnode->xfactory(data=>'./config/io/out');
    $self->{'io_in'} = $io_in;
    $self->{'io_out'} = $io_out;
    print "saxhandler = $saxhandler\n";
    print "io_in = $io_in\n";
    print "io_out = $io_out\n";
    $io_in->test_io();
    print STDERR "I should really start parsing now\n";
    use XML::SAX;
    use XML::LibXML::SAX::Parser;
    use XML::SAX::ExpatXS;
    my $parser = XML::SAX::ExpatXS->new(
       Handler=>$saxhandler
    );
    $self->{'parser'} = $parser;

    # some debugging :-/
    #use overload;
    #if (defined overload::Method($io_in,q{*{}})) { print STDERR "The io_in has glob overloading i\n"} 
    # else { print STDERR "io_in does not have glob overloading\n"; }
    #my $io_io = *{$io_in};
    #print "STDERR : io_io is now ",$io_io,"\n";
    #$io_io = IO::File->new('/opt/PMT/work/in/5/etlexpmx_MGW_20130823113729_1137151.xml','r'); #*{$io_in};

  };
  if ($@) { print STDERR "An error occurred during run of ExpatXSParser: ",Dumper($@),"\n";}
  else {
  	$self->{'_configured_'} = 1;
  }

  return $self->{'_configured_'};

}

sub run {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $xnode = $self->{'xnode'};
  my $controller = $ic->{'RUNTIME/SYSTEM/CONTROLLER'};

  my $s = $self->p_configure();
  #use Data::Dumper;
  #print STDERR "In ExpatXSParser:: run, ic = ",Dumper($ic), "\n";

  print STDERR "DOING RUN IN EXPATXSPARSER\n";
  $self->{'_status_'} = 'running';
  #return ;

  my ($saxhandler,$io_in,$io_out);
  eval {
#   	$saxhandler = $xnode->xfactory(data=>'./config/saxhandler');
#     $self->{'saxhandler'} = $saxhandler;
#   	$io_in = $xnode->xfactory(data=>'./config/io/in');
#   	$io_out = $xnode->xfactory(data=>'./config/io/out');
#     $saxhandler->setIOSpec(out=>$io_out->getIOHandle());
#     print "saxhandler = $saxhandler\n";
#     print "io_in = $io_in\n";
#     print "io_out = $io_out\n";
#     $io_in->test_io();
#     print STDERR "I should really start parsing now\n";
#     use XML::SAX;
#     use XML::LibXML::SAX::Parser;
#     use XML::SAX::ExpatXS;
#     my $parser = XML::SAX::ExpatXS->new(
#        Handler=>$saxhandler
#     );
#     use overload;
#     if (defined overload::Method($io_in,q{*{}})) { print STDERR "The io_in has glob overloading i\n"} else { print STDERR "io_in does not have glob overloading\n"; }
#     my $io_io = *{$io_in};
#     print "STDERR : io_io is now ",$io_io,"\n";
#     $io_io = IO::File->new('/opt/PMT/work/in/5/etlexpmx_MGW_20130823113729_1137151.xml','r'); #*{$io_in};

    my $parser = $self->{'parser'};
    $io_in = $self->{'io_in'};
    $io_out = $self->{'io_out'};
    $saxhandler = $self->{'saxhandler'};

    $parser->parse({Source=>{ByteStream=>$io_in->getIOHandle()}});
    if ($saxhandler->can('getStatistics')) {
      my $rs = $saxhandler->getStatistics();
      eval {
        my $rspeed = $rs->{'record_count'} / ($rs->{'end_time'} - $rs->{'start_time'});
        my $rc = $rs->{'record_count'};
        my $td = $rs->{'end_time'} - $rs->{'start_time'};
        print STDERR "PARSESTATISTICS $$;$rs->{'start_time'};$rc;$rspeed;$td;$rs->{'start_time'};$rs->{'end_time'};$ic->{'WORKLIST/ITEM'}\n";
      };
      #use Data::Dumper;
      #print STDERR "Got statistics:",Dumper($result->{'parse_statistics'}),"\n";
    }

    print STDERR "Checking what else I should do\n";
    if ($xnode->xfind('config/gather_statistics/data()',default=>0)) {
      print STDERR "I should do statistics\n";
  		if ($saxhandler->can('getProcessStatistics')) {
    		my $data = $saxhandler->getProcessStatistics();
    		$controller->sendGeneric(type=>'process_data',data=>{ data_type=>'process_statistics', detail=>$data});
  		}
  		else {
    		$controller->sendGeneric(type=>'process_data',data=>{data_type=>'process_statistics',detail=>{}});
  		}
    }
    else  {
      print STDERR "No statistics required\n";
    }
    if ($xnode->xfind('config/gather_data_summary',default=>0)) {
  		if ($saxhandler->can('getDataSummary')) {
    		my $data = $saxhandler->getDataSummary();
    		$controller->sendGeneric(type=>'process_data',data=>{ data_type=>'data_summary', detail=>$data});
  		}
  		else {
    		$controller->sendGeneric(type=>'process_data',data=>{data_type=>'data_summary',detail=>{}});
  		}
    }
    if ($xnode->xfind('config/get_results_during_run',default=>0)) {
      print STDERR "I should do process_results during run\n";
      $self->getResults();
    }
  };
  if ($@) { print STDERR "An error occurred during run of ExpatXSParser: ",Dumper($@),"\n";}
}

sub logProcessStatistics {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $xnode = $self->{'xnode'};
  my $controller = $ic->{'RUNTIME/SYSTEM/CONTROLLER'};
  my $saxhandler = $self->{'saxhandler'};
  
}

sub logDataSummary {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $xnode = $self->{'xnode'};
  my $controller = $ic->{'RUNTIME/SYSTEM/CONTROLLER'};
  my $saxhandler = $self->{'saxhandler'};
}

sub initialize {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  use Time::HiRes qw(time);
  my $start_tm = time();
  $self->{'_status_'} = undef;
  my $wi = $ic->expand('{{WORKLIST/ITEM|default notknown}}');
  my $t = time();
  print STDERR "done $$ doing initialize in ",__PACKAGE__,"for item $wi at $t\n";
  my $s = $self->p_configure();
  my $t = time();
  print STDERR "done $$ p_configure in ",__PACKAGE__,"for item $wi at $t\n";
  if ($s) {
    my $saxhandler = $self->{'saxhandler'};
    my $io_in = $self->{'io_in'};
    my $io_out = $self->{'io_out'};

    for my $l ($saxhandler,$io_in,$io_out) {
      if ($l->can('initialize')) {
        $l->initialize();
  	    $t = time();
        print STDERR "done $$ subcomponent ",ref $l," initialize in ",__PACKAGE__,"for item $wi at $t\n";
      }
    }
  	$t = time();
    print STDERR "done $$ subcomponents initialize in ",__PACKAGE__,"for item $wi at $t\n";
    $saxhandler->setIOSpec(out=>$io_out->getIOHandle());
  	$t = time();
    print STDERR "done $$ setiospec in ",__PACKAGE__,"for item $wi at $t\n";
    print STDERR "Initialized Parser\n";
  }
  else {
    # I should actually  croak something here
  }
  my $end_tm = time();
  my $delta = $end_tm - $start_tm;
  print STDERR "done $$ initialization in expatxsparser $$ took $delta seconds\n";
}

sub getResults {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $xnode = $self->{'xnode'};
  my $controller = $ic->{'RUNTIME/SYSTEM/CONTROLLER'};
  #if (not defined $self->{'_status_'}) {
  #}
  #my $s = $self->p_configure();
  my $s = 1; # this should be a bunch of checks
  if ($s) {
    my $saxhandler = $self->{'saxhandler'};
    my $io_in = $self->{'io_in'};
    my $io_out = $self->{'io_out'};
    my $final_result = {};
    for my $l ($saxhandler,$io_in,$io_out) {
      if ($l->can('getResults')) {
        my $lr = $l->getResults();
        for my $k (keys %$lr) { $final_result->{$k} = $lr->{$k}; }
      }
    }
    $controller->sendGeneric(type=>'process_data',data=>{ data_type=>'result', detail=>$final_result});
  }
}

#sub reset {
#  my $self = shift;
#}


1;
