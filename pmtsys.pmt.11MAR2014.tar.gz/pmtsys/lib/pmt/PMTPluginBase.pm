package PMTPluginBase;


# ##############################################################
#
# This is basically a placeholder
# It doesn't need any methods, only required to build an 
# an inheritance-tree
# 
# ##############################################################

1;
