package PMTFactories;

use strict;
use Data::Dumper;
use Carp;

sub DBLookupResourceFactory {
  my %args = @_;
  my $ic = $args{'initialcontext'};
  my $n = $args{'data'};
  my $xnode = $args{'xnode'};
  my $name = $n->getAttribute('name');

  my $resource_definition = $n->xfind("resource_definition");
  my $db_connection = $n->xfind('db_connection/resource_factory()');
  $resource_definition->{'dbconn'} = $db_connection;
  $resource_definition->{'initialcontext'} = $ic;

  use PMTUtilities qw(h2a);
  $a = h2a(hash=>$resource_definition);

  print STDERR "CREATING A DBTIE\n";

  use DBTie;
  my %hh;
  tie %hh,'DBTie',@$a;
  print STDERR "DONE CREATING A DBTIE WITH NAME $name\n";
  return \%hh;
}

sub DBConnection {
  my %args = @_;
  my $data = $args{'data'};
  my $ic = $args{'initialcontext'};
  my $name = $args{'name'};
  my $xnode = $args{'xnode'};

  use PMTDBConnectionManager ;
  return PMTDBConnectionManager::getConnection(name=>$name,initialcontext=>$ic,data=>$data);
}

sub FileWriter {
  my %args = @_;
  my $ic = $args{'initialcontext'};
  my $n = $args{'data'};
  my $xnode = $args{'xnode'};

  use PMTFileWriter();

}

1;
