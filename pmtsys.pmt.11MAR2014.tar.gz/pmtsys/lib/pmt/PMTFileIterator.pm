package PMTFileIterator;

use PMTIteratorBase;
our @ISA = qw(PMTIteratorBase);

use strict;
use Carp;
use overload q{<>} => \&iterator_overload,
             'bool'=> \&bool_overload,
             '!' => \&neg_overload,
             q{""} => sub { return "<" . __PACKAGE__ ." instance>"; };


sub new {
  my $package = shift;
  my %args = @_;
  use Data::Dumper;
  my $initparams = $args{'initparams'};
  my $list = [];
  if (defined $initparams->{'list'}) {
    $list = $initparams->{'list'};
  }
  else {
  	#print STDERR "PMTFileIterator created with ",Dumper($initparams),"\n";
  	use PMTUtilities qw(getFileList h2a);
    use Data::Dumper;
  	my $gfla = h2a(hash=>$initparams->{'fileparams'});
    $list = getFileList(@$gfla);
    print STDERR "PMTFileListIterator got filelist: @$list\n";
  }
  my $o = {};
  $o->{'_list_'} = [];
  for my $i (@$list) {
    push @{$o->{'_list_'}},$i;
  }
  $o->{'config'} = {};
  if (defined $initparams->{'config'}) {
    use PMTUtilities qw(evalBoolean);
    $o->{'config'}->{'recycle'} = evalBoolean(value=>$initparams->{'config'}->{'recycle'});
  }
  $o->{'_empty_'} = 0;
  $o->{'recyclelist'} = [];
  $o->{'initialcontext'} = $args{'initialcontext'};
  $o->{'xnode'} = $args{'xnode'};
  if (defined $initparams->{'config'}->{'batchsize'}) {
    $o->{'batchsize'} = $initparams->{'config'}->{'batchsize'};
  }
  else {
    $o->{'batchsize'} = 1;
  }
  print "Created a FileIterator with batchsize = $o->{'batchsize'}\n";
  $o->{'force_array'} = 0;
  return bless $o;
}

sub iterator_overload {
  my $self = shift;
  return $self->next(); 
}

sub neg_overload {
  my $self = shift;
  my $self = shift;
  if ($self->{'recycle'}) {
  	if (scalar @{$self->{'_list_'}} + scalar @{$self->{'recyclelist'}} > 0) { return 0; } else { return 1; }
  }
  if (scalar @{$self->{'_list_'}} > 0) { return 0; } else { return 1; }
}

sub bool_overload {
  my $self = shift;
  if ($self->{'recycle'}) {
  	if (scalar @{$self->{'_list_'}} + scalar @{$self->{'recyclelist'}} > 0) { return 1; } else { return 0; }
  }
  if (scalar @{$self->{'_list_'}} > 0) { return 1; } else { return 0; }
}

sub next {
  my $self = shift;
  my $batchsize = $self->{'batchsize'};
  if (wantarray) {
    print STDERR "TODO: PMTFileIterator listcontext is buggy \n";
    if ($self->{'_empty_'}) {
      # this does basically imply that is recyclable and that it was called when empty,
      # so we have returned one empty value
      push @{$self->{'_list_'}},@{$self->{'recyclelist'}};
      $self->{'recyclelist'} = [];
      $self->{'_empty_'} = 0;
      return $self->next();
    }
    else {
			my @l = ();
			while (scalar @{$self->{'_list_'}}) {
				push @l, shift @{$self->{'_list_'}};
			} 
			if ($self->{'config'}->{'recycle'}) {
				push @{$self->{'recyclelist'}},@l;
			}
			if (not scalar @l) {
				$self->{'_empty_'} = 1;
			}
			return @l;
    }
  }
  elsif (defined wantarray) {
    # we gotta do stuff with the batchsize here
    # if batchsize = -1 -> return all the elements
    # else return the number of elements in the batchsize
  	# should this one even have the concept of a parent ? I don't think so :-)
    if ($self->{'_empty_'}) {
      # this does basically imply that is recyclable and that it was called when empty,
      # so we have returned one empty value
      push @{$self->{'_list_'}},@{$self->{'recyclelist'}};
      $self->{'recyclelist'} = [];
      $self->{'_empty_'} = 0;
      return $self->next();
    }
    else { # it is not empty
      #print "it is not flagged as empty\n";
      if ($batchsize == -1) {
      	my @vals = ();
				while (scalar @{$self->{'_list_'}}) {
					#print "it appears to have items\n";
					my $val = shift @{$self->{'_list_'}};
          if ($val) {
            push @vals,$val;
          }
				}
        use Data::Dumper;
        print STDERR "PMTFileIterator returning ",Dumper(\@vals),"\n";
				return \@vals;
      }
      elsif ($batchsize > 1)  { 
        my @vals = ();
        while (scalar @{$self->{'_list_'}} and scalar @vals < $batchsize) {
          my $val = shift @{$self->{'_list_'}};
          push @vals,$val;
        }
        return \@vals;
      }
      else { # batchsize = 1
        my $val = shift @{$self->{'_list_'}};
        if ($val) {
          if ($self->{'force_array'}) { return [$val]; } else { return $val; }
        }
        else {
          if ($self->{'force_array'}) { return []; } else { return undef; }
        }
      }
		}
  }
	else { # wantarray is not even defined
    if ($self->{'_empty_'}) {
      # this does basically imply that is recyclable and that it was called when empty,
      # so we have returned one empty value
      push @{$self->{'_list_'}},@{$self->{'recyclelist'}};
      $self->{'recyclelist'} = [];
      $self->{'_empty_'} = 0;
      return $self->next();
    }
    else {
			if (scalar @{$self->{'_list_'}} > 0) {
				my $val = shift @{$self->{'_list_'}}; 
      	if ($self->{'config'}->{'recycle'}) {
        	push @{$self->{'recyclelist'}},$val;
      	}
      	return undef;
			}	
    	return undef;
    }
	} # end of not even defined wantarray
}

sub reset {
  #print STDERR "resetting ",__PACKAGE__,"\n";
  my $self = shift;
  while (scalar @{$self->{'recyclelist'}}) {
    push @{$self->{'_list_'}}, shift @{$self->{'recyclelist'}};
  }
  $self->{'finished'} = 0;
  $self->{'_empty_'} = 0;
}

DESTROY {
  my $self = shift;
  # if a parent is defined, and the parent has recycle mode we should return all the elements on the parent too
  # kinda tricky, to be implemented later
}

1;

