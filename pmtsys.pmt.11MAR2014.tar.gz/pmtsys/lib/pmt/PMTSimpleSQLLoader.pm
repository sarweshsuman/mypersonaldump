package PMTSimpleSQLLoader;

use strict;
use Carp;

sub new {
  my $class = shift;
  my %args = @_;

  my $o = {};
  my $ic = $args{'initialcontext'};
  my $xnode = $args{'xnode'};
  $o->{'initialcontext'} = $ic;
  $o->{'xnode'} = $xnode;
  $o->{'start_tm'} = undef;
  $o->{'end_tm'} = undef;
  $o->{'cmd_output'} = undef;
  return bless $o;
}

sub run {
  my $self = shift;
  my %args = @_;
  my $ic = $self->{'initialcontext'};
  my $item = $ic->{'WORKLIST/ITEM'};
  my $xnode = $self->{'xnode'};
  print STDERR "Doing run in PMTSimpleSQLLoader for $item\n";
  #use PMTUtilities qw(runSysCommand expand);
  # create a parfile
  # create a control_file
  # Those can actually be fifos 
  print STDERR "PMTSimpleSQLLoader looking for following parameters:\n";
  use Data::Dumper;
  my $template_directory;
  my $template_file; 
  my $par_template_file; 
  eval {
   $template_directory = $xnode->xfind('config/template_dir');
   $template_file = $xnode->xfind('config/ctlfile_template');
   $par_template_file = $xnode->xfind('config/parfile_template');
   print STDERR "PMTSimpleSQLLoader: template_directory: $template_directory\n";
   print STDERR "PMTSimpleSQLLoader: template_file: 		 $template_file\n";
   print STDERR "PMTSimpleSQLLoader: par_template_file:  $par_template_file\n";
  };
  if ($@) { print STDERR "Error occurred while trying to find file locations in PMTSimpleSQLLoader: ",Dumper($@),"\n"; }

  use PMTUtilities qw(expand loadResource);
  use File::Spec;

  my $full_template;
  my $template_contents;
  my $expanded_template;

  $ic->addParameterStack();
  #eval {
  $full_template = File::Spec->catfile($template_directory,$template_file);
  $template_contents = loadResource(resource=>$full_template);
  print STDERR "using template: $template_contents\n";
  $expanded_template = expand(src=>$template_contents,evalcontext=>[$ic]);
  print STDERR "using expanded template: $expanded_template\n";
  #}; if ($@) { print STDERR "Error occurred while trying to expand ctlfile_template ",Dumper($@),"\n"; }

  use File::Temp;
  use IO::File;
  my $logfile = $ic->expand('{{ENV/PMTROOT}}/logs/sqlldr/sqlldr_log.{{_PROCESSID_}}.{{_NOW_|formatDateTime %Y%m%d%H%M%S}}.log');
  my $ctlfile = tmpnam(); $ctlfile="$ctlfile.ctl"; print STDERR "controlfile written to $ctlfile\n";
  my $parfile = tmpnam(); $parfile="$parfile.par"; print STDERR "parfile written to $parfile\n";

  $ic->{'_LOCAL_/CONTROLFILE'} = $ctlfile;

  my $par_file_contents;
  eval {
  my $par_template_contents = loadResource(resource=>$par_template_file);
  $par_file_contents = expand(src=>$par_template_contents,nokeysplit=>1,evalcontext=>[$ic]);
  print STDERR "Using parfile_contents: $par_file_contents\n";
  }; if ($@) { print STDERR "Error occurred while trying to expand parfile_template ",Dumper($@),"\n"; }

  my $file_generation_ok = 1;
  eval {
  my $f_ctlfile = IO::File->new($ctlfile,'w');
  my $f_parfile = IO::File->new($parfile,'w');
  print $f_ctlfile $expanded_template;
  print $f_parfile $par_file_contents;
  $f_ctlfile->close();
  $f_parfile->close();
  };
  if ($@) { $file_generation_ok = 0; print STDERR "Error occurred while trying to write files ",Dumper($@),"\n"; }

  $ic->popParameterStack();
  
  if ($file_generation_ok) {
  	use PMTUtilities qw(runSysCmd);
  	my $result = runSysCmd(command=>"sqlldr parfile=$parfile log=$logfile 2>&1");
  	my $rc = $result->{'rc'};
  	if (-f $ctlfile ) { unlink $ctlfile; }
  	if (-f $parfile ) { unlink $parfile; }
  	if ($rc == 0) {
    	print STDERR "sqlldr ran without issues\n";
      if ($args{'cleanup'}) {
        my $cl = $item; if (ref $cl eq 'ARRAY') { } else { $cl = [$cl]; }
        for my $c (@$cl) { my $rc = `rm -f $c`; }
      }
  		if (-f $logfile ) { unlink $logfile; }
  	}
  	else {
  		print STDERR "output of sqlldr :",Dumper($result),"\n";
  	}
    
  }

  #my $par_contents = expand(infile=>$par_template_file,evalcontext=>[$ic]);
  #my $ctl_contents = expand(infile=>$ctl_template_file,evalcontext=>[$ic]);

}

sub initialize {
  my $self = shift;
  print STDERR "Doing initialize in PMTSimpleSQLLoader\n";
}

sub logProcessStatistics {
  my $self = shift;
  print "Doing process statistics in PMTSimpleSQLLoader\n";
  # Parse the output 
}

1;
