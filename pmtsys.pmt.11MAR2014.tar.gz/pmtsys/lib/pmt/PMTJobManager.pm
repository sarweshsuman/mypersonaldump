package ProcessGroupManager; 

use strict;
use Carp;
use PMTExecContext;

sub new {
  my $package = shift;
  my %args = @_;

  my $o = {};
  my $parent_ic = $args{'initialcontext'};
  my $xnode = $args{'xnode'};
  my $name = $args{'name'};
  #my $worklist = $args{'worklist'};
  #my $resultcollector = $args{'resultcollector'};

  #print STDERR "In constructor of processgroupmanager with name $name\n";
  # Cloning the ic ...
  $o->{'initialcontext'} = new PMTExecContext($parent_ic); #new PMTExecContext($parent_ic);
  $o->{'xnode'} = $xnode;
  $o->{'name'} = $name;
  #$o->{'worklist'} = $worklist;
  #$o->{'resultcollector'} = $resultcollector;
  $o->{'jobmanager'} = $args{'jobmanager'};
  $o->{'_pool_'} = {};
  $o->{'_setup_'} = 0;
  $o->{'started_'} = 0;
  $o->{'_running_'} = 0;
  $o->{'_finished_'} = 0;

  my $ic = $o->{'initialcontext'}; 
  $ic->{'RUNTIME/EXEC/GROUP'} = $name;
  use Time::HiRes qw(time);
  $ic->appendJLOG(directives=>{type=>'event',context=>{group=>$name},mtime=>time()},data=>{event_type=>'process_group_create'});
  return bless $o;
}

sub evalGroupWaitCondition {
  my $self = shift;
  my %args = @_;
  my $groupnode = $args{'groupnode'};
  print STDERR "Checking for wait_condition on groupnode $groupnode\n";
  if ($groupnode->exists('wait')) {
    my $cnode = $groupnode->xnode(data=>'wait');
    print STDERR "found condition node: $cnode",ref $cnode,"\n";
    if ($cnode->exists('exists')) { }
    elsif ($cnode->exists('evalvalue')) {
      use Data::Dumper;
      my $rc = 1;
      eval {
      my $val = $cnode->xfind('evalvalue/data()');
      print STDERR "evalvalue is now $val\n";
      $rc = $val + 0; # force it to be numeric :-/
      };
      if ($@) { print STDERR "Error occurred during evaluation of evalvalue: ",Dumper($@),"\n"; return 1; }
      print "Returning wait_condition value $rc\n";
      return $rc;
    }
    # a few shortcuts for convenience
    elsif ($cnode->exists('code')) {}
    elsif ($cnode->exists('group_end')) { } 
    elsif ($cnode->exists('group_start')) { }
    return 1;
  }
  else {
    print STDERR "The group does not have a wait condition\n";
    return 1;
  }
}

sub setup {
	my $self = shift;
  my $name = $self->{'name'};
	my $xnode = $self->{'xnode'};
  my $ic = $self->{'initialcontext'};
  #my $worklist = $self->{'worklist'};
  #my $resultcollector = $self->{'resultcollector'};
 
  if ($self->{'_setup_'}) { return ; }

  # Actually I should check if there's wait condiition now
  print "Doing setup in processgroupmanager $name\n";
  my $waitcondition = $xnode->evalPreReqs(condition_type=>'wait');
  if (not $waitcondition) {
    print STDERR "group $name Wait condition not fullfilled ... group $name setup will have to wait\n";
    return;
  }
  # the wait condition is ok but is the condition to use it also ok ?
  my $use_condition = $xnode->evalPreReqs(condition_type=>'condition');
  if (not $use_condition) {
    $self->{'_finished_'} = 1;
    $ic->log(message=>"Group $name does not have to run, condition 'condition' fail",domain=>"system",level=>"info");
		$ic->appendJLOG(directives=>{type=>'event',context=>{group=>$name},mtime=>time()},data=>{event_type=>'process_group_end',detail=>{status=>'condition_fail'}});
    return;
  }

  # I need the helper:

  # find the number of subprocesses:
  my $max_processes;
  if ($xnode->exists('config/param[@name="subprocesses"]')) {
    $max_processes = $xnode->xfind('config/param[@name="subprocesses"]');
  }
  else {
    # base ourselves on the Sys::CPU module
  	use Sys::CPU;
  	my $number_of_cpus = Sys::CPU::cpu_count();
    $max_processes = $number_of_cpus;
  }

  print "using max processes: $max_processes\n";

  #print "worklist is here: $worklist\n";


  my $helper_node = $xnode->xfind('config/param[@name="helper"]');


  # and to I have a processmodel here ?
  # well the xnode is basically the processmodel;
  #print "looking for processmodel in processgroupmanager: $xnode\n";




  #my $processmodel; my $worklist = new PMTWorkList(list=>['evert']); my $resultcollector;
  #my $number_of_subprocesses = 1;

  #print STDERR "Looking for a loopdriver in creation of group in $xnode\n";

  my $loopdriver;

  if ($xnode->exists('loopdriver')) {
    $loopdriver = $xnode->xfind('loopdriver');
    print STDERR "Found a loopdriver in processgroupmanager: $loopdriver\n";
  }
  else {
    print STDERR "Could not find a loopdriver in processgroupmanager\n";
  }

  
  # now, how we go about this ... kinda depends on the empty attribute on the loopdriver
  
  my $empty_policy = $xnode->xfind('loopdriver/@empty_policy',default=>'undef');
  $empty_policy = uc $empty_policy;
  print STDERR "Found a loopdriver with policy $empty_policy\n";

	my $workercount = 0;
  if ($empty_policy eq 'UNDEF') {
		#my $item = <${loopdriver}>;
		use PMTWorkList;
    my $do_continue = 1;
		while ($workercount < $max_processes and $do_continue) {
			print STDERR "helpernode is now : ",$helper_node,"\n";
		 
      my $item = <${loopdriver}>;
      if (defined $item) {
				my $h = $helper_node->xfind('./factory()');
				$h->setWorkListPolicy(policy=>'UNDEF');
				my $process_model = undef;
				if ($xnode->exists('process_model')) { $process_model = $xnode->xfind('process_model/xnodePath()'); }
				print "Creating a helperhelper with process_model $process_model\n";
				$h->setResources(process_model=>$process_model,worklist => new PMTWorkList(list=>[$item],parent=>$loopdriver));
				$h->setProcessModel(process_model=>$process_model);

				$self->{'_pool_'}->{$workercount} = $h;
				#$item = <${loopdriver}>;
				$workercount++;
      }
      else {
        $do_continue = 0;
      }
		}
		print STDERR "Using $workercount processes\n";
  }
  else {
    # The empty policy is anything else but UNDEF, we basically spawn the exact number of processes
		while ($workercount < $max_processes) {
			print STDERR "helpernode is now : ",$helper_node,"\n";
		 
			my $h = $helper_node->xfind('./factory()');
      $h->setWorkListPolicy(policy=>$empty_policy);
			my $process_model = undef;
			if ($xnode->exists('process_model')) { $process_model = $xnode->xfind('process_model/xnodePath()'); }
			print "Creating a helperhelper with process_model $process_model\n";
			$h->setResources(process_model=>$process_model,worklist=>$loopdriver);
			$h->setProcessModel(process_model=>$process_model);

			$self->{'_pool_'}->{$workercount} = $h;
			$workercount++;
		}
		print STDERR "Using $workercount processes\n";
  }
  if ($workercount == 0) {
    # looks like there's nothing to process
    $self->{'_finished_'} = 1;
    $self->end();
    return;
  }

  # And now loop while there are items and or children are running ...
  print STDERR "End of SETUP in ProcessGroupManager\n";
  $self->{'_setup_'} = 1;
}

sub start {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $xnode = $self->{'xnode'};
  my $name = $self->{'name'};
  if ($self->{'_started_'}) { return 1; }
  print STDERR "Doing start in process group\n";
 
  $self->setup();
  if ($self->{'_setup_'}) { 
    if ($xnode->evalPreReqs(condition_type=>'wait_start')) {
    	$self->{'_started_'} = 1; 
  		$ic->appendJLOG(directives=>{type=>'event',context=>{group=>$name},mtime=>time()},data=>{event_type=>'process_group_start'});
    }
    else { 
      print STDERR "Start condition for process group $name not fullfilled. Start will have to wait\n";
    }
  }
  return $self->{'_started_'};
}

sub execLocalCallStep {
  my $self = shift;
  my %args = @_;
  my $stepnode = $args{'stepnode'};
  my $object = $stepnode->xfind('object');
  my $method = $stepnode->xfind('method');
  my $params = {};
  if ($stepnode->exists('params')) {
    $params = $stepnode->xfind('params');
  }
  use PMTUtilities qw(h2a);
  my @cp = h2a(hash=>$params);
  eval {
    $object->$method(@cp);
  };
  if ($@) { print STDERR "Error occurred in local call step: $@\n"; }
}

sub execLocalIcUpdateStep {
  my $self = shift;
  my %args = @_;
  my $stepnode = $args{'stepnode'};
}

sub execLocalStep {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $stepnode = $args{'stepnode'};
  # what can I find here
  print STDERR "Executing a local step: $stepnode\n";
  my $names = $stepnode->xfind('*[name() != "pre_reqs"]/name(.)',force_array=>1);
  for my $n (@$names) {
    print STDERR "Executing a local step of type: $n\n";
  }
  my $stepelements = $stepnode->xnode(data=>'*[name() != "pre_reqs"]',force_array=>1);
  for my $sel (@$stepelements) {
    my $n = $sel->xfind('./name()');
    if ($n eq 'ic_update') {
      my $ic_update = $sel->xfind('./parseParamset()');
      use PMTUtilities qw(icdefined mergeRecursiveHash);
      if (icdefined $ic_update) {
        mergeRecursiveHash(src=>$ic_update,update=>$ic);
      }
    }
    elsif ($n eq 'call') {
      $self->execLocalCallStep(stepnode=>$sel);
    }
  }
}
sub end {
  my $self = shift;
  my $xnode = $self->{'xnode'};
  my $jobmanager = $self->{'jobmanager'};
  print STDERR "doing end in process group $self->{'name'}\n";
  my $endsteps = $xnode->xnode(data=>'end/steps/step',force_array=>1);
  for my $step (@$endsteps) {
    if ($step->evalPreReqs(condition_type=>'condition')) {
      $self->execLocalStep(stepnode=>$step);
    }
  }
}

sub run {
  my $self = shift;
  my $xnode = $self->{'xnode'};
  my $name = $self->{'name'};
  my $ic = $self->{'initialcontext'};
  print STDERR "Doing run in processgroupmanager\n";
  $self->start();
  if ($self->{'_started_'} == 0) { return; }
  if ($self->{'_running_'}) { return ; }
  if ($xnode->evalPreReqs(condition_type=>'wait_run')) {
  
		use Data::Dumper;
		eval {
			for my $h (values %{$self->{'_pool_'}}) {
				print STDERR "Invoking run on $h\n";
				$h->();
				print STDERR "Invoked run on $h\n";
			}
		};
		if ($@) {
			print STDERR "Error calling run in workerpool\n",Dumper($@),"\n";
      $self->{'_finished_'} = 1;
  		$ic->appendJLOG(directives=>{type=>'event',context=>{group=>$name},mtime=>time()},data=>{event_type=>'process_group_end',detail=>{status=>'fail'}});
		}
		$self->{'_running_'} = 1;
  }
  else {
    $ic->log(message=>"Process group $name method run: wait condition not fullfilled. Waiting",domain=>"system",level=>"debug");
  }
  print STDERR "end of run in processgroupmanager\n";
}

sub isFinished {
  my $self = shift;
  my $run_count = 0;
  my $ic = $self->{'initialcontext'};
  $self->run();
  if ($self->{'_finished_'}) { return 1; }
  if (not $self->{'_running_'}) { return 0; }
  #
  print STDERR "Checking workerpool\n";
  for my $h (keys %{$self->{'_pool_'}}) {
    print STDERR "checking helper $h\n";
    my $f = $self->{'_pool_'}->{$h}->isFinished();
    print "helper $h is finished: $f\n";
    if ($self->{'_pool_'}->{$h}->isFinished()) {
      # I don't think we should do anything here
      print STDERR "HelperHelper $h is finished\n";
      delete $self->{'_pool_'}->{$h};
    }
    else {
      $run_count++;
    }
    print STDERR "Done checking helper $h\n";
  }
  if ($run_count > 0) { return 0; } 
  else { 
    my $name = $self->{'name'};
  	$ic->appendJLOG(directives=>{type=>'event',context=>{group=>$name},mtime=>time()},data=>{event_type=>'process_group_end',detail=>{status=>'success'}});
    $self->{'_finished_'} = 1;
    $self->end();
    return 1; 
  };
}

sub teardown {
  my $self = shift;
}

DESTROY {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  print STDERR "In destructor of Processgroup\n";
  my $name = $self->{'name'};
  #$ic->appendJLOG(directives=>{type=>'event',context=>{group=>$name},mtime=>time()},data=>{event_type=>'process_group_end'});
  my $pool = $self->{'_pool_'};
  while (scalar @{$self->{'_pool_'}}) { 
    # The following line should invoke the destructor in the PMTHelperHelper;
    shift @{$self->{'_pool_'}};
  }
  print STDERR "End of destructor in Processgroup\n";
}

1;


package PMTJobManager;

use strict;
use Carp;

use Data::Dumper;
use File::Spec;
use PMTUtilities qw(serializeTo deserializeFrom getPMTSysConfig);
use JSON;

sub new {
  my $class = shift;
  my %args = @_;

  my $o = {};
  $o->{'initialcontext'} = $args{'initialcontext'};
  $o->{'xnode'} = $args{'xnode'};
  $o->{'initparams'} = $args{'initparams'};

  bless $o;
  if ($o->{'xnode'}) {
	  #print STDERR "Parsemanager Path of xnode = ",$o->{'xnode'}->xfind('./xnodePath()'),"\n";
  }
  else {
    #print STDERR "xnode is not defined in PMTJobManager";
  }
  return $o;
}

sub execLocalCallStep {
  my $self = shift;
  my %args = @_;
  my $stepnode = $args{'stepnode'};
}

sub execLocalIcUpdateStep {
  my $self = shift;
  my %args = @_;
  my $stepnode = $args{'stepnode'};
}

sub execLocalStep {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
  my $stepnode = $args{'stepnode'};
  # what can I find here
  print STDERR "Executing a local step: $stepnode\n";
  my $names = $stepnode->xfind('*[name() != "pre_reqs"]/name(.)',force_array=>1);
  for my $n (@$names) {
    print STDERR "Executing a local step of type: $n\n";
  }
  my $stepelements = $stepnode->xnode(data=>'*[name() != "pre_reqs"]',force_array=>1);
  for my $sel (@$stepelements) {
    my $n = $sel->xfind('./name()');
    if ($n eq 'ic_update') {
      my $ic_update = $sel->xfind('./parseParamset()');
      use PMTUtilities qw(icdefined mergeRecursiveHash);
      if (icdefined $ic_update) {
        mergeRecursiveHash(src=>$ic_update,update=>$ic);
      }
    }
  }
}

sub execLocalSteps {
  my $self = shift;
  my %args = @_;
  use PMTUtilities qw(icdefined);
  my $rnode = $args{'container'};
  my $steps = $rnode->xnode(data=>'steps/step',force_array=>1);
  for my $step (@$steps) {
    #print "doing setup step: $step";
    if ($step->evalPreReqs(condition_type=>'condition')) {
      # actually carry out the step
      $self->execLocalStep(stepnode=>$step);
    }
  }
}

sub run {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $xnode = $self->{'xnode'};


  # the xnode contains the xnode for the PMTJobManager
  #print STDERR "run_multiprocess running with xnode\n$xnode\n";

  $ic->log(message=>"Running in MULTIPROCESSING mode",domain=>"system",level=>"info");

  use Sys::CPU;
  my $number_of_cpus = Sys::CPU::cpu_count();
  $ic->log("I got $number_of_cpus cpus",domain=>"system",level=>"info");


  my $processmodel = $self->{'initparams'}->{'process'};

  my $ic_update;
  my $setup = $processmodel->xnode(data=>'setup');
  if (icdefined $setup) {
    $self->execLocalSteps(container=>$setup);
  }

  my $groupsnode = $xnode->xfind('//groups/xnode()');

  my $groups = $xnode->xfind('//groups/group/xnode()',force_array=>1);

  print STDERR "TODO: Move the create conditions on the group to the actual create condition node\n";
  my $processgroupmanagers = {};
  for my $g (@$groups) {
    my $name = $g->xfind('./@name/data(.)');
    print STDERR "Creating a processgroupmanager with name $name\n";
    
    my $condition_check = $g->evalPreReqs(condition_type=>'create_condition');
    # = $self->evalGroupCreateCondition(groupnode=>$g);
    if ($condition_check) {
      print STDERR "Conditions are fullfilled : creating group $name\n";
    	#$processgroupmanagers->{$name} = new ProcessGroupManager(jobmanager=>$self,name=>$name,initialcontext=>$ic,xnode=>$g,worklist=>$worklist,resultcollector=>$resultcollector);
    	$processgroupmanagers->{$name} = new ProcessGroupManager(jobmanager=>$self,name=>$name,initialcontext=>$ic,xnode=>$g);
    }
    else {
      print STDERR "Dropping group $name since condition not fullfilled\n";
    }
    use Time::HiRes qw(time);
  }

  my $run_count = scalar keys %$processgroupmanagers;

  # and now wait till they finish ...
  print STDERR "Waiting for processgroupmanagers to finish\n";
  while ($run_count > 0) {
    print STDERR "still got running processgroupmanagers ...\n";
    $run_count = 0;
    for my $k (keys %$processgroupmanagers) {
      if ($processgroupmanagers->{$k}->isFinished()) {
        # we shouldn't do anything here I guess
      }
      else { 
        $run_count++;
      }
    }
    print STDERR "run_count is $run_count in processgroupmanagers check\n";
    use Time::HiRes qw(sleep);
    sleep 0.05;
  }
  print STDERR "processgroupmanager is finished or so it seems\n";

  return;

}

1;
