package PMTInterceptorBase;

use strict;
use PMTPluginBase;

our @ISA = qw(PMTPluginBase);

# ##############################################################
# This is basically a placeholder
# ##############################################################

sub getCloneData { return {}; }

1;
