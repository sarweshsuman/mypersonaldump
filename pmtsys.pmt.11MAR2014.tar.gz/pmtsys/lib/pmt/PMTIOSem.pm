package PMTIOSemSentinel;

use strict;
use Carp;
use threads;
use threads::shared;

sub new {
  my $class = shift;
  my $o = {};
  $o->{'master'} = shift;
  return bless $o;
}

sub DESTROY {
  my $self = shift;
  my $master = $self->{'master'};
  $master->unlock();
}

1;


package PMTIOSem;

use strict;
use Carp;

use threads;
use threads::shared;
use IPC::SysV qw(IPC_PRIVATE S_IRUSR S_IWUSR IPC_CREAT);
use IPC::Semaphore ;
use PMTUtilities qw(partial);

use overload q{""} => \&asstring,
             q{&{}} => \&call_overload;

sub new {
  my $class = shift;
  my $io =shift;
  my %args = @_;
  my $o = {};
  $o->{'io'} = $io;
  $o->{'sem'} = undef;
  $o->{'semkey'} = undef;
  $o->{'master'} = $args{'master'};

  my @stats = stat($io);
  my $inode = @stats[1];
  $o->{'semkey'} = $inode;
  my $sem = IPC::Semaphore->new($inode,1,S_IRUSR | S_IWUSR | IPC_CREAT);
  $sem->setall((1));
  $o->{'sem'} = $sem;
  return bless $o;
}

sub asstring {
  my $self = shift;
  return "< PMTIOSemaphore Instance [inode ".$self->{'semkey'}."]>";
}

sub unlock {
  my $self = shift;
  my $tid = threads->tid() * 10;
  my $stid = threads->tid() * -10;
  my $sem = $self->{'sem'};
  my @semvals = $sem->getall();
  $sem->op(0,1,0);
  #if ($semvals[0] == $stid) {
  #  return undef;
  #}
  #else { croak { message=>"mmmm, I'm not unlocking my own lock" }; }
}

sub run {
  my $self = shift;
  my $sem = $self->{'sem'};
  my $tid = threads->tid() * -10;
  my @semvals = $sem->getall();
  #print STDERR "Current val of sem for channel = $semvals[0]\n";
  $sem->op(0,-1,0);
  #print STDERR "Lock acquired in PMTIOSem\n";
  return PMTIOSemSentinel->new($self);
  #if ($semvals[0] == $tid) {
  #  print STDERR "current val is $tid, which is what I expect, simply returning $tid\n";
  #  return undef;
  #}
  #else { 
  #  print STDERR "current val $semvals[0], try to lock with value $tid\n";
  #  $sem->op(0,$tid,0);
  #  print STDERR "And locked with val $tid\n";
  #}
}

sub call_overload {
  my $self = shift;
  return partial(\&run,$self);
}

sub DESTROY {
  my $self = shift;
  if ($self->{'master'}) {
    my $sem = $self->{'sem'};
    $sem->remove();
  }
}


1;
