package PMTIOChannel;

use strict;
use Carp;

use IO::File;
use PMTFifoSentinel;

#use overload '*{}' => 

use overload q{""} => \&asstring, q{*{}}=>\&io_overload;

sub new {
  my $package = shift;
  my %args = @_;
  my $o = {};

  $o->{'initialcontext'} = $args{'initialcontext'};
  $o->{'xnode'} = $args{'xnode'};

  my $xnode = $args{'xnode'};
  
  my $ic = $o->{'initialcontext'}; 
  $o->{'uri'} = $xnode->xfind('./params/uri/data()');
  print STDERR "PMTIOChannel using uri: $o->{'uri'}\n";
  $o->{'policy'} = $xnode->xfind('./params/io_policy/data()',default=>'auto');
  $o->{'mode'} = $xnode->xfind('./params/access_mode/data()');
  $o->{'io'} = undef;

  return bless $o;
}

sub setURI {
  my $self = shift;
  my %args = @_;
  my $self->{'uri'} = $args{'uri'};
  if (defined $self->{'io'}) { $self->{'io'} = undef; }
}

sub createIO {
  #my $self->{'io'};
}

sub asstring {
  my $self = shift;
  return "<". __PACKAGE__ . "instance [".$self->{'uri'}."]>";
}

sub test_io {
  my $self = shift;
  my $uri = $self->{'uri'};
  use PMTUtilities qw(parseURI);
  my $pu = parseURI(uri=>$uri);
  use Data::Dumper;
  print STDERR "Parsed uri in PMTIOChannel: \n",Dumper($pu),"\n";
  print "mode = $self->{'mode'}\n";
   
}

sub io_overload {
  my $self = shift;
  print STDERR "io_overloader in PMTIOChannel\n";
  return $self->getIOHandle();
}

sub getIOHandle {
  my $self = shift;
  if ($self->{'io'}) {
    return $self->{'io'};
  }
  my $mode = $self->{'mode'};
  use PMTUtilities qw(parseURI);
  my $uri = $self->{'uri'};
  my $parsed_uri = parseURI(uri=>$uri);
  if ($parsed_uri->{'local'}) {
    my $p = $parsed_uri->{'path'};
    my $mode = $self->{'mode'};
    print "Using path $p (mode $mode)\n";
    use IO::File;
    $self->{'io'} = IO::File->new($parsed_uri->{'path'},$mode);
    print "PMTIOChannel is returning a $self->{'io'}\n";
    return $self->{'io'};
  }
}

sub initialize {
  my $self = shift;
  my $xnode = $self->{'xnode'};

  if ($self->{'io'}) {
    $self->{'io'}->close();
    $self->{'io'} = undef;
  }
  if ($self->{'uri'}) {
    $self->{'uri'} = undef;
  }
  my $uri = $xnode->xfind('./params/uri');
  $self->{'uri'} = $uri;
}

sub AUTOLOAD {
  my $self = shift;
  my $io = $self->{'io'};
  our $AUTOLOAD;
  my @methodcomps = split('::',$AUTOLOAD);
  my $method = pop(@methodcomps);
  #print "looking for method $method\n";
  return $io->$method(@_);
}

sub start {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
}

sub run {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my %args = @_;
}

sub end {
  my $self = shift;
  my $ic = $self->{'initialcontext'};
  my $self = shift;
}



1;
