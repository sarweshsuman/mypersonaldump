from .job import Job
from .job_runner import JobRunner
from multiprocessing import Process,Pipe

class JobManager:
    def __init__(self,initialContext):
        self.__initialContext = initialContext
        self.__running_jobs={}   # 'JobName':<process object>
        self.__failed_jobs=[]
        self.__completed_jobs=[]


    def __start_job(self,components):
        # This method will start the job
        parent_conn , child_conn = Pipe()
        p = Process(target=JobRunner.run_job,args=(components,self.__initialContext,child_conn))
        p.start()
        self.__running_jobs[components['jobname']]=p

    def __stop_job(self,components):
        jobName=components['jobname']
        if not jobName in self.__running_jobs:
            raise Exception("{} not found in running job queue ".format(jobName))
        else:
            p = self.__running_jobs[jobName]
            p.terminate()

    def __job_status(self,components):
        jobName=components['jobname']
        if not jobName in self.__running_jobs:
            raise Exception("{} not found in running job queue ".format(jobName))
        else:
            p = self.__running_jobs[jobName]
            if p.is_alive() == True:
                return "Running"
            else:
                p.name = jobName
                del self.__running_jobs[jobName]
                if p.exitcode != 0:
                    self.__failed_jobs.append(p)
                    return "Failed"
                else:
                    self.__completed_jobs.append(p)
                    return "Success"

    def manage_job(self,event_type,components):
        if event_type == 'START':
            self.__start_job(components)
        elif event_type == 'STOP':
            self.__stop_job(components)
        elif event_type == 'STATUS':
            return self.__job_status(components)
        else:
            raise Exception("event type {} not supported ".format(event_type))
