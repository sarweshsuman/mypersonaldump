import importlib
import os

class JobRunner:
    def run_job(components,initialContext,child_conn):
        # child_conn is to communicate with the parent
        # not implemented yet

        logger = initialContext['framework/logger']
        categories_in_order = initialContext['job_runner/categories_to_execute_in_order'].split(',')
        initialContext['job_runner/run/output']={}
        initialContext['job_runner/run/last_layer'] = -1
        layer = 0
        for category in categories_in_order:

            category_execute_bool=False

            for component in components:
                initialContext['job_runner/run/current_layer'] = layer
                if not 'category' in components[component]:
                    # Error, category not mentioned, will fail this job
                    raise Exception("Component {} does not have category parameter defined, can't continue..".format(component))
                else:
                    if components[component]['category'] == category:
                        package_name = initialContext[os.path.join(category,'package_name')]
                        class_name = None
                        if os.path.join(category,'class_name') in initialContext:
                            #  class_name is defined in ini file so will use that ( for data sources mainly )
                            class_name = initialContext[os.path.join(category,'class_name')]
                        else:
                            # class_name should be defined in component as a parameter, it could be Train,Predict etc
                            if 'action' in components[component]:
                                class_name = components[component]['action']
                            else:
                                logger.error("No class_name found for component {}, skipping it..".format(component))
                                break
                        method_name = initialContext[os.path.join(category, 'method_name')]
                        package_ref = importlib.import_module(package_name)
                        class_ref = getattr(package_ref,class_name)
                        class_obj = class_ref(initialContext,components[component])
                        method_ref = getattr(class_obj,method_name)
                        method_ref()
                        initialContext['job_runner/run/last_layer']=layer
                        layer += 1
                        category_execute_bool=True
            if category_execute_bool == False:
                if initialContext[category]['optional'] == False:
                    raise Exception("Category {} is not optional, it should be in the flow definition".format(category))
