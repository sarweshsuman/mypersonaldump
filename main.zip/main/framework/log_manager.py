import os
import logging

class LogManager:
    __logging_filename='mlframework.log'
    def __init__(self,initialContext):
        self.__initialContext=initialContext
        self.__logging_level=self.__initialContext['logging/logging_level']
        self.__logging_dir=self.__initialContext['logging/logging_dir']
        if not os.path.exists(self.__logging_dir):
            os.mkdir(self.__logging_dir)
        elif os.path.isdir(self.__logging_dir) == False:
            # logging dir is not directory
            self.__logging_dir='/tmp'
        # by default INFO
        logging.basicConfig(filename=os.path.join(self.__logging_dir,self.__logging_filename), level=self.__logging_level,format="%(asctime)s %(name)-12s %(levelname)-8s %(message)s")
        self.__initialContext['framework/logger']=logging