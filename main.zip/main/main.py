from main.framework.context_manager import ContextManager
from main.framework.log_manager import LogManager
from main.utils.kafka.kafka_consumer import SimpleKafkaConsumer
from main.framework.job_manager import  JobManager
import time

def start(inifile):
    ctx = ContextManager().get_context(inifile)
    ctx['framework/start_time'] = time.strftime("%Y-%m-%d %H:%M:%S")
    ctx['framework/start_time_in_epoch'] = int(time.time())
    LogManager(ctx)
    logger = ctx['framework/logger'].getLogger(__name__)

    logger.info("Initialized Context")
    logger.info("Initialized Logger")

    manager = JobManager(ctx)

    ctx['framework/job_manager'] = manager

    consumer = SimpleKafkaConsumer('framework', ctx)
    logger.info("Initialized Kafka")

    consumer.start()

if __name__ == '__main__':
    start('inifile.cfg')