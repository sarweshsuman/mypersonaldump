class JobDetails(object):

    def __init__(self,topicName=None, sender=None, eventType=None,
                 appName=None, componentName=None, domain=None,
                 processId=None, jobType=None, componentMap=set()):
        self.__topicName = topicName
        self.__sender = sender
        self.__eventType = eventType
        self.__appName = appName
        self.__componentName = componentName
        self.__domain = domain
        self.__processId = processId
        self.__jobType = jobType
        self.__componentMap = componentMap
        

    @property
    def topicName(self):
        return self.__topicName or self.defaultTopicName()

    @topicName.setter
    def topicName(self, value):
        self.__topicName = value

    @property
    def sender(self):
        return self.__sender or self.defaultSender()

    @sender.setter
    def sender(self, value):
        self.__sender = value

    @property
    def eventType(self):
        return self.__eventType or self.defaultEventType()

    @eventType.setter
    def eventType(self, value):
        self.__eventType = value

    @property
    def appName(self):
        return self.__appName or self.defaultAppName()

    @appName.setter
    def appName(self, value):
        self.__appName = value

    @property
    def componentName(self):
        return self.__componentName or self.defaultComponentName()

    @componentName.setter
    def componentName(self, value):
        self.__componentName = value

    @property
    def domain(self):
        return self.__domain or self.defaultDomain()

    @domain.setter
    def domain(self, value):
        self.__domain = value

    @property
    def processId(self):
        return self.__processId or self.defaultProcessId()

    @processId.setter
    def processId(self, value):
        self.__processId = value

    @property
    def jobType(self):
        return self.__jobType or self.defaultJobType()

    @jobType.setter
    def jobType(self, value):
        self.__jobType = value

    @property
    def componentMap(self):
        return self.__componentMap

    @componentMap.setter
    def componentMap(self, value):
        self.__componentMap = value
    def __str__(self):
        for comp in self.__componentMap:
         print(comp)
        return "TopicName: {} Sender: {} EventType: {} AppName: {} ComponentName: {} Domain: {} ProcessId: {} JobType: {}".format(self.__topicName,self.__sender,self.__eventType,self.__appName,self.__componentName,self.__domain,self.__processId,self.__jobType)
