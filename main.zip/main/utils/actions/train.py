import importlib
import os

class Train:

    def __init__(self, initialContext,component):

        self.__initialContext = initialContext
        self.__logger = self.__initialContext['framework/logger'].getLogger(__name__)

        self.__component = component

        self.__my_layer_num = self.__initialContext['job_runner/run/current_layer']
        self.__prev_layer_num = self.__initialContext['job_runner/run/last_layer']

        self.__model_library_package_name = self.__initialContext[os.path.join(self.__component['category'],'model_library_package_name')]

        self.__model_class = self.__component['name']

        self.__model_package = importlib.import_module(self.__model_library_package_name)
        self.__model_class_ref = getattr(self.__model_package,self.__model_class)
        self.__model = self.__model_class_ref(self.__initialContext,self.__component)

    def execute(self):
        if self.__prev_layer_num == -1:
            # Train cannot be the 1st layer
            self.__logger.error("Train cannot be 1st layer")
            raise Exception("Train cannot be 1st layer")
        generator = self.__initialContext[os.path.join('job_runner', 'run', 'output')][self._prev_layer_num]
        if generator == None:
            self.__logger.error("generator expected but got None")
            raise Exception("generator expected but got None")

        if type(generator).__name__ != 'generator':
            self.__logger.error("generator expected but got {}".format(type(generator).__name__))
            raise Exception("generator expected but got {}".format(type(generator).__name__))

        for iter in range(self.__epochs):
            print("Fetching next batch")
            batch = next(generator)
            print("Received batch")
            self.__model.step(batch,iter)
        self.__initialContext[os.path.join('job_runner', 'run', 'output')][self.__my_layer_num]=None
