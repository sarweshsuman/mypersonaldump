import importlib
import os

class DataSource:
    def __init__(self,initialContext,component):

        self.__initialContext = initialContext
        self.__component = component

        self.__my_layer_num = self.__initialContext['job_runner/run/current_layer']
        self.__prev_layer_num = self.__initialContext['job_runner/run/last_layer']

        self.__data_sources_package_name = self.__initialContext[os.path.join(self.__component['category'],'data_sources_library_package_name')]

        self.__source_class = self.__component['name']

        self.__source_package = importlib.import_module(self.__data_sources_package_name)
        self.__source_class_ref = getattr(self.__source_package, self.__source_class)
        self.__source = self.__source_class_ref(self.__initialContext,self.__component)

        self.__logger = self.__initialContext['framework/logger'].getLogger(__name__)
        self.__logger.info("Initialized")

    def execute(self):
        self.__logger.info("Called execute")
        self.__initialContext[os.path.join('job_runner','run','output')][self.__my_layer_num]=self.__source.get_generator()
        self.__logger.info("recevied generator for the source data ")