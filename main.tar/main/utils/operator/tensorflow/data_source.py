import importlib
import os

class DataSource:
    def __init__(self,initialContext):
        self.__initialContext = initialContext
        self.__source_package_name = self.__initialContext[os.path.join('operator',self.__class__.__name__,'source_package_name')]
        self.__source_class = self.__initialContext[os.path.join('operator',self.__class__.__name__,'source_class')]
        print("\n\n\n")
        print(self.__initialContext)
        print("\n")
        self.__source_package = importlib.import_module(self.__source_package_name)
        self.__source_class_ref = getattr(self.__source_package, self.__source_class)
        self.__source = self.__source_class_ref(self.__initialContext)

        self.__logger = self.__initialContext['framework/logger'].getLogger(__name__)
        self.__logger.info("Initialized")

    def execute(self):
        self.__logger.info("Called execute")
        self.__initialContext['data_source/source_generator']=self.__source.get_generator()
        self.__logger.info("recevied generator for the source data ")
        return self.__initialContext
