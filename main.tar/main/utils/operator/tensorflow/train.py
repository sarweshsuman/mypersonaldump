import importlib
import os

from main.utils.data_helpers.batch import Batch

class Train:

    def __init__(self, initialContext):
        self.__initialContext = initialContext
        self.__initialContext[os.path.join('operator','class_name')]=self.__class__.__name__
        self.__model_package_name = self.__initialContext[os.path.join('operator',self.__class__.__name__,'model_package_name')]
        self.__model_name= self.__initialContext[os.path.join('operator',self.__class__.__name__,'model_name')]
        self.__epochs = int(initialContext[os.path.join('operator',self.__class__.__name__,'epochs')])
        self.__model_package = importlib.import_module(self.__model_package_name)
        self.__model_class_ref = getattr(self.__model_package,self.__model_name)
        self.__model = self.__model_class_ref(self.__initialContext)

        # This part is now migrated to DataSource, it is the responsibility of the data source
        # to create a batch - generator and set it in initialContext as output
        #self.__batch = Batch(self.__initialContext)
        #self.__batch_iterator = self.__batch.get_batch(self.__model_name)
    def execute(self):
        generator=self.__initialContext['output']
        if generator == None:
            print("No Input received from any data source")
            return
        #print("Here with generator of value {}".format(next(generator)))
        for iter in range(self.__epochs):
            batch = next(generator)
            self.__model.step(batch,iter)
        self.__initialContext['output']=None
