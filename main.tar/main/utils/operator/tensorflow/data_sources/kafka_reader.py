from main.utils.kafka.kafka_consumer import SimpleKafkaConsumer

class Kafka:
    def __init__(self,initContext):
        self.__initialContext = initContext
        self.__consumer = SimpleKafkaConsumer('operand/data_source',self.__initialContext)
        #self.__batch_size = self.__initialContext['']
    def get_generator(self):
        yield self.__consumer.get_n_messages(50)

