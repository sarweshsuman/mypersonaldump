from main.utils.cdt.platform.message.message import PlatformMessage
from kafka import KafkaConsumer
import os

class SimpleKafkaConsumer:
    def __init__(self,key,initialContext):
        self.__key=key
        self.__initialContext = initialContext
        self.__kafka_topic=self.__initialContext[os.path.join(self.__key,'topic_name')]
        self.__kafka_bootstrapservers = self.__initialContext[os.path.join(self.__key,'bootstrap_servers')]

        #self.__consumer = KafkaConsumer(bootstrap_servers=self.__kafka_bootstrapservers, auto_offset_reset='earliest')
        #self.__consumer.subscribe([self.__kafka_topic])

        self.__logger=self.__initialContext['framework/logger'].getLogger(__name__)
        self.__initialContext[os.path.join(self.__key,'framework/kafka/consumer')]=self
        self.__logger.info("Initialized")

    def start(self):
        self.__logger.info("Starting Kafka")
        self.__logger.info("Listening to topic {}".format(self.__kafka_topic))

        manager = self.__initialContext['framework/job_manager']

        #for kafka_message in self.__consumer:
        #    self.__logger.info("Received one message {}".format(kafka_message.value))

        #This message str is for testing kafka dataSource then train
        #message_str='<?xml version="1.0" encoding="UTF-8"?><PlatformMessage><Message><TopicName>MLFramework</TopicName><Sender>Platform</Sender><EventType>START</EventType><AppName>ObjectClassifier</AppName><ComponentName>MLFramework</ComponentName><Domain>Aricent</Domain><ProcessId>10201010</ProcessId><JobType>STREAM</JobType></Message><ComponentConfig><Component><ComponentID>003</ComponentID><ComponentParent>MLFramework</ComponentParent><ComponentName>DataSource</ComponentName><PropertyConfig><InputConfiguration><Property PropertyID="001"><PropertyName>type</PropertyName><PropertyValue>operator</PropertyValue></Property><Property PropertyID="002"> <PropertyName>serial_number</PropertyName><PropertyValue>0</PropertyValue></Property><Property PropertyID="001"><PropertyName>operator_package</PropertyName><PropertyValue>main.utils.operator.tensorflow.data_source</PropertyValue></Property><Property PropertyID="001"><PropertyName>operator_class</PropertyName><PropertyValue>DataSource</PropertyValue></Property><Property PropertyID="001"><PropertyName>source_package_name</PropertyName><PropertyValue>main.utils.operator.tensorflow.data_sources.kafka_reader</PropertyValue></Property>					<Property PropertyID="001"><PropertyName>source_class</PropertyName><PropertyValue>Kafka</PropertyValue></Property>					</InputConfiguration><InputDataFormat/><OutputConfiguration/><OutputDataFormat/></PropertyConfig></Component>	<Component><ComponentID>002</ComponentID><ComponentParent>MLFramework</ComponentParent><ComponentName>Kafka</ComponentName><PropertyConfig><InputConfiguration><Property PropertyID=""><PropertyName>type</PropertyName><PropertyValue>operand</PropertyValue></Property><Property PropertyID=""><PropertyName>operator</PropertyName><PropertyValue>DataSource</PropertyValue></Property><Property PropertyID="001"><PropertyName>topic_name</PropertyName><PropertyValue>imagearray</PropertyValue></Property><Property PropertyID="001"><PropertyName>bootstrap_servers</PropertyName><PropertyValue>0.0.0.1,0.0.0.2</PropertyValue></Property></InputConfiguration><InputDataFormat/><OutputConfiguration/><OutputDataFormat/></PropertyConfig></Component>		<Component><ComponentID>002</ComponentID><ComponentParent>MLFramework</ComponentParent><ComponentName>ImageClassification</ComponentName><PropertyConfig><InputConfiguration><Property PropertyID=""><PropertyName>type</PropertyName><PropertyValue>operand</PropertyValue></Property><Property PropertyID=""><PropertyName>operator</PropertyName><PropertyValue>Train</PropertyValue></Property><Property PropertyID=""><PropertyName>image_height</PropertyName><PropertyValue>28</PropertyValue></Property><Property PropertyID=""><PropertyName>image_width</PropertyName><PropertyValue>28</PropertyValue></Property><Property PropertyID="002"><PropertyName>num_classes</PropertyName><PropertyValue>10</PropertyValue></Property><Property PropertyID="002"><PropertyName>num_layers</PropertyName><PropertyValue>2</PropertyValue></Property><Property PropertyID="002"><PropertyName>filter_height</PropertyName><PropertyValue>5</PropertyValue></Property><Property PropertyID="002"><PropertyName>filter_width</PropertyName><PropertyValue>5</PropertyValue></Property><Property PropertyID="002"><PropertyName>num_filters_per_layer</PropertyName><PropertyValue>32,64</PropertyValue></Property></InputConfiguration><InputDataFormat/><OutputConfiguration/><OutputDataFormat/></PropertyConfig></Component><Component><ComponentID>003</ComponentID><ComponentParent>MLFramework</ComponentParent><ComponentName>Train</ComponentName><PropertyConfig><InputConfiguration><Property PropertyID="001"><PropertyName>type</PropertyName><PropertyValue>operator</PropertyValue></Property><Property PropertyID="002"> <PropertyName>serial_number</PropertyName><PropertyValue>1</PropertyValue></Property><Property PropertyID="001"><PropertyName>operator_package</PropertyName><PropertyValue>main.utils.operator.tensorflow.train</PropertyValue></Property><Property PropertyID="001"><PropertyName>operator_class</PropertyName><PropertyValue>Train</PropertyValue></Property><Property PropertyID="001"><PropertyName>model_package_name</PropertyName><PropertyValue>main.models.tensorflow.classification.image.classification_model</PropertyValue></Property><Property PropertyID="001"><PropertyName>model_name</PropertyName><PropertyValue>ImageClassification</PropertyValue></Property><Property PropertyID="001"><PropertyName>epochs</PropertyName><PropertyValue>1000</PropertyValue></Property><Property PropertyID="001"><PropertyName>batch_size</PropertyName><PropertyValue>50</PropertyValue></Property></InputConfiguration><InputDataFormat/><OutputConfiguration/><OutputDataFormat/></PropertyConfig></Component></ComponentConfig></PlatformMessage>'

        # This message str is to test MNIST_data data source and then train
        message_str='''<?xml version="1.0" encoding="UTF-8"?>
<PlatformMessage>
<Message>
<TopicName>MLFramework</TopicName>
<Sender>Platform</Sender>
<EventType>START</EventType>
<AppName>ObjectClassifier</AppName>
<ComponentName>MLFramework</ComponentName>
<Domain>Aricent</Domain>
<ProcessId>10201010</ProcessId>
<JobType>STREAM</JobType>
</Message>
<ComponentConfig>
<Component><ComponentID>003</ComponentID><ComponentParent>MLFramework</ComponentParent>
<ComponentName>DataSource</ComponentName>
<PropertyConfig><InputConfiguration>
<Property PropertyID="001"><PropertyName>type</PropertyName><PropertyValue>operator</PropertyValue></Property>
<Property PropertyID="002"><PropertyName>serial_number</PropertyName><PropertyValue>0</PropertyValue></Property>
<Property PropertyID="001"><PropertyName>operator_package</PropertyName><PropertyValue>main.utils.operator.tensorflow.data_source</PropertyValue></Property>
<Property PropertyID="001"><PropertyName>operator_class</PropertyName><PropertyValue>DataSource</PropertyValue></Property>
<Property PropertyID="001"><PropertyName>source_package_name</PropertyName><PropertyValue>main.utils.data_helpers.models.tensorflow.classification.image.mnist_data</PropertyValue></Property>
<Property PropertyID="001"><PropertyName>source_class</PropertyName><PropertyValue>Mnist</PropertyValue></Property>
</InputConfiguration>
<InputDataFormat/><OutputConfiguration/><OutputDataFormat/></PropertyConfig></Component>
<Component><ComponentID>002</ComponentID><ComponentParent>MLFramework</ComponentParent>
<ComponentName>Mnist</ComponentName><PropertyConfig><InputConfiguration>
<Property PropertyID=""><PropertyName>type</PropertyName><PropertyValue>operand</PropertyValue></Property>
<Property PropertyID=""><PropertyName>operator</PropertyName><PropertyValue>DataSource</PropertyValue></Property>
<Property PropertyID="001"><PropertyName>batch_size</PropertyName><PropertyValue>50</PropertyValue></Property>
</InputConfiguration><InputDataFormat/><OutputConfiguration/><OutputDataFormat/></PropertyConfig></Component>
<Component><ComponentID>002</ComponentID><ComponentParent>MLFramework</ComponentParent>
<ComponentName>ImageClassification</ComponentName><PropertyConfig><InputConfiguration>
<Property PropertyID=""><PropertyName>type</PropertyName><PropertyValue>operand</PropertyValue></Property>
<Property PropertyID=""><PropertyName>operator</PropertyName><PropertyValue>Train</PropertyValue></Property>
<Property PropertyID=""><PropertyName>image_height</PropertyName><PropertyValue>28</PropertyValue></Property>
<Property PropertyID=""><PropertyName>image_width</PropertyName><PropertyValue>28</PropertyValue></Property>
<Property PropertyID="002"><PropertyName>num_classes</PropertyName><PropertyValue>10</PropertyValue></Property>
<Property PropertyID="002"><PropertyName>num_layers</PropertyName><PropertyValue>2</PropertyValue></Property>
<Property PropertyID="002"><PropertyName>filter_height</PropertyName><PropertyValue>5</PropertyValue></Property>
<Property PropertyID="002"><PropertyName>filter_width</PropertyName><PropertyValue>5</PropertyValue></Property>
<Property PropertyID="002"><PropertyName>num_filters_per_layer</PropertyName><PropertyValue>32,64</PropertyValue></Property>
</InputConfiguration><InputDataFormat/><OutputConfiguration/><OutputDataFormat/></PropertyConfig></Component>
<Component><ComponentID>003</ComponentID><ComponentParent>MLFramework</ComponentParent>
<ComponentName>Train</ComponentName><PropertyConfig><InputConfiguration>
<Property PropertyID="001"><PropertyName>type</PropertyName><PropertyValue>operator</PropertyValue></Property>
<Property PropertyID="002"> <PropertyName>serial_number</PropertyName><PropertyValue>1</PropertyValue></Property>
<Property PropertyID="001"><PropertyName>operator_package</PropertyName><PropertyValue>main.utils.operator.tensorflow.train</PropertyValue></Property>
<Property PropertyID="001"><PropertyName>operator_class</PropertyName><PropertyValue>Train</PropertyValue></Property>
<Property PropertyID="001"><PropertyName>model_package_name</PropertyName><PropertyValue>main.models.tensorflow.classification.image.classification_model</PropertyValue></Property>
<Property PropertyID="001"><PropertyName>model_name</PropertyName><PropertyValue>ImageClassification</PropertyValue></Property>
<Property PropertyID="001"><PropertyName>epochs</PropertyName><PropertyValue>1000</PropertyValue></Property>
</InputConfiguration><InputDataFormat/><OutputConfiguration/><OutputDataFormat/></PropertyConfig>
</Component></ComponentConfig></PlatformMessage>'''
        message = PlatformMessage()
        message.parse_xml(message_str)

            # This is temporary has to be moved to other location
            # We cannot call directly job manager from here

        jobdef = manager.create_jobdef(message)
        manager.manage_job(jobdef)
        self.__logger.info("Processed Message")
        self.__logger.info("Waiting for next Message")
    def get_n_messages(self,num_messages):
        count=0
        kafka_messages=[]
        for message in self.__consumer:
            kafka_messages.append(message)
            count += 1
            if count == num_messages:
                break
        return kafka_messages
