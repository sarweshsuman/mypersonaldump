class KafkaConsumer:
    def __init__(self,initialContext):
        self.__initialContext = initialContext
        self.__kafka_topic=self.__initialContext['kafka/topic_name']
        self.__logger=self.__initialContext['framework/logger'].getLogger(__name__)
        self.__initialContext['framework/kafka/consumer']=self
        self.__logger.info("Initialized")
    def start(self):
        self.__logger.info("Fetched one message")

        # This is temporary has to be moved to other location
        # We cannot call directly job manager from here

        manager = self.__initialContext['framework/job_manager']

        # Need to parse the xml to some class
        # Avanish part goes here


        manager.create_jobdef()

        return '<?xml version="1.0" encoding="UTF-8"?><PlatformMessage><Message><TopicName>MLFramework</TopicName><Sender>Platform</Sender><EventType>START</EventType><AppName>Sequence2Sequence</AppName><ComponentName>MLFramework</ComponentName><Domain>Aricent</Domain><ProcessId>10201010</ProcessId><JobType>BATCH</JobType></Message><ComponentConfig><Component><ComponentID>002</ComponentID><ComponentParent>MLFramework</ComponentParent><ComponentName>seq2seq</ComponentName><PropertyConfig><InputConfiguration><Property PropertyID=""><PropertyName>type</PropertyName><PropertyValue>model</PropertyValue></Property><Property PropertyID=""><PropertyName>learning.rate</PropertyName><PropertyValue>0.1</PropertyValue></Property></InputConfiguration><InputDataFormat/><OutputConfiguration/><OutputDataFormat/></PropertyConfig></Component><Component><ComponentID>003</ComponentID><ComponentParent>MLFramework</ComponentParent><ComponentName>Train</ComponentName><PropertyConfig><InputConfiguration><Property PropertyID=""><PropertyName>type</PropertyName><PropertyValue>operator</PropertyValue></Property><Property PropertyID=""><PropertyName>model.name</PropertyName><PropertyValue>seq2seq</PropertyValue></Property><Property PropertyID=""><PropertyName>source.data.set</PropertyName><PropertyValue>file://tmp/source.en</PropertyValue></Property><Property PropertyID=""><PropertyName>target.data.set</PropertyName><PropertyValue>file://tmp/target.en</PropertyValue></Property></InputConfiguration><InputDataFormat/><OutputConfiguration/><OutputDataFormat/></PropertyConfig></Component></ComponentConfig></PlatformMessage>'