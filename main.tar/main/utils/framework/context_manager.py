import configparser

class ContextManager:
    initialContext={}
    def __init__(self):
        pass
    def get_context(self,inifile):
        self.config = configparser.ConfigParser()
        self.config.read(inifile)
        for section in self.config.sections():
            for opt in self.config.options(section):
                value = self.config.get(section,opt)
                self.initialContext["/".join([section,opt])]=value
        self.initialContext['framework/context_manager']=self
        return self.initialContext
