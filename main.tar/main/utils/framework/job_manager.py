from .job import Job

class JobManager:
    def __init__(self,initialContext):
        self.running_jobs=[]
        self.failed_jobs=[]
        self.jobs_to_stop=[]
        self.jobs_to_start=[]
    def create_jobdef(self,platformMessage):
        jobdef=Job()
        components = platformMessage.get_components()
        operator=[]
        operand=[]
        for component in components:
            if component['type'] == 'operator':
                operator.append(component)
            else:
                operand.append(component)
        for component in operator:
            jobdef.add_operator(component['name'], component)
        for component in operand:
            jobdef.add_operand(component['name'], component)
        return jobdef
    def submit_job(self,jobdef):
        self.jobs_to_start.append(jobdef)
