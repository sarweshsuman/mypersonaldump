
import importlib
from .job import Job
import os
import sys

class JobRunner:
    def run_job(job,initialContext,child_conn):
        # child_conn is to communicate with the parent
        for operator in job.get_operator_as_generator():
            print("Processing operator {}".format(operator))
            if type(operator) == list:
                # operator's within this list is to be run in parallel
                pass
            elif type(operator) == str:
                # I got the operator, now i will instantiate the class and pass the operand details
                operator_package = job.get_operator_package(operator)
                print("Operator package {}".format(operator_package))
                operator_class = job.get_operator_class(operator)
                print("Operator class {}".format(operator_class))

                operator_module = importlib.import_module(operator_package)
                operator_class_ref = getattr(operator_module,operator_class)

                """
                -- Have to add the parameters of this operator to the initialContext
                -- Also have to add parameters of the operand specific to this operator to initialContext
                -- and send it to operator_class_ref
                """

                parameters=job.get_operator_parameters(operator)
                print("Parameters for this operator {}".format(parameters))
                for param in parameters:
                    if param == 'operand':
                        for operand_param in parameters[param]:
                            # Removing slash from front if exists
                            initialContext[os.path.join('operand',operator,parameters[param]['name'],operand_param.lstrip('/'))]=parameters[param][operand_param]
                    else:
                        initialContext[os.path.join('operator',operator,param.lstrip('/'))]=parameters[param]
                # For example, initializing train.py
                operator_class_obj = operator_class_ref(initialContext)
                operator_class_obj.execute()

            else:
                # I dont understand this type
                raise Exception("Non compatible operator found")

            print("Printing Here")
            print(initialContext)
            print("Printing Ends here")
            sys.exit(1)
if __name__ == '__main__':
    initialContext={}
    job=Job()
    """
    job.add_operator('Train',{
    'serial_number':0,
    'operator_package':'main.utils.operator.tensorflow.train',
    'operator_class':'Train',
    'parameters':{
    'train/model_package_name':'main.operator.tensorflow.classification.image.classification_model',
    'train/model_name':'ImageClassification',
    'train/epochs':1000,
    'train/batch_size':50
    }})"""
    job.add_operator('Train',{
    'serial_number':0,
    'operator_package':'main.utils.operator.tensorflow.train',
    'operator_class':'Train',
    'train/model_package_name':'main.operator.tensorflow.classification.image.classification_model',
    'train/model_name':'ImageClassification',
    'train/epochs':1000,
    'train/batch_size':50
    })
    """
    job.add_operand('MnistExample',{'operator':'Train',
    'image_classification/image_height':28,
    'image_classification/image_width':28,
    'image_classification/num_classes':10,
    'image_classification/num_layers':2,
    'image_classification/filter_height':5,
    'image_classification/filter_width':5,
    'image_classification/num_filters_per_layer':'32,64'
    })
    """
    job.add_operand('MnistExample',{'operator':'Train',
    'image_height':28,
    'image_width':28,
    'num_classes':10,
    'num_layers':2,
    'filter_height':5,
    'filter_width':5,
    'num_filters_per_layer':'32,64'
    })
    print(job.operator_definition)
    JobRunner.run_job(job,initialContext)
