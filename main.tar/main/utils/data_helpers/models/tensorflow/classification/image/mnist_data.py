from tensorflow.examples.tutorials.mnist import input_data
import os

class Mnist:
    def __init__(self,initContext):
        self.__initialContext=initContext
        self.__batch_size=int(self.__initialContext[os.path.join('operand',self.__initialContext[os.path.join('operator','class_name')],self.__class__.__name__,'batch_size')])
        self.__mnist = input_data.read_data_sets('MNIST_data', one_hot=True)
    def get_generator(self):
        def mnist_batch():
            while True:
               yield self.__mnist.train.next_batch(self.__batch_size)
        return mnist_batch()
