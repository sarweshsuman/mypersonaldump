from main.utils.data_helpers.models.tensorflow.classification.image.mnist_data import Mnist

class Batch:
    def __init__(self,initialContext):
        self.batch_size = int(initialContext['operator/train/batch_size'])
        self.model_name = initialContext['operator/train/model_name']

        self.generator_functions={}
        self.mnist = Mnist()
        def mnist_batch():
            while True:
               yield self.mnist.mnist.train.next_batch(self.batch_size)
        self.generator_functions['ImageClassification']=mnist_batch() # need to fix this, because here the image classification batch is fixed to mnit data

    def get_batch(self,model_name):
        if model_name in self.generator_functions:
            return self.generator_functions[model_name]
        else:
            raise Exception("Generator Function Not Found for model {}".format(model_name))
