import importlib

from main.utils.data_helpers.batch import Batch

class Train:
    """ Train expects following in initialContext
    it is an operator
    operator/train/model_package_name
    operator/train/model_name
    operator/train/epochs

    This will have to be updated so that each run has its own configuration and does not
    impact other runs
    """
    def __init__(self, initialContext):
        self.model_package_name = initialContext['operator/train/model_package_name']
        self.model_name= initialContext['operator/train/model_name']
        self.epochs = initialContext['operator/train/epochs']
        self.model_package = importlib.import_module(self.model_package_name)
        self.model_class_ref = getattr(self.model_package,self.model_name)
        self.model = self.model_class_ref(initialContext)
        self.batch = Batch(initialContext)
        self.batch_iterator = self.batch.get_batch(self.model_name)
    def execute(self):
        for iter in range(self.epochs):
            batch = next(self.batch_iterator)
            self.model.step(batch,iter)


if __name__ == '__main__':
    initialContext={}
    initialContext['model/model_package_name']='main.models.tensorflow.classification.image.classification_model'
    initialContext['model/model_name']='mnist'
    initialContext['model/train/epochs']=20000

    initialContext['model/train/batch_size']=50

    initialContext['models/tensorflow/classification/image/Classification/input/image_heigth'] = 28
    initialContext['models/tensorflow/classification/image/Classification/input/image_width'] = 28
    initialContext['models/tensorflow/classification/image/Classification/output/num_classes'] = 10
    initialContext['models/tensorflow/classification/image/Classification/network/num_layers'] = 2
    initialContext['models/tensorflow/classification/image/Classification/network/filter_height'] = 5
    initialContext['models/tensorflow/classification/image/Classification/network/filter_width'] = 5
    initialContext['models/tensorflow/classification/image/Classification/network/num_filters_per_layer'] = '32,64'

    train=Train(initialContext)
    train.train()
