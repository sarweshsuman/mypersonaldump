from main.utils.framework.context_manager import ContextManager
from main.utils.framework.log_manager import LogManager
from main.utils.kafka.simple_kafka_client import KafkaConsumer
import time

class Main:
    def start(self,inifile):
        ctx = ContextManager().get_context(inifile)
        ctx['framework/start_time']=time.strftime("%Y-%m-%d %H:%M:%S")
        ctx['framework/start_time_in_epoch']=int(time.time())
        LogManager(ctx)
        logger=ctx['framework/logger'].getLogger(__name__)
        logger.info("Initialized Context")
        logger.info("Initialized Logger")
        consumer = KafkaConsumer(ctx)
        logger.info("Initialized Kafka")

        # Skipping MetricManager

        # will initialize JobManager


        print(ctx)

if __name__ == '__main__':
    main = Main()
    main.start('inifile.cfg')
