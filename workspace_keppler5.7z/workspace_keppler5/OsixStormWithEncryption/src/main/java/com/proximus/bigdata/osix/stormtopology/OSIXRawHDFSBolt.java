package com.proximus.bigdata.osix.stormtopology;

import org.apache.storm.hdfs.bolt.HdfsBolt;
import org.apache.storm.hdfs.bolt.AbstractHdfsBolt;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.tuple.Tuple;

import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.client.HdfsDataOutputStream;
import org.apache.hadoop.hdfs.client.HdfsDataOutputStream.SyncFlag;
import org.apache.storm.hdfs.bolt.format.FileNameFormat;
import org.apache.storm.hdfs.bolt.format.RecordFormat;
import org.apache.storm.hdfs.bolt.rotation.FileRotationPolicy;
import org.apache.storm.hdfs.bolt.sync.SyncPolicy;
import org.apache.storm.hdfs.common.rotation.RotationAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.voltage.securedata.hadoop.crypto.CryptoException;

import java.io.IOException;
import java.net.URI;
import java.util.EnumSet;
import java.util.Map;

public class OSIXRawHDFSBolt extends AbstractOSIXHDFSBolt {

	private static final Logger LOG = LoggerFactory.getLogger(OSIXRawHDFSBolt.class);

    private transient FSDataOutputStream out;
    private RecordFormat format;
    private long offset = 0;

    public OSIXRawHDFSBolt withFsUrl(String fsUrl){
        this.fsUrl = fsUrl;
        return this;
    }

    public OSIXRawHDFSBolt withConfigKey(String configKey){
        this.configKey = configKey;
        return this;
    }

    public OSIXRawHDFSBolt withFileNameFormat(FileNameFormat fileNameFormat){
        this.fileNameFormat = fileNameFormat;
        return this;
    }

    public OSIXRawHDFSBolt withRecordFormat(RecordFormat format){
        this.format = format;
        return this;
    }

    public OSIXRawHDFSBolt withSyncPolicy(SyncPolicy syncPolicy){
        this.syncPolicy = syncPolicy;
        return this;
    }

    public OSIXRawHDFSBolt withRotationPolicy(FileRotationPolicy rotationPolicy){
        this.rotationPolicy = rotationPolicy;
        return this;
    }

    public OSIXRawHDFSBolt addRotationAction(RotationAction action){
        this.rotationActions.add(action);
        return this;
    }

    @Override
    public void doPrepare(Map conf, TopologyContext topologyContext, OutputCollector collector) throws IOException {
        LOG.info("Preparing OSIXRawHDFS Bolt...");
        this.fs = FileSystem.get(URI.create(this.fsUrl), hdfsConfig);
    }

    public void execute(Tuple tuple) {
        try {
            byte[] r_bytes = tuple.getBinary(tuple.fieldIndex("bytes"));
        	String osix_record = new String(r_bytes,"UTF-8");
        	OsixMessage encrypted_record = new OsixMessage(this.encrypt,osix_record);
        	byte[] bytes = encrypted_record.toString().getBytes();
            synchronized (this.writeLock) {
                out.write(bytes);
                String eol = "\n";
                out.write(eol.getBytes());
                this.offset += bytes.length + 1;

                if (this.syncPolicy.mark(tuple, this.offset)) {
                    if (this.out instanceof HdfsDataOutputStream) {
                        ((HdfsDataOutputStream) this.out).hsync(EnumSet.of(SyncFlag.UPDATE_LENGTH));
                    } else {
                        this.out.hsync();
                    }
                    this.syncPolicy.reset();
                }
            }

            this.collector.ack(tuple);

            if(this.rotationPolicy.mark(tuple, this.offset)){
                rotateOutputFile(); // synchronized
                this.offset = 0;
                this.rotationPolicy.reset();
            }
        }
        catch (CryptoException e) {
            LOG.error("Encryption failed.", e);
            LOG.error("Failed For Message "+(new String(tuple.getBinary(tuple.fieldIndex("bytes")))));
            this.collector.fail(tuple);
        }
        catch (IOException e) {
            LOG.error("write/sync failed.", e);
            this.collector.fail(tuple);
        }
    }

    @Override
    void closeOutputFile() throws IOException {
        this.out.close();
    }

    //@Override
    Path createOutputFile() throws IOException {
        Path path = new Path(this.fileNameFormat.getPath(), this.fileNameFormat.getName(this.rotation, System.currentTimeMillis()));
        this.out = this.fs.create(path);
        return path;
    }

    @Override
    public void declareOutputFields(OutputFieldsDeclarer outputFieldsDeclarer) {
    }
}
