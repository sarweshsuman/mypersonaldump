package com.proximus.bigdata.osix.stormtopology;

import java.util.ArrayList;
import java.util.Arrays;

import backtype.storm.generated.AuthorizationException;
import org.apache.storm.hdfs.bolt.HdfsBolt;
import org.apache.storm.hdfs.bolt.format.DefaultFileNameFormat;
import org.apache.storm.hdfs.bolt.format.DelimitedRecordFormat;
import org.apache.storm.hdfs.bolt.format.FileNameFormat;
import org.apache.storm.hdfs.bolt.format.RecordFormat;
import org.apache.storm.hdfs.bolt.format.DefaultSequenceFormat;
import org.apache.storm.hdfs.bolt.rotation.FileRotationPolicy;
import org.apache.storm.hdfs.bolt.rotation.FileSizeRotationPolicy;
import org.apache.storm.hdfs.bolt.rotation.FileSizeRotationPolicy.Units;
import org.apache.storm.hdfs.bolt.sync.CountSyncPolicy;
import org.apache.storm.hdfs.bolt.sync.SyncPolicy;

import storm.kafka.BrokerHosts;
import storm.kafka.ZkHosts;
import storm.kafka.KafkaSpout;
import storm.kafka.SpoutConfig;
import backtype.storm.Config;
import backtype.storm.StormSubmitter;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.topology.TopologyBuilder;
// import java.util.ImmutableList;
// from google guava

public class NoOpTopology {

	public static void main(String[] args) throws AlreadyAliveException, InvalidTopologyException {
		// TODO Auto-generated method stub

		
		if (args.length > 0) {
			System.out.println("Got args: " + Arrays.toString(args));
		}
		else {
			System.out.println("No Args specified. Please specify a properties file");
			System.exit(1);
		}
		
		TopologyBuilder tb = new TopologyBuilder();
		
	//	SpoutConfig spc = new SpoutConfig((BrokerHosts) Arrays.asList("localhost","evertnet")
 		SpoutConfig spc = new SpoutConfig(new ZkHosts("hadoopm01.cluster.bc:2181")
		        ,"osix" // topic
				,"/osixkafka"      // root path in zookeeper for the spout to store consumer offsets
				,"discovery"  // id for storing consumer offsets in zookeeper
				);
 						
		KafkaSpout kfksp = new KafkaSpout(spc); 
		NoOpBolt hdfs = new NoOpBolt();
			
		// I need to insert something here, somethung to split that JSON ...
		// Into an array
		/*
		FileRotationPolicy rotationPolicy = new FileSizeRotationPolicy(5.0f, Units.MB);
		FileNameFormat fnformat = new DefaultFileNameFormat().withPath("/osix");
		SyncPolicy syncPolicy = new CountSyncPolicy(1000);
		RecordFormat rformat = new DelimitedRecordFormat().withFieldDelimiter("|");
		*/
		/*
		hdfs = new OSIXRawHDFSBolt()
			.withFsUrl("hdfs://hadoopm01.cluster.bc:8020")
			.withFileNameFormat(fnformat)
			.withRecordFormat(rformat)
			.withRotationPolicy(rotationPolicy)
			.withSyncPolicy(syncPolicy);
		//HdfsBolt tb2 = new HdfsBolt();
		//kfksp.declareOutputFields();
		*/
		
		tb.setSpout("kafkareader", kfksp);
		tb.setBolt("hdfswriter",hdfs).shuffleGrouping("kafkareader");
		
		Config conf = new Config(); // this is a config that should contain the deployment crap
		
		// now create a stormsubmitter
        try {
            StormSubmitter.submitTopology("osix_kafka",conf, tb.createTopology());
        } catch (AuthorizationException e) {
            e.printStackTrace();
        }
    }
}
