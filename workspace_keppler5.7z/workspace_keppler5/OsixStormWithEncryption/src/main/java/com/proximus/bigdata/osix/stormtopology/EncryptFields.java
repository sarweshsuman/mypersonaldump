package com.proximus.bigdata.osix.stormtopology;

import java.io.Serializable;

import org.apache.hadoop.conf.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.voltage.securedata.hadoop.config.ConfigSettings;
import com.voltage.securedata.hadoop.config.ConfigSettings.FieldConfig;
import com.voltage.securedata.hadoop.crypto.Crypto;
import com.voltage.securedata.hadoop.crypto.CryptoException;
import com.voltage.securedata.hadoop.crypto.CryptoFactory;
import com.voltage.securedata.hadoop.util.HDFSConfigLoader;

public class EncryptFields implements Serializable{
	private static final Logger LOG = LoggerFactory.getLogger(EncryptFields.class);
	private static ConfigSettings configSettings;
	private Crypto crypto;
	private int minLength=-1;
	private Crypto network_event_ts;
	private Crypto imsi;
	private Crypto imei;
	private Crypto lac;
	private Crypto rac;
	private Crypto tac;
	private Crypto cell;
	private Crypto accept_event_date;

	public EncryptFields() throws Exception {
		Configuration config = new Configuration();
		config.set("VOLTAGE_CONFIG_FILE","/tmp/vsconfig.properties");
		config.set("VOLTAGE_AUTH_FILE","/tmp/vsauth.properties");
		configSettings = HDFSConfigLoader.load(config);
		if (configSettings == null ) {
			throw new Exception("Config Setting variable in Encrypt Field is null");
		}
		CryptoFactory.init(configSettings);

		FieldConfig fieldConfig;
		fieldConfig = configSettings.getHiveField("NETWORK_EVENTS_TS");
		if (fieldConfig == null ) {
			throw new Exception("fieldConfig variable in Encrypt Field is null for nets");
		}

		network_event_ts = CryptoFactory.getCrypto(fieldConfig.getApiType(),fieldConfig.getFormatInfo());
		if (network_event_ts == null ) {
			throw new Exception("network_event_ts variable in Encrypt Field is null");
		}

		fieldConfig = configSettings.getHiveField("IMSI");
		if (fieldConfig == null ) {
			throw new Exception("fieldConfig variable in Encrypt Field is null for imsi");
		}

		imsi = CryptoFactory.getCrypto(fieldConfig.getApiType(),fieldConfig.getFormatInfo());
		if (imsi == null ) {
			throw new Exception("imsi variable in Encrypt Field is null");
		}

		fieldConfig = configSettings.getHiveField("IMEI");
		if (fieldConfig == null ) {
			throw new Exception("fieldConfig variable in Encrypt Field is null for imei");
		}

		imei = CryptoFactory.getCrypto(fieldConfig.getApiType(),fieldConfig.getFormatInfo());
		if (imei == null ) {
			throw new Exception("imei variable in Encrypt Field is null");
		}

		fieldConfig = configSettings.getHiveField("LAC");
		if (fieldConfig == null ) {
			throw new Exception("fieldConfig variable in Encrypt Field is null for lac");
		}

		lac = CryptoFactory.getCrypto(fieldConfig.getApiType(),fieldConfig.getFormatInfo());
		if (lac == null ) {
			throw new Exception("lac variable in Encrypt Field is null");
		}

		fieldConfig = configSettings.getHiveField("RAC");
		if (fieldConfig == null ) {
			throw new Exception("fieldConfig variable in Encrypt Field is null for rac");
		}

		rac = CryptoFactory.getCrypto(fieldConfig.getApiType(),fieldConfig.getFormatInfo());
		if (rac == null ) {
			throw new Exception("rac variable in Encrypt Field is null");
		}

		fieldConfig = configSettings.getHiveField("TAC");
		if (fieldConfig == null ) {
			throw new Exception("fieldConfig variable in Encrypt Field is null for tac");
		}

		tac = CryptoFactory.getCrypto(fieldConfig.getApiType(),fieldConfig.getFormatInfo());
		if (tac == null ) {
			throw new Exception("tac variable in Encrypt Field is null");
		}

		fieldConfig = configSettings.getHiveField("CELL");
		if (fieldConfig == null ) {
			throw new Exception("fieldConfig variable in Encrypt Field is null for cell");
		}

		cell = CryptoFactory.getCrypto(fieldConfig.getApiType(),fieldConfig.getFormatInfo());
		if (cell == null ) {
			throw new Exception("cell variable in Encrypt Field is null");
		}

		fieldConfig = configSettings.getHiveField("RECORD"); // accept_event_ts = RECORD as alias
		if (fieldConfig == null ) {
			throw new Exception("fieldConfig variable in Encrypt Field is null for accept_event_date");
		}

		accept_event_date = CryptoFactory.getCrypto(fieldConfig.getApiType(),fieldConfig.getFormatInfo());
		if (accept_event_date == null ) {
			throw new Exception("accept_event_date variable in Encrypt Field is null");
		}

	}
	public String getEncryptedNetworkEventTS(String network_event_ts) throws CryptoException{
		try{
			return this.network_event_ts.protectFormattedData(network_event_ts);
		}
		catch(CryptoException e){
			LOG.error(e.getMessage());
			LOG.error("Received Error for network_event_ts="+network_event_ts);
			throw e;
		}
	}
	public String getEncryptedImsi(String imsi) throws CryptoException{
		try{
		return this.imsi.protectFormattedData(imsi);
		}
		catch(CryptoException e){
			LOG.error(e.getMessage());
			LOG.error("Received Error for imsi="+imsi);
			throw e;
		}

	}
	public String getEncryptedImei(String imei) throws CryptoException{
		try{
		return this.imei.protectFormattedData(imei);
		}
		catch(CryptoException e){
			LOG.error(e.getMessage());
			LOG.error("Received Error for imei="+imei);
			throw e;
		}

	}
	public String getEncryptedLac(String lac) throws CryptoException{
		try{
		return this.lac.protectFormattedData(lac);
		}
		catch(CryptoException e){
			LOG.error(e.getMessage());
			LOG.error("Received Error for lac="+lac);
			throw e;
		}

	}
	public String getEncryptedRac(String rac) throws CryptoException{
		try{
		return this.rac.protectFormattedData(rac);
		}
		catch(CryptoException e){
			LOG.error(e.getMessage());
			LOG.error("Received Error for rac="+rac);
			throw e;
		}

	}
	public String getEncryptedTac(String tac) throws CryptoException{
		try{
		return this.tac.protectFormattedData(tac);
		}
		catch(CryptoException e){
			LOG.error(e.getMessage());
			LOG.error("Received Error for tac="+tac);
			throw e;
		}

	}
	public String getEncryptedCell(String cell) throws CryptoException{
		try{
		return this.cell.protectFormattedData(cell);
		}
		catch(CryptoException e){
			LOG.error(e.getMessage());
			LOG.error("Received Error for cell="+cell);
			throw e;
		}

	}
	public String getEncryptedAcceptEventDate(String accept_event_date) throws CryptoException{
		try{
		return this.accept_event_date.protectFormattedData(accept_event_date);
		}
		catch(CryptoException e){
			LOG.error(e.getMessage());
			LOG.error("Received Error for accept_event_date="+accept_event_date);
			throw e;
		}

	}
}
