package com.proximus.bigdata.osix.stormtopology;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;

import backtype.storm.generated.AuthorizationException;
import org.apache.storm.hdfs.bolt.HdfsBolt;
import org.apache.storm.hdfs.bolt.format.DefaultFileNameFormat;
import org.apache.storm.hdfs.bolt.format.DelimitedRecordFormat;
import org.apache.storm.hdfs.bolt.format.FileNameFormat;
import org.apache.storm.hdfs.bolt.format.RecordFormat;
import org.apache.storm.hdfs.bolt.format.DefaultSequenceFormat;
import org.apache.storm.hdfs.bolt.rotation.FileRotationPolicy;
import org.apache.storm.hdfs.bolt.rotation.FileSizeRotationPolicy;
import org.apache.storm.hdfs.bolt.rotation.FileSizeRotationPolicy.Units;
import org.apache.storm.hdfs.bolt.sync.CountSyncPolicy;
import org.apache.storm.hdfs.bolt.sync.SyncPolicy;
import org.apache.storm.hdfs.common.rotation.RotationAction;

import storm.kafka.BrokerHosts;

// depends on whether we want dynamic or static ...

import storm.kafka.ZkHosts;
import storm.kafka.KafkaSpout;
import storm.kafka.SpoutConfig;
import backtype.storm.Config;
import backtype.storm.StormSubmitter;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.topology.TopologyBuilder;


// import java.util.ImmutableList;
// from google guava

public class TopologyMain {

	public static void main(String[] args) throws AlreadyAliveException, InvalidTopologyException {
		// TODO Auto-generated method stub

 		if (args.length > 0) {
			System.out.println("Got args: " + Arrays.toString(args));
		}
		else {
			System.out.println("No Args specified. Please specify a properties file");
			System.exit(255);
		}

 		String propfilename = args[0]; // this should be a properties file
 		Properties props = new Properties();

 		try   {

 			TopologyBuilder tb = new TopologyBuilder();

			FileInputStream  infle = new FileInputStream(propfilename);
		    props.load(infle);

		    // check for a few properties we do absolutely need
		    // The kafka part in the config
		    String kafka_topic = props.getProperty("kafka.topic");
		    String kafka_zookeeper_consumer_offset_path = props.getProperty("kafka.zookeeper.consumer.offset.path","/osixkafka");
		    String kafka_zookeeper_consumer_offset_id = props.getProperty("kafka.zookeeper.consumer.offset.id","discovery");
		    String broker_hosts = props.getProperty("broker.hosts","localhost:2181");
		    String hdfs_url = props.getProperty("hdfs.url","hdfs://localhost:8020");
		    String storm_topology_name = props.getProperty("storm.topology.name","osix_kafka");
		    String kafka_spout_name = props.getProperty("kafka.spout.name","kafkareader");
		    String hdfs_bolt_name = props.getProperty("hdfs.bolt.name","hdfswriter");
		    String hdfs_path = props.getProperty("hdfs.build.path",props.getProperty("hdfs.path","/osix"));
		    String hdfs_prefix = props.getProperty("hdfs.file.prefix","osix");
		    String hdfs_extension = props.getProperty("hdfs.file.extension","txt");
		    String hdfs_noop = props.getProperty("hdfs.noop","false");
		    boolean hnoop = false;
		    if (hdfs_noop.equalsIgnoreCase("true")) {
		    	hnoop = true;
		    }
		    else {
		    	hnoop = false;
		    }

	 		SpoutConfig spc = new SpoutConfig(new ZkHosts(broker_hosts)
			        ,kafka_topic // topic
					,kafka_zookeeper_consumer_offset_path      // root path in zookeeper for the spout to store consumer offsets
					,kafka_zookeeper_consumer_offset_id   // id for storing consumer offsets in zookeeper
					);

			KafkaSpout kfksp = new KafkaSpout(spc);

		    FileRotationPolicy rotationPolicy = new FileSizeRotationPolicy(127.0f, Units.MB);
			FileNameFormat fnformat = new DefaultFileNameFormat().withPath(hdfs_path).withPrefix(hdfs_prefix).withExtension(hdfs_extension);
			SyncPolicy syncPolicy = new CountSyncPolicy(1000);
			RecordFormat rformat = new DelimitedRecordFormat().withFieldDelimiter("|");
			RotationAction rac = new FileMoverRotationAction(props);



			OSIXRawHDFSBolt hdfs = new OSIXRawHDFSBolt()
				.withFsUrl(hdfs_url)
				.withFileNameFormat(fnformat)
				.withRecordFormat(rformat)
				.withRotationPolicy(rotationPolicy)
				.withSyncPolicy(syncPolicy)
				.addRotationAction(rac);


			NoOpBolt hdfs2 = new NoOpBolt();

			// Avoid some warnings
			if(hdfs2 != null && hdfs != null) {}

			tb.setSpout(kafka_spout_name, kfksp);
			if (hnoop) {
				tb.setBolt(hdfs_bolt_name,hdfs2).shuffleGrouping(kafka_spout_name);
			}
			else {
				tb.setBolt(hdfs_bolt_name,hdfs).shuffleGrouping(kafka_spout_name);
			}

			Config conf = new Config(); // this is a config that should contain the deployment crap

			//StormSubmitter.LOG.info("Submitting topology " + storm_topology_name);
			// Stormsubmitter
            try {
                StormSubmitter.submitTopology(storm_topology_name,conf, tb.createTopology());
            } catch (AuthorizationException e) {
                e.printStackTrace();
            }

        }
 		catch (FileNotFoundException e) {
 			System.out.println("The specified file " + propfilename + " does not exist");
 			System.exit(255);
 		}
 		catch (IOException e) {
 			System.out.println("An IO Exception Occurred: " + e.getMessage());
 			System.exit(255);
 		}
	}
}
